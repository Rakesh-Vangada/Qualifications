#--Script Name: CAGG_File_Check.sh
#--Date       : 27-Oct-2016
#--Author     : Rakesh Kumar
#--Category   : Shell Script
#--Impact to Reports : No
#--Impact to Infomanager: No
#--Description : This Script is used to monitor the files sent to CAGG/EDM/ODS Team.
#-------------------------------------------------------------------------------------------------------------

countryCodePassed="$2"
dateLen=${#datePassed}

countryCodePassedLen=${#countryCodePassed}

if [[ $countryCodePassedLen -ge 2 && $countryCodePassedLen -lt 3 ]] ; then
	COUNTRY_LIST=$countryCodePassed
else
	COUNTRY_LIST="AE AO BD BH BW CI CM CN GB GH GM HK ID IN IQ JO JP KE LK MO MU MY MZ NG NP OM PH PK QA SG SL TH TW TZ UG US VN ZA ZM ZW"
fi

d=`date +%Y%m%d`
file="$d"

#CAGG Filename check Function
run_CAGG_Filename_check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/batch/download/cagg/history"
countryCodesIdentified=""
countryCodesNotIdentified=""

for fileName in "$DIR"/*"$file"*
do
    if [ -f "$fileName" ]; then
	fName=$(basename $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		countryCode=`expr ${fName:0:2}`
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentified" != *"$countryCode"* ]] ; then
				countryCodesIdentified="$countryCodesIdentified $countryCode"
			fi
		fi
	fi
    fi
done

echo "CAGG File Name OK for ::: $countryCodesIdentified"

for country in `echo $COUNTRY_LIST`
do
        if [[ "$countryCodesIdentified" != *"$country"* ]] ; then
                countryCodesNotIdentified="$countryCodesNotIdentified $country"
        fi
done

echo "CAGG File Name NOT OK for ::: $countryCodesNotIdentified"
}


#CAGG FTFID check Function
run_CAGG_FTFID_Check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedFTFID=""
countryCodesNotIdentifiedFTFID=""

for fileName in "$DIR"/*_"$file"_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedFTFID="$countryCodesIdentifiedFTFID $countryCode"
			fi
		fi
	fi
    fi
done

echo "Country IdentifiedFTFID ::: $countryCodesIdentifiedFTFID"

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedFTFID="$countryCodesNotIdentifiedFTFID $country"
	fi
done
echo "Country Not IdentifiedFTFID ::: $countryCodesNotIdentifiedFTFID"
}

#EDM_Master File name check Function
run_EDM_Master_Filename_check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/batch/upload/edmmst/history"
countryCodesIdentified=""
countryCodesNotIdentified=""

for fileName in "$DIR"/*"$file"*
do
    if [ -f "$fileName" ]; then
	fName=$(basename $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		countryCode=`expr ${fName:0:2}`
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentified" != *"$countryCode"* ]] ; then
				countryCodesIdentified="$countryCodesIdentified $countryCode"
			fi
		fi
	fi
    fi
done

echo "EDM Master File Name OK for ::: $countryCodesIdentified"

for country in `echo $COUNTRY_LIST`
do
        if [[ "$countryCodesIdentified" != *"$country"* ]] ; then
                countryCodesNotIdentified="$countryCodesNotIdentified $country"
        fi
done

echo "EDM Master File Name NOT OK for ::: $countryCodesNotIdentified"
}

#EDM Master FTFID check Function
run_EDM_Master_FTFID_check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedEDMMFTFID=""
countryCodesNotIdentifiedEDMMFTFID=""

for fileName in "$DIR"/*_"$file"_EDM_MASTER_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedEDMMFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedEDMMFTFID="$countryCodesIdentifiedEDMMFTFID $countryCode"
			fi
		fi
	fi
    fi
done

echo "Country IdentifiedEDMMFTFID ::: $countryCodesIdentifiedEDMMFTFID"

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedEDMMFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedEDMMFTFID="$countryCodesNotIdentifiedEDMMFTFID $country"
	fi
done

echo "Country Not IdentifiedEDMMFTFID ::: $countryCodesNotIdentifiedEDMMFTFID"
}

#EDM_Exception File name check Function
run_EDM_Exception_Filename_check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/batch/upload/edmexc/history"
countryCodesIdentified=""
countryCodesNotIdentified=""

for fileName in "$DIR"/*"$file"*
do
    if [ -f "$fileName" ]; then
	fName=$(basename $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		countryCode=`expr ${fName:0:2}`
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentified" != *"$countryCode"* ]] ; then
				countryCodesIdentified="$countryCodesIdentified $countryCode"
			fi
		fi
	fi
    fi
done

echo "EDM Exception File Name OK for ::: $countryCodesIdentified"

for country in `echo $COUNTRY_LIST`
do
        if [[ "$countryCodesIdentified" != *"$country"* ]] ; then
                countryCodesNotIdentified="$countryCodesNotIdentified $country"
        fi
done

echo "EDM Exception File Name NOT OK for ::: $countryCodesNotIdentified"
}

#EDM Exception FTFID check function
run_EDM_Exception_FTFID_check()
{
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedEDMEFTFID=""
countryCodesNotIdentifiedEDMEFTFID=""

#echo "DIR ::: $DIR"
#echo "Date ::: $file"
#echo "$DIR"/*_"$file"_EDM_EXCPN_FTFID.log

for fileName in "$DIR"/*_"$file"_EDM_EXCPN_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedEDMEFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedEDMEFTFID="$countryCodesIdentifiedEDMEFTFID $countryCode"
			fi
		fi
	fi
    fi
done
echo "Country IdentifiedEDMEFTFID ::: $countryCodesIdentifiedEDMEFTFID"

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedEDMEFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedEDMEFTFID="$countryCodesNotIdentifiedEDMEFTFID $country"
	fi
done
echo "Country Not IdentifiedEDMEFTFID ::: $countryCodesNotIdentifiedEDMEFTFID"
}

#echo "CAGG Filename check"
run_CAGG_Filename_check
#echo "CAGG filename check completed"

#echo "CAGG FTFID check"
run_CAGG_FTFID_Check
#echo "CAGG FTFID check completed"

#echo "EDM_Master_Filename_check"
run_EDM_Master_Filename_check
#echo "EDM_Master_Filename_check completed"

#echo "EDM_Master_FTFID"
run_EDM_Master_FTFID_check
#echo "EDM_Master_FTFID completed"

#echo "EDM_Exception_Filename_check"
run_EDM_Exception_Filename_check
#echo "EDM_Exception_Filename_check completed"

#echo "EDM_Exception_FTFID"
run_EDM_Exception_FTFID_check
#echo "EDM_Exception_FTFID completed"


