#!/bin/ksh
echo "Running Environment Script"
sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh SG

echo "Sourcing Profile"
. /prd/cocoa/hk/bin/scripts/profile/SG.profile

jname=PCOCOSG220D
export PGM_NAME="COCOATHOMSONREUTERSFILESUPLOAD.sh"
echo =======================================================================  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

/usr/bin/scp askadm@10.20.223.169:/prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/results/*.xml /prd/cocoa/batch/upload/tr/ 
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

export TR_UPLOAD=/prd/cocoa/batch/upload/tr
export TR_INCOMING=/prd/cocoa/batch/upload/tr/
export tracktime=`date '+%Y%m%d%H%M%S'`
export BUSINESS_DATE=`date '+%d%m%Y'`
export RECEIVEDTIME=`date '+%H%M%S'`
echo $BUSINESS_DATE
export NEW_RMDS_FILE_NAME=RMDS-$BUSINESS_DATE
export NEW_DWE_MB_FILE_NAME=DWE_MB-$BUSINESS_DATE
export NEW_DWE_PL_FILE_NAME=DWE_PL-$BUSINESS_DATE
#export NEW_DWE_FILE_NAME=DWE-$BUSINESS_DATE-$RECEIVEDTIME-SG.xml
export NEW_DSS_COM_FILE_NAME=DSS_C-$BUSINESS_DATE
export NEW_DSS_DERV_FILE_NAME=DSS_D-$BUSINESS_DATE
export NEW_DSS_COM_MCI_FILE_NAME=DSSMCI_C-$BUSINESS_DATE
export NEW_DSS_DERV_MCI_FILE_NAME=DSSMCI_D-$BUSINESS_DATE
export NEW_DSS_DERV_NCX_FILE_NAME=DSSNCX_D-$BUSINESS_DATE



# this is for data stream public ledger
if [ `find $TR_UPLOAD/*Datastream-PublicLedger*.xml  -type f` ]; then
cd $TR_UPLOAD
export  RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datastream/cca-tr-datastream-incoming
mv $TR_UPLOAD/*Datastream-PublicLedger*.xml $TR_INCOMING/tr-datastream/cca-tr-datastream-incoming/$NEW_DWE_PL_FILE_NAME-$RECEIVEDTIME-SG.xml
sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASTREAM PUBLIC LEDGER FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASTREAM PUBLIC LEDGER file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for data stream metal Bulletin
if [ `find $TR_UPLOAD/*Datastream-MetalBulletin*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datastream/cca-tr-datastream-incoming
mv $TR_UPLOAD/*Datastream-MetalBulletin*.xml $TR_INCOMING/tr-datastream/cca-tr-datastream-incoming/$NEW_DWE_MB_FILE_NAME-$RECEIVEDTIME-SG.xml
# this is last file in its category , so doesn't need to wait long
sleep 60;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASTREAM PUBLIC LEDGER FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASTREAM PUBLIC LEDGER file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi






# this is for DSS MCI and NCX commodity 
if [ `find $TR_UPLOAD/*DSS-MCI-NCX-Commodity*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-MCI-NCX-Commodity*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_COM_MCI_FILE_NAME-$RECEIVEDTIME-SG.xml
# small file , so giving it 180 sec
sleep 180;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE MCI NCX COMMODITY FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE MCI NCX COMMODITY file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for DSS NCX Derivaties 
if [ `find $TR_UPLOAD/*DSS-NCX-Derivative*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-NCX-Derivative*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_DERV_NCX_FILE_NAME-$RECEIVEDTIME-SG.xml
sleep 180;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE  NCX DERIVATE FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE  NCX DERIVATE file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi



# this is for DSS MCI derivate 
if [ `find $TR_UPLOAD/*DSS-MCI-Derivative*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-MCI-Derivative*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_DERV_MCI_FILE_NAME-$RECEIVEDTIME-SG.xml
sleep 120;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE MCI DERIVATE FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE MCI DERIVATE file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi



# this is for DSS derivate 
if [ `find $TR_UPLOAD/*DSS-Derivative*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-Derivative*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_DERV_FILE_NAME-$RECEIVEDTIME-SG.xml
sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE DERIVATE FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE DERIVATE file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi



# this is for DSS commodity 
echo "checking for DSS_Commodity" >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo "checking for DSS_Commodity ABC-" $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
#if [ -s /prd/cocoa/batch/upload/tr/DSS-Commodity*.xml ]; then
if [ -s $TR_UPLOAD/*DSS-Commodity*.xml ]; then
echo  "Entering into the if condition for DSS-Commodity"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-Commodity*.xml $TR_UPLOAD/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_COM_FILE_NAME-$RECEIVEDTIME-SG.xml
echo "Files moved to cca-tr-datascope-incoming folder"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
#sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE COMMODITY FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE COMMODITY file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for RMDS
if [ `find $TR_UPLOAD/*RMDS*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#/tr-rmds/cca-tr-rmds-incoming/
mv $TR_UPLOAD/*RMDS*.xml $TR_INCOMING/tr-rmds/cca-tr-rmds-incoming/$NEW_RMDS_FILE_NAME-$RECEIVEDTIME-SG.xml
#sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  RMDS FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No RMDS file Available for SG. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi

ssh askadm@10.20.223.169 'mv /prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/results/*.xml /prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/processed-results/'

#RIC code  started
echo "RIC code started"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

echo "Running Request generation"
LOCAL_REQUEST_DIR=/prd/cocoa/batch/TR/tr-temp_req/
REMOTE_PENDING_DIR=/prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/pending-requests/
REMOTE_NEW_DIR=/prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/new-requests/
REMOTE_ARCHIVE=/prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/request-archive/
DUMMY_FILE_FROM=/prd/cocoa/batch/TR/
DUMMY_FILE_TO=/prd/cocoa/batch/upload/tr/tr-request/cca-tr-request-incoming/

# first clean and trigger the request generation process

rm -r $LOCAL_REQUEST_DIR/*.xml;
cp $DUMMY_FILE_FROM/TR_DUMMY_FILE-01012013-1-SG.dat $DUMMY_FILE_TO;

# sleep for 5 min
sleep 300;

# for Each request file generated , upload them to ASK

for file in $LOCAL_REQUEST_DIR/*.xml
do
echo "file name=$file"
newName=`echo "$file"| grep -o 'REQUEST.*.xml'|cut -d_ -f1` 
echo "$newName"

if [ `ssh askadm@10.20.223.169 "find $REMOTE_PENDING_DIR/$newName*.xml -type f"` ]; then
echo "found"
ssh askadm@10.20.223.169 "mv $REMOTE_PENDING_DIR/$newName*.xml $REMOTE_ARCHIVE"
else
echo "notfound"
fi
echo "uploading the file $file to remote server $REMOTE_NEW_DIR"
scp $file askadm@10.20.223.169:$REMOTE_NEW_DIR
done
echo "RIC code ended"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

#15-Aug-2016 COCOA-1531(Price Variation Performance issue):Add script to run procedure--Added By Rakesh
run_sql()
{
  sqlplus -S ${PRM_CONNECT_STRING} <<EOF
  SET PAGESIZE 0;
  SET FEEDBACK OFF;
  SET SERVEROUT ON;
  VAR RET_CODE NUMBER;
  EXEC SCBP_P_RPT_PRICE_VAR_CHECK(NULL);
  EXIT;
EOF
echo "Price Variance Procedure is successful--inside function"

}

echo "going to call the Price Variance procedure"
run_sql
echo "Price Variance Procedure is successful--Function exited"

#04-Oct-2016 MTO[Adding the housekeeping Scripts for PG1094]--Added by Rakesh
echo "Housekeeping Initiated for PG1094 ASKADM"
ssh askadm@10.20.223.169 "find /prd/cocoa/tr/askapp/Cocoa_1.1.5/var/log/ -name "ask.*.log" -mmin +60 | xargs gzip"
ssh askadm@10.20.223.169 "find /prd/cocoa/tr/askapp/Cocoa_1.1.5/work/xml-oa/processed-results/ -name "*.xml"  -mmin +60 | xargs gzip"
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  Housekeeoing intitiated $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
echo "Housekeeping completed"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

