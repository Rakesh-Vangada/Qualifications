#!/bin/ksh
echo "Running Environment Script"
sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh $1

echo "Sourcing Profile"
. /prd/cocoa/hk/bin/scripts/profile/$1.profile

jname=PCOCO"$1"220D
export PGM_NAME="COCOATHOMSONREUTERSFILESUPLOAD.sh"
echo =======================================================================  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

/usr/bin/scp askadm@10.20.223.169:/prd/cocoa/tr/askapp/Cocoa_1.1.4/work/xml-oa/results/*.xml /prd/cocoa/batch/upload/tr/ 

export TR_UPLOAD=/prd/cocoa/batch/upload/tr
export TR_INCOMING=/prd/cocoa/batch/upload/tr/
export tracktime=`date '+%Y%m%d%H%M%S'`
export BUSINESS_DATE=`date '+%d%m%Y'`
export RECEIVEDTIME=`date '+%H%M%S'`
echo $BUSINESS_DATE
export NEW_RMDS_FILE_NAME=RMDS-$BUSINESS_DATE
export NEW_DWE_MB_FILE_NAME=DWE_MB-$BUSINESS_DATE
export NEW_DWE_PL_FILE_NAME=DWE_PL-$BUSINESS_DATE
#export NEW_DWE_FILE_NAME=DWE-$BUSINESS_DATE-$RECEIVEDTIME-$1.xml
export NEW_DSS_COM_FILE_NAME=DSS_C-$BUSINESS_DATE
export NEW_DSS_DERV_FILE_NAME=DSS_D-$BUSINESS_DATE
export NEW_DSS_COM_MCI_FILE_NAME=DSSMCI_C-$BUSINESS_DATE
export NEW_DSS_DERV_MCI_FILE_NAME=DSSMCI_D-$BUSINESS_DATE



# this is for data stream public ledger
if [ `find $TR_UPLOAD/*Datastream-PublicLedger*.xml  -type f` ]; then
cd $TR_UPLOAD
export  RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datastream/cca-tr-datastream-incoming
mv $TR_UPLOAD/*Datastream-PublicLedger*.xml $TR_INCOMING/tr-datastream/cca-tr-datastream-incoming/$NEW_DWE_PL_FILE_NAME-$RECEIVEDTIME-$1.xml
sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASTREAM PUBLIC LEDGER FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASTREAM PUBLIC LEDGER file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for data stream metal Bulletin
if [ `find $TR_UPLOAD/*Datastream-MetalBulletin*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datastream/cca-tr-datastream-incoming
mv $TR_UPLOAD/*Datastream-MetalBulletin*.xml $TR_INCOMING/tr-datastream/cca-tr-datastream-incoming/$NEW_DWE_MB_FILE_NAME-$RECEIVEDTIME-$1.xml
# this is last file in its category , so doesn't need to wait long
sleep 60;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASTREAM PUBLIC LEDGER FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASTREAM PUBLIC LEDGER file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi






# this is for DSS MCI and NCX commodity 
if [ `find $TR_UPLOAD/*DSS-MCI-NCX-Commodity*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-MCI-NCX-Commodity*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_COM_MCI_FILE_NAME-$RECEIVEDTIME-$1.xml
# small file , so giving it 180 sec
sleep 180;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE MCI NCX COMMODITY FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE MCI NCX COMMODITY file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for DSS MCI derivate 
if [ `find $TR_UPLOAD/*DSS-MCI-Derivative*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-MCI-Derivative*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_DERV_MCI_FILE_NAME-$RECEIVEDTIME-$1.xml
sleep 120;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE MCI DERIVATE FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE MCI DERIVATE file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi



# this is for DSS derivate 
if [ `find $TR_UPLOAD/*DSS-Derivative*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-Derivative*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_DERV_FILE_NAME-$RECEIVEDTIME-$1.xml
sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE DERIVATE FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE DERIVATE file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi



# this is for DSS commodity 
if [ `find $TR_UPLOAD/*DSS-Commodity*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#tr-datascope/cca-tr-datascope-incoming/
mv $TR_UPLOAD/*DSS-Commodity*.xml  $TR_INCOMING/tr-datascope/cca-tr-datascope-incoming/$NEW_DSS_COM_FILE_NAME-$RECEIVEDTIME-$1.xml
#sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  DATASCOPE COMMODITY FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No DATASCOPE COMMODITY file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi


# this is for RMDS
if [ `find $TR_UPLOAD/*RMDS*.xml  -type f` ]; then
cd $TR_UPLOAD
export RECEIVEDTIME=`date '+%H%M%S'`
echo $RECEIVEDTIME
#/tr-rmds/cca-tr-rmds-incoming/
mv $TR_UPLOAD/*RMDS*.xml $TR_INCOMING/tr-rmds/cca-tr-rmds-incoming/$NEW_RMDS_FILE_NAME-$RECEIVEDTIME-$1.xml
#sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  RMDS FILE COPIED  SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
else
echo "No RMDS file Available for $1. Please check the upload path $TR_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
fi

ssh askadm@10.20.223.169 'mv /prd/cocoa/tr/askapp/Cocoa_1.1.4/work/xml-oa/results/*.xml /prd/cocoa/tr/askapp/Cocoa_1.1.4/work/xml-oa/processed-results/'
