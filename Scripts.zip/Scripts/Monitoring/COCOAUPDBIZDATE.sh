#####################################################################
# Purpose : Business Date Update 
# ------------------------------------------------------------------
# Date         Author        Description
# 26-Sep-2011  Nadeem        Included the batch stat script#
#
# Change History
# ---------------- 
# Script Written by: Rakesh Kumar
# Script date: 28-Sep-2016
# Description: Scripts for Automated Housekeeping Added
# Search String: Scripts for Automated Housekeeping Added
#####################################################################
#!/bin/ksh

get_tbucode()
{
sqlplus -s ${PRM_CONNECT_STRING}<<!EOF>/dev/null
set head off;
set pages 0;
set feedback off;
spool ${TBU_LIST}
select tbu_code from scbt_r_tbu_mst where cty_code='${CTY_CODE}' and rownum=1;
spool off;
quit;
!EOF
}

load_od() 
{
   echo "Business Date Update"
   for i in `cat ${TBU_LIST}.lst`
   do
      export TBU_CODE=$i
   done
   CLASSPATH=$OAF_BATCH_CP
   CLASSPATH=$CLASSPATH:$APPL_CONFIG
   echo "Business Date Update For ${CTY_CODE} ${TBU_CODE}..."
   echo "Classpath: ${CLASSPATH}" 
   $JAVA_HOME/java -cp $CLASSPATH com.scb.client.batch.SCBBatchEODClient SCB ${CTY_CODE} ${TBU_CODE} UPDBIZDATE
   export ret=$?
   echo "Returning value........${ret}"
}

echo "Running Environment Script"
sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh $1

echo "Sourcing Profile"
. /prd/cocoa/hk/bin/scripts/profile/$1.profile

jname=PCOCO"$1"190D
export PGM_NAME="COCOAUPDBIZDATE.sh"
echo =======================================================================  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL R

echo "Getting TBU List"
TBU_LIST=${APPL_LOG}/${CTY_CODE}_TBUCODE$$
get_tbucode

echo "Business Date Update Process"
load_od

echo "Exit script with status ${ret}"

echo  ${PGM_NAME} ENDED SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

# Scripts for Automated Housekeeping Added

if [ $1 = "SG" ] || [ $1 = "AE" ] || [ $1 = "IN" ] || [ $1 = "NG" ] || [ $1 = "MY" ] || [ $1 = "US" ]  || [ $1 = "OM" ]; then
echo "Housekeeping Initiated"

find /prd/cocoa/batch/upload/mds/bloomberg/history -name "CCA_MDS_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/mds/bloomberg/history -type f -mtime +10 | xargs rm
find /prd/cocoa/batch/upload/hogan/history -name "CCA_ACCT_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/caggbasel/error/error -name "CCA_BASEL_GLOBAL*err" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/caggbasel/error/error -name "CCA_BASEL_GLOBAL*dup" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/caggbasel/history -name "CCA_BASEL_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tprecon/OTP/history -name "CCA_OTP_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tprecon/DTP/history -name "CCA_DTP_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tr/tr-rmds/cca-tr-rmds-history -name "RMDS*-SG.xml" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tr/tr-rmds/cca-tr-rmds-history -type f -mtime +10 | xargs rm
find /prd/cocoa/batch/upload/tr/tr-datascope/cca-tr-datascope-history -name "DSS*-SG.xml" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tr/tr-datascope/cca-tr-datascope-history -type f -mtime +10 | xargs rm 
find /prd/cocoa/batch/upload/tr/tr-datastream/cca-tr-datastream-history -name "DWE*-SG.xml" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/tr/tr-datastream/cca-tr-datastream-history -type f -mtime +10 | xargs rm
find /prd/cocoa/batch/upload/ebbs/grec/history -name "CCA_ACCT_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/ebbs/xml/history -name "BK_DEP*.TXT" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/ebbs/xml/history -name "BK_BAL*.TXT" -mmin +60 | xargs gzip
#find /prd/cocoa/batch/upload/edmexc/history -name "*CCA_EXCPN*_D_1.dat" -mmin +60 | xargs gzip
#find /prd/cocoa/batch/upload/edmmst/history -name "*CCA_MASTER*_D_1.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/acbs/history -name "CCA_ACBS_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/ods/history -name "CCA_ODS_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/upload/mrs/history -name "CCA_MRS_GLOBAL*.dat" -mmin +60 | xargs gzip
find /prd/cocoa/batch/download/cagg/history -name "*CCA_COLT *.dat" -mmin +60 | xargs gzip

export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} ENDED SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

echo "Housekeeping completed"
fi



if [ "$ret" == "0" ]; then
#new script added for 11G report schedule process.
sh /prd/cocoa/hk/bin/scripts/COCONQFLAGUP.sh ${CTY_CODE}
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} ENDED SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL S
else
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} ENDED FAILED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL F
fi


exit $ret
