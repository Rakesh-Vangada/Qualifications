#--Script Name: Health_Check.sh
#--Date       : 14-Sep-2017
#--Author     : Rakesh Kumar
#--Category   : Shell Script
#--Root Cause Fixed  :
#--Impact to Reports : No
#--Impact to Infomanager: No
#--Description : This Script is used to perform health check on WAAS servers
#--------------------------------------------------------------------------------------------------

echo "Checking Instances on 2A"
date ; ps -ef|grep java|grep 'PRD_WAAS_RTP'| awk {'print  $1 "|" $NF'}|sort|uniq;

ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP05B/PRD_WAAS_RTP_ITP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE05B| grep SystemOut.log| awk '{ print "LogCheck: ITP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP05B/PRD_WAAS_RTP_IWS_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE05B| grep SystemOut.log| awk '{ print "LogCheck: IWS instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP05B/PRD_WAAS_RTP_BAT_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE05B| grep SystemOut.log| awk '{ print "LogCheck: BAT instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP05B/PRD_WAAS_RTP_REP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE05B| grep SystemOut.log| awk '{ print "LogCheck: REP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p

echo "Checking Instances on 3A"
date ; ps -ef|grep java|grep 'PRD_WAAS_RTP'| awk {'print  $1 "|" $NF'}|sort|uniq;

ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP07B/PRD_WAAS_RTP_ITP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE07B| grep SystemOut.log| awk '{ print "LogCheck: ITP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP07B/PRD_WAAS_RTP_IWS_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE07B| grep SystemOut.log| awk '{ print "LogCheck: IWS instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP07B/PRD_WAAS_RTP_BAT_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE07B| grep SystemOut.log| awk '{ print "LogCheck: BAT instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP07B/PRD_WAAS_RTP_REP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE07B| grep SystemOut.log| awk '{ print "LogCheck: REP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p


echo "Checking Instances on 2B"
date ; ps -ef|grep java|grep 'PRD_WAAS_RTP'| awk {'print  $1 "|" $NF'}|sort|uniq;


ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP06B/PRD_WAAS_RTP_ITP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE06B| grep SystemOut.log| awk '{ print "LogCheck: ITP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP06B/PRD_WAAS_RTP_IWS_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE06B| grep SystemOut.log| awk '{ print "LogCheck: IWS instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP06B/PRD_WAAS_RTP_BAT_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE06B| grep SystemOut.log| awk '{ print "LogCheck: BAT instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP06B/PRD_WAAS_RTP_REP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE06B| grep SystemOut.log| awk '{ print "LogCheck: REP instance SystemOut.log Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p


echo "Checking Instances on 3B"
date ; ps -ef|grep java|grep 'PRD_WAAS_RTP'| awk {'print  $1 "|" $NF'}|sort|uniq;

Log Check:                                                                                                  
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP08B/PRD_WAAS_RTP_ITP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE08B| grep SystemOut.log| awk '{ print "LogCheck: ITP instance SystemOut.log Sysout Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP08B/PRD_WAAS_RTP_IWS_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE08B| grep SystemOut.log| awk '{ print "LogCheck: IWS instance SystemOut.log Sysout Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP08B/PRD_WAAS_RTP_BAT_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE08B| grep SystemOut.log| awk '{ print "LogCheck: BAT instance SystemOut.log Sysout Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
ls -lrt /IBM/websphere/support/logs/PRD_WAAS_OTPTRADE_HK_APP08B/PRD_WAAS_RTP_REP_APP_HK_DC_PRD_WAAS_OTPTRADE_APP_NODE08B| grep SystemOut.log| awk '{ print "LogCheck: REP instance SystemOut.log Sysout Last_update_Timestamp " $6$7 " " $8}'| sed -n 2p
