#This will ZIP the files older than 1 days
for i in `find /apps/jboss/support/logs/ -type f -name "*.log.*" -a -not -name "*.bz2" -a -not -name "*.gz" -mmin +120 -print`
do
gzip $i
done

for i in `find /apps/jboss/support/logs/ -type f -name *.txt -mmin +720 -print`
do
gzip $i
done

#This will remove the files with is older thaan 10 days.
for i in `find /apps/jboss/support/logs/ -type f -name "*.log.*" -mtime +10 -print`
do
rm $i
done

for i in `find /apps/jboss/support/logs/ -type f -name *.txt*.gz -mtime +10 -print`
do
rm $i
done

find /apps/jboss/servers/request_response/shared/edmi/response_processed -type f -name "*.xml" -mtime +10 -exec rm {} \;
find /apps/jboss/servers/request_response/shared/edmi/request_processed -type f -name "*.xml" -mtime +10 -exec rm {} \;


> /apps/jboss/servers/msg_tracker/logs/logstash/msg_tracker_logstash.log
