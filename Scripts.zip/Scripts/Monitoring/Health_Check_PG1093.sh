#--Script Name: Health_Check_PG1093.sh
#--Date       : 14-Sep-2017
#--Author     : Rakesh Kumar
#--Category   : Shell Script
#--Root Cause Fixed  :
#--Impact to Reports : No
#--Impact to Infomanager: No
#--Description : This Script is used to perform health check on WAAS servers
#--------------------------------------------------------------------------------------------------

echo "Checking Instance on PG1093"
date ; ps -ef|grep java|grep Dwas|grep -v grep|awk {'print  $1 "|" $NF'}|sort|uniq; 

