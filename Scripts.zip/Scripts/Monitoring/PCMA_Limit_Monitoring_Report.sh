#####################################################################
# Purpose : Automation of the month end reports
# Script Name: inventory_download.sh
# Job Name: PCOCOGB350D
# ---------------------------------------------------------------
# Change History
# --------------------
# Script Written by: Rakesh Kumar
# Script date: 01-Feb-2017
# Change: CRQ000000376012 
# Description: PCMA_Limit_Monitoring_Report
# Search String: PCMA_Limit_Monitoring_Report
#
# Change on derivation of previous date
# Script change: 02-Aug-2017
# Search String: Derivation of previous date
#####################################################################

#!/bin/ksh
echo "Running Environment Script"
#sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh $1
sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh SG


echo "Sourcing Profile"
#. /prd/cocoa/hk/bin/scripts/profile/$1.profile
. /prd/cocoa/hk/bin/scripts/profile/SG.profile

echo "Profile setted up"

#Initialize the value for the batch stat
#jname=PCOCO"$1"350D
jname=PCOCOGB350D
export PGM_NAME="PCMA_Limit_Monitoring_Report.sh"
echo =======================================================================  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
#Con=/obiee11g/prd/cocoa/hk/bin/scripts/config/$1/JOBLIST.cfg


export LOG_PATH=$APPL_LOG
export today=`date '+%y%m%d_%H%M'`
export LOG_FILE=${LOG_PATH}/${CTY_CODE}_${logdate}.log
export APPL_SCRIPTS=/prd/cocoa/hk/bin/scripts/
#export UPLOAD_PATH="/prd/obiee/OracleBI/ReportsHistory/${CTY_CODE}/"
export tracktime=`date '+%Y%m%d'`
export dt=${BUS_DATE}

#Derivation of previous date Starts
d=$(date +%d_%b_%Y --date="yesterday") 
echo $d
#Derivation of previous date Ends

sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh GB $jname $PGM_NAME $tracktime NULL R

echo  ${PGM_NAME} RUNNING AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log

ssh obiee11g@10.20.223.140 mkdir -p /prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown/

echo "Generating SIPALL Report"
sqlplus -s /nolog <<!EOF
connect $PRM_CONNECT_STRING
SET MARKUP HTML ON ENTMAP ON SPOOL ON PREFORMAT OFF ;
SPOOL /tmp/SIPALL_Report.xls
@${APPL_SCRIPTS}/Month_End_Report_Generation/SIPALL.sql;
SPOOL OFF
exit
!EOF

sleep 60

rsync --chmod=u+rwx,g+rwx,o+rwx /tmp/SIPALL_Report* obiee11g@10.20.223.140:/prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown

echo "Generating Exchange_Approved_Location_with_Commodity Report"
sqlplus -s /nolog <<!EOF
connect $PRM_CONNECT_STRING
SET MARKUP HTML ON ENTMAP ON SPOOL ON PREFORMAT OFF ;
SPOOL /tmp/Exchange_Approved_Location_with_Commodity_Report.xls
@${APPL_SCRIPTS}/Month_End_Report_Generation/Exchange_Approved_Location_with_Commodity.sql;
SPOOL OFF
exit
!EOF

sleep 60
rsync --chmod=u+rwx,g+rwx,o+rwx /tmp/Exchange_Approved_Location_with_Commodity_Report* obiee11g@10.20.223.140:/prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown

echo "Generating Exchange_Approved_Brand Report"
sqlplus -s /nolog <<!EOF
connect $PRM_CONNECT_STRING
SET MARKUP HTML ON ENTMAP ON SPOOL ON PREFORMAT OFF ;
SPOOL /tmp/Exchange_Approved_Brand_Report.xls
@${APPL_SCRIPTS}/Month_End_Report_Generation/Exchange_Approved_Brand.sql;
SPOOL OFF
exit
!EOF

sleep 60
rsync --chmod=u+rwx,g+rwx,o+rwx /tmp/Exchange_Approved_Brand_Report* obiee11g@10.20.223.140:/prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown

echo "Generating Active_Storage_Locations Report"
sqlplus -s /nolog <<!EOF
connect $PRM_CONNECT_STRING
SET MARKUP HTML ON ENTMAP ON SPOOL ON PREFORMAT OFF ;
SPOOL /tmp/Active_Storage_Locations_Report.xls
@${APPL_SCRIPTS}/Month_End_Report_Generation/Active_Storage_Locations.sql;
SPOOL OFF
exit
!EOF

sleep 60
rsync --chmod=u+rwx,g+rwx,o+rwx /tmp/Active_Storage_Locations_Report* obiee11g@10.20.223.140:/prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown


echo "Generating Exchange_Approved_Location Report"
sqlplus -s /nolog <<!EOF
connect $PRM_CONNECT_STRING
SET MARKUP HTML ON ENTMAP ON SPOOL ON PREFORMAT OFF ;
SPOOL /tmp/Exchange_Approved_Location_Report.xls
@${APPL_SCRIPTS}/Month_End_Report_Generation/Exchange_Approved_Location.sql;
SPOOL OFF
exit
!EOF

sleep 60
rsync --chmod=u+rwx,g+rwx,o+rwx /tmp/Exchange_Approved_Location_Report* obiee11g@10.20.223.140:/prd/obiee/OracleBI/ReportsHistory/GLOBAL/HUB_ALL/PCMA_Limit_Monitoring_Report/$d/Drilldown


export ret=$?
export tracktime=`date '+%Y%m%d%H%M%S'`
if [ "$ret" == "0" ]; then
        #sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL S
        sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh SG $jname $PGM_NAME $tracktime NULL S
	echo  ${PGM_NAME} ENDED SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
       exit 0
else
        #sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL F
	sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh SG $jname $PGM_NAME $tracktime NULL F
        echo  ${PGM_NAME} ENDED FAILED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
        exit 1
fi

