#####################################################################
#script Name: HOUSEKEEP.sh
#Purpose: Housekeeping Script for PG543 /obiee11g Filesystem
#Script Written by: Rakesh Kumar
#Script date: 30-Aug-2016

# Change History
# Date:30-Aug-2016
# Description: Script for Automated Housekeeping on PG543
#####################################################################


echo "Housekeeping /obiee11g/tmp folder"


find /obiee11g/tmp -type f -name "MIME*" -mtime +1 | xargs rm
find /obiee11g/tmp -type f -name "saw*" -mtime +1 | xargs rm
find /obiee11g/product/instances/instance1 -type d -name "core*" -mtime +5 | xargs rm -rf

echo "Housekeeping the /var folder"
USED=`df -kh /var |grep -v .Filesystem. |awk '{ print $4}'| sed 's/%//g'| tail -n+3`
echo $USED

if [ $USED == '80' ] ;
        then
        echo "Utilization is greater than or equal to 80% "
        echo "Going to remove the files from /var/tmp/oradiag_obiee11g/diag/clients/user_obiee11g/host_3745110104_11/cdump"
        echo "Running the housekeeping script"

        find /var/tmp/oradiag_obiee11g/diag/clients/user_obiee11g/host_3745110104_11/cdump -mindepth 1 -maxdepth 1 | xargs rm -rf

        echo "Cdump files removed from /var/tmp/oradiag_obiee11g/diag/clients/user_obiee11g/host_3745110104_11/cdump"
        else
        echo "Utilization is within threshold"
		fi
		
