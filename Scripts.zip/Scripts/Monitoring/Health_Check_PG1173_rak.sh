#--Script Name: Health_Check_PG1173.sh
#--Date       : 21-Sep-2017
#--Author     : Rakesh Kumar
#--Category   : Shell Script
#--Root Cause Fixed  :
#--Impact to Reports : No
#--Impact to Infomanager: No
#--Description : This Script is used to perform health check on ESB servers
#--------------------------------------------------------------------------------------------------

echo "Checking Disk Space on each File System"
df -k
echo "		"
echo "Checking Instances on ESB server PG1173"
date ; ps -ef|grep java|grep 'PRD_TFMIS_HUB_HK'| awk {'print  $9'}|cut -f5- -d/|cut -f1 -d/|sort|uniq;
ps -ef|grep java|grep 'PRD_TFESB_HUB_HK'| awk {'print  $9'}|cut -f 5-7 -d/|cut -f1 -d/|sort|uniq;
ps -ef|grep java|grep 'PRD_TFNTP_HUB_HK'|awk {'print  $9'}|cut -f 5-7 -d/|cut -f1 -d/|sort|uniq;

