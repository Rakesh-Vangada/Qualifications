#--Script Name: CAGG_File_Check.sh
#--Date       : 13-Jan-2016
#--Author     : Rakesh Kumar
#--Category   : Shell Script
#--Root Cause Fixed  :
#--Impact to Reports : No
#--Impact to Infomanager: No
#--Description : This Script is used to monitor the files sent to CAGG Team.
#------------------------------------------------------------------------------------------

#!/bin/bash
# assign a value:
# CURRENT_DATE=$1
#echo $CURRENT_DATE 

countryCodePassed="$2"
dateLen=${#datePassed}

countryCodePassedLen=${#countryCodePassed}

# echo "CTY_CODE ::: $countryCodePassedLen"

if [[ $countryCodePassedLen -ge 2 && $countryCodePassedLen -lt 3 ]] ; then
	COUNTRY_LIST=$countryCodePassed
else
	COUNTRY_LIST="AE AO BD BH BW CI CM CN GB GH GM HK ID IN IQ JO JP KE LK MO MU MY MZ NG NP OM PH PK QA SG SL TH TW TZ UG US VN ZA ZM ZW"
fi

d=`date +%Y%m%d`
#echo $d
file="$d"
#echo "Just before entering the cagg check"
#echo $file

echo "================================CAGG FTFID Check=================================="
	
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedFTFID=""
countryCodesNotIdentifiedFTFID=""

#echo "DIR ::: $DIR"
#echo "Date ::: $file"
#echo "$DIR"/*_"$file"_FTFID.log

for fileName in "$DIR"/*_"$file"_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedFTFID="$countryCodesIdentifiedFTFID $countryCode"
			fi
		fi
	fi
    fi

done

echo "Country IdentifiedFTFID ::: $countryCodesIdentifiedFTFID"
echo ""
echo "============================"
echo "CAGG File sent for (Countries)"
echo "============================"
echo "Country IdentifiedFTFID ::: $countryCodesIdentifiedFTFID"
echo ""

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedFTFID="$countryCodesNotIdentifiedFTFID $country"
	fi
done

echo ""
echo "==========================="
echo "CAGG File FTFID NOT sent for (Countries)"
echo "==========================="
echo "Country Not IdentifiedFTFID ::: $countryCodesNotIdentifiedFTFID"
echo ""

echo "================================EDM MASTER FTFID Check=================================================================================="
	
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedEDMMFTFID=""
countryCodesNotIdentifiedEDMMFTFID=""

#echo "DIR ::: $DIR"
#echo "Date ::: $file"
#echo "$DIR"/*_"$file"_EDM_MASTER_FTFID.log

for fileName in "$DIR"/*_"$file"_EDM_MASTER_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedEDMMFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedEDMMFTFID="$countryCodesIdentifiedEDMMFTFID $countryCode"
			fi
		fi
	fi
    fi

done

echo "Country IdentifiedEDMMFTFID ::: $countryCodesIdentifiedEDMMFTFID"
echo ""
echo "============================"
echo "EDM Master File sent for (Countries)"
echo "============================"
echo "Country IdentifiedEDMMFTFID ::: $countryCodesIdentifiedEDMMFTFID"
echo ""

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedEDMMFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedEDMMFTFID="$countryCodesNotIdentifiedEDMMFTFID $country"
	fi
done

echo ""
echo "==========================="
echo "EDM Master File FTFID NOT sent for (Countries)"
echo "==========================="
echo "Country Not IdentifiedEDMMFTFID ::: $countryCodesNotIdentifiedEDMMFTFID"
echo ""

echo "================================EDM EXCEPTION FTFID Check=================================================================================="
	
countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/hk/bin/scripts/logs"
countryCodesIdentifiedEDMEFTFID=""
countryCodesNotIdentifiedEDMEFTFID=""

#echo "DIR ::: $DIR"
#echo "Date ::: $file"
#echo "$DIR"/*_"$file"_EDM_EXCPN_FTFID.log

for fileName in "$DIR"/*_"$file"_EDM_EXCPN_FTFID.log
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$file"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentifiedEDMEFTFID" != *"$countryCode"* ]] ; then
				countryCodesIdentifiedEDMEFTFID="$countryCodesIdentifiedEDMEFTFID $countryCode"
			fi
		fi
	fi
    fi

done

echo "Country IdentifiedEDMEFTFID ::: $countryCodesIdentifiedEDMEFTFID"
echo ""
echo "============================"
echo "EDM EXCPN File sent for (Countries)"
echo "============================"
echo "Country IdentifiedEDMEFTFID ::: $countryCodesIdentifiedEDMEFTFID"
echo ""

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentifiedEDMEFTFID" != *"$country"* ]] ; then
		countryCodesNotIdentifiedEDMEFTFID="$countryCodesNotIdentifiedEDMEFTFID $country"
	fi
done

echo ""
echo "==========================="
echo "EDM EXCPN File FTFID NOT sent for (Countries)"
echo "==========================="
echo "Country Not IdentifiedEDMEFTFID ::: $countryCodesNotIdentifiedEDMEFTFID"
echo ""

#TH="<th style=' background-color:#00BFFF ; overflow-wrap:break-word ; width: 6px;'width=\"10%\" align=\"centre\" colspan=\"2\">"
#TD="<td style='background-color:#FFFFF0;font-family:Times New Roman;' width=\"10%\" align=\"left\" colspan=\"2\">"
#TD_R="<td style='background-color:red;font-family:Times New Roman;' width=\"10%\" align=\"left\" colspan=\"2\">"
#MESSAGE="<table border=1><tr>${TH}File_Status</th>${TH}COUNTRIES</th></tr>"

#MESSAGE="${MESSAGE} <tr>${TD}Files_Identified_CAGG</td>${TD}${countryCodesIdentifiedFTFID}</td></tr>"
#MESSAGE="${MESSAGE} <tr>${TD}Files_NOT_Identified_CAGG</td>${TD}${countryCodesNotIdentifiedFTFID}</td></tr>"
#MESSAGE="${MESSAGE} <tr>${TD}Files_Identified_EDM MASTER</td>${TD}${countryCodesIdentifiedEDMMFTFID}</td></tr>"
#MESSAGE="${MESSAGE} <tr>${TD}Files_NOT_Identified_EDM_MASTER</td>${TD}${countryCodesNotIdentifiedEDMMFTFID}</td></tr>"
#MESSAGE="${MESSAGE} <tr>${TD}Files_Identified_EDM_EXCEPTION</td>${TD}${countryCodesIdentifiedEDMEFTFID}</td></tr>"
#MESSAGE="${MESSAGE} <tr>${TD}Files_NOT_Identified_EDM_EXCEPTION</td>${TD}${countryCodesNotIdentifiedEDMEFTFID}</td></tr>"


#echo $MESSAGE #output the message


