#!/bin/bash
# assign a value:
# CURRENT_DATE=`date +%d%m%Y`

datePassed="$1"
countryCodePassed="$2"
dateLen=${#datePassed}

countryCodePassedLen=${#countryCodePassed}

# echo "CTY_CODE ::: $countryCodePassedLen"

if [[ $dateLen -eq 8 ]] ; then
	CURRENT_DATE=$datePassed
else
	CURRENT_DATE=`date +%Y%m%d`
fi

if [[ $countryCodePassedLen -ge 2 && $countryCodePassedLen -lt 3 ]] ; then
	COUNTRY_LIST=$countryCodePassed
else
	COUNTRY_LIST="AE AO BD BH BW CI CM CN GB GH GM HK ID IN IQ JO JP KE LK MO MU MY MZ NG NP OM PH PK QA SG SL TH TW TZ UG US VN ZA ZM ZW"
fi

countryCode=""
fileNotMatched=""
DIR="/prd/cocoa/batch/download/cagg/history"
countryCodesIdentified=""
countryCodesNotIdentified=""

echo "DIR ::: $DIR"
echo "Date ::: $CURRENT_DATE"

for fileName in "$DIR"/*"$CURRENT_DATE"*
do
    if [ -f "$fileName" ]; then
	#echo FILE : "$fileName"
	fName=$(basename $fileName)
	#echo File Name:$fName
	#dir=$(dirname $fileName)
	if [[ "$fileName" == *"$CURRENT_DATE"* ]] ; then
		#findCountryCode "$fileName"
		countryCode=`expr ${fName:0:2}`
		#echo CTYCODE: $countryCode
		if [[ "$COUNTRY_LIST" == *"$countryCode"* ]] ; then
			if [[ "$countryCodesIdentified" != *"$countryCode"* ]] ; then
				countryCodesIdentified="$countryCodesIdentified $countryCode"
			fi
		fi
	fi
    fi
done

#echo "Country Identified ::: $countryCodesIdentified"
echo ""
echo "============================"
echo "CAGG File sent for (Countries)"
echo "============================"
echo "Country Identified ::: $countryCodesIdentified"
echo ""

#for country in `echo $countryCodesIdentified`
#do 
	#echo $country
#done

for country in `echo $COUNTRY_LIST`
do 
	if [[ "$countryCodesIdentified" != *"$country"* ]] ; then
		countryCodesNotIdentified="$countryCodesNotIdentified $country"
	fi
done

#echo ""
echo "==========================="
echo "CAGG File NOT sent for (Countries)"
echo "==========================="
echo "Country Not Identified ::: $countryCodesNotIdentified"
echo ""



