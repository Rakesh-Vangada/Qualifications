#####################################################################
# Purpose : MRS UPLOAD for COCOA
# ----------------------------
# Date         Author        Description
# 26-Sep-2011  Nadeem        Included the batch stat script
#
#
#
#
#
#####################################################################
#!/bin/ksh
echo "Running Environment Script"
sh /prd/cocoa/hk/bin/scripts/SETENVIRONMENT.sh $1

echo "Sourcing Profile"
. /prd/cocoa/hk/bin/scripts/profile/$1.profile

jname=PCOCO"$1"120D
export PGM_NAME="COCOAMRS.sh"
echo =======================================================================  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} STARTED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME $tracktime NULL R

#Commented by Sathish to bypass Nepal
if [ $1 = "NP" ] || [ $1 = "MZ" ] || [ $1 = "IQ" ] || [ $1 = "AO" ]; then
exit 0
fi

#Update the currency rate for VN
update_VNCurrencyRate()
{
echo "Inside the update currency rate method"
sqlplus -s ${PRM_CONNECT_STRING}<<!EOF>/dev/null
#sqlplus -s ${PRM_CONNECT_STRING}<<!EOF>/dev/null
set head off;
set pages 0;
set feedback off;
spool VNcurrecnyUpdate
UPDATE SCBT_R_LIMIT_FX_MAINT_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1;
UPDATE SCBT_R_LIMIT_FX_RATE_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1;
COMMIT;
spool off;
quit;
!EOF
}


export MRS_UPLOAD=/prd/cocoa/batch/upload/mrs/
export MRS_INCOMING=/prd/cocoa/batch/upload/mrs/incoming/
export tracktime=`date '+%Y%m%d%H%M%S'`
export BUSINESS_DATE=`date '+%d%m%Y'`
echo $BUSINESS_DATE
export NEW_FILE_NAME=CCA_MRS_GLOBAL-$BUSINESS_DATE-1-$1.dat
echo $NEW_FILE_NAME
if [ `find $MRS_UPLOAD/LR$1MRS.txt  -type f` ]; then
cd $MRS_UPLOAD
mv $MRS_UPLOAD/LR$1MRS.txt $MRS_INCOMING/$NEW_FILE_NAME
sleep 300;
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} ENDED SUCCESSFULLY AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME NULL $tracktime S
sh /prd/cocoa/hk/bin/scripts/COCOAEBBSCSL.sh $1
#Update the currency rate for VN
        if [ $1 = "VN" ]; then
                update_VNCurrencyRate
        fi
else
echo "No MRS file Availble for $1. Please check the upload path $MRS_UPLOAD"  >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
export tracktime=`date '+%Y%m%d%H%M%S'`
echo  ${PGM_NAME} ENDED FAILED AT $tracktime >> ${APPL_LOG}/${CTY_CODE}_${logdate}.log
sh /prd/cocoa/hk/bin/scripts/TFTIPBATCHSTAT.sh $1 $jname $PGM_NAME NULL $tracktime F
exit 1
fi
