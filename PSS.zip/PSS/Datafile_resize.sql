NOTE:
======
RESIZING OF THE DATA FILES CANNOT BE DONE IF THE AUTOEXTEND IS NOT ENABLED FOR THE DATA FILE


alter database datafile '/prd/coco/cocorpt/dbs/tbs_data01/ts_cocoa_data1_11.dbf' resize 27500m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_data01/ts_cocoa_data1_11.dbf' autoextend on maxsize 30720m;

alter database datafile '/prd/coco/cocorpt/dbs/tbs_index01/ts_cocoa_indx1_01.dbf' resize 13600m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_index01/ts_cocoa_indx1_01.dbf' autoextend on maxsize 15360m;

alter database datafile '/prd/coco/cocorpt/dbs/tbs_data02/ts_cocoa_data1_14.dbf' resize 14700m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_data02/ts_cocoa_data1_14.dbf' autoextend on maxsize 20480m;

alter database datafile '/prd/coco/mis/dbs/tbs_data01/ts_cocoa_aux1_03.dbf' resize 17300m;
alter database datafile '/prd/coco/mis/dbs/tbs_data01/ts_cocoa_aux1_03.dbf' autoextend on maxsize 20480m;

alter database datafile '/prd/coco/cocorpt/dbs/tbs_data03/ts_cocoa_sys1_08.dbf' resize 70m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_data03/ts_cocoa_sys1_08.dbf' autoextend on maxsize 1024m;

alter database datafile '/prd/coco/cocorpt/dbs/tbs_data02/ts_cocoa_und1_02.dbf' resize 1100m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_data02/ts_cocoa_und1_02.dbf' autoextend on maxsize 4096m;

alter database datafile '/prd/coco/cocorpt/dbs/tbs_data03/ts_cocoa_aux1_07.dbf' resize 3500m;
alter database datafile '/prd/coco/cocorpt/dbs/tbs_data03/ts_cocoa_aux1_07.dbf' autoextend on maxsize 10240m;





