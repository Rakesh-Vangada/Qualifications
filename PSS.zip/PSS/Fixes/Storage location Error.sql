--Date       : 18-FEB-2014-IM0000018068591.sql
--Author     : KISHORE
--Reviewed   : KRISHNA
--Module     : Storage Location
-- ID    : IM0000018068591
--Root Cause Fixed  :No
--Impact to Reports : No
--Description : Storage Location
-------------------------------------------------------------------------------------------------------------------
Storage_Location Error
==================

-----------------------------------------------------------------------------------------
insert into SCBT_R_STORAGE_LOCATION_MST(
select BANK_GROUP_CODE,CTY_CODE,STEP_ID,a.STORAGE_LOC_ID,STORAGE_LOC_NAME,ADD_ID,STORAGE_TYPE,EXCH_DELIV_LOC_FLAG,EXCH_CODE,LOC_EXCH_CODE,ADD_1,ADD_2,ADD_3,STATE_CODE,PROVINCE_CODE,ADD_CTY_CODE,POSTAL_CODE,LOC_CAPACITY,LOC_CAPACITY_UOM,TRAN_DIFF_CCY_CODE,TRAN_DIFF_CCY_AMT,TRAN_DIFF_REVIEW_DATE,LOC_BLACKLISTED_FLAG,LOC_BLACKLISTED_REASON,BONDED_LOC_FLAG,INSURED_LOC_LIMIT_FLAG,INSPECTION_REQUIRED_FLAG,STORAGE_COMPANY_ID,INSURED_FLAG,COPYOFADDR,EXPIRY_DATE,LOCATION_CODE
from SCBT_R_STORAGE_LOCATION_HIST a, 
(select STORAGE_LOC_ID,max(trunc(CHECKER_TIMESTAMP)) as CHECKER_TIMESTAMP_MAX from SCBT_R_STORAGE_LOCATION_HIST where op_code<>'D' 
and STORAGE_COMPANY_ID = 'SC001083' 
and (STORAGE_LOC_ID,STORAGE_COMPANY_ID) not in (select STORAGE_LOC_ID,STORAGE_COMPANY_ID
from SCBT_R_STORAGE_LOCATION_MST M where M.STORAGE_COMPANY_ID = 'SC001083') group by STORAGE_LOC_ID) B 
where STORAGE_COMPANY_ID = 'SC001083'  and B.CHECKER_TIMESTAMP_MAX = TRUNC(a.CHECKER_TIMESTAMP)
and a.STORAGE_LOC_ID = B.STORAGE_LOC_ID );

>>for deleting multiple records
------------------------------------------
delete from SCBT_R_STORAGE_LOCATION_MST where step_id in
(select m.step_id from SCBT_R_STORAGE_LOCATION_MST m, SCBT_R_STORAGE_LOCATION_hist h where
m.step_id = h.step_id and m.storage_loc_id = h.storage_loc_id and h.checker_timestamp <>
(select max(checker_timestamp) from SCBT_R_STORAGE_LOCATION_hist hist where hist.storage_loc_id = h.storage_loc_id)
and m.storage_loc_id in
(select STORAGE_LOC_ID from scbt_r_storage_location_mst where STORAGE_LOC_ID <> 'SC000528012' 
group by STORAGE_LOC_ID having count(*) > 1))
