
select * from SCBT_R_CUST_PRODUCT_LIMIT where CUST_ID = '800002488' and LIMIT_CAT_CODE = 'V' 

UPDATE SCBT_T_PROD_LIMIT_UTIL u SET u.limit_ccy_utilised_amt = (SELECT 
SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, u.limit_ccy_code, 'Y'))
FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh 
     WHERE u.bank_group_code = mv.bank_group_code
       AND u.bank_group_code = rh.bank_group_code
       AND u.cty_code = mv.cty_code
       AND u.cty_code = rh.cty_code
     AND rh.req_type_code = 'NEW' AND rh.req_status_code = 'CON'
     AND mv.init_req_id = rh.init_req_id
     and MV.LIMIT_ID = U.LIMIT_ID)
       where U.LIMIT_ID in ('6163');
       
-- To update Pending increase   
=======================
   UPDATE SCBT_T_PROD_LIMIT_UTIL u SET u.limit_ccy_pend_inc_amt =
(SELECT NVL(SUM(amt),0) FROM (
              SELECT mv.init_req_id,
              SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) amt
              FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh, SCBT_T_PROD_LIMIT_UTIL cu
              WHERE rh.bank_group_code = 'SCB'
                    AND rh.cty_code='HK'
                     AND cu.bank_group_code = mv.bank_group_code
                AND cu.bank_group_code = rh.bank_group_code
                        AND  cu.cty_code = mv.cty_code
                AND cu.cty_code = rh.cty_code
        AND rh.req_type_code      = 'NEW'
        AND rh.req_status_code   = 'PEND'
        AND mv.init_req_id      = rh.init_req_id
            and CU.LIMIT_ID = MV.LIMIT_ID
                  AND cu.limit_id ='6163'
              GROUP BY mv.init_req_id
              HAVING SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) > 0
                    ))
                    where U.LIMIT_ID ='6163';
SELECT * from SCBT_T_PROD_LIMIT_UTIL where limit_id = '6163'
   
  -- To update Pending decrease
  ========================
   UPDATE SCBT_T_PROD_LIMIT_UTIL u SET u.limit_ccy_pend_dec_amt =
  (SELECT NVL(SUM(amt),0) FROM (
                SELECT mv.init_req_id,
                SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) amt
                FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh, SCBT_T_PROD_LIMIT_UTIL cu
                where RH.BANK_GROUP_CODE = 'SCB'
                      AND rh.cty_code='IN'
                       AND cu.bank_group_code = mv.bank_group_code
                  AND cu.bank_group_code = rh.bank_group_code
                          AND  cu.cty_code = mv.cty_code
                  AND cu.cty_code = rh.cty_code
          AND rh.req_type_code      = 'NEW'
          AND rh.req_status_code   = 'PEND'
          AND mv.init_req_id      = rh.init_req_id
              and CU.LIMIT_ID = MV.LIMIT_ID
                    AND cu.limit_id ='6163'
                GROUP BY mv.init_req_id
                HAVING SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) < 0
                      ))
                      where U.LIMIT_ID ='6163';
