--Date       : 07-JAN-2015-IM0000020411697.sql
--Author     : KISHORE
--Reviewed   : KRISHNA
--Module     : COLLATERAL 
--JIRA ID    :   IM0000020411697  
--Root Cause Fixed  :No
--Impact to Reports : No
--Description : COLLATERAL 
-------------------------------------------------------------------------------------------------------------------

update SCBT_T_PARCEL_MST set CMV_CCY_AMT=0,GCV_CCY_AMT=0,NCV_CCY_AMT=0 where COLLATERAL_ID='GB779T06944001CN' 
and parcel_id ='CN00131787';

select * from SCBT_T_COLL_LIMIT_REQ_LOG_DTL where INIT_REQ_ID='46642256';
update scbt_t_coll_limit_req_log_dtl set CMV_TXN_CCY_AMT=-614920.47 where init_req_id='46642256' and req_sr_no=1;

select * from SCBT_T_COLL_LIMIT_MVMT where INIT_REQ_ID='46642256';
update scbt_t_coll_limit_mvmt set txn_ccy_amt=-614920.47 where init_req_id='46642256' and req_sr_no=1 and limit_id<>'11237';

UPDATE SCBT_T_COLL_LIMIT_UTIL u SET u.limit_ccy_utilised_amt = (SELECT 
SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, u.limit_ccy_code, 'Y'))
FROM SCBT_T_COLL_LIMIT_MVMT mv, SCBT_T_COLL_LIMIT_REQ_LOG rh 
     WHERE u.bank_group_code = mv.bank_group_code
       AND u.bank_group_code = rh.bank_group_code
       AND u.cty_code = mv.cty_code
       AND u.cty_code = rh.cty_code
     AND rh.req_type_code = 'NEW' AND rh.req_status_code = 'CON'
     AND mv.init_req_id = rh.init_req_id
     and MV.LIMIT_ID = U.LIMIT_ID)
       WHERE u.limit_id IN ('12008','19069');