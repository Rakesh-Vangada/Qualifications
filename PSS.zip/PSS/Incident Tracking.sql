	Incident Query

	select problem__,
			 p.short_description,
			 p.assignment_group,
			 p.service,
			 p.occurance_time,
			 p.assignee_name,
			 p.status,
			 p.service_class,
			 p.Cause_code,
			 p.Caused_by,
			 p.Resolution_code,
			 p.resolution,
			 p.affected_service,
			 p.failed_service,
			 p.severity,
			 p.priority,
			 p.department,   
			 p.resumed,
			 p.drill_down_one, 
			 p.drill_down_two,
			 p.accepted_time,
			 p.assigned_time,
			 p.New_time,
			 p.closed_time,
			 p.resolved_time,
			 p.resumed_time,
			 p.technology_country,
			 p.country,
			 p.component,
			 p.change_no,
			 p.Closure_code,
			 p.Root_cause_code,
			 p.Modified_date,
			 p.Type,
	remedy.scb_incident_common_api.is_sla_met(service,severity,kpiuser.Sf_Sum_of_OnlineHour(remedy.localtime(affected_country,start_time),
		   Decode(Resumed_Time,Null,to_date(to_char(last_day(remedy.localtime(affected_country,start_time)) + 1,'dd/mm/yyyy') ||'23:59:59','dd/mm/yyyy hh24:mi:ss'),
	remedy.localtime(affected_country,Resumed_Time)),severity,r.region)) sla_met,
		   to_char(p.start_time, 'MONTH') MTH
	from remedy.scb_problemmanagement p, kpiuser.slm_region r
	where p.start_time >= to_date('19/11/2013', 'DD/MM/YYYY')
	   and p.start_time <= to_date('05/12/2013', 'DD/MM/YYYY')
	   and p.country = r.country
	   and p.assignment_group in
	   ('GBL-ISCM-COCOA')

	