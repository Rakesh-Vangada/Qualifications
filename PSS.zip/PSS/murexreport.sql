SELECT DISTINCT scbf_get_party_name(inv.bank_group_code, inv.cust_id) customer_name,
       inv.cty_code business_unit,
       DECODE(goods_in_type_code,'T','VESSEL',
       scbf_c_get_code_desc(inv.bank_group_code,
                            inv.cty_code,
                            '*',
                            'EN',
                            'CD099',
                            loc.add_cty_code,
                            '1')) AS storage_country,
       DECODE(goods_in_type_code,'T','VESSEL',loc.state_code) AS state ,
       DECODE(goods_in_type_code,'T','VESSEL',scbf_c_get_code_desc(inv.bank_group_code,
                            inv.cty_code,
                            '*',
                            'EN',
                            'CD061',
                            loc.location_code,
                            '1')) AS location_code,
       DECODE(goods_in_type_code,'T','IN TRANSIT',scbf_get_storage_company_name(inv.bank_group_code,
                                     SUBSTR(inv.storage_location_id, 1, 8))) AS storage_company_name,
       DECODE(goods_in_type_code,'T','IN TRANSIT',scbf_get_storage_location_name(inv.bank_group_code,
                                      inv.storage_location_id)) AS storage_location_name,
       inv.sip_deal_ref_no sip_deal_ref_no,
       scbf_get_commodity_name(inv.bank_group_code, inv.commodity_id) commodity_name,
       scbf_c_get_code_desc(inv.bank_group_code,
                            inv.cty_code,
                            '*',
                            'EN',
                            'CD016',
                            inv.net_commodity_qnty_uom,
                            '1') inventory_uom,
       (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) AS inventory_netweight,
       (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) *
       shist.purchase_price_ccy_amt inventory_value,
       shist.deal_type_code,
       shist.deal_start_date,
       shist.deal_end_date,
       shist.deal_type_code,
       SHIST.DEAL_SECURITY_LEVEL_CODE,
       SHIST.EXCHANGE_CODE,
       (shist.net_commodity_qnty - NVL(shist.utilised_qnty, 0)) deal_tonnage,
       shist.purchase_price_ccy_code deal_purchase_price_ccy_code,
       shist.purchase_price_ccy_amt deal_purchase_price,
       scbf_c_get_code_desc(inv.bank_group_code,
                            inv.cty_code,
                            '*',
                            'EN',
                            'CD016',
                            shist.purchase_price_uom,
                            '1') deal_purchase_price_uom,
       shist.invoice_ccy_code deal_invoice_ccy,
       shist.invoice_ccy_amt deal_invoice_value,
       inv.first_collateral_date,
       inv.document_ref_no,
       inv.shape_type_code shape_type,
       inv.shape_no no_of_shapes,
       inv.sec_commodity_qnty_uom package_type,
       inv.sec_commodity_qnty no_of_packages,
       inv.cust_id customer_id,
       inv.commodity_id,
       inv.deal_id,
       inv.deal_step_id,
       inv.storage_location_id,
       inv.inventory_type_code,
       inv.inventory_status_code,
       inv.COLLATERAL_ID,
       INV.INVENTORY_ID
  FROM scbt_t_inventory_snapshot   inv,
       scbt_t_sip_deal_smry_hst    shist,
       scbt_r_storage_location_mst loc
WHERE inv.bank_group_code = shist.bank_group_code
   AND inv.cty_code = shist.cty_code
   AND inv.cust_id = shist.cust_id
   AND inv.bank_group_code = loc.bank_group_code(+)
   AND inv.storage_location_id = loc.storage_loc_id(+)
   AND SUBSTR(inv.deal_id, 1, 11) = SUBSTR(shist.deal_id, 1, 11)
   AND inv.goods_in_type_code in ('T', 'S')
   AND inv.inventory_status_code IN ('01', '02')
   AND inv.inventory_type_code IN ('MST', 'ROI', 'TRI', 'CRE')
   AND (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) > 0
   AND shist.deal_status_code NOT IN ('IRO', 'FRO', 'DCL', 'FER')
   AND inv.deal_step_id IN
       (SELECT MAX(hi.deal_step_id)
          FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv1
         WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')
           AND step_code = 'SIPI'
           AND hi.step_status_code = '03'
           AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv1.deal_id, 1, 11)
         GROUP BY SUBSTR(hi.deal_id, 1, 11))
   AND shist.deal_step_id IN
       (SELECT MAX(hi.deal_step_id)
          FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv2
         WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')
           AND step_code = 'SIPD'
           AND hi.step_status_code = '03'
           AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv2.deal_id, 1, 11)
         GROUP BY SUBSTR(hi.deal_id, 1, 11))
order by   INVENTORY_ID  
		