echo "Environment Setup for Country " $1
export CTY_PROFILE=/prd/cocoa/hk/bin/scripts/profile/$1.profile

if [ `find /prd/cocoa/hk/bin/scripts/profile/$1.profile -type f` ]; then
   echo "$1 Profile already created"
else
for f in `find /prd/cocoa/hk/bin/scripts  -type f|grep CTY.cfg`;
do
   cp $f $f.bak
   echo "The Profile for country $1 will be in /prd/cocoa/hk/bin/scripts/profile/$1.profile "
   sed s/COUNTRY/$1/g < $f.bak > $f > /prd/cocoa/hk/bin/scripts/profile/$1.profile
   cp $f.bak $f
   rm $f.bak
done
fi
