MIS Priveleges
===========
MISOWNER: Same privs as COCOOWNER on MIS objects.
MISAPLUSER: insert, delete, update on all MIS objects
MISREADER: select on all MIS objects
All MIS users should have cocoreader access in terms to access the COCOA APP tables.

--MIS staging Check - Check at 2:00 PM
---------------------------------------
select * from JBS_COUNTRY_STAGING_STATUS where BUSINESS_DATE = trunc(sysdate-1)
and job_instance_id = '-1'

--MIS Foundation Check - check at 4.45 PM
------------------------------------------
SELECT  
JI.JOB_INSTANCE_ID,
JB.JOB_NAME,
JI.START_TS,  
JI.END_TS,
TO_CHAR(TO_DATE('01-JAN-2011')  + (NVL(JI.END_TS,SYSDATE) - JI.START_TS),'hh24:mi:ss' ) DURATION,
(select max(job_param_value) 
  from JBS_JOB_PARAM jp join JBS_JOB_INSTANCE_PARAM  jip  on JP.JOB_PARAM_ID = JIP.JOB_PARAM_ID where JIP.JOB_INSTANCE_ID = ji.JOB_INSTANCE_ID  and lower(jp.JOB_PARAM_NAME) = 'p_table_name') table_name,
JI.STATUS_CODE,
JI.ERROR_MESSAGE,
JI.ROWS_SUCCESSFUL,
JI.*
FROM 
JBS_JOB_INSTANCE JI LEFT OUTER JOIN  JBS_JOB JB ON JI.JOB_ID = JB.JOB_ID 
WHERE JI.START_TS IS NOT NULL 
order by JI.START_TS desc

/*
Note:
1.For Manual running the foundation run through control M only.
2.All work flows have only 1 control M.
3.The second script is for foundation check.
   In the table records
   it starts with - MIS_INIT_FND_LOAD
   it ends with - MIS_POST_LOAD
   */  
   
--Table space queries   
----------------------

---check tables which having more then 256k initial extent ---- partitioned tables
select distinct TABLE_NAME, INITIAL_EXTENT, NEXT_EXTENT from DBA_TAB_PARTITIONS where table_owner='MISOWNER' 
and initial_extent > 262144 and table_name not like 'BIN%';


---check contigous chunck available on datafile--
SELECT   file_id, BYTES AS free_chunk
    FROM dba_free_space
   WHERE tablespace_name = 'TS_COCOA_MIS_DATA1'
   and bytes>=8388608
ORDER BY BYTES DESC;

select table_owner,table_name,partition_name,high_value from dba_tab_partitions where table_name='MIS_R_TXN_COLLATERAL_COVERAGE';

