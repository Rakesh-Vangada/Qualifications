http://10.112.182.27:9082/magellan_srv_web/Cocoa_PREPROD.jnlp

select PARCEL_ID,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_mst  where 
parcel_type_code not in ('MST', 'REL') andHEAL
deal_id in ('SG957T01670')
and (net_commodity_qnty - nvl(utilised_qnty,0))>0 and cty_code='SG';

select DEAL_ID,COLLATERAL_ID,PARCEL_ID,LINK_PARCEL_ID,PARCEL_TYPE_CODE,
STORAGE_COMPANY_ID,SCBF_GET_STORAGE_COMPANY_NAME('SCB',STORAGE_COMPANY_ID) AS COMP,
STORAGE_LOCATION_ID,SCBF_GET_STORAGE_LOCATION_NAME('SCB',STORAGE_LOCATION_ID)AS LOCATION_NAME
from scbt_t_parcel_mst  where parcel_type_code not in ('MST') and
cty_code='SG' AND 
storage_location_id = 'SC001310001' ORDER BY PARCEL_TYPE_CODE DESC

select cty_code,deal_id,commodity_id,parcel_id,net_commodity_qnty , utilised_qnty 
from scbt_t_parcel_mst  where commodity_id in ('CM10000043','CM10000258') and parcel_type_code not in ('MST', 'REL') 
and (net_commodity_qnty - nvl(utilised_qnty,0))>0 and cty_code='SG'

select * from scbt_t_parcel_mst where LINK_PARCEL_ID='PP00064414' or PARCEL_ID='PP00064414' or PARENT_PARCEL_ID='PP00064414'

select 501.13000-201.263 from dual -- 299.867

select 299.867-201.263 from dual -- 98.604


800014500

D08M12Y2011!
======================== commodities

Query to find the commodities
select cty_code,deal_id,commodity_id,parcel_id,net_commodity_qnty , utilised_qnty 
from scbt_t_parcel_mst  where commodity_id in (select commodity_id from SCBT_R_COMMODITY_DTLS dtls, SCBT_R_COMMODITY_PRICE_MST prc where
dtls.price_feed_id=prc.feed_id and prc.source_type_code='MAN') and parcel_type_code not in ('MST', 'REL') and (net_commodity_qnty - nvl(utilised_qnty,0))>0 and cty_code='SG'

Query to find the transactions linked to those commodities
SELECT CUST_ID ,DEAL_ID,PRODUCT_CODE,PROD_LIMIT_ID,TXN_REC_ID,TXN_REF_ID,TXN_CCY_NET_AMT,TXN_CCY_UTIL_AMT
FROM SCBT_T_TXN_MST WHERE DEAL_ID IN (
select deal_id
from scbt_t_parcel_mst  where commodity_id in (select commodity_id from SCBT_R_COMMODITY_DTLS dtls, SCBT_R_COMMODITY_PRICE_MST prc where
dtls.price_feed_id=prc.feed_id and prc.source_type_code='MAN') and parcel_type_code not in ('MST', 'REL') 
and (net_commodity_qnty - nvl(utilised_qnty,0))>0 and cty_code='SG')
AND (TXN_CCY_NET_AMT-nvl(TXN_CCY_UTIL_AMT,0))>0

ACBS - SELECT * FROM SCBT_R_PARAM_DATA WHERE PARAM_ID='TP13' AND CTY_CODE='SG'

select DISTINCT PARAM_CODE_ID,UPDATE_LEVEL_CODE from scbt_r_param_defn where CODE_FLAG='Y' and UPDATE_LEVEL_CODE='02' order by PARAM_CODE_ID asc


============= TP SYSTEM
SELECT * FROM SCBT_T_TD_TXN_LOG WHERE SYSTEM_CODE='OTP' AND DEAL_ID LIKE '%TF121B8526-00001%' 

SELECT * FROM SCBT_T_TP_DEAL_REGISTER_HST WHERE cocoa_deal_id='CN333T00248' -- TP_DEAL_ID LIKE '%223010001937%';

SELECT * FROM SCBT_T_IPS_TP_SYSTEM_OUT_MSG WHERE MSG_CONTENT LIKE '%TF121B8526-00001%';

SELECT * FROM SCBT_T_RPT_CHNL_MSG where MSG_CRE_TIMESTAMP >'24-JUN-2013' AND CTY_CODE='AE' 

SELECT * FROM SCBT_T_RPT_CHNL_MSG where STEP_ID like 'CN333T00248%'

SELECT * FROM SCBT_T_RPT_CHNL_DTLS where rec_id in ('21429182','21182667','21035342');

SELECT * FROM SCBT_R_PARAM_DATA WHERE PARAM_ID='TP02' AND CTY_CODE='CN'

SELECT * FROM SCBT_T_DEAL_HIST WHERE CTY_CODE='AE' AND CHECKER_TIMESTAMP > '24-JUN-2013' ORDER BY CHECKER_TIMESTAMP DESC;

SELECT * FROM SCBT_T_TD_TXN_LOG WHERE SYSTEM_CODE='DTP' AND DEAL_ID LIKE '%223010001937%' 

SELECT * FROM SCBT_T_TP_DEAL_REGISTER_HST WHERE TP_DEAL_ID LIKE '%223010001937%';

SELECT * FROM SCBT_T_IPS_TP_SYSTEM_IN_MSG WHERE MSG_CONTENT LIKE '%223010001937%';

SELECT * FROM SCBT_T_IPS_TP_SYSTEM_IN_MSG WHERE MSG_CONTENT LIKE '%TF121B8526-00001%';

SELECT * FROM SCBT_T_TXN_HST WHERE DEAL_ID='SG957T11179'

SELECT * FROM SCBT_T_DEAL_HIST WHERE DEAL_ID='SG957T11179'

SELECT PARCEL_ID ,UTILISED_QNTY , NET_COMMODITY_QNTY, SEC_UTILISED_QNTY,SEC_NET_COMMODITY_QNTY ,
(NET_COMMODITY_QNTY-UTILISED_QNTY) as AVAIL_QTY FROM SCBT_T_PARCEL_MST WHERE PARCEL_ID IN('RL00033924','CN00021420');

SELECT PARCEL_ID ,UTILISED_QNTY , NET_COMMODITY_QNTY, SEC_UTILISED_QNTY,SEC_NET_COMMODITY_QNTY ,
(NET_COMMODITY_QNTY-UTILISED_QNTY) as AVAIL_QTY FROM SCBT_T_PARCEL_MST  WHERE PARCEL_ID IN('CN00021420') or LINK_PARCEL_ID IN('CN00021420')or 
PARENT_PARCEL_ID  IN('CN00021420')

SELECT * FROM SCBT_T_PARCEL_MST WHERE PARCEL_ID IN('CN00021420') or LINK_PARCEL_ID IN('CN00021420')or 
PARENT_PARCEL_ID  IN('CN00021420')

SELECT * FROM SCBT_T_PARCEL_MST WHERE parcel_id = 'CN00021420'; 

UPDATE SCBT_T_PARCEL_MST SET parcel_status_code = '07' WHERE parcel_id = 'CN00021420';

after lc cancel
user had done release collateral on cancel step
@ release collateral step user had done cancel release (made release collateral quantity 2 zero)
so parcel status of parent came back from auto bookoff
================================ BU CODE ISSUES ==========================
SELECT h.BU_CODE,m.bu_code AS reg_bu_code, h.deal_id,m.deal_id AS reg_deal_id FROM SCBT_T_DEAL_HIST h, SCBT_T_DEAL_REGISTER_HDR_MST m WHERE h.deal_id=m.deal_id AND h.cty_code=m.cty_code AND h.bank_group_code=m.BANK_GROUP_CODE
AND h.BU_CODE<>m.bu_code AND h.cty_code  IN ('HK') --('HK','US','CN')


UPDATE SCBT_T_DEAL_HIST h SET h.bu_code=(
SELECT bu_code FROM SCBT_T_DEAL_REGISTER_HDR_MST  WHERE h.deal_id=deal_id AND h.cty_code=cty_code AND h.bank_group_code=BANK_GROUP_CODE
AND h.BU_CODE<>bu_code) WHERE h.Bu_code <>
(SELECT m.bu_code FROM SCBT_T_DEAL_REGISTER_HDR_MST m WHERE h.deal_id=m.deal_id AND h.cty_code=m.cty_code AND h.bank_group_code=m.BANK_GROUP_CODE)
AND h.cty_code='CN'
=======================================================
SELECT * FROM SCBT_R_CUST_APPR_LOCATION WHERE CUST_ID='800007881'

SELECT * FROM SCBT_R_CUST_APPR_LOCATION_HIST WHERE CUST_ID='800007881' order by checker_timestamp desc;

SELECT * FROM SCBT_R_STORAGE_COMPANY_MST WHERE STORAGE_COMPANY_ID='SC000004'
==================================================
CREATE UNIQUE INDEX PK_R_CUST_APPR_LOCATION_HIST ON SCBT_R_CUST_APPR_LOCATION_HIST 
(BANK_GROUP_CODE, CTY_CODE, LOCATION_LIMIT_GROUP_ID, CUST_ID, STEP_ID) 
NOLOGGING TABLESPACE TS_COCOA_INDX1 PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE ( INITIAL 64K NEXT 1M MINEXTENTS 1 MAXEXTENTS UNLIMITED PCTINCREASE 0 BUFFER_POOL DEFAULT ) NOPARALLEL;
==================================== 02 JULY 2013===============================================================
SELECT * FROM SCBT_S_DAILY_PARAM WHERE CTY_CODE='MZ';


UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='27-JAN-2014',PREV_BUSINESS_DATE='25-JAN-2014',NEXT_BUSINESS_DATE='28-JAN-2014' WHERE CTY_CODE='VN';

SELECT * FROM SCBT_S_DAILY_PARAM WHERE CTY_CODE IN ('PK','ZM','MO');

UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='02-JUL-2013' WHERE CTY_CODE IN ('PK','ZM','MO');

SELECT UMST.USER_ID,UMST.USER_NAME, CODE.CODE_VALUE,UFA.FUNCTION_CODE,MFUNC.QUICK_LAUNCH_CODE,CODE.DESC_1 
FROM SCBT_R_USER_MST UMST, SCBT_R_USER_FUNC_ACCS_MST UFA,SCBT_S_MODULE_FUNC_DEFN MFUNC,SCBT_R_CODE_DATA CODE
WHERE UMST.USER_ID = UFA.USER_ID
AND CODE.CODE_VALUE = UFA.FUNCTION_CODE
AND CODE.CODE_VALUE = MFUNC.MODULE_FUNC_CODE
AND UMST.USER_BRCH_CODE LIKE 'HK%'
AND UFA.FUNCTION_CODE LIKE 'E%'
AND MFUNC.QUICK_LAUNCH_CODE = MFUNC.NODE_ID
--AND UFA.FUNCTION_CODE ='M2011'
--AND UMST.USER_ID='1181741'
====================================== PRICE FEED issue from Babu AE CTL_COMMODITY_LIST_INPUT ==============================
select step_status_code,  Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1),COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
			COMMODITY_CODE
			from
			SCBT_R_COMMODITY_HIST where step_status_code in ('01', '11','02')  and BANK_GROUP_CODE=?   and NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper(?)
			and upper(COMMODITY_TYPE_CODE) like upper(?) and upper(COMMODITY_CAT_CODE) like upper(?) and upper(EXCH_CODE) like upper(?) and upper(COMMODITY_OWNER) like (?)
			and upper(HUB_BU_CODE) like (?)  and upper(BU_CODE) like (?) and upper(COMMODITY_ID) like upper(?)
			UNION ALL
			select '03', Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1), COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
			COMMODITY_CODE
			from
			SCBT_R_COMMODITY_MST mst where BANK_GROUP_CODE=?   AND  NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper(?)
			and upper(COMMODITY_TYPE_CODE) like upper(?) and upper(COMMODITY_CAT_CODE) like upper(?) and upper(EXCH_CODE) like upper(?) and upper(COMMODITY_OWNER) like (?)
			 and upper(HUB_BU_CODE) like (?)  and upper(BU_CODE) like (?)
			and mst.BANK_GROUP_CODE=? AND upper(COMMODITY_ID) like upper(?) and mst.COMMODITY_ID  NOT IN (select COMMODITY_ID from SCBT_R_COMMODITY_HIST 
						where step_status_code in ('01', '11','02') and COMMODITY_ID = mst.COMMODITY_ID  
						AND BANK_GROUP_CODE=mst.BANK_GROUP_CODE)

================================================== CTL_COMMODITY_FEED_ID_LIST ===============================
select * from ( select FEED_ID, FEED_NAME,PRICE_DESC,DELIV_SCHEDULE_DAYS, DELIV_SCHEDULE_CODE, DELIV_SCHEDULE_YEAR, PRICE_SOURCE_CODE,FEED_OWNER_USERID,UM.USER_NAME,  
	         FEED_PRICE_CCY, FEED_PRICE_AMT,FEED_PRICE_UOM,TO_CHAR(VENDOR_LAST_UPDATE_DATE,'dd-MM-yyyy'),TO_CHAR(UPDATE_USER_TIMESTAMP,'dd-MM-yyyy'),  
	         UPDATE_USERID,TO_CHAR(PRICE_DATE,'dd-MM-yyyy'), TO_CHAR(LAST_TRADE_DATE,'dd-MM-yyyy')
	         from SCBT_R_COMMODITY_PRICE_MST CP,SCBT_R_USER_MST UM 
	         where CP.bank_group_code = UM.bank_group_code and CP.FEED_OWNER_USERID = UM.USER_ID AND
	         CP.bank_group_code = ? and upper(CP.feed_id) like upper(?) and upper(CP.feed_name) like upper(?)  and upper(CP.FEED_OWNER_USERID) like upper(?) 
	         and upper(CP.PRICE_SOURCE_CODE) like upper(?) and upper(nvl(CP.PRICE_DESC,'%')) like upper(?) ) where rownum <= ?

================================================== 03 July FX rate ==========================
---- To check FX revaluation

SELECT * FROM scbt_r_limit_fx_rate_mst WHERE cty_code = 'IN' AND fx_ccy_code = 'USD'

SELECT * FROM scbt_r_limit_fx_maint_mst WHERE cty_code = 'IN' AND fx_ccy_code = 'USD'

DECLARE

retVar VARCHAR2(10);

BEGIN

Scbk_P_Prod_Tls.SCBP_TLS_PROD_CCYREVALPROCESS(retVar,'SCB','JO',TO_DATE('02-JUL-2013','DD-MON-YYYY'),'MANUALRUN001');

END; 
============================
UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='03-JUL-2013',PREV_BUSINESS_DATE='02-JUL-2013',NEXT_BUSINESS_DATE='04-JUL-2013' WHERE CTY_CODE='ZW';

UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='03-JUL-2013',PREV_BUSINESS_DATE='01-JUL-2013',NEXT_BUSINESS_DATE='04-JUL-2013' WHERE CTY_CODE='ZM';

=======================================05 July 2013 ============================
SELECT CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
        P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
        SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(PM.NET_COMMODITY_QNTY,0)) AS PRIM_PENDING_INWARD,
        SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(PM.SEC_NET_COMMODITY_QNTY,0)) AS SEC_PENDING_INWARD
        FROM SCBT_T_PARCEL_HST P,SCBT_R_COMMODITY_MST CM,SCBT_T_DEAL_HIST DH,SCBT_T_PARCEL_MST PM,SCBT_T_COLLATERAL_REGISTER_MST CR,SCBT_T_COLLATERAL_REGISTER_HST CH 
        WHERE P.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND DH.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.CTY_CODE = DH.CTY_CODE
        AND P.BANK_GROUP_CODE = PM.BANK_GROUP_CODE(+) AND P.CTY_CODE = PM.CTY_CODE(+) AND P.PARCEL_ID = PM.PARCEL_ID(+)
        AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE(+) AND P.CTY_CODE = CR.CTY_CODE(+) AND P.COLLATERAL_ID = CR.COLLATERAL_ID(+)
        AND P.COMMODITY_ID = PM.COMMODITY_ID(+) AND P.COLLATERAL_TYPE_CODE = PM.COLLATERAL_TYPE_CODE(+)
        AND P.BANK_GROUP_CODE = CH.BANK_GROUP_CODE AND P.CTY_CODE = CH.CTY_CODE AND P.COLLATERAL_ID = CH.COLLATERAL_ID
        AND P.DEAL_ID = CH.DEAL_ID AND P.DEAL_ID = DH.DEAL_ID AND DH.DEAL_ID = CH.DEAL_ID AND DH.CUST_ID = CH.CUST_ID        
        AND DH.DEAL_STEP_ID = P.DEAL_STEP_ID  AND DH.DEAL_STEP_ID = CH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE <> '03' AND P.COMMODITY_ID = CM.COMMODITY_ID 
        AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL') 
        AND P.BANK_GROUP_CODE = 'SCB' AND P.CTY_CODE = 'ZA' AND CH.CUST_ID = '800011956' AND P.DEAL_ID LIKE '%'
        GROUP BY CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
        P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)	

SELECT CR.COLLATERAL_CATEGORY ,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(P.UTILISED_QNTY,0)) AS PRIM_TOTAL_QNTY,SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(P.SEC_UTILISED_QNTY,0)) AS SEC_TOTAL_QNTY
		FROM SCBT_T_PARCEL_MST P,SCBT_R_COMMODITY_MST CM,SCBT_T_COLLATERAL_REGISTER_MST CR 
		WHERE P.COMMODITY_ID = CM.COMMODITY_ID AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL')
		AND P.BANK_GROUP_CODE = 'SCB' AND P.CTY_CODE = 'ZA' AND CR.CUST_ID = '800011956' AND CR.DEAL_ID LIKE '%'
		AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE AND P.CTY_CODE = CR.CTY_CODE AND P.DEAL_ID = CR.DEAL_ID AND P.COLLATERAL_ID = CR.COLLATERAL_ID
		GROUP BY CR.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
		P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
================================================================================================================================
select * from SCBT_T_CUST_RECONCIL_SMRY_MST WHERE CTY_CODE='SG'; -- 'SG','PH','CN','HK','TW','JP','MY','TH','AE','BH','OM','PK','QA','JO','ID','IN','MU','NP','BD','LK','MO'

SELECT PRICE_FEED_ID,COMMODITY_ID FROM SCBT_T_PARCEL_MST WHERE PARCEL_ID='PP00048760'

SELECT * FROM SCBT_R_COMMODITY_PRICE_MST  WHERE FEED_ID='RAWGRF2'

SELECT * FROM SCBT_R_COMMODITY_DTLS WHERE COMMODITY_ID='CM10000073' AND COMMODITY_PRICE_ID='12764335'--price_feed_id='RAWGRF2'
================================================Jamie========================
select * from SCBT_R_COMMODITY_MST C where C.COMMODITY_OWNER ='1226436' --58 rows

update SCBT_R_COMMODITY_MST  set COMMODITY_OWNER='1165316' where COMMODITY_OWNER ='1226436'

select * from SCBT_R_COMMODITY_MST C where C.COMMODITY_OWNER ='1226436' --0


select * from SCBT_R_COMMODITY_PRICE_MST CP where FEED_OWNER_USERID  ='1226436' -- 39 rows

update SCBT_R_COMMODITY_PRICE_MST  set FEED_OWNER_USERID='1165316' where FEED_OWNER_USERID  ='1226436';

select * from SCBT_R_COMMODITY_PRICE_MST CP where FEED_OWNER_USERID  ='1226436' --0 rows
=============================================== 16 JULY======================
(SELECT NVL(SUM(Scbf_Tls_Exch_Rate(BANK_GROUP_CODE, CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(cash_margin_ccy_amt,0), 'USD', 'N')
                 - Scbf_Tls_Exch_Rate(BANK_GROUP_CODE, CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(CM_CCY_RELEASE_AMT,0), 'USD', 'N')),0) TOTAL_MST_CM_AMT FROM SCBT_T_TXN_MST WHERE cust_id = '800006010' AND txn_step_code = 'NEW'
                 AND txn_rec_id NOT IN (SELECT parent_txn_rec_id FROM SCBT_T_TXN_HST th,SCBT_T_DEAL_HIST dh
                 WHERE th.cty_code = dh.cty_code AND th.bank_group_code = dh.bank_group_code AND dh.deal_id = th.deal_id AND th.cust_id = dh.cust_id
                 AND dh.deal_step_id = th.deal_step_id AND dh.step_status_code <> '03' AND dh.cust_id = '800006010') AND txn_step_code NOT IN ('DRAW','MISC'))
            +

            (SELECT NVL(SUM(Scbf_Tls_Exch_Rate(th.BANK_GROUP_CODE, th.CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(cash_margin_ccy_amt,0), 'USD', 'N')
              -Scbf_Tls_Exch_Rate(th.BANK_GROUP_CODE, th.CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(CM_CCY_RELEASE_AMT,0), 'USD', 'N')),0) TOTAL_HST_CM_AMT FROM SCBT_T_TXN_HST th,SCBT_T_DEAL_HIST dh
            WHERE th.cty_code = dh.cty_code AND th.bank_group_code = dh.bank_group_code AND dh.deal_id = th.deal_id AND th.cust_id = dh.cust_id
            AND dh.step_status_code <> '03' AND dh.cust_id = '800006010' AND txn_step_code NOT IN ('DRAW','MISC'))
            
--Total cash and deposit balance(Z)
(SELECT  NVL(SUM(Scbf_Tls_Exch_Rate(ASM.BANK_GROUP_CODE, ASM.CTY_CODE, ASM.ACC_CCY_CODE, NVL(ASM.ACC_CCY_ANTICIPATED_AMT,0), 'USD', 'N')),0)  FROM SCBT_R_CUST_ACCT_MAINTENANCE CAM, SCBT_T_CUST_ACC_SMRY_MST ASM WHERE 
            CAM.CUST_ID = ASM.CUST_ID AND CAM.BANK_GROUP_CODE = ASM.BANK_GROUP_CODE AND CAM.ACC_NO = ASM.ACC_NO
            AND CAM.cust_id = '800006010' AND CAM.INCLUDE_FOR_CASH_COLLATERAL = 'Y' 
            AND CAM.ACC_NO NOT IN (SELECT NVL(PRODL.OVERDRAFT_FACILITY_ACCNO,'NA') FROM SCBT_R_CUST_PRODUCT_LIMIT PRODL
            WHERE PRODL.SHORTFALL_OFFSET = 'HO' AND PRODL.CUST_ID = '800006010'))            
            
SELECT ACC_CCY_ANTICIPATED_AMT FROM SCBT_T_CUST_ACC_SMRY_MST WHERE CUST_ID='800006010'           
======================================================17 JULY================================================
SELECT  CUST_ID,CASH_MARGIN_CCY_AMT FROM SCBT_T_TXN_MST WHERE CTY_CODE='US' AND CUST_ID ='800000184' AND CASH_MARGIN_CCY_AMT > 0

SELECT DISTINCT CUST_FACILITY_TYPE_CODE FROM SCBT_R_PARTY_MST WHERE CUST_FACILITY_TYPE_CODE <> 'CTAC'

SELECT * FROM SCBT_R_CUST_DOCUMENTS_MST WHERE CTY_CODE='US' AND CUST_ID ='800000184' and doc_id='4364'

SELECT * FROM SCBT_R_CUST_DOCUMENTS_HIST WHERE CTY_CODE='US' AND CUST_ID ='800000184' and doc_id='4364'

====================== Execute this on Sunday ==================================
SELECT * FROM SCBT_R_BIP_REPORT_NAMES WHERE CATEGORY='Others' AND rpt_id='OTH013';

UPDATE SCBT_R_BIP_REPORT_NAMES SET REPORT_NAME='Outstanding_Exposure_Report' WHERE CATEGORY='Others' AND rpt_id='OTH013';
================== INSURANCE REPORTS ====================
select decode(i.BACKED_BY_ID,'OTH',i.INS_COMPANY_NAME,Scbf_C_Get_Code_Desc ('SCB','*','*','EN','CI140',i.BACKED_BY_ID,1)) AS Insurance_name,i.POLICY_NO,
i.INS_CCY_CODE,i.INS_AMT,i.INS_ISSUE_DATE,i.INS_START_DATE,i.INS_EXPIRY_DATE,i.SPECIAL_INSTRUCTIONS
from SCBT_R_CUST_INS_LIMIT l,scbt_r_ins_mst i where l.cty_code = 'SG' and l.bank_group_code = 'SCB'
and l.bank_group_code = i.bank_group_code 
AND regexp_substr ( ',' || l.ins_policy_id || ',' , ',' || i.POLICY_NO || ',', 1, 1 ) =( ',' || i.POLICY_NO || ',')


select distinct p.STORAGE_COMPANY_ID,sc.STORAGE_COMPANY_NAME,p.STORAGE_LOCATION_ID,s.STORAGE_LOC_NAME,s.ADD_CTY_CODE 
from scbt_t_collateral_register_mst c,scbt_t_parcel_mst p,scbt_r_storage_location_mst s,scbt_r_storage_company_mst sc where c.bank_group_code = p.bank_group_code
and c.cty_code = 'SG' and c.bank_group_code = 'SCB' and p.GOODS_IN_TYPE_CODE = 'S' 
and s.BANK_GROUP_CODE = sc.BANK_GROUP_CODE and s.STORAGE_COMPANY_ID = sc.STORAGE_COMPANY_ID
and s.bank_group_code = p.bank_group_code and p.STORAGE_COMPANY_ID = s.STORAGE_COMPANY_ID and p.STORAGE_LOCATION_ID = s.STORAGE_LOC_ID
and c.cty_code = p.cty_code and p.collateral_id = c.collateral_id and p.deal_id = c.deal_id and 
c.collateral_id in (
select l.collateral_id from scbt_t_txn_mst t,scbt_t_txn_cr_linkage_mst l where t.cty_code = 'SG' and product_code in ('FAWR','LAI') and nvl(txn_status_code,'01') <> '11'
and t.txn_rec_id = l.txn_rec_id and t.cty_code = l.cty_code and t.BANK_GROUP_CODE = l.bank_group_code
and t.txn_ref_id = l.txn_ref_id and t.deal_id = l.deal_id and t.cust_id = l.cust_id)

===================
SELECT *  FROM SCBT_T_INVENTORY_MST WHERE LATEST_DEAL_STEP_ID='HK514S01669M0002' -- CM10001239

UPDATE SCBT_T_INVENTORY_MST SET COMMODITY_ID='CM10000843' WHERE  LATEST_DEAL_STEP_ID='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

SELECT * FROM SCBT_T_INVENTORY_HST WHERE DEAL_STEP_ID='HK514S01669M0002'

UPDATE SCBT_T_INVENTORY_HST SET COMMODITY_ID='CM10000843' WHERE  DEAL_STEP_ID='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

SELECT * FROM SCBT_T_INVENTORY_SMRY_MVMT WHERE DEAL_STEP_ID='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

UPDATE SCBT_T_INVENTORY_SMRY_MVMT SET COMMODITY_ID='CM10000843' WHERE DEAL_STEP_ID='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

SELECT * FROM SCBT_T_INVENTORY_SMRY WHERE LATEST_DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

UPDATE SCBT_T_INVENTORY_SMRY SET COMMODITY_ID='CM10000843'  WHERE LATEST_DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239'


SELECT * FROM SCBT_T_INVENTORY_SMRY_HST WHERE DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239' --NO REC

SELECT * FROM SCBT_T_SIP_DEAL_SMRY_HST WHERE DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

UPDATE SCBT_T_SIP_DEAL_SMRY_HST SET COMMODITY_ID='CM10000843' WHERE DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239'

SELECT * FROM SCBT_T_SIP_DEAL_SMRY_MST WHERE LATEAST_DEAL_STEP_ID ='HK514S01669M0002' AND COMMODITY_ID='CM10001239'


SELECT * FROM SCBT_T_SIP_DEAL_SMRY_HST WHERE DEAL_STEP_ID ='HK514S01669M0002' AND EXCHANGE_CODE='NEC'

UPDATE SCBT_T_SIP_DEAL_SMRY_HST SET EXCHANGE_CODE='LME'  WHERE DEAL_STEP_ID ='HK514S01669M0002' AND EXCHANGE_CODE='NEC'

UPDATE SCBT_T_INVENTORY_SMRY SET EXCHANGE_CODE='LME' WHERE LATEST_DEAL_STEP_ID ='HK514S01669M0002' AND EXCHANGE_CODE='NEC' 

UPDATE SCBT_T_INVENTORY_SMRY SET EXCHANGE_CODE='LME' WHERE LATEST_DEAL_STEP_ID ='HK514S01669M0002' AND EXCHANGE_CODE='NEC' 

UPDATE SCBT_T_INVENTORY_SMRY_MVMT SET  EXCHANGE_CODE='LME' WHERE DEAL_STEP_ID='HK514S01669M0002' AND EXCHANGE_CODE='NEC' 
========================  July 22 ========================================

select * from SCBT_T_SIP_DEAL_SMRY_HST where deal_id like 'HK514S01195%'

select * from SCBT_T_SIP_DEAL_SMRY_MST WHERE CUST_ID='800007887' AND SIP_DEAL_REF_NO='NRC-047C(3)' and lateast_deal_step_id = 'HK514S01195M0026'

-- update SCBT_T_SIP_DEAL_SMRY_MST set lateast_deal_step_id = 'HK514S01195M0023' WHERE CUST_ID='800007887' AND SIP_DEAL_REF_NO='NRC-047C(3)' and lateast_deal_step_id = 'HK514S01195M0026'

select * from SCBT_T_SIP_DEAL_SMRY_HST where deal_id like 'HK514S01293%'

select * from SCBT_T_SIP_DEAL_SMRY_MST where lateast_deal_step_id like 'HK514S01293%'

select * from SCBT_T_SIP_DEAL_SMRY_MST WHERE CUST_ID='800007887' AND SIP_DEAL_REF_NO='NRC-054B(3)' and lateast_deal_step_id = 'HK514S01293M0016'
select * from SCBT_T_SIP_DEAL_SMRY_HST WHERE CUST_ID='800007887' AND SIP_DEAL_REF_NO='NRC-054B(3)' 
select * from  SCBT_T_DEAL_HIST where deal_id like 'HK514S01293%'
select * from  SCBT_T_DEAL_MST where deal_id like 'HK514S01293-R002'

--update SCBT_T_SIP_DEAL_SMRY_MST set lateast_deal_step_id = 'HK514S01293M0015' WHERE CUST_ID='800007887' AND SIP_DEAL_REF_NO='NRC-054B(3)' and lateast_deal_step_id = 'HK514S01293M0016'

===========================Stanley================================

select distinct p.STORAGE_COMPANY_ID, sc.STORAGE_COMPANY_NAME,p.STORAGE_LOCATION_ID,s.STORAGE_LOC_NAME,s.ADD_CTY_CODE, 
c.CUST_ID,SCBF_GET_PARTY_NAME('SCB',c.CUST_ID) as CUSTOMER_NAME,p.DEAL_ID,c.LATEST_DEAL_STEP_ID,p.PARCEL_ID,
(net_commodity_qnty - nvl(utilised_qnty,0)) as stock_stored
from scbt_t_collateral_register_mst c,scbt_t_parcel_mst p,scbt_r_storage_location_mst s,scbt_r_storage_company_mst sc where c.bank_group_code = p.bank_group_code
and c.cty_code = 'SG' and c.bank_group_code = 'SCB' and p.GOODS_IN_TYPE_CODE = 'S' 
--and (net_commodity_qnty - nvl(utilised_qnty,0))>0  
--and parcel_type_code not in ('MST', 'REL')
and s.BANK_GROUP_CODE = sc.BANK_GROUP_CODE and s.STORAGE_COMPANY_ID = sc.STORAGE_COMPANY_ID
and s.bank_group_code = p.bank_group_code and p.STORAGE_COMPANY_ID = s.STORAGE_COMPANY_ID and p.STORAGE_LOCATION_ID = s.STORAGE_LOC_ID
and c.cty_code = p.cty_code and p.collateral_id = c.collateral_id and p.deal_id = c.deal_id and 
c.collateral_id in (
select l.collateral_id from scbt_t_txn_mst t,scbt_t_txn_cr_linkage_mst l where t.cty_code = 'SG' 
and product_code in ('FAWR','LAI') 
and nvl(txn_status_code,'01') <> '11'
and t.txn_rec_id = l.txn_rec_id and t.cty_code = l.cty_code and t.BANK_GROUP_CODE = l.bank_group_code
and t.txn_ref_id = l.txn_ref_id and t.deal_id = l.deal_id and t.cust_id = l.cust_id) 
order by p.STORAGE_COMPANY_ID;

======== without txn rec and ref Ids=====================
select distinct p.STORAGE_COMPANY_ID, sc.STORAGE_COMPANY_NAME,p.STORAGE_LOCATION_ID,s.STORAGE_LOC_NAME,s.ADD_CTY_CODE, 
c.CUST_ID,SCBF_GET_PARTY_NAME('SCB',c.CUST_ID) as CUSTOMER_NAME,p.DEAL_ID,c.LATEST_DEAL_STEP_ID,p.PARCEL_ID,
(net_commodity_qnty - nvl(utilised_qnty,0)) as stock_stored
from scbt_t_collateral_register_mst c,scbt_t_parcel_mst p,scbt_r_storage_location_mst s,scbt_r_storage_company_mst sc where c.bank_group_code = p.bank_group_code
and c.cty_code = 'SG' and c.bank_group_code = 'SCB' and p.GOODS_IN_TYPE_CODE = 'S' 
--and (net_commodity_qnty - nvl(utilised_qnty,0))>0  
--and parcel_type_code not in ('MST', 'REL')
and s.BANK_GROUP_CODE = sc.BANK_GROUP_CODE and s.STORAGE_COMPANY_ID = sc.STORAGE_COMPANY_ID
and s.bank_group_code = p.bank_group_code and p.STORAGE_COMPANY_ID = s.STORAGE_COMPANY_ID and p.STORAGE_LOCATION_ID = s.STORAGE_LOC_ID
and c.cty_code = p.cty_code and p.collateral_id = c.collateral_id and p.deal_id = c.deal_id and 
c.collateral_id in (
select l.collateral_id from scbt_t_txn_mst t,scbt_t_txn_cr_linkage_mst l where t.cty_code = 'SG' 
and product_code in ('FAWR','LAI') 
and nvl(txn_status_code,'01') <> '11'
--and t.txn_rec_id = l.txn_rec_id 
and t.cty_code = l.cty_code and t.BANK_GROUP_CODE = l.bank_group_code
--and t.txn_ref_id = l.txn_ref_id 
and t.deal_id = l.deal_id and t.cust_id = l.cust_id) 
order by p.STORAGE_COMPANY_ID;

select l.collateral_id,t.txn_rec_id , l.txn_rec_id ,product_code,l.cust_id,SCBF_GET_PARTY_NAME('SCB',l.CUST_ID) as CUSTOMER_NAME from scbt_t_txn_mst t,scbt_t_txn_cr_linkage_mst l 
where t.cty_code = 'SG' 
and product_code in ('FAWR','LAI') 
and nvl(txn_status_code,'01') <> '11'
--and t.txn_rec_id = l.txn_rec_id 
and t.cty_code = l.cty_code and t.BANK_GROUP_CODE = l.bank_group_code
--and t.txn_ref_id = l.txn_ref_id 
and t.deal_id = l.deal_id and t.cust_id = l.cust_id 
and l.cust_id='800002527'

--800002527,800002510 

select * from scbt_t_txn_mst where cust_id='800002527' and product_code in ('FAWR','LAI') and nvl(txn_status_code,'01') <> '11'

select * from scbt_t_txn_mst where cust_id='800002510' and product_code in ('FAWR','LAI') and nvl(txn_status_code,'01') <> '11'

select * from scbt_t_txn_cr_linkage_mst where cust_id='800002510'
===============================================================================
'ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM'
"BPRF:MCU2A0"*60%
LPLMECOPPERFUTURELME

SELECT COUNT(*) FROM SCBT_T_IPS_CAGG_BASEL_REF WHERE BUSINESS_DATE BETWEEN '30-DEC-2013' AND '31-DEC-2013' AND CTY_CODE IN ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM')

eRROR:SCBT_T_IPS_CAGG_FEED_MST_ERR


cagg Report - Master
====================

select succ.*, cust.party_name from scbt_t_ips_cagg_feed_mst succ, scbt_r_party_mst cust        
where  succ.business_date ='13-SEP-13' and
succ.cty_code = cust.cty_code and succ.cust_id=cust.party_id and 
succ.cty_code in ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM') 
order by succ.cty_code


select unsucc.*, cust.party_name from scbt_t_ips_cagg_feed_mst_err unsucc, scbt_r_party_mst cust        
where  unsucc.business_date ='13-SEP-13' and    
unsucc.cty_code = cust.cty_code and unsucc.cust_id=cust.party_id and 
unsucc.cty_code in ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM') 
order by unsucc.cty_code

cagg Report - History
=============================
--SCBT_T_IPS_CAGG_BASEL_REF
select succ_hist.*, cust.party_name from scbt_t_ips_cagg_feed_hist succ_hist, scbt_r_party_mst cust        
where succ_hist.business_date ='28-JUN-2013' and    
succ_hist.cty_code = cust.cty_code and succ_hist.cust_id=cust.party_id and 
succ_hist.cty_code in ('CN') 
order by succ_hist.cty_code

select unsucc.*, cust.party_name from scbt_t_ips_cagg_feed_mst_err unsucc, scbt_r_party_mst cust        
where  unsucc.business_date ='13-SEP-13' and    
unsucc.cty_code = cust.cty_code and unsucc.cust_id=cust.party_id and 
unsucc.cty_code in ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM') 
order by unsucc.cty_code

CAGG_PHYSICAL
CAGG_LINKED_CASH_MARGIN
CAGG_UNLINKED_CASH_MARGIN
CAGG_TOPUP_TXN_LEVEL
CAGG_TOPUP_CUST_LEVEL
CAGG_TOPUP_FACILITY_LEVEL
CAGG_UNLINKED_COLL_ERR
CAGG_BBTL_COLL
CAGG_BBTL_COLL

============commodity maint===========
select step_status_code,  Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1),COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
            COMMODITY_CODE
            from
            SCBT_R_COMMODITY_HIST where step_status_code in ('01', '11','02')  and BANK_GROUP_CODE='SCB'   and NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper('%')
            and upper(COMMODITY_TYPE_CODE) like upper('%') and upper(COMMODITY_CAT_CODE) like upper('%') and upper(EXCH_CODE) like upper('%') and upper(COMMODITY_OWNER) like ('%')
            and upper(HUB_BU_CODE) like ('GB779')  and upper(BU_CODE) like ('GB*') and upper(COMMODITY_ID) like upper('CM10000554')            
            UNION ALL
            select '03', Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1), COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
            COMMODITY_CODE
            from
            SCBT_R_COMMODITY_MST mst where BANK_GROUP_CODE='SCB'   AND  NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper('%')
            and upper(COMMODITY_CAT_CODE) like upper('%') and upper(EXCH_CODE) like upper('%') and upper(COMMODITY_OWNER) like ('%')
            and upper(HUB_BU_CODE) like ('GB779')  and upper(BU_CODE) like ('GB*') and upper(COMMODITY_TYPE_CODE) like upper('%') 
            and mst.BANK_GROUP_CODE='SCB' AND upper(COMMODITY_ID) like upper('CM10000554') and mst.COMMODITY_ID  NOT IN (select COMMODITY_ID from SCBT_R_COMMODITY_HIST 
            where step_status_code in ('01', '11','02') and COMMODITY_ID = mst.COMMODITY_ID  
            AND BANK_GROUP_CODE=mst.BANK_GROUP_CODE)

SELECT  Scbf_C_Get_Code_Desc('SCB', '*', '*', 'EN', 'CD007', 'LME', 1) FROM DUAL			
==============
SELECT * FROM SCBT_R_COMMODITY_HIST WHERE COMMODITY_ID='CM10000554'

SELECT * FROM SCBT_R_COMMODITY_MST WHERE COMMODITY_ID='CM10000554'

SELECT * FROM SCBT_R_COMMODITY_PRICE_MST WHERE FEED_ID IN ('LPLMECOPPERFUTURELME','425','MCU2A0')

SELECT * FROM SCBT_R_COMM_ADJ_VARIABLE

SELECT * FROM SCBT_R_COMMODITY_ADJ_DTLS

SELECT * FROM SCBT_R_COMMODITY_DTLS where commodity_id='CM10000554'

SELECT * FROM SCBT_R_COMMODITY_DTLS_HIST where commodity_id='CM10000554'

SELECT * FROM SCBT_R_COMMODITY_ADJ_DTLS where commodity_id='CM10000554'

SELECT * FROM SCBT_R_COMMODITY_MST

SELECT * FROM SCBT_R_COMMODITY_HIST
==========================================================================
SELECT DISTINCT SIP_DEAL_REF_NO FROM SCBT_T_INVENTORY_MST WHERE STORAGE_LOCATION_ID='SC000480001' --177 ,JBA-153A(2) , JBA-153B(2) , NUKA-190(2) , NUKA-199(2)

SELECT DISTINCT SIP_DEAL_REF_NO FROM SCBT_T_INVENTORY_HST WHERE STORAGE_LOCATION_ID='SC000480001' --301 , NUKA-218(2) , JBA-153A(2) , JBA-153B(2) , NUKA-190(2) , NUKA-199(2)

SELECT DISTINCT SIP_DEAL_REF_NO FROM SCBT_T_INVENTORY_SNAPSHOT WHERE STORAGE_LOCATION_ID='SC000480001' --444 , NUKA-218(2) , JBA-153A(2) , JBA-153B(2) ,NUKA-190(2) , NUKA-199(2) 

SELECT DISTINCT DEAL_ID FROM SCBT_T_PARCEL_MST WHERE STORAGE_LOCATION_ID='SC000480001'--14 , GB779T00260

SELECT DISTINCT DEAL_ID FROM SCBT_T_PARCEL_HST WHERE STORAGE_LOCATION_ID='SC000480001' --688 , GB779T00260
======================Approved securities CAGG  =============================================
select * from scbt_t_ips_sci_lmt_appr_sec where las_le_id='11268765' and las_lmt_id='20888630';

SELECT * FROM SCBT_R_PARAM_DATA WHERE PARAM_ID ='CA01' AND PARAM_DATA_02='CF1081' AND PARAM_KEY_03='OTHEN' AND PARAM_KEY_04='H'

UPDATE SCBT_R_PARAM_DATA SET PARAM_KEY_04='UH' WHERE PARAM_ID ='CA01' AND PARAM_DATA_02='CF1081' AND PARAM_KEY_03='OTHEN' AND PARAM_KEY_04='H'

SELECT * FROM SCBT_R_PARAM_DATA WHERE PARAM_ID ='CA01' AND PARAM_DATA_02='CF1082' AND PARAM_KEY_03='OTHEN' AND PARAM_KEY_04='UH'

UPDATE SCBT_R_PARAM_DATA SET PARAM_KEY_04='H' WHERE PARAM_ID ='CA01' AND PARAM_DATA_02='CF1082' AND PARAM_KEY_03='OTHEN' AND PARAM_KEY_04='UH'

=============================================================
SET DEFINE OFF;
Insert into SCBT_R_PARAM_DATA
   (BANK_GROUP_CODE, PARAM_ID, STEP_ID, CTY_CODE, PARTY_ID, TBU_CODE, PARAM_KEY_01, PARAM_KEY_02, PARAM_KEY_03, PARAM_KEY_04, PARAM_KEY_05, PARAM_KEY_06, PARAM_KEY_07, PARAM_KEY_08, PARAM_KEY_09, PARAM_KEY_10, PARAM_DATA_01, PARAM_DATA_02, PARAM_DATA_03, PARAM_KEY_SEQ_CODE)
 Values
   ('SCB', 'CA01', 'PARAMSTEP001', '*', '*', '*', 'PHY', 'EGY', 'OTHEN', 'UH', '*', '*', '*', '*', '*', '*', 'CF', 'CF1081', 'Energy - Others - Unhedged', '10001111000000');
COMMIT;


SET DEFINE OFF;
Insert into SCBT_R_PARAM_DATA
   (BANK_GROUP_CODE, PARAM_ID, STEP_ID, CTY_CODE, PARTY_ID, TBU_CODE, PARAM_KEY_01, PARAM_KEY_02, PARAM_KEY_03, PARAM_KEY_04, PARAM_KEY_05, PARAM_KEY_06, PARAM_KEY_07, PARAM_KEY_08, PARAM_KEY_09, PARAM_KEY_10, PARAM_DATA_01, PARAM_DATA_02, PARAM_DATA_03, PARAM_KEY_SEQ_CODE)
 Values
   ('SCB', 'CA01', 'PARAMSTEP001', '*', '*', '*', 'PHY', 'EGY', 'OTHEN', 'H', '*', '*', '*', '*', '*', '*', 'CF', 'CF1082', 'Energy - Others - Fixed Price / Hedged', '10001111000000');
COMMIT;



=================================================== 29 July ===================
select * from scbt_t_txn_hst where deal_id='AE123T03759'order by deal_step_id --TXN_REF_ID='AE123T06939TR002' --deal_step_id='AE123T05655M0006'


SELECT * FROM SCBT_T_IPS_CIS_SIP_DEAL

SELECT * FROM SCBT_T_IPS_CIS_IN_MSG where RECV_DATE > '28-JUL-2013' order by RECV_DATE DESC;

-- To Check the message and its deal details
SELECT SIPD.CIS_DEAL_REF,IN_MSG.MSG_ID,IN_MSG.MSG_TYPE,IN_MSG.RECV_DATE,SIPD.BUSINESS_DATE,SIPD.CIS_CUST_ID,SIPD.ACTION_TYPE,SIPD.IS_PROCESSED,
SIPD.DEAL_LEG,SIPD.MUREX_REF_NO  
FROM SCBT_T_IPS_CIS_IN_MSG IN_MSG
LEFT OUTER JOIN SCBT_T_IPS_CIS_SIP_DEAL SIPD
ON SIPD.MSG_ID = IN_MSG.MSG_ID
WHERE IN_MSG.MSG_TYPE='ONLINE' 
AND (SIPD.IS_PROCESSED is null or SIPD.IS_PROCESSED='N') 
AND SIPD.BANK_GROUP_CODE = 'SCB' AND SIPD.CTY_CODE in ('*','HK')
AND (UPPER(SIPD.ACTION_TYPE)=UPPER('Validated') or UPPER(SIPD.ACTION_TYPE)=UPPER('VALD'))
AND IN_MSG.MSG_CONTENT LIKE '%LTC-155%' 
ORDER BY IN_MSG.RECV_DATE DESC

SELECT * FROM SCBT_T_IPS_TP_SYSTEM_IN_MSG WHERE MSG_CONTENT LIKE '%123010249725%' order by recv_date desc -- 123010249725

SELECT * FROM SCBT_T_TD_TXN_LOG WHERE SYSTEM_CODE='OTP' /*AND DEAL_ID='TF128W0030-00001'*/ ORDER BY LOGGED_TIMESTAMP DESC;


SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE CUST_ID='800002532' AND CTY_CODE='SG'

SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST WHERE CUST_ID='800002532' AND CTY_CODE='SG'

SELECT * FROM SCBT_T_SOFT_LOCK WHERE USER_ID='1429233'

SELECT * FROM SCBT_S_DAILY_PARAM WHERE cty_code='AO' --BUSINESS_DATE='29-JUL-2013' and cty_code='AO' --30

select * from SCBT_T_DELETED_DEAL_STEP_DTLS where deal_step_id like 'AE123T05655%'

select * from scbt_t_txn_hst where deal_id='AE123T06939'order by deal_step_id --TXN_REF_ID='AE123T06939TR002' --deal_step_id='AE123T05655M0006'

select * from scbt_t_deal_hist where deal_id='AE123T06939'


select * from scbt_t_parcel_hst where deal_step_id like 'AE123T06939%'; AE123T03759

========================================Booking Location=====================
INSERT INTO SCBT_R_CODE_DATA(BANK_GROUP_CODE, CTY_CODE, TBU_CODE, LANG_CODE, CODE_ID, CODE_VALUE, STEP_ID, DESC_1, RECORD_LOCK_FLAG, PARENT_CODE_VALUE)
VALUES('SCB', '*', '*', 'EN', 'CD002', 'DF', 'G58W3ZG362-27336', 'DUBAI INTL FIN', 'N', 'CG2');

INSERT INTO SCBT_R_CODE_DATA(BANK_GROUP_CODE, CTY_CODE, TBU_CODE, LANG_CODE, CODE_ID, CODE_VALUE, STEP_ID, DESC_1, RECORD_LOCK_FLAG, PARENT_CODE_VALUE)
VALUES ('SCB', '*', '*', 'EN', 'CD099', 'DF', 'G58W3ZG362-27344', 'DUBAI INTL FIN', 'N', 'CG2');
======================================================================================================================

select * from scbt_r_param_data where param_id ='UC01' and param_key_01 = 'BBL' and param_key_02 = 'GAL'

select * from scbt_r_param_data where param_id ='UC01' and param_key_01 = 'GAL' and param_key_02 = 'BBL'

select * from scbt_r_code_data where desc_1 like 'Barr%'
===============================================================================================================
SET DEFINE OFF;
Insert into SCBT_T_COLLATERAL_REGISTER_HST
   (BANK_GROUP_CODE, CTY_CODE, DEAL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID, COLLATERAL_CATEGORY, COLLATERAL_SUB_CATEGORY, CUST_ID, IS_LC_CONFIRMED, ISSUE_DATE, IS_SANCTION_CHECK_DONE, GENERATE_REL_NOTE, RELEASE_AGAINST_CASH, TOTAL_CMV_CCY_AMT, TOTAL_CMV_CCY_CODE, TOTAL_NCV_CCY_AMT, TOTAL_NCV_CCY_CODE, TOTAL_GCV_CCY_AMT, TOTAL_GCV_CCY_CODE, CR_CCY_CODE, NCV_CCY_UTIL_AMT, RECEIVABLE_CCY_AMT, NCV_UTIL_PCT, PYMT_CCY_AMT, CONTROL_EXPORT_PROCEEDS, PARENT_COLLATERAL_ID, CR_STATUS_CODE, PHY_SALE_PRICE_CCY_AMT, MST_DEAL_STEP_ID, ORIGINAL_NCV_CCY_AMT, ORIGINAL_NCV_CCY_CODE, COLL_HEADER_NAME, IS_LC_PRICE_BASIS)
 Values
   ('SCB', 'GB', 'GB779T02696', 'GB779T02696002PP', '24314265', 'GB779T02696M0025', 'PHY', 'PURC', '800007199', 'N', TO_DATE('05/07/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'N', 'N', 'N', 0, 'USD', 0, 'USD', 0, 'USD', 'USD', 0, 0, 100, 0, 'N', 'GB779T02460001PP', '12', 0, 'GB779T02696A0046', 193586.48, 'USD', '13/0009', 'Y');
Insert into SCBT_T_COLLATERAL_REGISTER_HST
   (BANK_GROUP_CODE, CTY_CODE, DEAL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID, COLLATERAL_CATEGORY, COLLATERAL_SUB_CATEGORY, CUST_ID, IS_LC_CONFIRMED, ISSUE_DATE, IS_SANCTION_CHECK_DONE, GENERATE_REL_NOTE, RELEASE_AGAINST_CASH, TOTAL_CMV_CCY_AMT, TOTAL_CMV_CCY_CODE, TOTAL_NCV_CCY_AMT, TOTAL_NCV_CCY_CODE, TOTAL_GCV_CCY_AMT, TOTAL_GCV_CCY_CODE, CR_CCY_CODE, NCV_CCY_UTIL_AMT, RECEIVABLE_CCY_AMT, NCV_UTIL_PCT, PYMT_CCY_AMT, CONTROL_EXPORT_PROCEEDS, CR_STATUS_CODE, MST_DEAL_STEP_ID, ORIGINAL_NCV_CCY_AMT, ORIGINAL_NCV_CCY_CODE, COLL_HEADER_NAME, IS_LC_PRICE_BASIS)
 Values
   ('SCB', 'GB', 'GB779T02696', 'GB779T02696001PP', '24314266', 'GB779T02696M0025', 'PHY', 'PURC', '800007199', 'N', TO_DATE('05/31/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'N', 'N', 'N', 0, 'USD', 0, 'USD', 0, 'USD', 'USD', 0, 0, 100, 0, 'N', '12', 'GB779T02696A0046', 743656.08, 'USD', '13/0009A', 'Y');


Insert into SCBT_T_PARCEL_HST
   (BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID, COLLATERAL_LIMIT_ID, PARCEL_TYPE_CODE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, COMMODITY_ID, COMMODITY_QNTY, COMMODITY_QNTY_UOM, UTILISED_QNTY, UTILISED_QNTY_UOM, ADJUSTMENT_QNTY, ADJUSTMENT_QNTY_UOM, NET_COMMODITY_QNTY, NET_COMMODITY_UOM, POSITIVE_TOLERANCE_PCT, NEGATIVE_TOLERANCE_PCT, DEAL_ID, DELIV_SCHEDULE_CODE, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PARCEL_REL_DATE, PRICE_BASIS_CODE, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_CODE, MARKET_PRICE_CCY_AMT, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_CCY_AMT, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_UOM, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_UOM, STORAGE_CTY_CODE, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_UOM, PRICE_ADJUST, SEC_COMMODITY_QNTY, SEC_UTILISED_QNTY, SEC_ADJUSTMENT_QNTY, SEC_NET_COMMODITY_QNTY, PRIM_SEC_UOM_CONVERSION_FACTOR, APPL_PRICE_BASIS_CODE, CR_STATUS_CODE, PREV_DEAL_STEP_ID, PARCEL_LEVEL_ADJ_FLAG, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, ORIGINAL_PRICE_BASE_CCY, ORIGINAL_PRICE_BASE_AMT, ORIGINAL_PRICE_BASE_UOM, MST_NET_QNTY, MST_UTIL_QNTY, MST_SEC_NET_QNTY, MST_SEC_UTIL_QNTY)
 Values
   ('SCB', 'GB', 'PP00063702', 'GB779T02696001PP', '24314268', 'GB779T02696M0025', '18462', 'PUR', 'GAWR', 'SUS', 'CM10000566', 1360, 'T', 1360, 'T', 0, 'T', 1360, 'T', 0, 0, 'GB779T02696', 'CSH', TO_DATE('05/31/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/25/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/21/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('07/18/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'PUP', 100, 'USD', 488.3, 'T', 'USD', 810.48, 'T', 'USD', 'T', 0, 'USD', 0, 'USD', 0, 'USD', 'USD', 'T', 'TZ', 4, 270, 'T', 1, '03', '10054402', 'USD', 488.3, 'T', 0, 0, 0, 0, 0, 1, 'PUP', 'H', 'GB779T02696A0046', 'D', 'N', 'N', 'USD', 810.48, 'T', 1360, 442.44981, 0, 0);
Insert into SCBT_T_PARCEL_HST
   (BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID, COLLATERAL_LIMIT_ID, PARCEL_TYPE_CODE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, COMMODITY_ID, COMMODITY_QNTY, COMMODITY_QNTY_UOM, UTILISED_QNTY, UTILISED_QNTY_UOM, ADJUSTMENT_QNTY, ADJUSTMENT_QNTY_UOM, NET_COMMODITY_QNTY, NET_COMMODITY_UOM, POSITIVE_TOLERANCE_PCT, NEGATIVE_TOLERANCE_PCT, DEAL_ID, DELIV_SCHEDULE_CODE, DELIV_SCHEDULE_YEAR, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PARCEL_REL_DATE, PRICE_BASIS_CODE, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_CODE, MARKET_PRICE_CCY_AMT, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_CCY_AMT, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_CCY_AMT, SALE_PRICE_UOM, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_CCY_AMT, MANUAL_PRICE_UOM, STORAGE_CTY_CODE, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_UOM, PRICE_ADJUST, PARENT_PARCEL_ID, SEC_COMMODITY_QNTY, SEC_UTILISED_QNTY, SEC_ADJUSTMENT_QNTY, SEC_NET_COMMODITY_QNTY, PRIM_SEC_UOM_CONVERSION_FACTOR, APPL_PRICE_BASIS_CODE, RECEIVABLE_CCY_AMT, CR_STATUS_CODE, PREV_DEAL_STEP_ID, PARCEL_LEVEL_ADJ_FLAG, TRANS_DIFFERENTIAL_CCY_AMT, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, ORIGINAL_PRICE_BASE_CCY, ORIGINAL_PRICE_BASE_AMT, ORIGINAL_PRICE_BASE_UOM, MST_NET_QNTY, MST_UTIL_QNTY, MST_SEC_NET_QNTY, MST_SEC_UTIL_QNTY)
 Values
   ('SCB', 'GB', 'PP00068995', 'GB779T02696002PP', '24314267', 'GB779T02696M0025', '18462', 'PUR', 'GAWR', 'SUS', 'CM10000566', 844.91517, 'T', 844.91517, 'T', 0, 'T', 844.91517, 'T', 0, 0, 'GB779T02696', 'CSH', 0, TO_DATE('05/07/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/01/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/28/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('07/18/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'PUP', 100, 'USD', 488.3, 'T', 'USD', 820.661225, 'T', 'USD', 0, 'T', 0, 'USD', 0, 'USD', 0, 'USD', 'USD', 0, 'T', 'ZW', 4, 270, 'T', 1, '03', '10054402', 'USD', 488.3, 'T', 0, 'PP00060165', 0, 0, 0, 0, 1, 'PUP', 0, 'H', 'GB779T02696A0046', 'D', 0, 'N', 'N', 'USD', 820.661, 'T', 844.91517, 609.02431, 0, 0);
COMMIT;
   
======================
UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='10-AUG-2013',PREV_BUSINESS_DATE='08-AUG-2013',NEXT_BUSINESS_DATE='11-AUG-2013' 
WHERE CTY_CODE IN ('AO','PK') 

SELECT * FROM SCBT_S_DAILY_PARAM WHERE CTY_CODE IN ('AO','QA','PH','OM','PK') --AND BUSINESS_DATE<>'10-AUG-2013'

SELECT * FROM SCBT_R_LOCAL_HOLIDAY_MST WHERE CTY_CODE IN ('AO','QA','PH','OM','PK') AND YEAR='2013' AND HOLIDAY_DATE > '08-AUG-2013' AND HOLIDAY_DATE < '11-AUG-2013'

SELECT * FROM SCBT_R_LOCAL_HOLIDAY_MST WHERE CTY_CODE IN ('AO','AE','PK') AND YEAR='2013'

SELECT * FROM SCBT_S_DAILY_PARAM WHERE CTY_CODE IN ('AO','PK') --AND BUSINESS_DATE<>'10-AUG-2013'
===================================================

SET DEFINE OFF;

Insert into SCBT_R_PARAM_DATA
   (BANK_GROUP_CODE, PARAM_ID, STEP_ID, CTY_CODE, PARTY_ID, TBU_CODE, PARAM_KEY_01, PARAM_KEY_02, PARAM_KEY_03, PARAM_KEY_04, PARAM_KEY_05, PARAM_KEY_06, PARAM_KEY_07, PARAM_KEY_08, PARAM_KEY_09, PARAM_KEY_10, PARAM_DATA_01, PARAM_DATA_02, PARAM_KEY_SEQ_CODE, RECORD_LOCK_FLAG)
 Values
   ('SCB', 'TP04', 'ZQ2HK52ZH9-583', 'CN', '*', '*', '1463227', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'USD', '0', '10010000000000', 'N');
   
Insert into SCBT_R_PARAM_DATA
   (BANK_GROUP_CODE, PARAM_ID, STEP_ID, CTY_CODE, PARTY_ID, TBU_CODE, PARAM_KEY_01, PARAM_KEY_02, PARAM_KEY_03, PARAM_KEY_04, PARAM_KEY_05, PARAM_KEY_06, PARAM_KEY_07, PARAM_KEY_08, PARAM_KEY_09, PARAM_KEY_10, PARAM_DATA_01, PARAM_DATA_02, PARAM_KEY_SEQ_CODE, RECORD_LOCK_FLAG)
 Values
   ('SCB', 'TP04', 'ZQ2HK52ZH9-583', 'CN', '*', '*', '1456740', '*', '*', '*', '*', '*', '*', '*', '*', '*', 'USD', '0', '10010000000000', 'N');   

COMMIT;

DSR-- TP04
select PARAM_KEY_01,Scbf_Get_User_Name('SCB',PARAM_KEY_01) as USER_NAME,PARAM_DATA_01,PARAM_DATA_02 from scbt_r_param_data where PARAM_ID ='TP04' AND CTY_CODE='IN' 


=========================== User Access==============================
SELECT Scbf_Get_User_Name('SCB',UMST.USER_ID) as USER_ID,CODE.CODE_VALUE,UFA.FUNCTION_CODE,MFUNC.QUICK_LAUNCH_CODE,CODE.DESC_1 
FROM SCBT_R_USER_MST UMST, SCBT_R_USER_FUNC_ACCS_MST UFA,SCBT_S_MODULE_FUNC_DEFN MFUNC,SCBT_R_CODE_DATA CODE
WHERE UMST.USER_ID = UFA.USER_ID
AND CODE.CODE_VALUE = UFA.FUNCTION_CODE
AND CODE.CODE_VALUE = MFUNC.MODULE_FUNC_CODE
AND UMST.USER_BRCH_CODE LIKE 'HK%'
AND UFA.FUNCTION_CODE LIKE 'M%'
AND MFUNC.QUICK_LAUNCH_CODE = MFUNC.NODE_ID

select * from SCBT_R_USER_MST where User_Name='Hinchcliffe,Michael Robert' --1408848

select * from SCBT_R_USER_MST where User_Name='Wong,Sin Man' --1443491

select * from SCBT_R_USER_MST where User_Name='Zheng,Yu' --1336502

=============================================================================================

SELECT * FROM SCBT_R_COMMODITY_PRICE_MST WHERE FEED_ID IN ('D-AANTB00','ANSINGMOGAS92SWANYM')

SELECT * FROM SCBT_R_COMMODITY_PRICE_MST WHERE UPPER(FEED_NAME)  LIKE UPPER('%MOGAS%') AND SOURCE_TYPE_CODE='AUTO'

SELECT * FROM SCBT_R_COMMODITY_PRICE_MST WHERE FEED_ID ='D-AANTB00'

SELECT * FROM SCBT_R_COMMODITY_DTLS WHERE COMMODITY_ID='CM10002246'

SELECT SOURCE_TYPE_CODE,FEED_NAME,FEED_ID,VENDOR_FEED_ID,PRICE_SOURCE_CODE,QUOTE_PRICE_UOM,FEED_PRICE_UOM,FEED_PRICE_CCY,FEED_PRICE_AMT,SOURCE_FILE_NAME
FROM SCBT_R_COMMODITY_PRICE_MST WHERE UPPER(FEED_NAME)  LIKE '%MOGAS%' AND SOURCE_TYPE_CODE='AUTO'
===================== SIP CUST NAME CHANGE REQUEST==========================
SELECT * FROM SCBT_T_INVENTORY_MST WHERE SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' ORDER BY LATEST_DEAL_STEP_ID DESC -- 48 records

SELECT * FROM SCBT_T_INVENTORY_HST WHERE SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' ORDER BY DEAL_STEP_ID DESC -- 142 records

SELECT * FROM SCBT_T_INVENTORY_SMRY WHERE SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' -- 1 record

SELECT * FROM SCBT_T_INVENTORY_SMRY_MVMT WHERE SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' --4 records

SELECT * FROM SCBT_T_INVENTORY_SNAPSHOT WHERE SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' --94 records

SELECT * FROM SCBT_T_SIP_DEAL_SMRY_MST WHERE  SIP_DEAL_REF_NO = 'OLCF-129(2)' AND CUST_ID='800007916' -- 1RECORD

SELECT * FROM SCBT_T_INVENTORY_SMRY_HST WHERE SIP_DEAL_REF_NO LIKE '%OLCF-129(2)%' AND CUST_ID='800007916' -- No records 

SELECT * FROM SCBT_T_DEAL_MST WHERE DEAL_ID='US777S01035' -- 1 RECORD
================================================================================================
SELECT * FROM SCBT_T_RECON_DB 

SELECT * FROM SCBT_R_RECON_DB_SETUP
============================== IM0000016619587 =======================================
SELECT * FROM SCBT_T_DEAL_MST WHERE CUST_ID='800014500' AND DEAL_ID='CN333F00072'

SELECT * FROM SCBT_T_DEAL_HIST WHERE DEAL_ID LIKE 'CN333F00072' AND deal_step_id='CN333F00072A0134' --step_code<>'AUTO'

UPDATE SCBT_T_DEAL_HIST SET co_borrower_id='800008329' WHERE DEAL_ID = 'CN333F00072' AND deal_step_id='CN333F00072A0134'

UPDATE SCBT_T_DEAL_HIST SET co_borrower_id='800008329' WHERE CUST_ID='800014500' AND DEAL_ID = 'CN333F00072' AND deal_step_id='CN333F00072A0145'

UPDATE SCBT_T_DEAL_HIST SET co_borrower_id='800008329' WHERE CUST_ID='800014500' AND DEAL_ID = 'CN333F00072' AND deal_step_id='CN333F00072A0147'

SET DEFINE OFF;
Insert into SCBT_R_REPORT_USER_LIST
   (USER_ID, USER_NAME, PASSWORD, URL, BIP_FLAG)
 Values
   (4, 'FM_USER', 'FM123456', 'http://10.20.223.142:8704/analytics/saw.dll?Dashboard&NQUser=##&NQPassword=@@&NQCountry=%%', 'N');
COMMIT;

==================
IM0000016522324 (WIP) : PM0000000016395 : APPLICATION--COCOA : Txn not part of exposure is being shown in client positions, facility collateral summary section.

IM0000016523641 (Suspended) - Closed
IM0000016523641 (Suspended) - Closed
=========================EBBS RECON 1====================================================
select * from SCBT_T_IPS_CB_ACCT_BALANCE WHERE ACCOUNTNO ='52205709202';
select * from SCBT_T_IPS_CB_ACCT_TXN_DTLS WHERE ACCOUNTNO ='52205709202';
select * from SCBT_T_IPS_CB_ACCT_DEP_DTLS WHERE ACCOUNTNO ='52205709202';
SELECT * from SCBT_T_CUST_EXT_ACCOUNTS_MST WHERE ACCOUNT_NUMBER='52205709202';
select * from SCBT_T_CUST_RECONCIL_SMRY_MST WHERE CTY_CODE='IN';

select distinct source_file_name from SCBT_T_IPS_CB_ACCT_BALANCE where trunc(processed_timestamp)=trunc(sysdate-1);
select distinct source_file_name from SCBT_T_IPS_CB_ACCT_DEP_DTLS where trunc(processed_timestamp)=trunc(sysdate-1);
select distinct source_file_name from SCBT_T_IPS_CB_ACCT_TXN_DTLS where trunc(processed_timestamp)=trunc(sysdate-1);

select RELATIONSHIPNO,ACCOUNTNO,SOURCE_FILE_NAME,PROCESSED_TIMESTAMP
from SCBT_T_IPS_CB_ACCT_BALANCE where source_file_name like '%AE%' and PROCESSED_TIMESTAMP IS NOT NULL ORDER BY PROCESSED_TIMESTAMP DESC

select ACCOUNTNO,PRINICIPAL_AMT,COUNTRY_CODE,SOURCE_FILE_NAME,PROCESSED_TIMESTAMP 
from SCBT_T_IPS_CB_ACCT_DEP_DTLS where source_file_name like '%AE%' and PROCESSED_TIMESTAMP IS NOT NULL ORDER BY PROCESSED_TIMESTAMP DESC

select RELATIONSHIPNO,ACCOUNTNO,MAKERID,SOURCE_FILE_NAME,PROCESSED_TIMESTAMP from SCBT_T_IPS_CB_ACCT_TXN_DTLS 
where source_file_name like '%AE%' and PROCESSED_TIMESTAMP IS NOT NULL ORDER BY PROCESSED_TIMESTAMP DESC



reconcile_account_type;
Scbt_r_Code_Data;
SCBT_R_CUST_ACCT_MAINTENANCE;
SCBT_R_PARTY_EXT_ID;
SCBT_S_DAILY_PARAM;
SCBT_T_CB_ACCT_TRAN_SMRY_MST;
SCBT_T_CUST_ACC_SMRY_MST;
SCBT_T_CUST_EXT_ACCOUNTS_HST;
SCBT_T_CUST_EXT_ACCOUNTS_MST;
SCBT_T_CUST_RECONCIL_SMRY_MST;
SCBT_T_IPS_CB_ACCT_BALANCE;
SCBT_T_IPS_CB_ACCT_DEP_DTLS;
SCBT_T_IPS_CB_ACCT_TXN_DTLS;
SCBT_T_IPS_SCI_CUST_SYSXREF;


SELECT ACCOUNT_NUMBER, ACCOUNT_CCY, INPUT_SOURCE, ACCOUNT_TYPE
            FROM SCBT_T_CUST_EXT_ACCOUNTS_MST
            WHERE CUSTOMER_ID in (
                SELECT LSX_EXT_SYS_CUST_ID FROM SCBT_T_IPS_SCI_CUST_SYSXREF 
                    WHERE LSX_LE_ID='11253758'
                AND UPPER(LSX_EXT_SYS_CODE_VALUE) in ('EBBS', 'HOGAN'))

SELECT CUSTOMER_ID,ACCOUNT_NUMBER, ACCOUNT_CCY, INPUT_SOURCE, ACCOUNT_TYPE
            FROM SCBT_T_CUST_EXT_ACCOUNTS_MST
            WHERE CUSTOMER_ID in (
                SELECT LSX_EXT_SYS_CUST_ID FROM SCBT_T_IPS_SCI_CUST_SYSXREF 
                    WHERE LSX_LE_ID IN ('11334298','11170881','11236901','11332251','11205375','11236836','11268765')
                AND UPPER(LSX_EXT_SYS_CODE_VALUE) in ('EBBS', 'HOGAN'))
                
SELECT * FROM SCBT_R_PARTY_EXT_ID WHERE PARTY_ID IN ('800012499')				
				
==========================================AE EBBS======================================
echo "-o /apps/AE/workingdir/eBBS/COCSL/AEEBBS -i /prd/cocoa/batch/download/ebbs/history/AEEBBS130821 -s AE.CCA.CCA.AE.EBS.EBS.CUSTDTLS" > /prd/cocoa/hk/bin/scripts/config/AE/EBBSCSL.cfg

/prd/isis/hk/bin/isisftrq HKCCA1P1 < /prd/cocoa/hk/bin/scripts/config/AE/EBBSCSL.cfg 

FTF ID : ed1afcbc-9aa3-11bd-85e9-813ec7938173
======================================================== deleted========================================
delete FROM SCBT_T_DELETED_DEAL_STEP_DTLS WHERE DEAL_STEP_ID ='SG957T08216M0004' and maker_id='1421803'
SET DEFINE OFF;
Insert into SCBT_T_DELETED_DEAL_STEP_DTLS
   (BANK_GROUP_CODE, CTY_CODE, BU_CODE, CUST_ID, DEAL_ID, DEAL_STEP_ID, BUSINESS_DATE, VALUE_DATE, STEP_CODE, STEP_STATUS_CODE, MAKER_ID, MAKER_TIMESTAMP, MANUAL_EXCEPTION_FLAG, EXCEPTION_PRE_APPROVED_FLAG, DELETED_BY_ID, DELETED_TIMESTAMP, TP_REJECT_FLAG)
 Values
   ('SCB', 'SG', 'SG957', '800009924', 'SG957T08216', 'SG957T08216M0004', TO_DATE('04/10/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('04/10/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'CTL', '09', '1421803', TO_DATE('04/10/2013 10:03:40', 'MM/DD/YYYY HH24:MI:SS'), 'N', 'N', '1421803', TO_DATE('04/10/2013 10:04:11', 'MM/DD/YYYY HH24:MI:SS'), 'N');
COMMIT;			
	
===========================CTY CODES================
'AE','AO','BD','BH','BW','CI','CM','CN','DF','GB','GH','GM','HK','ID','IN','IQ','JO','JP','KE','LK','MO','MU','MY','MZ','NG','NP','OM','PH','PK','QA','SG','SL','TH','TW','TZ','UG','US','VN','ZA','ZM','ZW'
========================== commdity daily patch ======================================
SELECT  m.commodity_id AS inventory_mst,s.commodity_id AS summary_mst
FROM SCBT_T_INVENTORY_MST m, SCBT_T_INVENTORY_SMRY s
WHERE m.CUST_ID=s.CUST_ID
AND m.deal_ID=s.deal_ID
AND s.COMMODITY_ID<>m.COMMODITY_ID AND m.INVENTORY_TYPE_CODE='MST' AND (m.NET_COMMODITY_QNTY-m.UTILISED_QNTY) >0
-- 2 records

UPDATE SCBT_T_INVENTORY_MST m SET m.commodity_id=(SELECT s.commodity_id FROM SCBT_T_INVENTORY_SMRY s WHERE m.CUST_ID=s.CUST_ID
AND m.deal_ID=s.deal_ID AND m.bank_group_code=s.bank_group_code AND m.cty_code=s.cty_code
)
WHERE  m.deal_id IN (
SELECT DISTINCT s.deal_id FROM SCBT_T_INVENTORY_SMRY s WHERE m.CUST_ID=s.CUST_ID
AND m.deal_ID=s.deal_ID AND m.bank_group_code=s.bank_group_code AND s.COMMODITY_ID<>m.COMMODITY_ID)
AND m.INVENTORY_TYPE_CODE='MST' AND (m.NET_COMMODITY_QNTY-m.UTILISED_QNTY) >0
======================= UOMs===========================================================
SELECT PARAM_KEY_01 SOURCE_ABBR, S.DESC_1 SOURCE, PARAM_KEY_02 TARGET_ABBR,T.DESC_1 TARGET, PARAM_DATA_01 CONVERSION_VALUE FROM SCBT_R_PARAM_DATA D, SCBT_R_CODE_DATA S, SCBT_R_CODE_DATA T WHERE PARAM_ID='UC01'
======================================================

SELECT * FROM SCBT_T_PARCEL_HST WHERE DEAL_ID ='HK514T05816' AND DEAL_STEP_ID='HK514T05816M0003' AND COLLATERAL_ID='HK514T05816001CN'
AND UTILISED_QNTY='396.9998' AND CMV_CCY_AMT='0.05' AND GCV_CCY_AMT='0.05' AND NCV_CCY_AMT='0.05'

UPDATE SCBT_T_PARCEL_HST SET UTILISED_QNTY='396.9999',CMV_CCY_AMT='0.0', GCV_CCY_AMT='0.0', NCV_CCY_AMT='0.0'
WHERE DEAL_ID ='HK514T05816' AND DEAL_STEP_ID='HK514T05816M0003' AND COLLATERAL_ID='HK514T05816001CN'
AND UTILISED_QNTY='396.9998' AND CMV_CCY_AMT='0.05' AND GCV_CCY_AMT='0.05' AND NCV_CCY_AMT='0.05'

SELECT * FROM SCBT_T_PARCEL_HST WHERE DEAL_ID ='HK514T05816' AND DEAL_STEP_ID='HK514T05816M0003' AND COLLATERAL_ID='HK514T05816003RL' AND
COMMODITY_QNTY='396.9998' AND NET_COMMODITY_QNTY='396.9998'

UPDATE SCBT_T_PARCEL_HST SET COMMODITY_QNTY='396.9999',NET_COMMODITY_QNTY='396.9999'
WHERE DEAL_ID ='HK514T05816' AND DEAL_STEP_ID='HK514T05816M0003' AND COLLATERAL_ID='HK514T05816003RL' AND
COMMODITY_QNTY='396.9998' AND NET_COMMODITY_QNTY='396.9998'

SELECT * FROM SCBT_T_PARCEL_MST WHERE DEAL_ID ='HK514T05816' AND PARCEL_TYPE_CODE='CON' AND UTILISED_QNTY='396.9998' AND CMV_CCY_AMT='0.05'
AND GCV_CCY_AMT='0.05' AND NCV_CCY_AMT='0.05'

UPDATE SCBT_T_PARCEL_MST SET UTILISED_QNTY='396.9999' , CMV_CCY_AMT='0.0' , GCV_CCY_AMT='0.0' , NCV_CCY_AMT='0.0'
WHERE DEAL_ID ='HK514T05816' AND PARCEL_TYPE_CODE='CON' AND UTILISED_QNTY='396.9998' AND CMV_CCY_AMT='0.05'
AND GCV_CCY_AMT='0.05' AND NCV_CCY_AMT='0.05'

SELECT * FROM SCBT_T_PARCEL_MST 
WHERE DEAL_ID ='HK514T05816' AND PARCEL_TYPE_CODE='REL' AND COMMODITY_QNTY='396.9998' AND NET_COMMODITY_QNTY='396.9998'

UPDATE SCBT_T_PARCEL_MST SET COMMODITY_QNTY='396.9999' , NET_COMMODITY_QNTY='396.9999'
WHERE DEAL_ID ='HK514T05816' AND PARCEL_TYPE_CODE='REL' AND COMMODITY_QNTY='396.9998' AND NET_COMMODITY_QNTY='396.9998'

SELECT * FROM SCBT_T_COLLATERAL_REGISTER_HST WHERE COLLATERAL_ID = 'HK514T05816001CN' AND DEAL_STEP_ID='HK514T05816M0003' AND
TOTAL_NCV_CCY_AMT='0.05' AND TOTAL_GCV_CCY_AMT='0.05' AND TOTAL_CMV_CCY_AMT='0.05'

UPDATE SCBT_T_COLLATERAL_REGISTER_HST SET TOTAL_NCV_CCY_AMT='0.0' , TOTAL_GCV_CCY_AMT='0.0' , TOTAL_CMV_CCY_AMT='0.0'
WHERE COLLATERAL_ID = 'HK514T05816001CN' AND DEAL_STEP_ID='HK514T05816M0003' AND
TOTAL_NCV_CCY_AMT='0.05' AND TOTAL_GCV_CCY_AMT='0.05' AND TOTAL_CMV_CCY_AMT='0.05'

--SELECT * FROM SCBT_T_COLLATERAL_REGISTER_HST WHERE COLLATERAL_ID ='HK514T05816003RL' AND DEAL_STEP_ID='HK514T05816M0003'

SELECT * FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE COLLATERAL_ID IN ('HK514T05816001CN') AND LATEST_DEAL_STEP_ID='HK514T05816M0003'
AND TOTAL_NCV_CCY_AMT='0.05' AND TOTAL_GCV_CCY_AMT='0.05' AND TOTAL_CMV_CCY_AMT='0.05'

UPDATE SCBT_T_COLLATERAL_REGISTER_MST SET TOTAL_NCV_CCY_AMT='0.0' , TOTAL_GCV_CCY_AMT='0.0' , TOTAL_CMV_CCY_AMT='0.0'
WHERE COLLATERAL_ID IN ('HK514T05816001CN') AND LATEST_DEAL_STEP_ID='HK514T05816M0003'
AND TOTAL_NCV_CCY_AMT='0.05' AND TOTAL_GCV_CCY_AMT='0.05' AND TOTAL_CMV_CCY_AMT='0.05'
==================================== Global reports====================================
UPDATE SCBT_R_USER_MST SET GLOBAL_REPORTS_ACCESS='GB779' where user_id ='1194885'

UPDATE SCBT_R_USER_MST SET GLOBAL_REPORTS_ACCESS='AE123,CN333,GB779,HK514,ID901,IN529,SG957,US777,ZA227' where user_id ='1433068'

SELECT * FROM SCBT_R_TBU_MST WHERE TBU_CODE =HUB_BU_CODE
========================================================TR Health check==============================
select distinct file_name from SCBT_T_IPS_TR_DATA_STREAM where business_date='13-MAR-2014' order by business_date desc 

select distinct file_name from SCBT_T_IPS_TR_DATASCOPE where business_date='13-MAR-2014'  order by business_date desc

select distinct file_name from SCBT_T_IPS_TR_RMDS where business_date='13-MAR-2014'  order by business_date desc
==================== mARTIN
UPDATE SCBT_T_IPS_SCI_APPR_LMTPROF SET LLP_EXTD_NEXT_RVW_DATE='' WHERE TO_CHAR(LLP_LE_ID) in ('11193147') AND LLP_EXTD_NEXT_RVW_DATE='31-AUG-2013'


800010866 - 11193147 - Done - Castleton Commodities
800010602 - 11289296 - 		MERCURIA ENERGY
800010848 - 11324140 -		KIRAN JEWELS INC
800010926 - 11269032 - 		TALY DIAMONDS LLC


DELETE FROM SCBT_R_PARTY_HIST WHERE PARTY_ID='800010926' AND STEP_STATUS_CODE<>'03' AND MAKER_ID='1003689'

DELETE FROM SCBT_R_PARTY_HIST WHERE PARTY_ID='800010602' AND STEP_STATUS_CODE<>'03' AND MAKER_ID='1317356'



select step_status_code,PARTY_ID,PARTY_NAME, CTY_CODE, ADD_1,ADD_2,ADD_3,ADD_CTY_CODE,OPEN_DATE,
        	RESIDENCE_CTY_CODE,INDUSTRY_CODE,RM_CODE,SPECIAL_REMARKS
        	from scbt_r_party_hist where step_status_code ='02' and party_id like '%'
			AND (replace(PARTY_NAME_UPP, ' ','') like replace('%', ' ', '') or replace('%', ' ', '') like replace(party_name_upp, ' ', '')) 
			and cty_code = 'US' and BANK_GROUP_CODE='SCB'
			
SELECT step_status_code, party_id, party_name, cty_code, add_1, add_2, add_3,
		    add_cty_code, open_date, residence_cty_code, industry_code, rm_code,special_remarks
		  	FROM scbt_r_party_hist hist
		 	WHERE hist.step_status_code IN ('01', '11','02') AND hist.cty_code = 'US' AND hist.party_id LIKE '%'
		    AND (replace(hist.party_name_upp, ' ', '') like replace('%', ' ', '') OR replace('%', ' ', '') like replace(hist.party_name_upp, ' ', ''))  
		    AND hist.bank_group_code = 'SCB'
			UNION ALL
			SELECT '03', party_id, party_name, cty_code, add_1, add_2, add_3,
		       add_cty_code, open_date, residence_cty_code,industry_code, rm_code,special_remarks
		    FROM scbt_r_party_mst mst
		 	WHERE party_id LIKE '%'
		 	AND (replace(party_name_upp, ' ', '') like replace('%', ' ', '') OR replace('%', ' ', '') like replace(party_name_upp, ' ', ''))
		    AND ((   cty_code = 'US' AND party_id NOT IN (
					SELECT party_id
		            FROM scbt_r_party_hist
		            WHERE step_status_code IN ('01', '11', '02') AND party_id =  mst.party_id AND cty_code = mst.cty_code
		              AND bank_group_code = mst.bank_group_code)
					 )
		        OR ( cty_code = '*' AND NOT EXISTS (
		                    SELECT 1
		                      FROM scbt_r_party_hist p
		                      WHERE p.step_status_code IN ('01', '11', '02','03') AND p.bank_group_code = mst.bank_group_code
		                       AND p.cty_code = 'US' AND p.party_id= mst.party_id)
							  )
		        OR (cty_code = '*' AND EXISTS (
		                    SELECT 1
		                      FROM scbt_r_party_hist p
		                      WHERE p.step_status_code IN ('01', '11', '02','03') AND p.bank_group_code = mst.bank_group_code
		                      AND p.step_code = '06' AND p.cty_code = 'US'
		                       AND p.party_id= mst.party_id)
					  )
			)
		   AND mst.bank_group_code = 'SCB'
		   AND mst.CUSTODIAN = 'N' 			

==================================
SELECT * FROM SCBT_T_TXN_CR_LINKAGE_MST WHERE DEAL_ID='GH501T00105' AND COLLATERAL_ID='GH501T00105001PP' --GH501T00105M0004

SELECT * FROM SCBT_T_TXN_CR_LINKAGE_HST WHERE DEAL_ID='GH501T00105' AND COLLATERAL_ID='GH501T00105001PP' ORDER BY DEAL_STEP_ID DESC

SELECT * FROM SCBT_T_TXN_CR_LINKAGE_MST WHERE DEAL_ID='CN121T00003' AND COLLATERAL_ID='CN121T00003001PP' --GH501T00105M0004

SELECT * FROM SCBT_T_TXN_CR_LINKAGE_HST WHERE DEAL_ID='CN121T00003' AND COLLATERAL_ID='CN121T00003001PP'

===================
SELECT collateral_id,parent_collateral_id,deal_step_id,cust_id FROM SCBT_T_COLLATERAL_REGISTER_HST WHERE deal_id='GB779T03913'

SELECT collateral_id,parent_collateral_id FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE cust_id='800007199'
AND parent_collateral_id LIKE deal_id||'%'
========================
SELECT collateral_id,parent_collateral_id FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE cust_id='800007199'
AND parent_collateral_id LIKE deal_id||'%';

UPDATE SCBT_T_COLLATERAL_REGISTER_MST SET parent_collateral_id='' WHERE 
collateral_id IN ('GB779T02696005PP','GB779T02696006PP','GB779T03167006PP','GB779T03167007PP');

DELETE FROM SCBT_T_COLLATERAL_REGISTER_HST WHERE rec_id='26420451' AND collateral_id='GB779T02696002PP'
AND deal_step_id='GB779T02696M0036';


SELECT NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_CMV_BY_TXN_REC_ID('SCB',
'HK',
'800009773',
SCBF_GET_EXP_CCY('SCB','HK','800009773'),
'19480488',
'USD',
'UTIL',
'M',
''),0) FROM DUAL
==================================UG328T00006=========================
select PARCEL_ID,PARENT_PARCEL_ID,LINK_PARCEL_ID,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_mst WHERE deal_id='UG328T00006' AND (PARCEL_ID='PP00051423' OR PARENT_PARCEL_ID='PP00051423' OR LINK_PARCEL_ID='PP00051423')
=========================== PP00051187=============

SET DEFINE OFF;
Insert into SCBT_T_PARCEL_HST
   (BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID, COLLATERAL_LIMIT_ID, PARCEL_TYPE_CODE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, COMMODITY_ID, COMMODITY_QNTY, COMMODITY_QNTY_UOM, UTILISED_QNTY, UTILISED_QNTY_UOM, ADJUSTMENT_QNTY, ADJUSTMENT_QNTY_UOM, NET_COMMODITY_QNTY, NET_COMMODITY_UOM, POSITIVE_TOLERANCE_PCT, NEGATIVE_TOLERANCE_PCT, DEAL_ID, DELIV_SCHEDULE_CODE, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PRICE_BASIS_CODE, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_CODE, MARKET_PRICE_CCY_AMT, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_CCY_AMT, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_UOM, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_UOM, STORAGE_CTY_CODE, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_UOM, PRICE_ADJUST, SEC_COMMODITY_QNTY, SEC_UTILISED_QNTY, SEC_ADJUSTMENT_QNTY, SEC_NET_COMMODITY_QNTY, PRIM_SEC_UOM_CONVERSION_FACTOR, APPL_PRICE_BASIS_CODE, CR_STATUS_CODE, PREV_DEAL_STEP_ID, PARCEL_LEVEL_ADJ_FLAG, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, ORIGINAL_PRICE_BASE_CCY, ORIGINAL_PRICE_BASE_AMT, ORIGINAL_PRICE_BASE_UOM, MST_NET_QNTY, MST_UTIL_QNTY, MST_SEC_NET_QNTY, MST_SEC_UTIL_QNTY, OP_CODE)
 Values
   ('SCB', 'AE', 'PP00051187', 'AE123T05371001PP', '26673248', 'AE123T05371M0010', '10026', 'PUR', 'DATR', 'SUS', 'CM10000783', 23962, 'T', 23952, 'T', 10, 'T', 23952, 'T', 0, 0, 'AE123T05371', 'CSH', TO_DATE('03/18/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/16/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('06/12/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'PUP', 85, 'USD', 179, 'T', 'USD', 77, 'T', 'USD', 'T', 0, 'USD', 0, 'USD', 0, 'USD', 'USD', 'T', 'IN', 4, 90, 'T', 1, '02', '1356121', 'USD', 179, 'T', 0, 0, -10, 10, -10, 1, 'PUP', 'UH', 'AE123T05371M0007', 'D', 'N', 'N', 'USD', 77, 'T', 23952, 0, -10, 0, 'U');
COMMIT;
=========================================================
select PARCEL_ID,PARCEL_STATUS_CODE,PARENT_PARCEL_ID,LINK_PARCEL_ID,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_mst WHERE  (PARCEL_ID='PP00051187' OR PARENT_PARCEL_ID='PP00051187' OR LINK_PARCEL_ID='PP00051187')


select DEAL_ID,DEAL_STEP_ID,PARCEL_ID,PARCEL_STATUS_CODE,PARENT_PARCEL_ID,LINK_PARCEL_ID,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_hst WHERE  UTILISED_QNTY >0 AND (PARCEL_ID='PP00051187' OR PARENT_PARCEL_ID='PP00051187' OR LINK_PARCEL_ID='PP00051187')


select DEAL_ID,DEAL_STEP_ID,PARCEL_ID,PARCEL_STATUS_CODE,PARENT_PARCEL_ID,LINK_PARCEL_ID,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_hst WHERE  UTILISED_QNTY >0 AND (PARCEL_ID='PP00051187' OR PARENT_PARCEL_ID='PP00051187' OR LINK_PARCEL_ID='PP00051187')

SELECT TXN_STATUS_CODE,TXN_STEP_CODE FROM SCBT_T_TXN_HST WHERE DEAL_ID='AE123T05371' AND DEAL_STEP_ID='AE123T05371M0010'

SELECT TXN_STATUS_CODE,TXN_STEP_CODE FROM SCBT_T_TXN_MST WHERE DEAL_ID='AE123T05371' AND LATEST_DEAL_STEP_ID='AE123T05371M0010'
======================= Cache gen details ==============

SELECT * FROM SCBT_R_PARAM_DEFN where UPDATE_LEVEL_CODE = '03' AND CODE_FLAG = 'N'

SELECT * FROM SCBT_R_PARAM_DEFN where param_code_id='LM05'

SELECT * FROM SCBT_R_PARAM_FIELD_DEFN where param_code_id='LM05'

====
SELECT *  FROM SCBT_T_IPS_SCI_LMT_APPR_SEC where LAS_LE_ID='11760970' AND LAS_LMT_ID='21882934';

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LIMITS WHERE TO_CHAR(LMT_LE_ID) in ('11760970');

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LMTPROF where TO_CHAR(LLP_LE_ID) in ('11760970');

SELECT *  FROM SCBT_T_IPS_SCI_LMT_APPR_SEC where LAS_LE_ID='12285170' AND LAS_LMT_ID='22031547';


SELECT LAS_LE_ID,LAS_LMT_ID, SEC_SUB_TYPE_VALUE FROM SCBT_T_IPS_SCI_LMT_APPR_SEC where LAS_LE_ID='12285170' --SEC_SUB_TYPE_VALUE='CF1081' --LAS_LE_ID='12285170' --AND LAS_LMT_ID='22031547';

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LIMITS WHERE TO_CHAR(LMT_LE_ID) in ('12285170') and lmt_id ='22031547'
=============
COCOA-926 - Outstanding amount is zero and the txn amount is 3,608,399.74 validation is using the utilAmt instead of osAmt

IM0000016848130 - Issue COCOA-988 - System not allowing to Reduce the IFNB Limit for the Client has been successfully created.


================ SCI Related tables =====================
-- SCBSCIOnlineMessageFormatter.java
SELECT * FROM SCBT_T_IPS_IN_MSG WHERE  RECV_DATE > '01-DEC-2013' and MSG_REFID ='11270026'

SELECT *  from SCBT_T_IPS_SCI_CUST_PROFILE where TO_CHAR(LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_CUST_CRDGRD where TO_CHAR(LCG_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_CUST_ISIC_DTLS where TO_CHAR(LID_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_CUST_SUBPROF where TO_CHAR(LSP_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_CUST_EMP_RELN where  TO_CHAR(LEM_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LMTPROF where TO_CHAR(LLP_LE_ID) in ('11270026');  -- BCA EXP DATE

SELECT *  FROM SCBT_T_IPS_SCI_CUST_SYSXREF WHERE TO_CHAR(LSX_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_CUST_REG_ADDR WHERE TO_CHAR(LRA_LE_ID) in ('11435692');

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LIMITS WHERE TO_CHAR(LMT_LE_ID) in ('11435692');

SELECT *  FROM SCBT_R_PARTY_EXT_ID_HIST where EXT_SYSTEM_ID='12172725'

SELECT *  FROM SCBT_T_IPS_SCI_LMT_APPR_SEC where LAS_LE_ID='11760970' AND LAS_LMT_ID='21882934';



SELECT APPRLMT.LMT_ID,APPRLMT.N_LMT_PRD_TYPE_VALUE ,
Scbf_C_Get_Code_Desc ('SCB','*','*','EN','CI124',
(SELECT CODE_VALUE_2 FROM SCBT_R_MAP_INFO WHERE MAP_ID= 'MLM03' AND CODE_VALUE_1=APPRLMT.N_LMT_PRD_TYPE_VALUE),1) AS PROD_DESC,
APPRSEC.SEC_SUB_TYPE_VALUE,APPRSEC.SEC_SUB_TYPE_CODE_VALUE_DESC
FROM scbt_t_ips_sci_lmt_appr_sec APPRSEC 
LEFT OUTER JOIN SCBT_T_IPS_SCI_APPR_LIMITS APPRLMT
ON APPRLMT.LMT_LE_ID=APPRSEC.LAS_LE_ID AND APPRLMT.LMT_ID=APPRSEC.LAS_LMT_ID
WHERE TO_CHAR(LMT_LE_ID) in ('11131010') AND APPRLMT.ACTIVE_FLAG='Y' AND APPRSEC.LAS_LE_ID='11131010'

SELECT APPRLMT.LMT_ID,APPRLMT.N_LMT_PRD_TYPE_VALUE ,
Scbf_C_Get_Code_Desc ('SCB','*','*','EN','CI124',
(SELECT CODE_VALUE_2 FROM SCBT_R_MAP_INFO WHERE MAP_ID= 'MLM03' AND CODE_VALUE_1=APPRLMT.N_LMT_PRD_TYPE_VALUE),1) AS PROD_DESC,
APPRSEC.SEC_SUB_TYPE_VALUE,APPRSEC.SEC_SUB_TYPE_CODE_VALUE_DESC
FROM scbt_t_ips_sci_lmt_appr_sec APPRSEC , SCBT_T_IPS_SCI_APPR_LIMITS APPRLMT
WHERE APPRLMT.LMT_LE_ID=APPRSEC.LAS_LE_ID AND APPRLMT.LMT_ID=APPRSEC.LAS_LMT_ID
AND TO_CHAR(LMT_LE_ID) in ('11131010') AND APPRLMT.ACTIVE_FLAG='Y' AND APPRSEC.LAS_LE_ID='11131010'

================================================= Vanranden Claire =============
SELECT * FROM SCBT_R_PARTY_HIST WHERE  cty_code = 'KE' AND party_id LIKE '800014846' AND STEP_STATUS_CODE ='02'--step_id='ZLBKMYYY3H-62353' AND

SELECT * FROM SCBT_R_CUST_ACCT_HIST WHERE  cty_code = 'KE' AND cust_id LIKE '800014846' AND STEP_STATUS_CODE ='02'--step_id='ZLBKMYYY3H-62353' AND

DELETE FROM SCBT_R_PARTY_HIST WHERE  cty_code = 'KE' AND party_id LIKE '800014846' AND STEP_STATUS_CODE ='02'--step_id='ZLBKMYYY3H-62353' AND

DELETE FROM SCBT_R_CUST_ACCT_HIST WHERE  cty_code = 'KE' AND cust_id LIKE '800014846' AND STEP_STATUS_CODE ='02'--step_id='ZLBKMYYY3H-62353' AND

SET DEFINE OFF;
Insert into SCBT_R_PARTY_HIST
   (BANK_GROUP_CODE, CTY_CODE, PARTY_ID, STEP_ID, PARTY_NAME, OPEN_DATE, RESIDENCE_CTY_CODE, INDUSTRY_CODE, RM_CODE, SEG_CODE, STEP_CODE, SUB_SEG_CODE, SUB_STEP_CODE, STEP_STATUS_CODE, MAKER_ID, MAKER_TIMESTAMP, ADD_CTY_CODE, BLACKLISTED_FLAG, BUSINESS_DIVISION, DUPLICATE_PARTY_FLAG, BUSINESS_DATE, LIMIT_SETUP_APPLN_REF, CURRENT_SCB_CG, NEXT_REVIEW_DATE, NEXT_EXT_REVIEW_DATE, GAM_CODE, SUSPEND_FLAG, OVERALL_EXP_CURRENCY, CMT_MGR_PWID, BACKUP_CMT_MGR_PWID, PARTY_NAME_UPP, FI_FLAG, STOP_LOSS_CCY_CODE, CUSTODIAN, CUST_FACILITY_TYPE_CODE, LTV_FORMULA)
 Values
   ('SCB', 'KE', '800014846', 'ZLBKMYYY3H-62353', 'PREMIER FLOUR MILLS LTD.', TO_DATE('07/29/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'KE', '3117', 'W15', 'A', '02', 'B1', '01', '02', '1298053', TO_DATE('09/19/2013 09:08:59', 'MM/DD/YYYY HH24:MI:SS'), 'KE', 'N', 'WB', 'N', TO_DATE('10/03/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), '10254999', '11B', TO_DATE('07/31/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('10/29/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'W14', 'N', 'USD', '1257254', '1406117', 'PREMIER FLOUR MILLS LTD.', 'N', 'USD', 'N', 'CTAC', 'LTV1');
COMMIT;

SET DEFINE OFF;
Insert into SCBT_R_CUST_ACCT_HIST
   (BANK_GROUP_CODE, CTY_CODE, CUST_ID, ACC_CCY_CODE, ACC_NO, ACC_DESC, STEP_ID, ACC_TYPE_CODE, STEP_CODE, SUB_STEP_CODE, STEP_STATUS_CODE, MAKER_ID, MAKER_TIMESTAMP, BUSINESS_DATE, INCLUDE_FOR_CASH_COLLATERAL, OP_CODE, CUST_CO_BORROWER_ID, EXPOSURE_OFFSET, ACCOUNT_LINKED, ACCOUNT_ID)
 Values
   ('SCB', 'KE', '800014846', 'USD', '87 0402015 1300', 'Premier USD Account', 'ZLBKMYYY3H-62353', 'AC01', '02', '01', '02', '1298053', TO_DATE('09/19/2013 09:08:59', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('09/19/2013 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'N', 'O', '800014846', 'N', 'N', '1854');
COMMIT;
============================ webber michael ====================

select * from scbt_t_parcel_mst where parcel_id='RC00012402'

UPDATE scbt_t_parcel_mst SET utilised_qnty=net_commodity_qnty WHERE parcel_id='RC00012402' --16036.289

SET DEFINE OFF;
Insert into SCBT_T_PARCEL_MST
   (BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, COLLATERAL_LIMIT_ID, PARCEL_TYPE_CODE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, COMMODITY_ID, COMMODITY_QNTY, COMMODITY_QNTY_UOM, UTILISED_QNTY, ADJUSTMENT_QNTY, ADJUSTMENT_QNTY_UOM, NET_COMMODITY_QNTY, NET_COMMODITY_UOM, POSITIVE_TOLERANCE_PCT, NEGATIVE_TOLERANCE_PCT, DEAL_ID, IS_QLTY_CONDITION_MET, DELIV_SCHEDULE_CODE, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PRICE_BASIS_CODE, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_CODE, MARKET_PRICE_CCY_AMT, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_UOM, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_UOM, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_UOM, PRICE_ADJUST, CUSTOMER_REFERENCE, RELEASE_ORDER_REFERENCE, SEC_COMMODITY_QNTY, SEC_UTILISED_QNTY, SEC_ADJUSTMENT_QNTY, SEC_NET_COMMODITY_QNTY, PRIM_SEC_UOM_CONVERSION_FACTOR, ISSUE_DATE, PAYMENT_CCY_AMT, PAYMENT_CCY_CODE, PAYMENT_DATE, RECEIVABLE_CCY_AMT, RECEIVABLE_CCY_CODE, BUYER_ID, PARCEL_LEVEL_ADJ_FLAG, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, RECJ158_CODE)
 Values
   ('SCB', 'GB', 'RC00012402', 'GB779O00036002RC', '9298', 'RCV', 'ROAS', 'SUS', 'CM10000582', 16036.289, 'T', 0, 0, 'T', 16036.289, 'T', 0, 0, 'GB779O00036', 'N', 'CSH', TO_DATE('07/17/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/10/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('12/05/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 'RCV', 100, 'USD', 648, 'T', 'USD', 'T', 'USD', 'T', 10391515.27, 'USD', 0, 'USD', 0, 'USD', 'USD', 'T', 5, 180, 'T', 1, '06', '15541714', 'USD', 648, 'T', 0, '12STD00028', 'DUF05C', 0, 0, 0, 0, 1, TO_DATE('06/13/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5889968.35, 'USD', TO_DATE('10/08/2012 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 5899968.35, 'USD', '800007800', 'D', 'N', 'N', 'AB104');
COMMIT;

select parcel_id, net_commodity_qnty, utilised_qnty,price_basis_code,receivable_ccy_amt,payment_ccy_amt,deal_Step_id,parcel_status_code
from scbt_t_parcel_hst where parcel_id='RC00012402' order by deal_step_id desc

====================================================
IM0000017053553 , IM0000017081129   - PM0000000017467
Issue COCOA-1000 - Stock report list the parcels which are already released has been successfully created.

UPDATE scbt_t_parcel_mst SET utilised_qnty=net_commodity_qnty WHERE parcel_id='RC00012402' --16036.289


UPDATE SCBT_T_PARCEL_MST SET utilised_qnty=net_commodity_qnty,cmv_ccy_amt=0 WHERE parcel_id='RC00012402'

UPDATE SCBT_T_PARCEL_MST SET total_cmv_ccy_amt=806772.45 WHERE collateral_id='GB779O00036002RC'

UPDATE SCBT_T_COLLATERAL_REGISTER_MST SET total_cmv_ccy_amt=806772.45 WHERE collateral_id='GB779O00036002RC'

UPDATE scbt_t_parcel_hst SET utilised_qnty=0 WHERE collateral_id='GB779T00250010PP' AND deal_step_id ='GB779T00250M0560'

AND parcel_id = 'PS00085185' 

UPDATE SCBT_R_PARTY_EXT_ID_HIST SET EXT_SYSTEM_ID='12729937' WHERE EXT_SYSTEM_ID='12097305' AND PARTY_ID='800012823'

UPDATE SCBT_R_PARTY_EXT_ID SET EXT_SYSTEM_ID='12729937' WHERE EXT_SYSTEM_ID='12097305' AND PARTY_ID='800012823'
====================================================
select * from ( SELECT step_status_code, party_id, party_name, cty_code, add_1, add_2, add_3,
		    add_cty_code, open_date, residence_cty_code, industry_code, rm_code,special_remarks
		  	FROM scbt_r_party_hist hist
		 	WHERE hist.step_status_code IN ('01', '11','02') AND hist.cty_code = 'IN' AND hist.party_id LIKE '800007420'
		    AND (replace(hist.party_name_upp, ' ', '') like replace('%', ' ', '') OR replace('%', ' ', '') like replace(hist.party_name_upp, ' ', ''))  
		    AND hist.bank_group_code = 'SCB'
			UNION ALL
			SELECT '03', party_id, party_name, cty_code, add_1, add_2, add_3,
		       add_cty_code, open_date, residence_cty_code,industry_code, rm_code,special_remarks
		    FROM scbt_r_party_mst mst
		 	WHERE party_id LIKE '800007420' 
		 	AND (replace(party_name_upp, ' ', '') like replace('%', ' ', '') OR replace('%', ' ', '') like replace(party_name_upp, ' ', ''))
		    AND ((   cty_code = 'IN' AND party_id NOT IN (
					SELECT party_id
		            FROM scbt_r_party_hist
		            WHERE step_status_code IN ('01', '11', '02') AND party_id =  mst.party_id AND cty_code = mst.cty_code
		              AND bank_group_code = mst.bank_group_code)
					 )
		        OR ( cty_code = '*' AND NOT EXISTS (
		                    SELECT 1
		                      FROM scbt_r_party_hist p
		                      WHERE p.step_status_code IN ('01', '11', '02','03') AND p.bank_group_code = mst.bank_group_code
		                       AND p.cty_code = 'IN' AND p.party_id= mst.party_id)
							  )
		        OR (cty_code = '*' AND EXISTS (
		                    SELECT 1
		                      FROM scbt_r_party_hist p
		                      WHERE p.step_status_code IN ('01', '11', '02','03') AND p.bank_group_code = mst.bank_group_code
		                      AND p.step_code = '06' AND p.cty_code = 'IN'
		                       AND p.party_id= mst.party_id)
					  )
			)
		   AND mst.bank_group_code = 'SCB'
		   AND mst.CUSTODIAN = 'N' )
		   
SELECT * FROM  SCBT_R_INS_MST WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_MST WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_HIST WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_ADD WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_CONTACT WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_CUST_ACCT_MAINTENANCE WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_CUST_CO_BORROWER WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_EXT_ID WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_T_IPS_SCI_CUST_PROFILE WHERE PARTY_ID='800007420'
SELECT * FROM  scbt_r_party_sci_mst WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_PARTY_LLS_ADD WHERE PARTY_ID='800007420'
SELECT * FROM  SCBT_R_CUST_DOCUMENTS_MST WHERE PARTY_ID='800007420'
SELECT * FROM  FROM SCBT_T_CUST_RECONCIL_SMRY_MST WHERE PARTY_ID='800007420'		   

SELECT * FROM SCBT_R_MAP_INFO WHERE MAP_ID='TXNVAL' AND CODE_VALUE_1='DRAW'

================ 
select * from ( 

select 
            loc.LOCATION_LIMIT_GROUP_NAME,loc.LOCATION_LIMIT_GROUP_ID,
            loc.BONDED_WAREHOUSE_FLAG,
            loc.EXCH_DELIV_LOC_FLAG,
            loc.EXCH_CODE,
            loc.STORAGE_LOCATION_ID, 
            loc.STORAGE_COMPANY_ID,loc.LIMIT_CCY_CODE,
            NVL(loc.limit_ccy_active_amt,0),
            NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
             NVL(loc.limit_ccy_active_amt,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
              NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'', loc.LOCATION_LIMIT_GROUP_ID,  TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate from  
            SCBT_R_CUST_APPR_LOCATION loc,
            SCBT_T_coll_LIMIT_UTIL util 
            where loc.BANK_GROUP_CODE= 'SCB'
        AND loc.cty_code= 'IN' 
        AND loc.CUST_ID  like '800012988'
        AND  loc.LOCATION_LIMIT_GROUP_ID =util.limit_id  (+)     
        
        UNION all 
        (select 
            '-','-',
            loc.BONDED_WAREHOUSE_FLAG,
            loc.EXCH_DELIV_LOC_FLAG,
            loc.EXCH_CODE,
            TO_CLOB('') as stLocation, 
            TO_CLOB('') as stCompany,loc.LIMIT_CCY_CODE,
            NVL(loc.limit_ccy_active_amt,0),
            NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
             NVL(loc.limit_ccy_active_amt,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
              NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'ADHOC',loc.LOCATION_LIMIT_GROUP_ID , TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate from  
            SCBT_R_ADHC_APPR_LOCATION loc,
            SCBT_T_coll_LIMIT_UTIL util
            where loc.BANK_GROUP_CODE= 'SCB'
        AND loc.cty_code= 'IN' 
        AND loc.CUST_ID  like '800012988'
        AND  loc.LOCATION_LIMIT_GROUP_ID =util.limit_id  (+)  ) )
        
select * from SCBT_T_coll_LIMIT_UTIL where limit_id='18387'      


SELECT C.LIMIT_ID,C.LIMIT_CCY_CODE,C.LIMIT_CCY_PEND_DEC_AMT
  FROM SCBT_T_coll_LIMIT_UTIL C, SCBT_R_CUST_APPR_LOCATION L
  WHERE C.LIMIT_ID      = L.LOCATION_LIMIT_GROUP_ID AND C.BANK_GROUP_CODE = L.BANK_GROUP_CODE
  AND C.CTY_CODE        = L.CTY_CODE AND C.CTY_CODE        = 'IN' AND C.BANK_GROUP_CODE = 'SCB' and LOCATION_LIMIT_GROUP_ID='18387'  
  
  ) CL,
  
SELECT M.LIMIT_ID,C.LIMIT_CCY_CODE,
  SUM(SCBF_TLS_EXCH_RATE(M.BANK_GROUP_CODE, M.CTY_CODE, M.TXN_CCY_CODE, M.TXN_CCY_AMT, C.LIMIT_CCY_CODE, 'Y')) AS LIMIT_MVMT_UTIL
  FROM SCBT_T_COLL_LIMIT_MVMT M,SCBT_T_COLL_LIMIT_REQ_LOG L,SCBT_T_COLL_LIMIT_UTIL C
  WHERE M.BANK_GROUP_CODE = L.BANK_GROUP_CODE  AND M.BANK_GROUP_CODE   = C.BANK_GROUP_CODE
  AND M.CTY_CODE          = L.CTY_CODE  AND M.CTY_CODE          = C.CTY_CODE  AND M.INIT_REQ_ID       = L.INIT_REQ_ID
  AND L.REQ_TYPE_CODE     = 'NEW'  AND L.REQ_STATUS_CODE   = 'PEND' AND M.LIMIT_ID          = C.LIMIT_ID
  AND C.CTY_CODE          = 'IN'  AND C.BANK_GROUP_CODE   = 'SCB' and M.LIMIT_ID ='18708' 
  GROUP BY M.CTY_CODE,  C.LIMIT_CCY_CODE,    M.LIMIT_ID  
  
  ) ML,  
  
  select * from scbt_t_parcel_hst p, scbt_t_deal_hist d where storage_location_id='SC001160001'
  and d.deal_step_id=p.deal_step_id and d.BANK_GROUP_CODE=p.BANK_GROUP_CODE
  and d.cty_code='IN' and d.step_status_code<>03
  
  
  UPDATE SCBT_T_coll_LIMIT_UTIL u SET u.limit_ccy_pend_dec_amt =
    (SELECT NVL(SUM(amt),0) FROM (
    SELECT mv.init_req_id,
    SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) amt
    FROM SCBT_T_coll_LIMIT_MVMT mv, SCBT_T_coll_LIMIT_REQ_LOG rh, SCBT_T_coll_LIMIT_UTIL cu
    WHERE rh.bank_group_code = 'SCB'
    AND rh.cty_code='IN'
    AND cu.bank_group_code = mv.bank_group_code
    AND cu.bank_group_code = rh.bank_group_code
    AND  cu.cty_code = mv.cty_code
    AND cu.cty_code = rh.cty_code
    AND rh.req_type_code      = 'NEW'
    AND rh.req_status_code   = 'PEND'
    AND mv.init_req_id      = rh.init_req_id
    AND cu.limit_id = mv.limit_id
    AND cu.limit_id ='18708'
    GROUP BY mv.init_req_id
    HAVING SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, cu.limit_ccy_code, 'N')) < 0
    ))
WHERE u.limit_id ='18708' -- 18708  18387

SELECT * FROM SCBT_T_coll_LIMIT_UTIL WHERE LIMIT_ID='18387'

SELECT * FROM  SCBT_T_COLL_LIMIT_MVMT WHERE LIMIT_ID='18387'

--CUSTOMER DASHBOARD PROD LIMIT UTILIZATION

SELECT C.CTY_CODE,C.LIMIT_ID,C.LIMIT_CCY_CODE,C.LIMIT_CCY_UTILISED_AMT,
  NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,L.LIMIT_PRODUCT_CODE),0) AS PROD_UTIL_AMT
  FROM SCBT_T_PROD_LIMIT_UTIL C,SCBT_R_CUST_PRODUCT_LIMIT L
  where C.LIMIT_ID      = L.LIMIT_ID and C.BANK_GROUP_CODE = L.BANK_GROUP_CODE
  AND C.CTY_CODE        = L.CTY_CODE and c.limit_id='10071' --20375.459910495206714

SELECT M.LIMIT_ID,C.LIMIT_CCY_CODE,
  SUM(SCBF_TLS_EXCH_RATE(M.BANK_GROUP_CODE, M.CTY_CODE, M.TXN_CCY_CODE, M.TXN_CCY_AMT, C.LIMIT_CCY_CODE, 'Y')) AS LIMIT_MVMT_UTIL
  FROM SCBT_T_PROD_LIMIT_MVMT M,SCBT_T_PROD_LIMIT_REQ_LOG L,SCBT_T_PROD_LIMIT_UTIL C
  WHERE M.BANK_GROUP_CODE = L.BANK_GROUP_CODE  AND M.BANK_GROUP_CODE   = C.BANK_GROUP_CODE
  AND M.CTY_CODE          = L.CTY_CODE  AND M.CTY_CODE          = C.CTY_CODE  AND M.INIT_REQ_ID       = L.INIT_REQ_ID
  AND L.REQ_TYPE_CODE     = 'NEW'  AND L.REQ_STATUS_CODE   = 'CON' AND M.LIMIT_ID          = C.LIMIT_ID
  AND C.CTY_CODE          = 'CN'  AND C.BANK_GROUP_CODE   = 'SCB' AND M.LIMIT_ID ='10071'
  GROUP BY M.CTY_CODE,  C.LIMIT_CCY_CODE,    M.LIMIT_ID 
 
 GROUP BY M.CTY_CODE,  C.LIMIT_CCY_CODE,    M.LIMIT_ID ,L.DEAL_ID
 
 SELECT * FROM SCBT_T_TXN_CR_LINKAGE_MST WHERE COLLATERAL_ID='HK514T07033003RC'

UPDATE SCBT_T_TXN_CR_LINKAGE_MST SET COVERAGE_PCT=0 WHERE COLLATERAL_ID='HK514T07033003RC' AND DEAL_STEP_ID='HK514T07033M0012'

SELECT * FROM SCBT_T_TXN_CR_LINKAGE_HST WHERE COLLATERAL_ID='HK514T07033003RC' AND DEAL_STEP_ID='HK514T07033M0012'

UPDATE SCBT_T_TXN_CR_LINKAGE_HST SET COVERAGE_PCT=0  WHERE COLLATERAL_ID='HK514T07033003RC' AND DEAL_STEP_ID='HK514T07033M0012'
===================
SELECT CUST_ID,DEAL_ID,LATEST_DEAL_STEP_ID,TXN_REF_ID,CASH_MARGIN_CCY_AMT,CASH_MARGIN_ADJ,CASH_MARGIN_ADJ_AMT,CM_CCY_RELEASE_AMT 
FROM SCBT_T_TXN_MST WHERE DEAL_ID='SG957T13722'  AND (CASH_MARGIN_CCY_AMT >0 OR CASH_MARGIN_ADJ_AMT >0)
--PROD_LIMIT_ID in ('20351488') AND CASH_MARGIN_CCY_AMT > 0

select * from SCBT_T_IPS_TR_DATASCOPE where FILE_NAME in('DSS_C-05112013-092804-SG.XML','DSS_C-05112013-092804-SG.xml') and 
RIC in ('W-DVDSWG-A13','W-EXDTHU-E14')


select * from scbt_t_txn_mst where deal_id='ZM339T00038' and txn_ref_id='ZM339T00038LC014';

update scbt_t_txn_mst set txn_ccy_util_amt=244092.4 where  deal_id='ZM339T00038' and txn_ref_id='ZM339T00038LC014'
and txn_rec_id='26333728';


SELECT * FROM SCBT_T_TXN_MST WHERE DEAL_ID='SG957T13722' 
AND LATEST_DEAL_STEP_ID='SG957T13722M0009' AND CASH_MARGIN_ADJ_AMT=27075

UPDATE SCBT_T_TXN_MST SET CASH_MARGIN_ADJ_AMT=0  WHERE DEAL_ID='SG957T13722' 
AND LATEST_DEAL_STEP_ID='SG957T13722M0009' AND CASH_MARGIN_ADJ_AMT=27075


========== SCI updation / revertion =====================
--UPDATE  SCBT_R_CUST_PRODUCT_LIMIT_HIST SET BOOKING_LOCATION='ZA' WHERE CUST_ID='800010874' AND LIMIT_ID='16625'  
--AND BOOKING_LOCATION='GB' AND OBU_ENTITY='SCBL'

--UPDATE SCBT_R_CUST_PRODUCT_LIMIT SET BOOKING_LOCATION='GB' WHERE CUST_ID='800010874' AND LIMIT_ID='16625'
--AND BOOKING_LOCATION='ZA' AND OBU_ENTITY='SCBL'

SELECT *  FROM SCBT_T_IPS_SCI_APPR_LIMITS WHERE TO_CHAR(LMT_LE_ID) in ('11335304') and lmt_id in ('20647017','20647019')
and N_LMT_BKG_LOCTN_ID=13000093

UPDATE SCBT_T_IPS_SCI_APPR_LIMITS SET N_LMT_BKG_LOCTN_ID=13000093 WHERE TO_CHAR(LMT_LE_ID) in ('11335304') and lmt_id in ('20647017','20647019')
and N_LMT_BKG_LOCTN_ID=13000024 -- 800010874

UPDATE SCBT_T_IPS_SCI_APPR_LIMITS SET N_LMT_BKG_LOCTN_ID=13000024 WHERE TO_CHAR(LMT_LE_ID) in ('11335304') and lmt_id in ('20647017','20647019')
and N_LMT_BKG_LOCTN_ID=13000093 -- 800010874

select * from scbt_t_ips_sci_stdc_bkgloctn where BKL_CNTRY_ISO_CODE='ZA' --BKL_LOCTN_ID=13000024 13000093

=====================IM0000017342630 ==========================
SELECT USER_ID,USER_NAME,DEL_AUTH_CCY_AMT FROM SCBT_R_USER_MST WHERE user_id in ('1320101','1350177','1406117','1440645')

UPDATE SCBT_R_USER_MST SET DEL_AUTH_CCY_AMT=0  WHERE user_id in ('1320101','1350177','1406117','1440645') --50000000
=========================
select hist.STEP_STATUS_CODE, hist.BACKED_BY_ID, hist.CTY_CODE, 
            Scbf_C_Get_Code_Desc(hist.BANK_GROUP_CODE, hist.CTY_CODE, '*', 'EN', 'CI140', hist.BACKED_BY_ID, 1) AS INS_COMPANY_NAME,
             Scbf_Get_Party_Name (hist.bank_group_code, hist.corporate_id) cust_name,hist.CORPORATE_ID,hist.POLICY_NO,hist.INACTIVE_POLICY_FLAG 
            from SCBT_R_INS_HIST hist where hist.step_status_code in ('01', '11','02') and hist.BACKED_BY_ID like '%'
            and hist.CTY_CODE in ('HK', '*') and upper(hist.POLICY_NO) like '%' and hist.BANK_GROUP_CODE='SCB'
            AND UPPER(Scbf_C_Get_Code_Desc(hist.BANK_GROUP_CODE, hist.CTY_CODE, '*', 'EN', 'CI140', hist.BACKED_BY_ID, 1))
             LIKE '%' AND Nvl(UPPER(Scbf_Get_Party_Name (hist.bank_group_code, hist.corporate_id)),'%') LIKE '%' AND 
             hist.INACTIVE_POLICY_FLAG LIKE UPPER('N')
                union
            select '03', mst.BACKED_BY_ID, mst.CTY_CODE,
            Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*', 'EN', 'CI140', mst.BACKED_BY_ID, 1) AS INS_COMPANY_NAME,
            Scbf_Get_Party_Name (mst.bank_group_code, mst.corporate_id) cust_name, mst.CORPORATE_ID,mst.POLICY_NO,mst.INACTIVE_POLICY_FLAG  
            from SCBT_R_INS_MST mst 
            where mst.BACKED_BY_ID like '%' and mst.CTY_CODE in ('HK', '*') and upper(mst.POLICY_NO) like '%'
            and mst.POLICY_NO NOT IN (select POLICY_NO from SCBT_R_INS_HIST where step_status_code in ('01', '11','02') and CTY_CODE = mst.CTY_CODE
            AND BANK_GROUP_CODE=mst.BANK_GROUP_CODE) and mst.BANK_GROUP_CODE='SCB'
            AND UPPER(Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*', 'EN', 'CI140', mst.BACKED_BY_ID, 1))
             LIKE '%' AND Nvl(UPPER(Scbf_Get_Party_Name (mst.bank_group_code, mst.corporate_id)),'%') LIKE '%' AND 
             mst.INACTIVE_POLICY_FLAG LIKE UPPER('N')
             
SELECT * FROM SCBT_R_INS_HIST WHERE  CTY_CODE='CN' AND BACKED_BY_ID='CPPI' ORDER BY CHECKER_TIMESTAMP DESC--POLICY_NO='ANIB90502413Q000491F'   

SELECT * FROM SCBT_R_INS_MST WHERE  POLICY_NO='ANIB90502413Q000491F'   
         
============ LIMIT SIDE TABLES=================
SELECT * FROM SCBT_R_CUST_LIMIT_HIST WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_COLLAT_LIMIT_HIST WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_APPR_COM_HIST WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_LIMIT_MST WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_COLLAT_LIMIT WHERE CUST_ID='800012586';

SELECT * FROM SCBT_R_CUST_APPR_COM WHERE CUST_ID='800012586';

====== DB UTIL

select BANNER from SYS.V_$VERSION

SELECT /* + RULE */  df.tablespace_name "Tablespace",
       df.bytes / (1024 * 1024) "Size (MB)",
       SUM(fs.bytes) / (1024 * 1024) "Free (MB)",
       NVL(ROUND(SUM(fs.bytes) * 100 / df.bytes),1) "% Free",
       ROUND((df.bytes - SUM(fs.bytes)) * 100 / df.bytes) "% Used"
  FROM dba_free_space fs,
       (SELECT tablespace_name,SUM(bytes) bytes
          FROM dba_data_files
         GROUP BY tablespace_name) df
WHERE fs.tablespace_name (+)  = df.tablespace_name
GROUP BY df.tablespace_name,df.bytes
UNION ALL
SELECT /* + RULE */ df.tablespace_name tspace,
       fs.bytes / (1024 * 1024),
       SUM(df.bytes_free) / (1024 * 1024),
       NVL(ROUND((SUM(fs.bytes) - df.bytes_used) * 100 / fs.bytes), 1),
       ROUND((SUM(fs.bytes) - df.bytes_free) * 100 / fs.bytes)
  FROM dba_temp_files fs,
       (SELECT tablespace_name,bytes_free,bytes_used
          FROM v$temp_space_header
         GROUP BY tablespace_name,bytes_free,bytes_used) df
WHERE fs.tablespace_name (+)  = df.tablespace_name
GROUP BY df.tablespace_name,fs.bytes,df.bytes_free,df.bytes_used
ORDER BY 4 DESC;

select segment_name,segment_type,bytes/1024/1024 MB  from dba_segments  where segment_type='TABLE' and segment_name='SCBT_R_BBC_DTLS_HIST';
 
 
select p.spid,s.sid,s.serial#,s.username,s.status,s.last_call_et,p.program,p.terminal,logon_time,module,s.osuser
from V$process p,V$session s
where s.paddr = p.addr and s.status = 'ACTIVE' and s.username not like '%sys%' and p.spid='5607564';

=============
SELECT * FROM SCBT_R_MAP_INFO WHERE MAP_ID='TXNVAL' AND CODE_VALUE_1='DRAW'

SELECT * FROM scbt_r_code_data code WHERE DESC_1 LIKE upper('%limit%')

--- SIP related Tables
SCBT_R_SIP_MANAGER_HIST
SCBT_R_SIP_MANAGER_MST
SCBT_T_SIP_DEAL_SMRY_HST
SCBT_T_SIP_DEAL_SMRY_MST
SCBT_T_INVENTORY_HST
SCBT_T_INVENTORY_MST
SCBT_T_INVENTORY_SMRY
SCBT_T_INVENTORY_SMRY_HST
SCBT_T_INVENTORY_SMRY_MVMT
SCBT_T_INVENTORY_SNAPSHOT
SCBT_T_DEAL_ER_SMRY_HST
SCBT_T_DEAL_ER_SMRY_MST
SCBT_T_DEAL_HIST
SCBT_T_DEAL_MST
SCBT_T_SIP_DEAL_SMRY_HST
SCBT_T_SIP_DEAL_SMRY_MST

--
SELECT * FROM SCBT_R_PARAM_DATA WHERE PARAM_ID='CA04' AND PARAM_DATA_01='Y' AND PARAM_KEY_SEQ_CODE='11001000000000'

--- EBBS RECON
SELECT  * FROM SCBT_T_CUST_RECONCIL_SMRY_MST WHERE 
CTY_CODE IN ('SL','PK','TH','IN','NG','ZM','GH','MO','MY','CM','SG','AE','CI','TZ','CN') 
ORDER BY RECONCILED_TIMESTAMP DESC

Hibernate: insert into SCBT_T_CUST_RECONCIL_SMRY_HST (ACCOUNT_TYPE, ACCOUNT_TYPE_DESC, INCLUDE_FOR_CASH_COLLATERAL, COCOA_AMOUNT_BALANCE, EBBS_AMOUNT_BALANCE, DIFFERENCE, REASON, PASS_ADJ_FLAG, RECONSILE_FLAG, JUSTIFICATION, MISMATCH_DATE, RECONCILED_USER, RECONCILED_TIMESTAMP, RECORD_LOCK_FLAG, BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER, ACCOUNT_CCY, RECONCILED_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_CUST_ACC_ACTIVITY_MST (TXN_TYPE_CODE, TXN_CCY_AMT, TXN_DATE, MATURITY_DATE, REMARKS, DEAL_STEP_ID, TXN_REC_ID, ADJUSTMENT_BY_RECONCILE, RECORD_LOCK_FLAG, ACTIVITY_ID, BANK_GROUP_CODE, CTY_CODE, CUST_ID, ACC_NO, TXN_CCY_CODE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_CUST_ACC_SMRY_HST (ACC_CCY_BALANCE_CCY, ACC_CCY_ANTICIPATED_CCY, ACC_TYPE_CODE, ACC_DESC, ACC_CCY_BALANCE_AMT, ACC_CCY_ANTICIPATED_AMT, BUSINESS_DATE, CHECKER_ID, CHECKER_TIMESTAMP, MAKER_ID, MAKER_TIMESTAMP, STEP_CODE, STEP_STATUS_CODE, SUB_STEP_CODE, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID, CUST_ID, ACC_NO, ACC_CCY_CODE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_CUST_ACC_ACTIVITY_HST (TXN_TYPE_CODE, TXN_CCY_AMT, TXN_DATE, MATURITY_DATE, REMARKS, BUSINESS_DATE, CHECKER_ID, CHECKER_TIMESTAMP, MAKER_ID, MAKER_TIMESTAMP, STEP_CODE, STEP_STATUS_CODE, SUB_STEP_CODE, TXN_REC_ID, ADJUSTMENT_BY_RECONCILE, ACTIVITY_ID, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID, CUST_ID, ACC_NO, TXN_CCY_CODE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: update SCBT_T_CUST_RECONCIL_SMRY_MST set ACCOUNT_TYPE=?, ACCOUNT_TYPE_DESC=?, INCLUDE_FOR_CASH_COLLATERAL=?, COCOA_AMOUNT_BALANCE=?, EBBS_AMOUNT_BALANCE=?, DIFFERENCE=?, REASON=?, PASS_ADJ_FLAG=?, RECONSILE_FLAG=?, JUSTIFICATION=?, MISMATCH_DATE=?, RECONCILED_USER=?, RECONCILED_TIMESTAMP=?, RECONCILED_STEP_ID=?, RECORD_LOCK_FLAG=? where BANK_GROUP_CODE=? and CTY_CODE=? and CUSTOMER_ID=? and ACCOUNT_NUMBER=? and ACCOUNT_CCY=?
Hibernate: update SCBT_T_CUST_ACC_SMRY_MST set ACC_CCY_BALANCE_CCY=?, ACC_CCY_ANTICIPATED_CCY=?, ACC_TYPE_CODE=?, ACC_DESC=?, ACC_CCY_BALANCE_AMT=?, ACC_CCY_ANTICIPATED_AMT=?, DEAL_STEP_ID=?, RECORD_LOCK_FLAG=? where BANK_GROUP_CODE=? and CTY_CODE=? and CUST_ID=? and ACC_NO=? and ACC_CCY_CODE=?


========= OD SYNDICATION O/S check
SELECT PROD_LIMIT_ID,SYNDICATION_ID,NVL(TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0),0) OUTSTANDING_AMT FROM  SCBT_T_TXN_MST  WHERE 
   BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB' AND
   CUST_ID = '800007200' 
      AND SYNDICATION_ID = 'SD100016' 
      AND PROD_LIMIT_ID = 10695
   AND NVL(TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0),0)>0;
   
--- IM0000017685077 & IM0000017656978 BU switch
select * from scbt_t_deal_hist where bu_code <> substr(deal_id,0,5); 

update scbt_t_deal_hist set bu_code=substr(deal_id,0,5) where  bu_code <> substr(deal_id,0,5);    


select PARCEL_ID,DEAL_ID,COLLATERAL_ID,DEAL_STEP_ID,PARCEL_TYPE_CODE,NET_COMMODITY_QNTY,UTILISED_QNTY, 
(NET_COMMODITY_QNTY-NVL(UTILISED_QNTY,0)) AS AVAIL,CMV_CCY_AMT,NCV_CCY_AMT, GCV_CCY_AMT
from scbt_t_parcel_hst where DEAL_STEP_ID LIKE 'US777T00453M%' AND  parcel_type_code not in ('MST', 'REL') 
order by deal_step_id desc

select cm.deal_id,cm.collateral_id,cm.total_cmv_ccy_amt,cm.total_gcv_ccy_amt,cm.total_ncv_ccy_amt 
from scbt_t_collateral_register_mst cm, scbt_t_txn_cr_linkage_mst tl where 
tl.deal_id=cm.deal_id and tl.collateral_id=cm.collateral_id and tl.deal_id='US777T00453' and cm.total_cmv_ccy_amt>0
and cm.collateral_category <>'REL' and coverage_pct>0;

===
select unsucc.*, cust.party_name from scbt_t_ips_cagg_feed_mst_err unsucc, scbt_r_party_mst cust        
where  unsucc.business_date ='27-DEC-2013' and    
unsucc.cty_code = cust.cty_code and unsucc.cust_id=cust.party_id and 
unsucc.cty_code in ('TH') 
order by unsucc.cty_code 

select unsucc.*, cust.party_name from scbt_t_ips_cagg_feed_mst_err unsucc, scbt_r_party_mst cust        
where  unsucc.business_date ='30-DEC-2013' and    
unsucc.cty_code = cust.cty_code and unsucc.cust_id=cust.party_id and 
unsucc.cty_code in ('BW','CI','CM','GH','GM','KE','MZ','NG','TZ','ZM','ZW') 
order by unsucc.cty_code 

SELECT TABLE_NAME FROM ALL_TABLES WHERE TABLE_NAME LIKE 'SCBT_R_LIMIT_FX%'

SELECT * FROM SCBT_R_LIMIT_FX_MAINT_MST WHERE CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

UPDATE SCBT_R_LIMIT_FX_MAINT_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS  
WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

SELECT * FROM SCBT_R_LIMIT_FX_RATE_MST  WHERE CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

UPDATE SCBT_R_LIMIT_FX_RATE_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS  
WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

select multiplying_factor*ccy_units from scbt_r_limit_fx_rate_mst where cty_code='VN' and fx_ccy_code='USD';

update scbt_r_limit_fx_rate_mst set rate=multiplying_factor*ccy_units 
where bank_group_code='SCB' and cty_code='VN' and fx_ccy_code='USD';



SELECT * FROM SCBT_R_LIMIT_FX_MAINT_MST WHERE CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

SELECT * FROM SCBT_R_LIMIT_FX_RATE_MST  WHERE CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

UPDATE SCBT_R_LIMIT_FX_MAINT_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS  
WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

UPDATE SCBT_R_LIMIT_FX_RATE_MST SET RATE=MULTIPLYING_FACTOR*CCY_UNITS  
WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='VN' AND RATE=MULTIPLYING_FACTOR AND CCY_UNITS > 1

ERROR: ORA-01017: invalid username/password; logon denied SP2-0306: Invalid option. Usage: CONN[ECT] [logon] [AS {SYSDBA|SYSOPER}] where <logon> ::= <username>[/<password>][@<connect_identifier>] | / SP2-0306: Invalid option. Usage: CONN[ECT] [logon] [AS {SYSDBA|SYSOPER}] where <logon> ::= <username>[/<password>][@<connect_identifier>] | / SP2-0157: unable to CONNECT to ORACLE after 3 attempts, exiting SQL*Plus

SCBT_R_CODE_DATA
SCBT_R_CUST_PRODUCT_LIMIT
SCBT_R_CUST_PROD_FSV_MST
SCBT_R_J158_MAINTENANCE_MST

SELECT * FROM SCBT_R_BBC_GENERAL_DTLS_MST WHERE CUST_ID='800007408'

SELECT * FROM SCBT_T_BBC_COLLATERAL_DTLS_MST WHERE CUST_ID='800007408'

SELECT * FROM SCBT_R_BBC_DTLS_MST --WHERE BBC_ID=''




--
select COUNT(*) from SCBT_T_SIP_DEAL_SMRY_MST where DEAL_ID = 'GB779S00320-R164'--1

select  COUNT(*) from SCBT_T_INVENTORY_HST where DEAL_ID = 'GB779S00320-R164' -- 2132

select  COUNT(*) from SCBT_T_INVENTORY_MST where DEAL_ID = 'GB779S00320-R164' --708

select  COUNT(*) from SCBT_T_INVENTORY_SMRY where DEAL_ID = 'GB779S00320-R164' --1

select  COUNT(*) from SCBT_T_INVENTORY_SMRY_HST where DEAL_ID = 'GB779S00320-R164' -- 0 

select  COUNT(*) from SCBT_T_INVENTORY_SMRY_MVMT where DEAL_ID = 'GB779S00320-R164' --2

select  COUNT(*) from SCBT_T_INVENTORY_SNAPSHOT where DEAL_ID = 'GB779S00320-R164'--708

select  COUNT(*) from SCBT_T_DEAL_ER_SMRY_HST where DEAL_ID = 'GB779S00320-R164'--0

select  COUNT(*) from SCBT_T_DEAL_ER_SMRY_MST where DEAL_ID = 'GB779S00320-R164' -- 0

select  COUNT(*) from SCBT_T_DEAL_HIST where DEAL_ID = 'GB779S00320-R164' --1

select  COUNT(*) from SCBT_T_DEAL_MST where DEAL_ID = 'GB779S00320-R164' --0

select  COUNT(*) from SCBT_T_SIP_DEAL_SMRY_HST where DEAL_ID = 'GB779S00320-R164'--3

select  COUNT(*) from SCBT_T_SIP_DEAL_SMRY_MST where DEAL_ID = 'GB779S00320-R164'

--COCOA FROZEN for SIP : IM0000017913279 
update scbt_t_inventory_mst set TEMP_DOCUMENT_REF_NO =null where (nvl(net_commodity_qnty,0)- nvl(utilised_qnty,0)) = 0 

update scbt_t_inventory_mst 
set TEMP_DOCUMENT_REF_NO =null where bank_group_code='SCB'
and cty_code='GB'
and CUST_ID='800007197'


update scbt_t_inventory_hst 
set TEMP_DOCUMENT_REF_NO =null where bank_group_code='SCB'
and cty_code='GB'
and CUST_ID='800007197'
and deal_step_id = 'GB779S00320M2383'

select  CTY_CODE, RM_CODE, RM_NAME, PEOPLEWISE_ID, PEOPLEWISE_NAME, EMAIL_CC_LIST, step_status_code 
		from SCBT_R_RM_HIST 
		where step_status_code in ('01', '11')  and upper(RM_CODE) like ?
		and BANK_GROUP_CODE=? and CTY_CODE like ?
		union
		select CTY_CODE, RM_CODE, RM_NAME, PEOPLEWISE_ID, PEOPLEWISE_NAME, EMAIL_CC_LIST, '03' 
		from SCBT_R_RM_MST mst 
		where upper(RM_CODE) like ? AND RM_CODE NOT IN
		(select RM_CODE from SCBT_R_RM_HIST where step_status_code in ('01', '11','02') 
		and RM_CODE = mst.RM_CODE AND BANK_GROUP_CODE=mst.BANK_GROUP_CODE and CTY_CODE=mst.CTY_CODE)
		and mst.BANK_GROUP_CODE=? and mst.cty_code like ?
CTL_RM_LIST_INPUT	

select COUNT(1) ,DOCUMENT_REF_NO,INVENTORY_ID  from SCBT_T_INVENTORY_HST where DEAL_ID = 'GB779S00920-R123'
group BY DOCUMENT_REF_NO,INVENTORY_ID
HAVING COUNT(1) > 30  -- 1086

delete from scbt_t_duplicate_chk_dtls where cty_code='GB' and business_type = 'SIP'

--Unable to delete the limits 2255 800002527

SELECT COUNT (1)
  FROM (SELECT COUNT (1) AS limit_count
          FROM SCBT_T_PROD_LIMIT_UTIL
         WHERE bank_group_code = 'SCB'
           AND cty_code = 'HK'
           AND limit_id IN (
                  SELECT limit_id
                    FROM SCBT_R_CUST_PRODUCT_LIMIT
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893'
                  UNION ALL
                  SELECT limit_id
                    FROM SCBT_R_CUST_BCA_COND_LIMIT
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893'
                  UNION ALL
                  SELECT insurance_limit_id
                    FROM SCBT_R_CUST_INS_LIMIT
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893')
           AND (limit_ccy_pend_inc_amt > 0
                OR limit_ccy_pend_dec_amt > 0
                OR limit_ccy_utilised_amt > 0
               )
        UNION ALL
        SELECT COUNT (1) AS limit_count
          FROM SCBT_T_COLL_LIMIT_UTIL
         WHERE bank_group_code = 'SCB'
           AND cty_code = 'HK'
           AND limit_id IN (
                  SELECT collateral_limit_id
                    FROM SCBT_R_CUST_COLLAT_LIMIT
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893'
                  UNION ALL
                  SELECT location_limit_group_id
                    FROM SCBT_R_CUST_APPR_LOCATION
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893'
                  UNION ALL
                  SELECT insurance_limit_id
                    FROM SCBT_R_CUST_INS_LIMIT
                   WHERE bank_group_code = 'SCB'
                     AND cty_code = 'HK'
                     AND cust_id = '800007893')
           AND (limit_ccy_pend_inc_amt > 0
                OR limit_ccy_pend_dec_amt > 0
                OR limit_ccy_utilised_amt > 0
               ))
 WHERE limit_count > 0

SELECT * FROM  SCBT_T_PROD_LIMIT_UTIL WHERE 
limit_id IN (SELECT limit_id FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE bank_group_code = 'SCB' AND cty_code = 'SG' AND CUST_ID='800014837')
AND ((LIMIT_CCY_PEND_INC_AMT > 0 AND LIMIT_CCY_PEND_INC_AMT < 1)
OR (LIMIT_CCY_PEND_DEC_AMT >  0  AND LIMIT_CCY_PEND_DEC_AMT <1)
OR (LIMIT_CCY_UTILISED_AMT > 0 AND LIMIT_CCY_UTILISED_AMT < 1)
)

UPDATE SCBT_T_PROD_LIMIT_UTIL SET LIMIT_CCY_PEND_INC_AMT=0,LIMIT_CCY_PEND_DEC_AMT=0,LIMIT_CCY_UTILISED_AMT=0
WHERE CTY_CODE='US' AND LIMIT_ID IN ('11979','10232','20441')

SELECT * FROM  SCBT_T_COLL_LIMIT_UTIL WHERE
LIMIT_CCY_PEND_INC_AMT > 0 AND LIMIT_CCY_PEND_INC_AMT < 1
AND LIMIT_CCY_PEND_DEC_AMT >  0  AND LIMIT_CCY_PEND_DEC_AMT <1
AND LIMIT_CCY_UTILISED_AMT > 0 AND LIMIT_CCY_UTILISED_AMT < 1
AND (limit_id IN (SELECT collateral_limit_id FROM SCBT_R_CUST_COLLAT_LIMIT WHERE bank_group_code = 'SCB' AND cty_code = 'GB') OR
LIMIT_ID IN (SELECT location_limit_group_id  FROM SCBT_R_CUST_APPR_LOCATION WHERE bank_group_code = 'SCB' AND cty_code = 'GB') OR
LIMIT_ID IN (SELECT insurance_limit_id FROM SCBT_R_CUST_INS_LIMIT WHERE bank_group_code = 'SCB'AND cty_code = 'GB'))

UPDATE SCBT_T_COLL_LIMIT_UTIL SET LIMIT_CCY_PEND_INC_AMT=0,LIMIT_CCY_PEND_DEC_AMT=0,LIMIT_CCY_UTILISED_AMT=0 WHERE CTY_CODE='US' 
AND LIMIT_ID IN ('17039','16850')




UPDATE  SCBT_T_PROD_LIMIT_UTIL SET LIMIT_CCY_PEND_INC_AMT=0,LIMIT_CCY_PEND_DEC_AMT=0,LIMIT_CCY_UTILISED_AMT=0 WHERE LIMIT_ID IN ('14647','14648') AND BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'HK'

UPDATE SCBT_T_PROD_LIMIT_UTIL SET LIMIT_CCY_PEND_INC_AMT=0,LIMIT_CCY_PEND_DEC_AMT=0,LIMIT_CCY_UTILISED_AMT=0
WHERE CTY_CODE='US' AND LIMIT_ID IN ('15877')

UPDATE SCBT_T_COLL_LIMIT_UTIL SET LIMIT_CCY_PEND_INC_AMT=0,LIMIT_CCY_PEND_DEC_AMT=0,LIMIT_CCY_UTILISED_AMT=0 WHERE CTY_CODE='US' 
AND LIMIT_ID IN ('17039','16850')


DECLARE
BEGIN
   FOR I IN 1..1 LOOP
  update SCBT_T_INVENTORY_HST set DOCUMENT_REF_NO=DOCUMENT_REF_NO +'-' +TO_CHAR(I,'999999999999999999999') where DEAL_ID = 'GB779S00920' and DOCUMENT_REF_NO='BBPB001 / ANPB105';
   END LOOP;
   COMMIT;
END;

UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='27-JAN-2014',PREV_BUSINESS_DATE='25-JAN-2014',NEXT_BUSINESS_DATE='28-JAN-2014' WHERE CTY_CODE='VN';

UPDATE SCBT_S_DAILY_PARAM SET BUSINESS_DATE='24-FEB-2014',PREV_BUSINESS_DATE='22-FEB-2014',NEXT_BUSINESS_DATE='25-FEB-2014' WHERE CTY_CODE='PK';

SELECT * FROM SCBT_T_CTY_DAY_MONTH_INDICATOR WHERE CTY_CODE IN ('VN') AND YEAR='2014' AND MONTH=1

UPDATE SCBT_T_CTY_DAY_MONTH_INDICATOR SET MONTH_END_FLAG=31 WHERE CTY_CODE IN ('VN') AND YEAR='2014' AND MONTH=1


select  NET_COMMODITY_UOM,SEC_NET_COMMODITY_QNTY,SEC_UTILISED_QNTY, SEC_NET_COMMODITY_QNTY_UOM, SEC_UTILISED_QNTY_UOM,deal_id,collateral_id
from SCBT_T_PARCEL_MST where --DEAL_ID='GB779T00250'  and COLLATERAL_ID='GB779T00250012PP'
parcel_id='PP00105657' --PP00109817 PP00109816  PP00105657

UPDATE SCBT_T_PARCEL_MST SET SEC_UTILISED_QNTY_UOM='BALE' WHERE parcel_id='PP00105657'

select  NET_COMMODITY_UOM, SEC_NET_COMMODITY_QNTY_UOM,link_PARCEL_ID,deal_id,collateral_id,deal_step_id
from SCBT_T_PARCEL_HST where  LINK_PARCEL_ID='PP00105657' or PARCEL_ID='PP00105657' or PARENT_PARCEL_ID='PP00105657'
--DEAL_ID='GB779T00250'  and COLLATERAL_ID='GB779T00250012PP'
--parcel_id='PP00109816' ;

select  NET_COMMODITY_UOM, SEC_NET_COMMODITY_QNTY_UOM,SEC_UTILISED_QNTY_UOM,deal_id,collateral_id,deal_Step_id
from SCBT_T_PARCEL_HST where --DEAL_ID='GB779T00250'  and COLLATERAL_ID='GB779T00250012PP'
 parcel_id='PP00105657' and deal_step_id='GB779T00250M0685'
 
UPDATE SCBT_T_PARCEL_HST SET SEC_UTILISED_QNTY_UOM='BALE' where  parcel_id='PP00105657' and deal_step_id='GB779T00250M0685'

---------------------
SELECT COMMST.CTY_CODE,COMMST.COMMODITY_OWNER,COMMST.COMMODITY_ID,COMMST.COMMODITY_CODE,
Scbf_C_Get_Code_Desc(COMMST.BANK_GROUP_CODE, COMMST.CTY_CODE, '*', 'EN', 'CD066', COMMST.COMMODITY_CODE, 1) COMM_DESC,
COMMST.COMMODITY_TYPE_CODE, COMMST.COMMODITY_CAT_CODE, COMMST.EXCH_CODE,PMST.FEED_ID,PMST.FEED_NAME,PMST.SOURCE_TYPE_CODE,PMST.PRICE_SOURCE_CODE,
PMST.PRICE_TYPE_CODE,PMST.VENDOR_CODE,PMST.PRICE_DESC,
Scbf_C_Get_Code_Desc(RICMST.BANK_GROUP_CODE,RICMST.CTY_CODE, '*', 'EN', 'CD112', RICMST.FREQUENCY, 1) AS FREQUENCY
  FROM SCBT_R_COMMODITY_MST COMMST
INNER 
  JOIN SCBT_R_COMMODITY_DTLS COMDTLS 
    ON COMDTLS.COMMODITY_ID = COMMST.COMMODITY_ID
INNER 
  JOIN SCBT_R_COMMODITY_PRICE_MST PMST
  ON COMDTLS.PRICE_FEED_ID = PMST.FEED_ID 
INNER 
    JOIN SCBT_T_TR_RICCODE_LIST_MST RICMST
    ON PMST.FEED_ID = RICMST.RIC_CODE   
    ORDER BY CTY_CODE ASC
    
PRICE_DATE, VENDOR_LAST_UPDATE_DATE,UPDATE_USER_TIMESTAMP,UPDATE_USERID   
SELECT COUNT(*) FROM  SCBT_R_COMMODITY_PRICE_MST PMST --   12791 
    
SELECT PMST.FEED_ID,PMST.FEED_NAME,PMST.SOURCE_TYPE_CODE,PMST.PRICE_SOURCE_CODE,
PMST.PRICE_TYPE_CODE,PMST.VENDOR_CODE,PMST.PRICE_DATE, PMST.VENDOR_LAST_UPDATE_DATE,PMST.UPDATE_USER_TIMESTAMP,PMST.UPDATE_USERID,PMST.PRICE_DESC,
Scbf_C_Get_Code_Desc(RICMST.BANK_GROUP_CODE,RICMST.CTY_CODE, '*', 'EN', 'CD112', RICMST.FREQUENCY, 1) AS FREQUENCY
FROM SCBT_R_COMMODITY_PRICE_MST PMST
LEFT OUTER JOIN SCBT_T_TR_RICCODE_LIST_MST RICMST
ON PMST.FEED_ID = RICMST.RIC_CODE 
ORDER BY RICMST.FREQUENCY ASC
-- CTL_CUSTOMER_ACCOUNT_MASTER_LIST_RELEASE
SELECT DISTINCT PM.PARTY_NAME, CAA.CUST_ID, CAA.ACC_NO, CAM.ACC_DESC, CAA.TXN_CCY_CODE, CAM.ACC_TYPE_CODE,CAM.SYSTEM_CODE,
CASE WHEN CAM.CUST_CO_BORROWER_ID=CAM.CUST_ID THEN '' 
ELSE CAM.cust_co_borrower_id END AS cust_co_borrower_id,
CASE WHEN CAM.CUST_CO_BORROWER_ID=CAM.CUST_ID THEN '' 
ELSE Scbf_Get_Party_Name(CAM.BANK_GROUP_CODE,CAM.CUST_CO_BORROWER_ID) END AS CUST_CO_BORROWER_NAME, 
PM.CTY_CODE
FROM SCBT_T_CUST_ACC_ACTIVITY_MST CAA , SCBT_R_CUST_ACCT_MAINTENANCE CAM, SCBT_R_PARTY_MST PM 
WHERE CAA.BANK_GROUP_CODE = 'SCB' AND CAA.CUST_ID LIKE '%' AND CAA.ACC_NO LIKE '%' 
AND CAA.CUST_ID=PM.PARTY_ID AND PM.CTY_CODE LIKE 'GB' AND CAA.ACC_NO= CAM.ACC_NO(+) 
AND CAM.CTY_CODE(+) = CAA.CTY_CODE AND CAM.CUST_ID(+) = CAA.CUST_ID ORDER BY CAA.CUST_ID ASC

PM0000000020332 -  SCI issue

-- tr
SELECT  DS.FILE_NAME,PM.PRICE_DATE,DS.BUSINESS_DATE,DS.INSTRUMENT_STATUS,DS.INSTRUMENT_SYMBOL,DS.INSTRUMENT_SOURCE,DS.CSNAME,DS.MNEM,
ER.ERROR_CODE,ER.ERROR_TYPE,ER.ERROR_MSG
FROM SCBT_T_IPS_TR_DATA_STREAM DS
LEFT OUTER JOIN SCBT_T_INTERFACE_ERROR ER
ON DS.MNEM = ER.INTERNAL_ID AND DS.FILE_NAME = ER.FILE_NAME
INNER JOIN Scbt_R_Commodity_Price_Mst PM
ON PM.FEED_ID = DS.MNEM
WHERE DS.BUSINESS_DATE='19-FEB-2014' AND DS.FILE_NAME=(SELECT MAX(FILE_NAME) FROM SCBT_T_INTERFACE_DETAILS WHERE PROCESSED_TIME > '18-FEB-2014' 
AND INTERFACE_ID='TR_DATASTREAM_PF') ORDER BY PM.BUSINESS_DATE DESC -- 890

SELECT  DSCOPE.FILE_NAME,PM.PRICE_DATE,DSCOPE.BUSINESS_DATE,DSCOPE.INSTRUMENT_STATUS,DSCOPE.INSTRUMENT_SYMBOL,DSCOPE.INSTRUMENT_SOURCE,
DSCOPE.INSTRUMENT_ID,ER.ERROR_CODE,ER.ERROR_TYPE,ER.ERROR_MSG
FROM SCBT_T_IPS_TR_DATASCOPE DSCOPE
LEFT OUTER JOIN SCBT_T_INTERFACE_ERROR ER
ON DSCOPE.INSTRUMENT_ID = ER.INTERNAL_ID AND DSCOPE.FILE_NAME = ER.FILE_NAME
INNER JOIN Scbt_R_Commodity_Price_Mst PM
ON PM.FEED_ID =  DSCOPE.INSTRUMENT_ID
WHERE DSCOPE.BUSINESS_DATE='19-FEB-2014' AND DSCOPE.FILE_NAME=(SELECT MAX(FILE_NAME) FROM SCBT_T_INTERFACE_DETAILS WHERE PROCESSED_TIME > '18-FEB-2014' 
AND INTERFACE_ID='TR_DATASCOPE_PF') ORDER BY PM.BUSINESS_DATE DESC --71

SELECT RMDS.FILE_NAME,RMDS.BUSINESS_DATE,RMDS.INSTRUMENT_STATUS,RMDS.X_RIC_NAME,RMDS.INSTRUMENT_SYMBOL,
RMDS.INSTRUMENT_SOURCE,
ER.ERROR_CODE,ER.ERROR_TYPE,ER.ERROR_MSG
FROM SCBT_T_IPS_TR_RMDS RMDS
LEFT OUTER JOIN SCBT_T_INTERFACE_ERROR ER
ON RMDS.X_RIC_NAME = ER.INTERNAL_ID AND RMDS.FILE_NAME = ER.FILE_NAME 
INNER JOIN Scbt_R_Commodity_Price_Mst PM
ON PM.FEED_ID =  RMDS.X_RIC_NAME
WHERE RMDS.BUSINESS_DATE='19-FEB-2014' AND RMDS.FILE_NAME=(SELECT MAX(FILE_NAME) FROM SCBT_T_INTERFACE_DETAILS WHERE PROCESSED_TIME > '18-FEB-2014' 
AND INTERFACE_ID='TR_RDMS_PF') ORDER BY PM.BUSINESS_DATE DESC -- 7397


SELECT * FROM SCBT_T_INTERFACE_DETAILS WHERE FILE_NAME='DWE_PL-19022014-033004-SG.xml' -- 890

SELECT * FROM SCBT_T_INTERFACE_DETAILS WHERE FILE_NAME='DSS_D-19022014-092304-SG.xml' -- 71

SELECT * FROM SCBT_T_INTERFACE_DETAILS WHERE FILE_NAME='RMDS-19022014-092804-SG.xml' -- 7411


--Cash Margin issue 
select * from SCBT_T_TXN_MST where CASH_MARGIN_CCY_AMT-CM_CCY_RELEASE_AMT >0 and TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)=0
and cty_code='SG';
update SCBT_T_TXN_MST set CM_CCY_RELEASE_AMT=CASH_MARGIN_CCY_AMT where CASH_MARGIN_CCY_AMT-CM_CCY_RELEASE_AMT >0 and TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)=0
and cty_code='SG';

-- CIS ERROR TEMPLATE : GET_PENDING_CIS_SIP_DEALS
select cty_code,PARTY_ID from scbt_r_party_ext_id where UPPER(ext_system_code)='CIS' and cty_code='GB' --and upper(ext_system_id)=upper(CIS_CUST_ID) 

SELECT * FROM  scbt_r_party_ext_id WHERE PARTY_ID='800000687' -- AND EXT_SYSTEM_ID='NOBLEAMESIP/SMD'

SELECT DISTINCT CIS_CUST_ID  FROM SCBT_T_IPS_CIS_SIP_DEAL WHERE CIS_CUST_ID LIKE 'NOBLERESOU%'

SELECT DISTINCT CIS_CUST_ID  FROM SCBT_T_IPS_CIS_SIP_DEAL  WHERE CTY_CODE='GB'--WHERE CIS_CUST_ID LIKE 'NOBLERESOU%'

select PARTY_ID,EXT_SYSTEM_CODE,EXT_SYSTEM_ID,CTY_CODE from scbt_r_party_ext_id where UPPER(ext_system_code)='CIS' and upper(ext_system_id) in 
(SELECT DISTINCT CIS_CUST_ID  FROM SCBT_T_IPS_CIS_SIP_DEAL  WHERE CTY_CODE='GB') ORDER BY PARTY_ID ASC

select PARTY_ID from scbt_r_party_ext_id where UPPER(ext_system_code)='CIS' and upper(ext_system_id)=upper('NOBLERESOU/SIN')

EBBS TABLES
============
SELECT * FROM SCBT_T_IPS_CB_ACCT_BALANCE WHERE source_file_name in ('CCA_ACCT_GLOBAL-20022014-1-GB.dat','CCA_ACCT_GLOBAL-22022014-1-GB.dat')

SELECT * FROM SCBT_T_IPS_CB_ACCT_DEP_DTLS WHERE COUNTRY_CODE='GB' and source_file_name 
in ('CCA_ACCT_GLOBAL-20022014-2-GB.dat','CCA_ACCT_GLOBAL-22022014-2-GB.dat')
ORDER BY DEPOSITOR_DATE DESC

DECLARE
retVar VARCHAR2(10);
-- 'CCA_ACCT_GLOBAL-20022014-1-GB.dat','CCA_ACCT_GLOBAL-22022014-1-GB.dat' 
-- 'CCA_ACCT_GLOBAL-20022014-2-GB.dat','CCA_ACCT_GLOBAL-22022014-2-GB.dat'
BEGIN
SCBT_EBBS_DATA_FEED.SCBT_EBBS_ACCT_MAST_PROC('SCB','GB','CCA_ACCT_GLOBAL-22022014-2-GB.dat');
END;


SELECT * FROM SCBT_T_CUST_EXT_ACCOUNTS_HST WHERE CTY_CODE='GB'

SELECT * FROM SCBT_T_CUST_EXT_ACCOUNTS_MST WHERE CTY_CODE='GB'

SELECT * FROM SCBT_T_IPS_CB_ACCT_DEP_DTLS WHERE COUNTRY_CODE='GB'

SELECT * FROM SCBT_T_CUST_EXT_ACCOUNTS_HST WHERE CTY_CODE='GB'

SELECT * FROM SCBT_T_CUST_EXT_ACCOUNTS_MST WHERE CTY_CODE='GB'


SELECT * FROM SCBT_T_PARCEL_MST WHERE  CTY_CODE='SG'  AND PARCEL_LEVEL_ADJ_FLAG='C' ORDER BY DEAL_ID DESC--AND PARCEL_ID='PP00102205'

SELECT * FROM SCBT_T_PARCEL_MST WHERE  CTY_CODE='SG'  AND PARCEL_LEVEL_ADJ_FLAG='C' ORDER BY DEAL_ID DESC--AND PARCEL_ID='PP00102205'

-- IM0000018217078 
select TXN_REC_ID,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,TP_REF_ID,DEAL_ID,LATEST_DEAL_STEP_ID from SCBT_T_TXN_MST 
where prod_limit_id='14414' and txn_step_code='NEW' and txn_ref_id='HK514T08237TR002' --- 35550106  35525421  35550106

select TXN_REC_ID,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,TP_REF_ID,DEAL_ID,DEAL_STEP_ID from SCBT_T_TXN_HST 
where tp_ref_id='514010889317' and txn_ref_id='HK514T08237TR002' order by deal_step_id desc

select TXN_REC_ID,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,TP_REF_ID,DEAL_ID,LATEST_DEAL_STEP_ID from SCBT_T_TXN_MST 
where txn_ccy_amt='2020200.00' --

select TXN_REC_ID,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,TP_REF_ID,DEAL_ID,DEAL_STEP_ID from SCBT_T_TXN_HST 
where txn_ccy_amt='2020200.00'

SELECT * FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL WHERE TXN_REC_ID='35550106'

SELECT * FROM SCBT_T_PROD_LIMIT_REQ_LOG WHERE REC_ID='35550106'

SELECT * FROM SCBT_T_PROD_LIMIT_MVMT


SET DEFINE OFF;
Insert into SCBT_T_TXN_MST
   (BANK_GROUP_CODE, CTY_CODE, TXN_REC_ID, PARENT_TXN_REC_ID, LATEST_TXN_REC_ID, TXN_REF_ID, PARENT_TXN_REF_ID, DEAL_ID, CUST_ID, PROD_LIMIT_ID, TXN_STEP_CODE, TP_REF_ID, PRODUCT_CODE, SHORTFALL_OFFSET_TYPE, CPTY_ID, NEGATIVE_TOLERANCE_PCT, POSITIVE_TOLERANCE_PCT, TXN_CCY_CODE, TXN_CCY_ORIGN_AMT, TXN_CCY_AMT, TXN_CCY_NET_AMT, TXN_STATUS_CODE, ISSUE_DATE, EFFECTIVE_DATE, MATURITY_DATE, TENOR, ACCEPTED_FLAG, CASH_MARGIN_CCY_CODE, CASH_MARGIN_CCY_AMT, REVOLVING_LC_FLAG, EVERGREEN_LC_FLAG, AUTO_REVERSAL_FLAG, LATEST_DEAL_STEP_ID, CASH_MARGIN_PCT, TP_SYSTEM_CODE, CASH_MARGIN_ORIGN_AMT, EFFECTIVE_DATE_IS_ZERO, PREV_DEAL_STEP_ID, TRANSACTION_TYPE, SCB_RISK_SHARING_PCT, SYND_POSITIVE_TOLERANCE_PCT, SYND_NEGATIVE_TOLERANCE_PCT, TOTAL_EXPIRY_DAYS, LIMIT_TRANSFER, BOOKING_LOCATION, OBU_ENTITY, OBU_LIMIT_FLAG)
 Values
   ('SCB', 'HK', '35550106', '35525421', '35550106', 'HK514T08237TR002', 'HK514T08237LC001', 'HK514T08237', '800009828', '14414', 'NEW', '514010889317', 'LATR', 'CO', '800002522', 0, 0, 'USD', 1500000, 1500000, 1500000, '01', TO_DATE('01/29/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('01/29/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('02/28/2014 00:00:00', 'MM/DD/YYYY HH24:MI:SS'), 30, 'N', 'USD', 0, 'N', 'N', 'N', 'HK514T08237M0002', 0, 'DTP', 0, 'N', 'HK514T08237M0002', 'SLD', 0, 0, 0, 30, 'N', 'HK', 'SCHK', 'N');
COMMIT;


SELECT * FROM SCBT_R_CODE_DATA WHERE CODE_ID='CD069' --AND CODE_VALUE='CRI'

--- INSURANCE PREMIUM
SELECT DEAL_ID,INVENTORY_ID,QTY FROM SCBT_T_INS_PREM_CALC_TMP WHERE TOTAL_DEAL_VALUE=0 ORDER BY DEAL_ID DESC

SELECT DEAL_ID,INVENTORY_ID,QTY FROM SCBT_T_INS_PREM_CALC_TMP where deal_id='US777S01309' and inventory_id='2211919'

SELECT SIP_DEAL_REF_NO,DEAL_ID,HEDGE_PRICE_CCY_CODE,HEDGE_PRICE_CCY_AMT FROM SCBT_T_SIP_DEAL_SMRY_MST WHERE DEAL_ID IN 
('SG957S00457','SG957S00457','SG957S00469','SG957S00489','SG957S00457','SG957S00469','SG957S00457','SG957S00355-R001',
'SG957S00457','SG957S00303-R004','SG957S00303-R004')

SELECT SIP_DEAL_REF_NO,DEAL_ID,HEDGE_PRICE_CCY_CODE,HEDGE_PRICE_CCY_AMT FROM SCBT_T_SIP_DEAL_SMRY_MST WHERE DEAL_ID IN ('US777S01309')

SELECT SIP_DEAL_REF_NO,DEAL_ID,HEDGE_PRICE_CCY_CODE,HEDGE_PRICE_CCY_AMT FROM SCBT_T_SIP_DEAL_SMRY_MST 
WHERE SIP_DEAL_REF_NO IN ('LBCU-008C(3)','LBCU-009A(3)','LBCU-011(3)','LBCU-012(3)','LBCU-013(3)','NBA-120B(5)','NBL-001A(2)','NUKA-379(2)','TRL-024(2)','TRL-025(3)','TRZ-061(3)')


SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD',501.509 * 7292.58,'USD','Y') from DUAL

SELECT * FROM SCBT_T_INS_PREM_CALC_TMP where deal_id='US777S01309' and inventory_id='2211919'

--- Mahesh
SELECT * FROM scbt_t_txn_cr_linkage_mst where collateral_id='GB779T03527002PP'  and coverage_pct=100  -- GB779T03527M0127

DELETE FROM scbt_t_txn_cr_linkage_mst where collateral_id='GB779T03527002PP'  and coverage_pct=100  -- GB779T03527M0127

SET DEFINE OFF;
Insert into SCBT_T_TXN_CR_LINKAGE_MST
   (BANK_GROUP_CODE, CTY_CODE, CUST_ID, DEAL_ID, DEAL_STEP_ID, TXN_REF_ID, TXN_REC_ID, COLLATERAL_ID, TXN_CCY_COVERAGE_AMT, TXN_CCY_CODE, COVERAGE_PCT)
 Values
   ('SCB', 'GB', '800007227', 'GB779T03527', 'GB779T03527M0127', 'GB779T03527LI002', '38102240', 'GB779T03527002PP', 1299400.84, 'USD', 100);
COMMIT;

UPDATE SCBT_T_DEAL_HIST SET STEP_STATUS_CODE='03' WHERE DEAL_STEP_ID='GB779T03527M0127' AND STEP_STATUS_CODE='01'

SELECT USER_ID,Scbf_Get_User_Name('SCB',USER_ID) as USER_NAME,CTY_CODE,TBU_CODE,LOCK_KEY,SESSION_ID,HOST_NAME 
FROM SCBT_T_SOFT_LOCK WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='GB' -- AND USER_ID=''

DELETE FROM SCBT_T_SOFT_LOCK WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE='GB' --AND USER_ID=''

-- RTP / TD
SELECT * FROM scbt_t_Td_txn_log_flat WHERE PARTY_NAME LIKE '%ICC CHEMICAL%'--LATEST

SELECT * FROM SCBT_T_TD_TXN_STAGE_LOG -- MOVEMENT DETAILS

----
SELECT * FROM SCBT_R_PARTY_EXT_ID WHERE EXT_SYSTEM_CODE LIKE '%SC%'

SELECT * FROM SCBT_T_IPS_SCI_CUST_SYSXREF WHERE  lsx_le_id IN
(SELECT EXT_SYSTEM_ID FROM SCBT_R_PARTY_EXT_ID WHERE CTY_CODE='GB' AND EXT_SYSTEM_CODE LIKE '%EB%')


SELECT * FROM SCBT_T_IPS_SCI_CUST_SYSXREF WHERE  LSX_EXT_SYS_CUST_ID IN
(SELECT EXT_SYSTEM_ID FROM SCBT_R_PARTY_EXT_ID WHERE CTY_CODE='GB' AND EXT_SYSTEM_CODE LIKE '%EB%')

SELECT PARTY_ID FROM SCBT_R_PARTY_EXT_ID WHERE PARTY_ID IN (SELECT DISTINCT CUST_ID FROM SCBT_T_CUST_ACC_SMRY_MST WHERE CTY_CODE='GB')
AND EXT_SYSTEM_CODE='SC'

    SELECT DISTINCT SCBT_T_CUST_EXT_ACCOUNTS_MST.CUSTOMER_ID,SCBT_T_CUST_EXT_ACCOUNTS_MST.EBBS_AMOUNT_BALANCE  --INTO i_relationId, i_ebbsBalance
     FROM SCBT_T_CUST_EXT_ACCOUNTS_MST, SCBT_R_PARTY_EXT_ID, SCBT_T_IPS_SCI_CUST_SYSXREF
     WHERE SCBT_R_PARTY_EXT_ID.PARTY_ID IN (SELECT PARTY_ID FROM SCBT_R_PARTY_EXT_ID WHERE PARTY_ID IN (SELECT DISTINCT CUST_ID FROM SCBT_T_CUST_ACC_SMRY_MST WHERE CTY_CODE='GB')
AND EXT_SYSTEM_CODE='SC')
     AND UPPER(SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_ext_sys_code_value) = UPPER(SCBT_T_CUST_EXT_ACCOUNTS_MST.INPUT_SOURCE)
     AND UPPER(SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_ext_sys_code_value) in ('EBBS','HOGAN')
     AND SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_ext_sys_cust_id = SCBT_T_CUST_EXT_ACCOUNTS_MST.CUSTOMER_ID
     AND SCBT_R_PARTY_EXT_ID.EXT_SYSTEM_ID =  to_char(SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_le_id)
     AND SCBT_T_CUST_EXT_ACCOUNTS_MST.ACCOUNT_NUMBER = '0101266176451'
     AND SCBT_T_CUST_EXT_ACCOUNTS_MST.Account_Ccy ='USD';
     
SELECT *  FROM SCBT_T_IPS_SCI_CUST_SYSXREF WHERE LSX_EXT_SYS_CUST_ID='1093762' --TO_CHAR(LSX_LE_ID) in ('11046154')  

SELECT *  FROM SCBT_T_CUST_EXT_ACCOUNTS_MST WHERE CTY_CODE='GB'  --and CUSTOMER_ID='800007227'

--Removal of Storage Location

RETREIVE_STORAGE_LOC_ID_QUERY
=============================
SELECT DISTINCT b.storage_location_id,'CTA-Collateral Creation',B.COLLATERAL_ID,B.DEAL_ID
                     FROM scbt_t_parcel_mst b
                    WHERE storage_location_id IS NOT NULL
                      AND bank_group_code = 'SCB'
                      AND cty_code = 'SG'
                      AND storage_location_id = 'SC001310001'
          UNION ALL
          SELECT DISTINCT c.storage_location_id,'SIP-Inventory Creation'
                     FROM scbt_t_inventory_mst c
                    WHERE storage_location_id IS NOT NULL
                      AND bank_group_code = 'SCB'
                      AND cty_code = 'SG'
                      AND storage_location_id = 'SC001310001'
          UNION ALL
          SELECT DISTINCT d.storage_loc_id,'Check Record Maintenance'
                     FROM SCBT_R_CHECK_RECORD_MST d
                    WHERE storage_loc_id IS NOT NULL
                      AND bank_group_code = 'SCB'
                      AND cty_code = 'SG'
                      AND storage_loc_id = 'SC001310001'
          UNION ALL
          SELECT DISTINCT TL.COLUMN_VALUE,'Customer Limit Setup - Approved Storage Location'
          FROM SCBT_R_CUST_APPR_LOCATION e, TABLE(CLOB_SPLIT(e.STORAGE_LOCATION_ID)) TL
          WHERE storage_location_id IS NOT NULL
          AND bank_group_code = 'SCB'
          AND cty_code =  'SG'
          AND TL.COLUMN_VALUE IS NOT NULL AND TL.COLUMN_VALUE LIKE 'SC001310001'
          
SELECT * FROM SCBT_R_STORAGE_LOCATION_MST WHERE STORAGE_LOC_ID='SC001310001'

SELECT *  FROM SCBT_T_PARCEL_MST WHERE STORAGE_LOCATION_ID = 'SC001310001' AND STORAGE_COMPANY_ID='SC001310'

UPDATE SCBT_T_PARCEL_MST SET STORAGE_LOCATION_ID = 'SC001216011' ,STORAGE_COMPANY_ID='SC001216' 
WHERE STORAGE_LOCATION_ID = 'SC001310001' AND STORAGE_COMPANY_ID='SC001310' --97

SELECT *  FROM SCBT_T_PARCEL_HST WHERE STORAGE_LOCATION_ID = 'SC001310001' AND STORAGE_COMPANY_ID='SC001310'

UPDATE SCBT_T_PARCEL_HST SET STORAGE_LOCATION_ID = 'SC001216011' ,STORAGE_COMPANY_ID='SC001216' 
WHERE STORAGE_LOCATION_ID = 'SC001310001' AND STORAGE_COMPANY_ID='SC001310' --1919
          
		  
-- ZA Contigent parcels report
SELECT CRM.CUST_ID, Scbf_Get_Party_Name (PRM.BANK_GROUP_CODE,CRM.CUST_ID) AS cust_name,
PRM.* FROM SCBT_T_PARCEL_MST PRM,scbt_t_collateral_register_mst CRM
WHERE  PRM.PARCEL_TYPE_CODE ='CON' AND  (PRM.net_commodity_qnty - nvl(PRM.utilised_qnty,0))>0 
AND PRM.CTY_CODE IN ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM')
and CRM.cty_code = PRM.cty_code and PRM.collateral_id = CRM.collateral_id and PRM.deal_id = CRM.deal_id
AND CRM.BANK_GROUP_CODE=PRM.BANK_GROUP_CODE  AND PRM.PARCEL_ID IN (
SELECT PM.PARCEL_ID FROM SCBT_T_PARCEL_MST PM
LEFT OUTER JOIN scbt_t_txn_cr_linkage_mst CR
 ON CR.COLLATERAL_ID = PM.COLLATERAL_ID
INNER JOIN SCBT_T_TXN_HST TXN
ON TXN.TXN_REC_ID=CR.TXN_REC_ID AND TXN.TXN_REF_ID=CR.TXN_REF_ID AND TXN.DEAL_ID=CR.DEAL_ID
WHERE TXN.TXN_STEP_CODE='CANC' AND TXN.CTY_CODE IN ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM')
AND (PM.NET_COMMODITY_QNTY-NVL(PM.UTILISED_QNTY,0)) > 0 )


SELECT TXN.CTY_CODE,TXN.CUST_ID,PM.PARCEL_ID,PM.DEAL_ID,PM.COLLATERAL_ID,PM.PARCEL_TYPE_CODE,PM.NET_COMMODITY_QNTY,PM.UTILISED_QNTY, 
(PM.NET_COMMODITY_QNTY-NVL(PM.UTILISED_QNTY,0)) AS OS FROM SCBT_T_PARCEL_MST PM
LEFT OUTER JOIN scbt_t_txn_cr_linkage_mst CR
 ON CR.COLLATERAL_ID = PM.COLLATERAL_ID
INNER JOIN SCBT_T_TXN_HST TXN
ON TXN.TXN_REC_ID=CR.TXN_REC_ID AND TXN.TXN_REF_ID=CR.TXN_REF_ID AND TXN.DEAL_ID=CR.DEAL_ID
WHERE TXN.TXN_STEP_CODE='CANC' AND TXN.CTY_CODE IN ('ZW','CI','CM','GM','NG','UG','KE','BW','GH','SL','TZ','ZA','ZM')
AND (PM.NET_COMMODITY_QNTY-NVL(PM.UTILISED_QNTY,0)) > 0 ORDER BY TXN.CTY_CODE ASC		  

--- mail
SELECT dh.DEAL_ID,dh.DEAL_STEP_ID,dh.TP_DEAL_ID,dh.TP_STEP_ID,dh.MAKER_ID,dh.MAKER_TIMESTAMP,dh.CHECKER_ID,dh.CHECKER_TIMESTAMP,mail.MSG_CRE_TIMESTAMP,
mdtls.RPT_CHNL_TO_ADDR
FROM SCBT_T_DEAL_HIST dh
INNER JOIN SCBT_T_RPT_CHNL_MSG mail
ON dh.DEAL_STEP_ID = mail.STEP_ID
INNER JOIN SCBT_T_RPT_CHNL_DTLS mdtls
on mail.REC_ID=mdtls.REC_ID
WHERE dh.CTY_CODE='AE' AND business_date between '30-MAR-2014' and '31-MAR-2014'
and maker_id='1002796' ORDER BY CHECKER_TIMESTAMP DESC;

SELECT FROM_TZ(CAST(TO_DATE(CHECKER_TIMESTAMP) AS TIMESTAMP), 'Etc/GMT+8')
AT TIME ZONE 'Etc/GMT+4' "West Coast Time",CHECKER_TIMESTAMP FROM SCBT_T_DEAL_HIST WHERE DEAL_STEP_ID='AE123T11511M0001'

select business_date AT TIME ZONE 'Kuala Lumpur/Malaysia'   as sydney_time from SCBT_T_DEAL_HIST ;

SELECT UNIQUE tzname, tzabbrev FROM V$TIMEZONE_NAMES  where tzabbrev='GMT+4'--TO_TIMESTAMP_TZ

SELECT UNIQUE tzname FROM V$TIMEZONE_NAMES;


SELECT FROM_TZ(CAST(TO_DATE('1999-12-01 11:00:00','YYYY-MM-DD HH:MI:SS') AS TIMESTAMP), 'America/New_York')
AT TIME ZONE 'Etc/GMT+8' "West Coast Time"
FROM DUAL;

SELECT FROM_TZ(CAST(TO_DATE(CHECKER_TIMESTAMP) AS TIMESTAMP), 'Etc/GMT+8')
AT TIME ZONE 'Etc/GMT+4' "West Coast Time",CHECKER_TIMESTAMP FROM SCBT_T_DEAL_HIST WHERE DEAL_STEP_ID='AE123T11511M0001'

SELECT TO_TIMESTAMP_TZ(business_date,   'YYYY-MM-DD HH:MI:SS TZH:TZM') FROM SCBT_T_DEAL_HIST;


-- MISMATCH IN COCOA STOCK REPORT (FOR BRUKFIELD RICE - PAKISTAN)
select PARCEL_ID,Parcel_type_code,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS,
FIRST_COLLATERAL_DATE
from scbt_t_parcel_mst  where 
parcel_type_code not in ('MST', 'REL') and
deal_id in ('PK415F00053')
AND PARCEL_ID IN ('PP00115519','PP00115052','PP00113989','PP00113156','PP00112756')
--and (net_commodity_qnty - nvl(utilised_qnty,0))>0 and cty_code='PK'
--AND COLLATERAL_ID IN ('PK415F00053007RL','PK415F00053002RL','PK415F00053003PP','PK415F00053004RL','PK415F00053009RL','PK415F00053001PP',
--'PK415F00053001RL','PK415F00053008RL')


select PARCEL_ID,LINK_PARCEL_ID,Parcel_type_code,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS,
FIRST_COLLATERAL_DATE 
from scbt_t_parcel_mst where LINK_PARCEL_ID IN ('PP00115519','PP00115052','PP00113989','PP00113156','PP00112756')
or PARCEL_ID IN ('PP00115519','PP00115052','PP00113989','PP00113156','PP00112756')
or PARENT_PARCEL_ID IN ('PP00115519','PP00115052','PP00113989','PP00113156','PP00112756')


ZM339T00038054PP
ZM339T00038030PP
ZM339T00038014PP
ZM339T00038023PP
ZM339T00038052PP
ZM339T00038031PP
ZM339T00038019PP
ZM339T00038013PP
ZM339T00038053PP

--- 130D JOBS 08-APR-2014
UPDATE SCBT_R_LIMIT_FX_MAINT_MST SET REFRESH_DATE = (SELECT REFRESH_DATE FROM scbt_r_limit_fx_rate_mst WHERE cty_code = 'TH' AND fx_ccy_code = 'USD')
WHERE cty_code = 'TH' AND fx_ccy_code = 'USD'

SELECT * FROM scbt_r_limit_fx_rate_mst WHERE cty_code = 'CN' AND fx_ccy_code = 'USD' 

UPDATE scbt_r_limit_fx_rate_mst SET RATE=6.1515,MULTIPLYING_FACTOR=6.1515,REFRESH_DATE='08-APR-2014',UPD_TIMESTAMP='08-APR-2014'
WHERE cty_code = 'CN' AND fx_ccy_code = 'USD'

SELECT * FROM scbt_r_limit_fx_maint_mst WHERE cty_code = 'CN' AND fx_ccy_code = 'USD'  

UPDATE scbt_r_limit_fx_maint_mst SET RATE=6.1515,MULTIPLYING_FACTOR=6.1515,REFRESH_DATE='08-APR-2014' 
WHERE cty_code = 'CN' AND fx_ccy_code = 'USD'

--
SELECT * FROM scbt_r_limit_fx_rate_mst WHERE cty_code = 'MU' AND fx_ccy_code = 'USD' 

SELECT * FROM scbt_r_limit_fx_maint_mst WHERE cty_code = 'MU' AND fx_ccy_code = 'USD'  

UPDATE scbt_r_limit_fx_maint_mst SET REFRESH_DATE=(SELECT REFRESH_DATE FROM scbt_r_limit_fx_rate_mst WHERE cty_code = 'MU' AND fx_ccy_code = 'USD')
WHERE cty_code = 'MU' AND fx_ccy_code = 'USD'

DECLARE
retVar VARCHAR2(10);
BEGIN
Scbk_P_Prod_Tls.SCBP_TLS_PROD_CCYREVALPROCESS(retVar,'SCB','MU',TO_DATE('08-APR-2014','DD-MON-YYYY'),'MANUALRUN001');
END; 

SELECT COUNT(*) FROM SCBT_R_LIMIT_FX_MAINT_MST WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'MO' 
AND REFRESH_DATE = (SELECT BUSINESS_DATE FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'MO');



GET_SEARCH_CUST_UNASSIGNED_COLLATERAL_LIST

/prd/cocoa/hk/bin/scripts/COCOAODSFILEGEN.sh

mv COCOAODSFILEGEN.sh COCOAODSFILEGEN.sh_bkp_12April14
mv COCOAODSFILEGEN.sh_new COCOAODSFILEGEN.sh



/opt/mule/lib/user/CCA_ODS_GLOBAL-ApplicationContext.xml

mv CCA_ODS_GLOBAL-ApplicationContext.xml CCA_ODS_GLOBAL-ApplicationContext.xml_bkp_12April14

mv CCA_ODS_GLOBAL-ApplicationContext.xml_new CCA_ODS_GLOBAL-ApplicationContext.xml

-- Outstanding exposure
SELECT SUM(CMV_CCY_AMT) FROM SCBT_T_PARCEL_MST WHERE PARCEL_TYPE_CODE NOT IN ('MST','REL') AND CMV_CCY_AMT > 0 AND
COLLATERAL_ID IN (SELECT COLLATERAL_ID FROM SCBT_T_TXN_CR_LINKAGE_MST WHERE CUST_ID='800010955' AND DEAL_ID 
IN ('US777T00299','US777T00299','US777T00985','US777T01025','US777T01065','US777T01071','US777T01103','US777T01109',
'US777T01151','US777T01163','US777T01167','US777T01173')) -- 7068253.59 (CDB : 7935632.86)

SELECT SUM(TOTAL_CMV_CCY_AMT) FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE CUST_ID='800010955' AND COLLATERAL_ID IN 
(SELECT COLLATERAL_ID FROM SCBT_T_TXN_CR_LINKAGE_MST WHERE CUST_ID='800010955' AND DEAL_ID 
IN ('US777T00299','US777T00299','US777T00985','US777T01025','US777T01065','US777T01071','US777T01103','US777T01109',
'US777T01151','US777T01163','US777T01167','US777T01173')) AND TOTAL_CMV_CCY_AMT > 0 -- 7068253.59 (Report : 7068.25*1000)

--- Sudheer TR Request
SELECT * FROM SCBT_T_IPS_TR_DATA_STREAM WHERE FILE_NAME='DWE_PL-15042014-033003-SG.xml' --890

SELECT * FROM SCBT_T_IPS_TR_DATASCOPE WHERE FILE_NAME='DSS_C-15042014-092805-SG.xml' -- 895

SELECT * FROM SCBT_T_IPS_TR_DATASCOPE WHERE FILE_NAME='DSSMCI_C-15042014-091505-SG.xml' -- 37

SELECT * FROM SCBT_T_IPS_TR_DATASCOPE WHERE FILE_NAME='DSS_D-15042014-092305-SG.xml' -- 71

SELECT * FROM SCBT_T_IPS_TR_DATASCOPE WHERE FILE_NAME='DSSMCI_D-15042014-092105-SG.xml' -- 6

SELECT * FROM SCBT_T_IPS_TR_DATASCOPE WHERE FILE_NAME='DSSNCX_D-15042014-091805-SG.xml' -- 13

SELECT INSTRUMENT_SYMBOL,X_RIC_NAME,DSPLY_NAME,DSPLY_NMLL,HST_CLOSE,CURRENCY,BID,ASK FROM SCBT_T_IPS_TR_RMDS 
WHERE FILE_NAME='RMDS-15042014-092805-SG.xml' --7411

---
select * from SCBT_T_PARCEL_MST where parcel_id in ('PP00059272','RL00061424','RL00061425','RL00063695');

select PARCEL_ID,LINK_PARCEL_ID,PARENT_PARCEL_ID,Parcel_type_code,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_mst where (LINK_PARCEL_ID IN ('PP00056932') or PARCEL_ID IN ('PP00056932') or PARENT_PARCEL_ID IN ('PP00056932'))

select DEAL_ID,DEAL_STEP_ID,PARCEL_ID,LINK_PARCEL_ID,Parcel_type_code,COLLATERAL_ID,NET_COMMODITY_QNTY,UTILISED_QNTY,(net_commodity_qnty - nvl(utilised_qnty,0)) AS OS
from scbt_t_parcel_hst where DEAL_STEP_ID LIKE 'GB779T01788M%' 
AND (LINK_PARCEL_ID IN ('PP00059272') or PARCEL_ID IN ('PP00059272') or PARENT_PARCEL_ID IN ('PP00059272')) 
ORDER BY DEAL_STEP_ID DESC

update scbt_t_parcel_mst set PARENT_PARCEL_ID='',LINK_PARCEL_ID='PP00056932' where parcel_id='PP00059272' and collateral_id='GB779T01788004PP';

update scbt_t_parcel_mst set PARENT_PARCEL_ID='PP00056932',LINK_PARCEL_ID='CN00043591' where parcel_id='PP00059272' and collateral_id='GB779T01788004PP';


select * from scbt_t_txn_mst where deal_id='GB779T05517' and txn_status_code<>'11'--39748409   39657555-P   40954953  40347947-P  40954953

select txn_ccy_net_amt,txn_ccy_util_amt,txn_rec_id,parent_txn_rec_id,txn_step_code from scbt_t_txn_hst where deal_Step_id='GB779T05517M0013';

update scbt_t_txn_mst set txn_ccy_util_amt=txn_ccy_net_amt, txn_status_code='11' where deal_id='GB779T05517' and txn_rec_id='39748409';