select T331298.CTY_CODE as c1,
       T331298.SIP_DEAL_REF_NO as c2,
T331298.DEAL_ID AS DEALID,
       NVL(T331298.Deal_Security_Level_Code ,'REPO'),
       NVL(T331381.APPROVED_SECURITY_LEVEL ,'REPO'),
       T331332.PARTY_NAME as c3,
       T331298.PURCHASE_PRICE_CCY_CODE as c4,
       T331298.PURCHASE_PRICE_CCY_AMT as c5,
       T331298.DEAL_START_DATE as c6,
       T331298.DEAL_END_DATE as c7,
       T331298.HEDGE_DATE as c8,
       nvl(T331298.NET_COMMODITY_QNTY, 0) - nvl(T331298.UTILISED_QNTY, 0) as c9,
       nvl(T331381.NET_COMMODITY_QNTY, 0) - nvl(T331381.UTILISED_QNTY, 0) as c10,
       nvl(T331381.NET_COMMODITY_QNTY, 0) - nvl(T331381.UTILISED_QNTY, 0) -
       (nvl(T331298.NET_COMMODITY_QNTY, 0) - nvl(T331298.UTILISED_QNTY, 0)) as c11,
       Scbf_C_Get_Code_Desc('SCB',
                            T331298.CTY_CODE,
                            '*',
                            'EN',
                            'CD016',
                            T331298.NET_COMMODITY_QNTY_UOM,
                            '1') as c12,
       cast(Scbf_C_Get_Code_Desc('SCB',
                                 T331405.CTY_CODE,
                                 '*',
                                 'EN',
                                 'CD066',
                                 T331405.COMMODITY_CODE,
                                 '1') as VARCHAR(80)) as c13,
       case
         when T331298.DEAL_STATUS_CODE = 'FRO' then
          'NO'
         when T331298.DEAL_STATUS_CODE = 'DCL' then
          'NO'
         when T331298.DEAL_STATUS_CODE = 'FER' then
          'NO'
         else
          'YES'
       end as c14,
       T331298.CUST_ID as c15,
       T331298.DEAL_TYPE_CODE as c16,
       T331298.INSURANCE_COVERED_BY as c17,
       T331332.CTY_CODE as c18,
       ROW_NUMBER() OVER(PARTITION BY nvl(T331298.NET_COMMODITY_QNTY, 0) - nvl(T331298.UTILISED_QNTY, 0), nvl(T331381.NET_COMMODITY_QNTY, 0) - nvl(T331381.UTILISED_QNTY, 0), T331298.CTY_CODE, T331298.CUST_ID, T331298.DEAL_END_DATE, T331298.DEAL_START_DATE, T331298.DEAL_TYPE_CODE, T331298.HEDGE_DATE, T331298.PURCHASE_PRICE_CCY_AMT, T331298.PURCHASE_PRICE_CCY_CODE, T331298.SIP_DEAL_REF_NO, T331298.INSURANCE_COVERED_BY, T331332.CTY_CODE, T331332.PARTY_NAME,case
         when T331298.DEAL_STATUS_CODE =
              'FRO' then
          'NO'
         when T331298.DEAL_STATUS_CODE =
              'DCL' then
          'NO'
         when T331298.DEAL_STATUS_CODE =
              'FER' then
          'NO'
         else
          'YES'
       end, cast(Scbf_C_Get_Code_Desc('SCB', T331405.CTY_CODE, '*', 'EN', 'CD066', T331405.COMMODITY_CODE, '1') as VARCHAR(80)), Scbf_C_Get_Code_Desc('SCB', T331298.CTY_CODE, '*', 'EN', 'CD016', T331298.NET_COMMODITY_QNTY_UOM, '1') ORDER BY nvl(T331298.NET_COMMODITY_QNTY, 0) - nvl(T331298.UTILISED_QNTY, 0) ASC, nvl(T331381.NET_COMMODITY_QNTY, 0) - nvl(T331381.UTILISED_QNTY, 0) ASC, T331298.CTY_CODE ASC, T331298.CUST_ID ASC, T331298.DEAL_END_DATE ASC, T331298.DEAL_START_DATE ASC, T331298.DEAL_TYPE_CODE ASC, T331298.HEDGE_DATE ASC, T331298.PURCHASE_PRICE_CCY_AMT ASC, T331298.PURCHASE_PRICE_CCY_CODE ASC, T331298.SIP_DEAL_REF_NO ASC, T331298.INSURANCE_COVERED_BY ASC, T331332.CTY_CODE ASC, T331332.PARTY_NAME ASC,case
         when T331298.DEAL_STATUS_CODE =
              'FRO' then
          'NO'
         when T331298.DEAL_STATUS_CODE =
              'DCL' then
          'NO'
         when T331298.DEAL_STATUS_CODE =
              'FER' then
          'NO'
         else
          'YES'
       end ASC, cast(Scbf_C_Get_Code_Desc('SCB', T331405.CTY_CODE, '*', 'EN', 'CD066', T331405.COMMODITY_CODE, '1') as VARCHAR(80)) ASC, Scbf_C_Get_Code_Desc('SCB', T331298.CTY_CODE, '*', 'EN', 'CD016', T331298.NET_COMMODITY_QNTY_UOM, '1') ASC) as c19
  from SCBT_R_COMMODITY_MST     T331405 /* Static Commodity */,
       SCBT_R_PARTY_MST         T331332 /* Static Party */,
       SCBT_T_SIP_DEAL_SMRY_MST T331298 /* Static Sip Deal Smry */,
       SCBT_T_INVENTORY_SMRY    T331381 /* Static Inventory Smry */
 where (T331381.BANK_GROUP_CODE = T331405.BANK_GROUP_CODE and
       T331298.BANK_GROUP_CODE = T331332.BANK_GROUP_CODE and
       T331298.CTY_CODE = T331332.CTY_CODE and
       T331298.CUST_ID = T331332.PARTY_ID and
       T331298.BANK_GROUP_CODE = T331381.BANK_GROUP_CODE and
       T331298.DEAL_ID = T331381.DEAL_ID and
       T331381.COMMODITY_ID = T331405.COMMODITY_ID)