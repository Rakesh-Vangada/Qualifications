Health check Steps
==================
/*
1.Handover mail
2.Batch Status Check - All Countries
*/

SELECT CTY_CODE "Country",TO_CHAR(BUSINESS_dATE,'dd/mm/yyyy') "Business Date",
TO_CHAR(MIN(JOB_START_TIME),'dd/mm/yy')"Start Day",
TO_CHAR(MIN(JOB_START_TIME),'hh:mi:ss')"Start Time",
TO_CHAR(MAX(JOB_END_tIME),'dd/mm/yy')"End Day",
SUBSTR(TO_CHAR(MAX(JOB_END_tIME),'hh:mi:ss'),0,10)"End Time",
SUBSTR((numtodsinterval((MAX(JOB_END_tIME) - MIN(JOB_START_TIME)), 'HOUR') * 24),11,9)"TOTAL RUN TIME",
TO_CHAR(MAX(JOB_END_tIME),'hh24:mi:ss')"ONLINE TIME",   
SUBSTR((numtodsinterval((MAX(JOB_END_tIME) - MIN(JOB_START_TIME)), 'HOUR') * 24),11,9)"TIME TAKEN FOR ONLINE"
FROM SCBT_T_BATCH_STAT S  
WHERE (JOB_NAME LIKE ('PCOCO%100D') OR JOB_NAME LIKE ('PCOCO%160D'))
AND JOB_NAME NOT LIKE 'PCOCO%9500D'AND JOB_NAME NOT LIKE 'PCOCO%1500D'
AND TRUNC(BUSINESs_DATE)=TRUNC(SYSDATE-1)
AND CTY_CODE NOT IN (
SELECT CTY_cODE FROM (
SELECT DISTINCT CTY_CODE,COUNT(1) FROM scbt_t_batch_STAT WHERE 
(JOB_NAME LIKE ('PCOCO%100D') OR JOB_NAME LIKE ('PCOCO%160D'))AND JOB_NAME NOT LIKE 
'PCOCO%9500D'AND JOB_NAME NOT LIKE 'PCOCO%1500D'
AND TRUNC(BUSINESs_DATE)=TRUNC(SYSDATE-1)
GROUP BY cty_Code HAVING COUNT(1)<>2))
GROUP BY CTY_cODE,BUSINESS_dATE
UNION 
SELECT CTY_CODE,TO_CHAR(BUSINESS_dATE,'dd/mm/yyyy') "Business Date",
TO_CHAR(MIN(JOB_START_TIME),'dd/mm/yy')"Start Day",
TO_CHAR(MIN(JOB_START_TIME),'hh24:mi:ss')"Start Time",'','','BATCH IS IN','PROGRESS','' 
FROM SCBT_T_BATCH_STAT WHERE CTY_CODE IN (
SELECT DISTINCT CTY_CODE FROM scbt_t_batch_STAT WHERE 
(JOB_NAME LIKE ('PCOCO%100D') OR JOB_NAME LIKE ('PCOCO%160D'))AND JOB_NAME NOT LIKE 
'PCOCO%9500D'AND JOB_NAME NOT LIKE 'PCOCO%1500D'
AND TRUNC(BUSINESs_DATE)=TRUNC(SYSDATE-1)
GROUP BY cty_Code HAVING COUNT(1)<>2) 
AND JOB_NAME LIKE 'PCOCO%100D' AND TRUNC(BUSINESs_DATE)=TRUNC(SYSDATE-1)
GROUP BY CTY_CODE,BUSINESS_dATE--- SL ISSUE
UNION
SELECT CTY_CODE,TO_CHAR(HOLIDAY_DATE,'dd/mm/yyyy'),'','','','','HOLIDAY','',HOLIDAY_DESC
FROM SCBT_R_LOCAL_HOLIDAY_MST WHERE HOLIDAY_dATE = TRUNC(SYSDATE-1) 
UNION 
SELECT cty_code,TO_CHAR(BUSINESS_DATE,'dd/mm/yyyy'), '','','','','BATCH','','not started'
FROM scbt_s_daily_param WHERE 
cty_code NOT IN('AQ','AT','ZW','AF','KR','LB') AND TRUNC(business_Date) = TRUNC(SYSDATE-1)
AND cty_code NOT IN(SELECT cty_Code FROM SCBT_T_BATCH_STAT 
WHERE (JOB_NAME NOT LIKE 'PCOCO%100D') AND (
CTY_code NOT IN (SELECT CTY_CODE FROM SCBT_R_LOCAL_HOLIDAY_MST WHERE HOLIDAY_dATE = TRUNC(SYSDATE-1))) 
AND TRUNC(BUSINESS_DATE)=TRUNC(SYSDATE-1))

/*

7:00 AM - important check--ZIP the file. basically 230D batch does the zipping.
========
PG817
/prd/cocoa/
gzip*dat
/prd/cocoa/batch/upload/obbs/grec/history

3. Health Check of application with price feed check
Take screen shot of application

run price feed check queries to check TR feeds...
*/
select distinct file_name from SCBT_T_IPS_TR_DATA_STREAM where business_date='14-Oct-2013' order by business_date desc;  1 File
select distinct file_name from SCBT_T_IPS_TR_DATASCOPE where business_date='14-Oct-2013'  order by business_date desc;       5 Files
select distinct file_name from SCBT_T_IPS_TR_RMDS where business_date='14-Oct-2013'  order by business_date desc;        1 Files

--in case of any discrepancies in Thomson Reuters
Thomson Reuters(TR)
===================
problem: Datascope/Datastream/rmds not available
Resolution:
Mail to Vishal Joshi, cc- COCOA PSI
Subject: URGENT >>>TR price for DATASCOPE not available - 16-Oct-2013

/prd/cocoa/batch/upload/tr/tr-datascope/cca-tr-datascope-history
/prd/cocoa/batch/upload/tr/tr-datastream/cca-tr-datastream-history
/prd/cocoa/batch/upload/tr/tr-rmds/cca-tr-rmds-history

check the logs  on PG1094  at prd/cocoa/tr/askapp/Cocoa_1.1.5/var/log/ask.2013-10-16.0.log




 