In PG190
=========
truncate table scbt_t_ins_pre_tmp;

truncate table scbt_t_ins_prem_calc_tmp;

exec scbk_p_ins_prem.scbp_ins_pre_calc_new('1','2014-02-01 00:00:00','2014-02-28 00:00:00');


After that we need to run the below query to generate the report:
-----------------------------------------------------------------

SELECT mst.cty_code AS BUSINESS_UNIT,
scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD099'    ,
                                                LOC.ADD_CTY_CODE   ,
                                                '1') Storage_Country,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD061'    ,
                                                LOC.LOCATION_CODE   ,
                                                '1') Storage_Location,
       scbf_get_storage_company_name(mst.bank_group_code,SUBSTR(tmp.storage_location_id,1,8)) Storage_Company_name,
       Scbf_Get_Storage_Location_Name(mst.bank_group_code,tmp.storage_location_id) Storage_Location,
       Scbf_Get_Commodity_Name(mst.bank_group_code,tmp.commodity_id) Commodity_name,
       mst.deal_type_code,
       mst.sip_deal_ref_no,
       mst.deal_start_date,
       mst.deal_end_Date,
       tmp.prem_start_date,
       tmp.prem_end_date,
       tmp.no_of_days,
       tmp.qty Quantity,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                tmp.net_commodity_qnty_uom,
                                                '1') UOM,
       mst.hedge_price_ccy_amt,
       tmp.total_deal_value,
       tmp.storage_location_id,
       tmp.commodity_id
       FROM SCBT_T_INS_PREM_CALC_TMP TMP, SCBT_T_SIP_DEAL_SMRY_MST MST, SCBT_R_STORAGE_LOCATION_MST LOC
 WHERE TMP.DEAL_ID = MST.DEAL_ID
 AND TMP.BANK_GROUP_CODE=MST.BANK_GROUP_CODE
 AND TMP.CUST_ID=MST.CUST_ID
 AND LOC.STORAGE_LOC_ID=TMP.STORAGE_LOCATION_ID
 AND LOC.BANK_GROUP_CODE=TMP.BANK_GROUP_CODE
 and tmp.total_deal_value > 0


-------------------------------------------------------

Extras:
---------

select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0 --90 ccy codes empty then proceed 

select * from scbt_t_ins_prem_calc_tmp 

select distinct PURCHASE_PRICE_CCY_CODE from SCBT_T_SIP_DEAL_SMRY_MST where deal_id in (select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0)

update SCBT_T_SIP_DEAL_SMRY_MST set hedge_price_ccy_code='USD' where deal_id in (select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0)

RUN PROC AGAIN:
=================
truncate table scbt_t_ins_pre_tmp;

truncate table scbt_t_ins_prem_calc_tmp;

exec scbk_p_ins_prem.scbp_ins_pre_calc_new('1','2014-02-01 00:00:00','2014-02-28 00:00:00');


select SCBF_TLS_EXCH_RATE('SCB', 'GB', 'USD', 1 * 13680.5,'USD','Y') from dual;

CHECK FOR THE TOTAL_DEAL_VALUE WHICH SHUD BE GT ZERO.

Generate the report
===================

SELECT mst.cty_code AS BUSINESS_UNIT,
scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD099'    ,
                                                LOC.ADD_CTY_CODE   ,
                                                '1') Storage_Country,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD061'    ,
                                                LOC.LOCATION_CODE   ,
                                                '1') Storage_Location,
       scbf_get_storage_company_name(mst.bank_group_code,SUBSTR(tmp.storage_location_id,1,8)) Storage_Company_name,
       Scbf_Get_Storage_Location_Name(mst.bank_group_code,tmp.storage_location_id) Storage_Location,
       Scbf_Get_Commodity_Name(mst.bank_group_code,tmp.commodity_id) Commodity_name,
       mst.deal_type_code,
       mst.sip_deal_ref_no,
       mst.deal_start_date,
       mst.deal_end_Date,
       tmp.prem_start_date,
       tmp.prem_end_date,
       tmp.no_of_days,
       tmp.qty Quantity,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                tmp.net_commodity_qnty_uom,
                                                '1') UOM,
       mst.hedge_price_ccy_amt,
       tmp.total_deal_value,
       tmp.storage_location_id,
       tmp.commodity_id
       FROM SCBT_T_INS_PREM_CALC_TMP TMP, SCBT_T_SIP_DEAL_SMRY_MST MST, SCBT_R_STORAGE_LOCATION_MST LOC
 WHERE TMP.DEAL_ID = MST.DEAL_ID
 AND TMP.BANK_GROUP_CODE=MST.BANK_GROUP_CODE
 AND TMP.CUST_ID=MST.CUST_ID
 AND LOC.STORAGE_LOC_ID=TMP.STORAGE_LOCATION_ID
 AND LOC.BANK_GROUP_CODE=TMP.BANK_GROUP_CODE
 and tmp.total_deal_value > 0
 
 select deal_id,hedge_price_ccy_amt,hedge_price_ccy_code from SCBT_T_SIP_DEAL_SMRY_HST where deal_id in (select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0) and hedge_price_ccy_amt is not null
 
 DEAL_ID
SG957S00355-R002
SG957S00303-R005
SG957S00559
SG957S00587


SELECT MST.DEAL_ID,MST.CTY_CODE, MST.PURCHASE_PRICE_CCY_CODE,MST.PURCHASE_PRICE_CCY_AMT,MST.NET_COMMODITY_QNTY_UOM,MST.NET_COMMODITY_QNTY,TMP.QTY,
MST.HEDGE_PRICE_CCY_CODE,MST.HEDGE_PRICE_CCY_AMT,TMP.TOTAL_DEAL_VALUE,MST.DEAL_TYPE_CODE
FROM scbt_t_ins_prem_calc_tmp TMP
LEFT OUTER JOIN SCBT_T_SIP_DEAL_SMRY_MST MST
ON TMP.DEAL_ID=MST.DEAL_ID
WHERE TMP.TOTAL_DEAL_VALUE <= 0

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (24.505 * 1800.5),'USD','Y') FROM DUAL -- 44121.2525

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (299.894 * 7386.15),'USD','Y') FROM DUAL -- 2215062.0681

--- FINAL
SELECT MST.DEAL_ID,MST.CTY_CODE,TMP.QTY,
MST.HEDGE_PRICE_CCY_CODE,MST.HEDGE_PRICE_CCY_AMT,TMP.TOTAL_DEAL_VALUE,MST.DEAL_TYPE_CODE
FROM scbt_t_ins_prem_calc_tmp TMP
LEFT OUTER JOIN SCBT_T_SIP_DEAL_SMRY_MST MST
ON TMP.DEAL_ID=MST.DEAL_ID
WHERE TMP.TOTAL_DEAL_VALUE <= 0

--SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (24.505 * 1800.5),'USD','Y') FROM DUAL -- 44121.2525

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (299.894 * 7386.15),'USD','Y') FROM DUAL -- SG957S00559 2215062.0681

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (299.929 * 7386.15),'USD','Y') FROM DUAL -- SG957S00559 2215320.58335

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (399.961 * 7386.15),'USD','Y') FROM DUAL -- SG957S00559  2954171.94015

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (299.759 * 7115),'USD','Y') FROM DUAL -- SG957S00303-R005 2132785.285

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (299.916 * 7270),'USD','Y') FROM DUAL -- SG957S00355-R002 2180389.32

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (499.268 * 7070),'USD','Y') FROM DUAL -- SG957S00587 3529824.76

SELECT SCBF_TLS_EXCH_RATE('SCB', 'SG', 'USD', (499.416 * 7070),'USD','Y') FROM DUAL -- SG957S00587 3530871.12

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='2215062.0681' WHERE DEAL_ID='SG957S00559' AND QTY='299.894' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='2215320.58335' WHERE DEAL_ID='SG957S00559' AND QTY='299.929' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='2954171.94015' WHERE DEAL_ID='SG957S00559' AND QTY='399.961' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='2132785.285' WHERE DEAL_ID='SG957S00303-R005' AND QTY='299.759' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='2180389.32' WHERE DEAL_ID='SG957S00355-R002' AND QTY='299.916' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='3529824.76' WHERE DEAL_ID='SG957S00587' AND QTY='499.268' AND TOTAL_DEAL_VALUE=0;

UPDATE SCBT_T_INS_PREM_CALC_TMP SET TOTAL_DEAL_VALUE='3530871.12' WHERE DEAL_ID='SG957S00587' AND QTY='499.416' AND TOTAL_DEAL_VALUE=0;
