--------------Check Record Maintenance---------

SELECT * FROM SCBT_R_CHECK_RECORD_LOG_MST ;
SELECT * FROM SCBT_R_CHECK_RECORD_LOG_HIST ;
SELECT * FROM SCBT_R_CHECK_RECORD_HIST;
SELECT * FROM SCBT_R_CHECK_RECORD_MST ;
SELECT * FROM SCBT_R_CHECK_RECORD_DOCUMENTS;

---------------Insurance Policy Maintenance ----------

SELECT * FROM SCBT_R_INS_MST WHERE POLICY_NO='SSC000581'
SELECT * FROM SCBT_R_INS_PREMIUM_MST WHERE INS_ID='2'
SELECT * FROM SCBT_R_CODE_DATA WHERE CODE_ID='CI140' ----Insurance Company Name
SELECT * FROM SCBT_R_CODE_DATA WHERE CODE_ID='CI319' --- Ownership
SELECT * FROM SCBT_R_CODE_DATA WHERE CODE_ID='CD082' -- Type of Insurance 

-----------------Customer Document Library-------------------

SELECT * FROM SCBT_R_CUST_DOCUMENTS_HIST;
SELECT * FROM SCBT_R_CUST_DOCUMENTS_MST 

-------------Deal Document Library-------------------------

SELECT * FROM SCBT_R_DEAL_DOCUMENTS_MST;
SELECT * FROM SCBT_R_DEAL_DOCUMENTS_HIST;

J158 Code and FSV
===============
select * from SCBT_R_CUST_PROD_FSV_MST where J158_CODE = 'CF844';
select * from SCBT_R_CUST_PROD_FSV_HIST where CUST_ID='800005807' and CTY_CODE='SG' and STEP_STATUS_CODE <> '03';
SCBT_R_J158_MAINTENANCE_HIST
SCBT_R_J158_MAINTENANCE_MST

Earmarking and adjustment
======================
SELECT * FROM SCBT_T_LIMIT_MAINT WHERE src_cust_id ='800005815' AND maint_status_code='OPN'
SCBT_T_LIMIT_MAINT_DTLS_HIST
SCBT_T_LIMIT_MAINT_SNAPSHOT

check record maintenance
=====================
SCBT_R_CHECK_RECORD_MST
scbt_r_check_record_log_hist

BCA Related
==========
select * from SCBT_T_IPS_SCI_CUST_PROFILE where LMP_SHORT_NAME like '%KAMA SCHACHTER JEWELRY INC%' ;-- will give the leid
select * from SCBT_T_IPS_IN_MSG  where MSG_REFID ='11266451';--use the same leid in this query to get the last rcv date

BCA expiry check after loading from SCI_IN_MSG
=====================================
SELECT *  FROM SCBT_T_IPS_SCI_APPR_LMTPROF WHERE TO_CHAR(LLP_LE_ID) in ('11191340')  ORDER BY LLP_BCA_REF_APPR_DATE DESC;


--Mail related tables
----------------------
 select * from SCBT_T_RPT_CHNL_MSG; --  pass deal step id
  select * from SCBT_T_RPT_CHNL_DTLS; --pass rec id from SCBT_T_RPT_CHNL_MSG

--CIS Related
 -----------------
SCBT_T_IPS_CIS_IN_MSG  ---this table just receives the SIp deals from CIS, if the message content is "validated" state then it will move it to  SCBT_T_IPS_CIS_ SIP_DEAL  else it will not.
SCBT_T_IPS_CIS_ SIP_DEAL --this table should get updated to get the Sip deal reflected in COCOA
 
  
--- SIP related Tables

SCBT_T_SIP_DEAL_SMRY_HST
SCBT_T_SIP_DEAL_SMRY_MST
SCBT_T_INVENTORY_HST
SCBT_T_INVENTORY_MST
SCBT_T_INVENTORY_SMRY
SCBT_T_INVENTORY_SMRY_HST
SCBT_T_INVENTORY_SMRY_MVMT
SCBT_T_INVENTORY_SNAPSHOT
SCBT_T_DEAL_ER_SMRY_HST
SCBT_T_DEAL_ER_SMRY_MST
SCBT_T_DEAL_HIST
SCBT_T_DEAL_MST


Exchange deliverable validation maintenance
===================================
select * from SCBT_R_EXCH_VALIDATION_MST where EXCHANGE_CODE='LME';
select * from scbt_r_exch_validation_mst where exchange_code='LME' and brand_id in ('10000690','10000689','10001051');

Limit tables:
===========
-- HISTORY DATA
SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST WHERE CUST_ID='800001396'  AND CTY_CODE='SG'-- 29 ROWS
SELECT * FROM SCBT_R_CUST_INS_LIMIT_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'-- 0
SELECT * FROM SCBT_R_CUST_PROD_FSV_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0
SELECT * FROM SCBT_R_CUST_COLLAT_LIMIT_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--24
SELECT * FROM SCBT_R_CUST_APPR_COM_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--8
SELECT * FROM SCBT_R_CUST_COL_GRP_LIMIT_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0
SELECT * FROM SCBT_R_CUST_BCA_COND_LIMIT_HST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0
SELECT * FROM SCBT_R_CUST_FACILITY_GRP_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0
SELECT * FROM SCBT_R_CUST_APPR_LOCATION_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--8
SELECT * FROM SCBT_R_CUST_LIMIT_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--8
SELECT * FROM SCBT_R_CUST_SYNDICATION_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0
SELECT * FROM SCBT_R_CUST_RISK_SHARING_HIST WHERE CUST_ID='800001396' AND CTY_CODE='SG'--0

-- MASTER DATA

SELECT * FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE CUST_ID='800001396'  AND CTY_CODE='SG'-- 5 ROWS
SELECT * FROM SCBT_R_PARTY_MST WHERE PARTY_ID='800001396' -- 3
SELECT * FROM SCBT_R_CUST_INS_LIMIT WHERE CUST_ID='800001396' --0
SELECT * FROM SCBT_R_CUST_PROD_FSV_MST WHERE CUST_ID='800001396' --0
SELECT * FROM SCBT_R_CUST_COLLAT_LIMIT WHERE CUST_ID='800001396' -- 6
SELECT * FROM SCBT_R_CUST_APPR_COM WHERE CUST_ID='800001396' AND CTY_CODE='SG'--1
SELECT * FROM SCBT_R_CUST_COL_GRP_LIMIT WHERE CUST_ID='800001396' AND CTY_CODE='SG' --0
SELECT * FROM SCBT_R_CUST_FACILITY_GRP WHERE CUST_ID='800001396' AND CTY_CODE='SG' --0
SELECT * FROM SCBT_R_CUST_BCA_COND_LIMIT WHERE CUST_ID='800001396' AND CTY_CODE='SG' --0
SELECT * FROM SCBT_R_CUST_APPR_LOCATION WHERE CUST_ID='800001396' AND CTY_CODE='SG' --1
SELECT * FROM SCBT_R_CUST_LIMIT_MST WHERE CUST_ID='800001396' AND CTY_CODE='SG' --1
SELECT * FROM SCBT_R_CUST_SYNDICATION_MST WHERE CUST_ID='800001396' AND CTY_CODE='SG' --0
SELECT * FROM SCBT_R_CUST_RISK_SHARING_MST WHERE CUST_ID='800001396' AND CTY_CODE='SG' --0


Coll limit tables
===============
seLECT count(*) FROM SCBT_T_COLL_LIMIT_MVMT WHERE init_req_id IN (SELECT init_req_id FROM SCBT_T_COLL_LIMIT_REQ_LOG_DTL WHERE OBLIGOR_ID='800007193' and cty_code='GB') and cty_code='GB';

SELECT count(*) FROM SCBT_T_COLL_LIMIT_REQ_LOG WHERE init_req_id IN (SELECT init_req_id FROM SCBT_T_COLL_LIMIT_REQ_LOG_DTL WHERE OBLIGOR_ID='800007193' and cty_code='GB') and cty_code='GB';

SELECT count(*) FROM SCBT_T_COLL_LIMIT_REQ_LOG_DTL WHERE OBLIGOR_ID='800007193' and cty_code='GB';

select count(*) from SCBT_T_COLL_LIMIT_UTIL where LIMIT_ID in (
SELECT collateral_limit_id FROM SCBT_R_CUST_COLLAT_LIMIT WHERE CUST_ID ='800009787' and cty_code='HK'
union
SELECT APPR_COMMODITY_LIMIT_ID FROM SCBT_R_CUST_APPR_COM WHERE CUST_ID ='800009787' and cty_code='HK'
union
SELECT LOCATION_LIMIT_GROUP_ID FROM SCBT_R_CUST_APPR_LOCATION WHERE CUST_ID ='800009787' and cty_code='HK'
union
SELECT COLLATERAL_GROUP_LIMIT_ID FROM SCBT_R_CUST_COL_GRP_LIMIT WHERE CUST_ID ='800009787' and cty_code='HK'
union
SELECT APPR_COMMODITY_LIMIT_ID FROM SCBT_R_CUST_APPR_COM WHERE CUST_ID ='800009787' and cty_code='HK'
union
select INSURANCE_LIMIT_ID from SCBT_R_CUST_INS_LIMIT where CUST_ID ='800009787' and CTY_CODE='HK'
) and cty_code='HK' and (LIMIT_CCY_PEND_INC_AMT>0 or LIMIT_CCY_PEND_DEC_AMT>0 or LIMIT_CCY_UTILISED_AMT>0);

Coll tables data:
SELECT count(*) FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE cust_id = '800007193' AND cty_code ='GB';

SELECT count(*) FROM SCBT_T_PARCEL_MST WHERE collateral_id IN (SELECT collateral_id FROM SCBT_T_COLLATERAL_REGISTER_MST WHERE cust_id = '800007193' AND cty_code ='GB');

Customer Maintenance
==================
--Master tables
SELECT * FROM SCBT_R_PARTY_MST WHERE PARTY_ID = '800001396' --AND CTY_CODE='SG'
SELECT * FROM SCBT_R_INS_MST WHERE CORPORATE_ID='800001396'
SELECT * FROM SCBT_R_PARTY_ADD WHERE PARTY_ID = '800001396'
SELECT * FROM SCBT_R_PARTY_CONTACT WHERE PARTY_ID = '800001396'
SELECT * FROM SCBT_R_CUST_ACCT_MAINTENANCE WHERE CUST_ID = '800001396'
SELECT * FROM SCBT_R_CUST_CO_BORROWER WHERE PARTY_ID = '800001396'
SELECT * FROM SCBT_R_PARTY_EXT_ID WHERE PARTY_ID = '800001396' --
SELECT * FROM SCBT_R_PARTY_SCI_MST WHERE PARTY_ID = '800001396' --
SELECT * FROM SCBT_R_PARTY_LLS_ADD WHERE PARTY_ID = '800001396'
SELECT * FROM SCBT_R_CUST_DOCUMENTS_MST WHERE CUST_ID='800001396'
SELECT PARTY_ID,PARTY_NAME,RESIDENCE_CTY_CODE,BLACKLISTED_FLAG,BLACKLIST_REASON,REMARKS FROM SCBT_R_PARTY_MST 
WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE='SG' AND PARTY_ID = '800001396'

--History tables
select * from SCBT_R_PARTY_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03'; --AND CTY_CODE='SG'
select * from SCBT_R_INS_HIST where CORPORATE_ID='800005807' and STEP_STATUS_CODE <> '03';
select * from SCBT_R_PARTY_ADD_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03';
select * from SCBT_R_PARTY_CONTACT_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03';
select * from SCBT_R_CUST_ACCT_MAINTENANCE where CUST_ID = '800005807' and STEP_STATUS_CODE <> '03';
select * from SCBT_R_CUST_CO_BORROWER_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03';
select * from SCBT_R_PARTY_EXT_ID_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03'; --
select * from SCBT_R_PARTY_SCI_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03'; --
select * from SCBT_R_PARTY_LLS_ADD_HIST where PARTY_ID = '800005807' and STEP_STATUS_CODE <> '03';
SELECT * FROM SCBT_R_CUST_DOCUMENTS_HIST WHERE CUST_ID='800005807' and STEP_STATUS_CODE <> '03';

CAGG CHECK
===========
select * from SCBT_R_CODE_DATA where CODE_ID='CD689' and CODE_VALUE in ('CF908','CF854','CF851');
select * from SCBT_T_IPS_SCI_APPR_LIMITS where LMT_LE_ID = '11245389'; 
select * from SCBT_T_IPS_SCI_APPR_LIMITS where LMT_LE_ID='11245389' and LMT_ID in ('20510269','70343945');
select * from scbt_t_ips_sci_lmt_appr_sec where las_le_id='11245389' and sec_sub_type_value in ('CF908','CF854','CF851');--20510269
SECURITEIS ARE AGAINST appr limit - 20510269

SCI Limits
=========

SELECT DISTINCT lmt_le_id,LIMIT_SETUP_APPLN_REF,limit_type,lmt_id, n_lmt_outer_lmt_id,code_value_2,desc_1,n_lmt_crrncy_iso_code,n_lmt_amt,
            n_lmt_expry_date,n_lmt_tenor,n_lmt_tenor_basis_value,sci_orgn_value,n_lmt_prd_type_value,n_lmt_share_ind,n_lmt_advise_ind,
            n_lmt_cmmtd_ind,borrower_id,borrower_name,borrower_limitid,borrower_le_id,n_lmt_revolve_code_value 
            FROM(
                   SELECT l.lmt_le_id,p.LIMIT_SETUP_APPLN_REF,DECODE (l.n_lmt_outer_lmt_id,'0', 'Outer','', 'Outer','Inner') AS limit_type, 
                 l.lmt_id, l.n_lmt_outer_lmt_id,m.code_value_2,
                 Scbf_C_Get_Code_Desc(p.BANK_GROUP_CODE, nvl(b.bkl_cntry_iso_code,'*'),'*', 'EN', 'CD043', m.code_value_2, 1) as desc_1,
                 l.n_lmt_crrncy_iso_code,l.n_lmt_amt,l.n_lmt_expry_date,l.n_lmt_tenor,
                 l.n_lmt_tenor_basis_value,(b.bkl_cntry_iso_code || '/' || b.bkl_bkg_loctn_orgn_value) AS sci_orgn_value,l.n_lmt_prd_type_value,
                   l.n_lmt_share_ind,l.n_lmt_advise_ind,l.n_lmt_cmmtd_ind,'' AS borrower_id,'' AS borrower_name, '' AS borrower_limitid,
                   '' AS borrower_le_id,l.n_lmt_revolve_code_value 
                 FROM scbt_t_ips_sci_appr_limits l,scbt_t_ips_sci_stdc_value s,scbt_t_ips_sci_stdc_bkgloctn b,SCBT_R_MAP_INFO m,
                   SCBT_R_PARTY_MST p,    SCBT_R_PARTY_EXT_ID e
                 WHERE l.lmt_le_id LIKE '%11247759%' AND s.stv_std_code_num = l.lmt_prd_type_num AND s.stv_std_code_value = l.n_lmt_prd_type_value
                 AND b.bkl_loctn_id = l.n_lmt_bkg_loctn_id AND l.n_lmt_prd_type_value = m.code_value_1(+) 
                   AND m.map_id = 'MLM03' AND p.BANK_GROUP_CODE = 'SCB'
                   AND p.PARTY_ID LIKE '800007336' AND e.PARTY_ID = p.PARTY_ID
                   AND e.cty_code = '*' AND e.EXT_SYSTEM_ID = l.LMT_LE_ID AND e.EXT_SYSTEM_CODE = 'SC'
                   AND P.CTY_CODE = '*' AND NVL(l.ACTIVE_FLAG,'Y') = 'Y'
            )                                                                                                                 
            START WITH n_lmt_outer_lmt_id IS NULL CONNECT BY PRIOR lmt_id=n_lmt_outer_lmt_id

