--------------BU Maintenance--------------***********

---General Details---
Select * from SCBT_R_TBU_MST
Select * from SCBT_R_TBU_HIST

---Address Details---
Select * from SCBT_R_TBU_ADD_MST
Select * from SCBT_R_TBU_ADD_HIST

---Nostro Account Details---
Select * from SCBT_R_TBU_NOSTRO_ACC_MST
Select * from SCBT_R_TBU_NOSTRO_ACC_HIST

--------------Code Maintenance--------------***********
Select * from SCBT_R_CODE_DATA_HIST
Select * from SCBT_R_CODE_DATA

--------------Param Maintenance--------------***********
---Param Data---
Select * from SCBT_R_PARAM_DATA
Select * from SCBT_R_PARAM_DATA_HIST

---Details about Param like access by whom, cty specific.....etc
Select * from SCBT_R_PARAM_DEFN

---Deatails about Param Keys and Details---
Select * from SCBT_R_PARAM_FIELD_DEFN

--------------Fx Rate Maintenance--------------***********
Select * from SCBT_R_LIMIT_FX_MAINT_MST
Select * from SCBT_R_LIMIT_FX_MAINT_HIST

Select * from SCBT_R_LIMIT_FX_RATE_HIST
Select * from SCBT_R_LIMIT_FX_RATE_MST


--------------Holiday Maintenance--------------***********
Select * from SCBT_R_LOCAL_HOLIDAY_MST
Select * from SCBT_R_LOCAL_HOLIDAY_HIST


--------------RM Maintenance--------------***********
Select * from SCBT_R_RM_MST
Select * from SCBT_R_RM_HIST


--------------SIP Manager Maintenance--------------***********
Select * from SCBT_R_SIP_MANAGER_MST
Select * from SCBT_R_SIP_MANAGER_HIST


--------------User Profile Maintenance--------------***********
Select * from SCBT_R_USER_MST
Select * from SCBT_R_USER_HIST





