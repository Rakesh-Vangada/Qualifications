-- LINKED CASH BALANCE

SELECT A.ACC_NO,A.ACC_CCY_ANTICIPATED_AMT, A.ACC_CCY_CODE 
FROM SCBT_T_CUST_ACC_SMRY_MST A,SCBT_R_CUST_ACCT_MAINTENANCE M
WHERE A.BANK_GROUP_CODE = 'SCB'
                         AND A.CTY_CODE        = 'GB'
                         AND A.CUST_ID         = '800013855'
                         --AND A.ACC_NO          = accNo
                         --AND A.ACC_CCY_CODE    = accCcy
                         AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
                         AND M.CTY_CODE        = A.CTY_CODE
                         AND M.CUST_ID         = A.CUST_ID
						 AND M.INCLUDE_FOR_CASH_COLLATERAL ='Y'
                         AND M.ACC_NO          = A.ACC_NO

-- EXPOSURE OFFSET AMOUNT						 
SELECT A.ACC_NO,A.ACC_CCY_ANTICIPATED_AMT, A.ACC_CCY_CODE 
FROM SCBT_T_CUST_ACC_SMRY_MST A,SCBT_R_CUST_ACCT_MAINTENANCE M
WHERE A.BANK_GROUP_CODE = 'SCB'
                         AND A.CTY_CODE        = 'GB'
                         AND A.CUST_ID         = '800013855'
                         --AND A.ACC_NO          = accNo
                         --AND A.ACC_CCY_CODE    = accCcy
                         AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
                         AND M.CTY_CODE        = A.CTY_CODE
                         AND M.CUST_ID         = A.CUST_ID
						 AND M.EXPOSURE_OFFSET = 'Y'
                         AND M.ACC_NO          = A.ACC_NO

-- CASH MARGIN AND OUTSTANDING AMOUNT

SELECT DEAL_ID,TXN_REF_ID,TXN_REC_ID,PROD_LIMIT_ID,CASH_MARGIN_CCY_CODE,
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
			  DECODE(TM.SCB_ROLE,'AG',TM.SYNDICATED_TXN_AMT-NVL(TM.SYNDICATED_UTIL_AMT,0),TM.TXN_CCY_NET_AMT-NVL(TM.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING
FROM SCBT_T_TXN_MST TM
WHERE TM.BANK_GROUP_CODE = 'SCB'
           AND TM.CTY_CODE = 'GB'
           AND TM.CUST_ID = '800013855'
           AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') 
	   AND ((TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) > 0 
            OR (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
           ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
           ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0) 
           AND NOT EXISTS  ( SELECT TXN_REC_ID
                             FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                             AND TH.CUST_ID = DH.CUST_ID
                             AND TH.DEAL_ID = DH.DEAL_ID
                             AND TH.CTY_CODE = DH.CTY_CODE
                             AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                             AND DH.STEP_STATUS_CODE IN ( '02','10','14') 
                             AND TH.BANK_GROUP_CODE = 'SCB'
                             AND TH.CTY_CODE = 'GB'
                             AND TH.CUST_ID = '800013855'
                             AND TH.TXN_REC_ID = TM.TXN_REC_ID) 
UNION ALL                             
SELECT TH.DEAL_ID,TH.TXN_REF_ID,TH.TXN_REC_ID,TH.PROD_LIMIT_ID,TH.CASH_MARGIN_CCY_CODE,
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
			  DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING
FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = 'SCB'
                   AND TH.CTY_CODE = 'GB'
                   AND TH.CUST_ID = '800013855'
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT','CANC') 
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' 

-- COLLATERAL CAP				   
				   
SELECT NVL(sum( d.ncv_txn_ccy_amt), 0) FROM SCBT_T_coll_LIMIT_REQ_LOG R,
SCBT_T_Coll_LIMIT_REQ_LOG_DTL D
WHERE  R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
AND R.CTY_CODE = D.CTY_CODE
AND R.INIT_REQ_ID= D.INIT_REQ_ID
AND R.REQ_TYPE_CODE = 'NEW'
AND R.REQ_STATUS_CODE in ('PEND','CON')
AND R.BANK_GROUP_CODE='SCB'
AND R.CTY_CODE ='GB'
AND D.COLLATERAL_LIMIT_ID in ('18622','18623','18624')

--Finding prod limit id for the client secured and unsecured 

  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT c
   WHERE bank_group_code      = 'SCB'
     AND cty_code                 = 'GB'
       AND cust_id                  = '800013855'
       AND shortfall_offset     = 'CUL' order by limit_classification;

-- Secured

    SELECT  DISTINCT TXN_REC_ID,
                 TXN_CCY,
                 SOURCE,
                 DEAL_STEP_ID
                 FROM
                   (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = 'SCB'
                       AND MST.CTY_CODE = 'GB'
                       AND MST.cust_id = '800013855'
                       AND MST.prod_limit_id in ('17299','17300','17321','18283','17322')
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
                                           AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE  
                           AND TH.CTY_CODE=DH.CTY_CODE      
                           AND TH.DEAL_ID=DH.DEAL_ID        
                           AND TH.CUST_ID=DH.CUST_ID        
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.PROD_LIMIT_ID in ('17299','17300','17321','18283','17322')    
                           AND TH.cust_id = '800013855')
           UNION ALL --COCOAREF_08012013 
           SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = 'SCB'
                        AND MST.CTY_CODE = 'GB'
                        AND MST.cust_id = '800013855'
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id in ('17299','17300','17321','18283','17322')
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y' 
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') 
                                            AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0 
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE 
                           AND TH.CTY_CODE=DH.CTY_CODE     
                           AND TH.DEAL_ID=DH.DEAL_ID       
                           AND TH.CUST_ID=DH.CUST_ID       
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  
                           AND TH.PROD_LIMIT_ID in ('17299','17300','17321','18283','17322')   
                           AND TH.cust_id = '800013855')                                      
              UNION ALL
                   SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         'H' AS SOURCE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.prod_limit_id in ('17299','17300','17321','18283','17322')
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT')    
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE  
                           AND TH.CTY_CODE=DH.CTY_CODE      
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           --AND NVL(TH.TXN_STATUS_CODE,'02') <> '11'   
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'   
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = '800013855');
                                       
-- Collalateral id

SELECT collateral_id,NVL(coverage_pct,0) 
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code='SCB'
                  AND cty_code = 'GB'
                  AND txn_rec_id in ('11941373','13406225','13406157','13794649','13796472','12090330')
                  AND cust_id = '800013855'    
                  AND txn_rec_id not in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = 'SCB'
                                      AND H1.cty_code = 'GB'
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      --AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H2.CUST_ID=DH.CUST_ID  
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') <> '08'
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID
                                      AND DH.cust_id = '800013855'    
                                      --AND NVL(H1.TXN_STATUS_CODE,'01') <> '11'     
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      AND H1.txn_step_code <> 'CANC');
                                       

--NCV Amt for collateral Group cap for secured please check if coverage percentage is 100

SELECT sum(total_ncv_ccy_amt)
                    FROM scbt_t_collateral_register_mst
                    WHERE bank_group_code='SCB'
                    AND cty_code = 'GB'
                    AND CUST_ID = '800013855'
                    AND collateral_id in ('GB779T01566001PP','GB779T01566003PP','GB779T01582001PP','GB779T01626001PP','GB779T01318001PP');
                              
                              
-- Unsecured txn rec id based on the unsecured limit id

    SELECT  DISTINCT TXN_REC_ID,
                 TXN_CCY,
                 SOURCE,
                 DEAL_STEP_ID
                 FROM
                   (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = 'SCB'
                       AND MST.CTY_CODE = 'GB'
                       AND MST.cust_id = '800013855'
                       AND MST.prod_limit_id in ('17306','18286','18284','17323','17325','17304','17303','17301')
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')  
                                           AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE  
                           AND TH.CTY_CODE=DH.CTY_CODE      
                           AND TH.DEAL_ID=DH.DEAL_ID        
                           AND TH.CUST_ID=DH.CUST_ID        
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.PROD_LIMIT_ID in ('17306','18286','18284','17323','17325','17304','17303','17301')    
                           AND TH.cust_id = '800013855')
           UNION ALL --COCOAREF_08012013 
           SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = 'SCB'
                        AND MST.CTY_CODE = 'GB'
                        AND MST.cust_id = '800013855'
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id in ('17306','18286','18284','17323','17325','17304','17303','17301')
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y' 
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') 
                                            AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0 
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE 
                           AND TH.CTY_CODE=DH.CTY_CODE     
                           AND TH.DEAL_ID=DH.DEAL_ID       
                           AND TH.CUST_ID=DH.CUST_ID       
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  
                           AND TH.PROD_LIMIT_ID in ('17306','18286','18284','17323','17325','17304','17303','17301')   
                           AND TH.cust_id = '800013855')                                      
              UNION ALL
                   SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         'H' AS SOURCE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = 'SCB'
                           AND TH.CTY_CODE = 'GB'
                           AND TH.prod_limit_id in ('17306','18286','18284','17323','17325','17304','17303','17301')
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT')    --AND TH.TXN_STEP_CODE != 'SETT'
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE  
                           AND TH.CTY_CODE=DH.CTY_CODE      
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           --AND NVL(TH.TXN_STATUS_CODE,'02') <> '11'   
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'   
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = '800013855');
                                                                   

-- Based on the txn rec id, retrieving the collateral id    

-- If the source is 'M' and deal step id is blank

SELECT collateral_id,NVL(coverage_pct,0) 
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code='SCB'
                  AND cty_code = 'GB'
                  AND txn_rec_id in ('10169450')
                  AND cust_id = '800013855'    
                  AND txn_rec_id not in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = 'SCB'
                                      AND H1.cty_code = 'GB'
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      --AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H2.CUST_ID=DH.CUST_ID  
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') <> '08'
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID
                                      AND DH.cust_id = '800013855'    
                                      --AND NVL(H1.TXN_STATUS_CODE,'01') <> '11'     
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      AND H1.txn_step_code <> 'CANC');


--If source is 'H'

                SELECT collateral_id,coverage_pct FROM (
                        SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                    WHERE bank_group_code='SCB'
                    AND cty_code = 'GB'
                    AND cust_id = '800013855'    
                    AND txn_rec_id = '13406277' AND deal_step_id = 'GB779T01740M0007' AND NVL(OP_CODE,'O') <> 'D'
                   UNION
                   SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                    WHERE bank_group_code='SCB'
                      AND cty_code = 'GB'
                      AND cust_id = '800013855'    
                      AND txn_rec_id = '13406277'
                      AND (collateral_id,txn_rec_id) NOT IN(
                               SELECT collateral_id,txn_rec_id
                                FROM Scbt_t_Txn_Cr_Linkage_hst
                                WHERE bank_group_code='SCB'
                              AND cty_code = 'GB'
                              AND cust_id = '800013855'    
                              AND txn_rec_id = '13406277' 
                                            AND deal_step_id = 'GB779T01740M0007' AND NVL(OP_CODE,'O') <> 'D'
                       ));

-- REFERENCE TABLE
					   
SELECT * FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST WHERE CUST_ID='800013855' 
AND CLIENT_GROUP_INDICATOR='CLIENT';

SELECT * FROM SCBT_T_CUST_SFALL_OFFSET_MST;

SELECT * FROM SCBT_T_COLL_SFALL_DETAIL_MST;					   
