select  CUSTOMER_NAME,
BUSINESS_UNIT,
  Storage_Country,
  State,
  Location_code,
  Storage_Company_name,
  Storage_Location_Name,
  SIP_DEAL_REF_NO,
  Commodity_name,
  INVENTORY_UOM,
  inventory_netweight,
  DEAL_TYPE_CODE,
  DEAL_START_DATE,
  DEAL_END_DATE,
  DEAL_SECURITY_LEVEL_CODE,
  deal_tonnage,
  DEAL_PURCHASE_PRICE_CCY_CODE,
  DEAL_PURCHASE_PRICE,
  DEAL_PURCHASE_PRICE_UOM,
  DEAL_INVOICE_CCY,
  DEAL_INVOICE_VALUE,
  COLLATERAL_FILE_REF_NO,
  first_collateral_date,
  Repurchase_Date ,
  DOCUMENT_REF_NO,
  SHAPE_TYPE,
  NO_OF_SHAPES,
  PACKAGE_TYPE,
  NO_OF_PACKAGES,
  INVENTORY_STATUS,
  CUSTODIAN_REF_NO,    
  EXCHG_SYSTEM_CODE,
  EXCHANGE_CODE_ID,  
  EXCHG_SYSTEM_ID

FROM ( SELECT DISTINCT   SCBF_GET_PARTY_NAME(inv.bank_group_code,inv.cust_id) CUSTOMER_NAME , inv.cty_code BUSINESS_UNIT,
scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD099'    ,
                                                LOC.ADD_CTY_CODE   ,
                                                '1')  Storage_Country,
                                                LOC.STATE_CODE State,

       scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD061'    ,
                                                LOC.LOCATION_CODE   ,
                                                '1') Location_code,
scbf_get_storage_company_name(inv.bank_group_code,SUBSTR(inv.storage_location_id,1,8)) Storage_Company_name,
Scbf_Get_Storage_Location_Name(inv.bank_group_code,inv.storage_location_id) Storage_Location_Name ,
inv.sip_deal_ref_no SIP_DEAL_REF_NO,
Scbf_Get_Commodity_Name(INV.bank_group_code,INV.commodity_id) Commodity_name,
       scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                inv.net_commodity_qnty_uom,
                                                '1') INVENTORY_UOM    ,
                (NVL (inv.net_commodity_qnty, 0) - NVL (inv.utilised_qnty, 0)
                ) AS INVENTORY_NETWEIGHT,

                

                SHIST.DEAL_START_DATE,
                SHIST.DEAL_END_DATE,
                SHIST.DEAL_TYPE_CODE,
                SHIST.DEAL_SECURITY_LEVEL_CODE,
                (SHIST.NET_COMMODITY_QNTY-NVL(SHIST.UTILISED_QNTY,0) ) DEAL_TONNAGE,
                SHIST.PURCHASE_PRICE_CCY_CODE DEAL_PURCHASE_PRICE_CCY_CODE ,
                SHIST.PURCHASE_PRICE_CCY_AMT DEAL_PURCHASE_PRICE,

                 scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                 SHIST.PURCHASE_PRICE_UOM,
                                                '1') DEAL_PURCHASE_PRICE_UOM,


                SHIST.INVOICE_CCY_CODE DEAL_INVOICE_CCY,
                SHIST.INVOICE_CCY_AMT DEAL_INVOICE_VALUE,
                INV.COLLATERAL_FILE_REF_NO,
                 inv.first_collateral_date,
                 CASE WHEN  INV.INVENTORY_TYPE_CODE='REL' THEN
   inv.Repurchase_Date
  ELSE
  null
  END Repurchase_Date,

                 INV.DOCUMENT_REF_NO,

                 INV.SHAPE_TYPE_CODE SHAPE_TYPE,
                  INV.SHAPE_NO NO_OF_SHAPES,

  INV.sec_commodity_qnty_uom PACKAGE_TYPE,
  INV.SEC_COMMODITY_QNTY NO_OF_PACKAGES,
  CASE WHEN  INV.INVENTORY_TYPE_CODE='REL' THEN
  'RELEASED'
  ELSE
  'OUTSTANDING'
  END INVENTORY_STATUS,

                inv.cust_id Customer_ID,
                inv.commodity_id,
                inv.deal_id,
                inv.deal_step_id,
                inv.storage_location_id,  inv.inventory_type_code,
                inv.inventory_status_code,
                INV.INVENTORY_ID,
                INV.CUSTODIAN_REF_NO CUSTODIAN_REF_NO,    
  INV.EXCHG_SYSTEM_CODE EXCHG_SYSTEM_CODE,
  INV.EXCHANGE_CODE_ID EXCHANGE_CODE_ID,  
  INV.EXCHG_SYSTEM_ID EXCHG_SYSTEM_ID
           FROM scbt_t_inventory_snapshot inv, scbt_t_sip_deal_smry_hst shist,
           scbt_r_storage_location_mst loc

          WHERE inv.bank_group_code = shist.bank_group_code
            AND inv.cty_code = shist.cty_code
            AND inv.cust_id = shist.cust_id
            and loc.storage_loc_id=inv.storage_location_id
            and loc.bank_group_code=inv.bank_group_code
             AND inv.inventory_type_code IN ('MST', 'ROI', 'TRI', 'CRE','REL')

           AND SUBSTR (inv.deal_id, 1, 11) = SUBSTR (shist.deal_id, 1, 11)

                    AND (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) > 0
                       AND shist.deal_status_code NOT IN ('IRO', 'FRO', 'DCL', 'FER')
                       AND inv.deal_step_id IN
                           (SELECT MAX(hi.deal_step_id)
                              FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv1
                             WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')

                               AND step_code = 'SIPI'
                  
                               AND hi.step_status_code = '03'
                               AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv1.deal_id, 1, 11)
                             GROUP BY SUBSTR(hi.deal_id, 1, 11))
                       AND shist.deal_step_id IN
                           (SELECT MAX(hi.deal_step_id)
                              FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv2
                             WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')
                               AND step_code = 'SIPD'
                   
                               AND hi.step_status_code = '03'
                               AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv2.deal_id, 1, 11)
                             GROUP BY SUBSTR(hi.deal_id, 1, 11))
    




            UNION ALL

            SELECT DISTINCT   SCBF_GET_PARTY_NAME(inv.bank_group_code,inv.cust_id) CUSTOMER_NAME , inv.cty_code BUSINESS_UNIT,
'VESSEL' STORAGE_COUNTRY,
'VESSEL' STATE,
       'VESSEL' Location_code,
'IN TRANSIT',
'IN TRANSIT' ,
inv.sip_deal_ref_no SIP_DEAL_REF_NO,
Scbf_Get_Commodity_Name(INV.bank_group_code,INV.commodity_id) Commodity_name,
       scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                inv.net_commodity_qnty_uom,
                                                '1') INVENTORY_UOM    ,
                (NVL (inv.net_commodity_qnty, 0) - NVL (inv.utilised_qnty, 0)
                ) AS INVENTORY_NETWEIGHT,
                

                SHIST.DEAL_START_DATE,
                SHIST.DEAL_END_DATE,
                SHIST.DEAL_TYPE_CODE,
                SHIST.DEAL_SECURITY_LEVEL_CODE,
                (SHIST.NET_COMMODITY_QNTY-NVL(SHIST.UTILISED_QNTY,0) ) DEAL_TONNAGE,
                SHIST.PURCHASE_PRICE_CCY_CODE DEAL_PURCHASE_PRICE_CCY_CODE ,
                SHIST.PURCHASE_PRICE_CCY_AMT DEAL_PURCHASE_PRICE,

                 scbf_c_get_code_desc(inv.BANK_GROUP_CODE,
                                                inv.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                 SHIST.PURCHASE_PRICE_UOM,
                                                '1') DEAL_PURCHASE_PRICE_UOM,


                SHIST.INVOICE_CCY_CODE DEAL_INVOICE_CCY,
                SHIST.INVOICE_CCY_AMT DEAL_INVOICE_VALUE,
                INV.COLLATERAL_FILE_REF_NO,
                 inv.first_collateral_date,
                 CASE WHEN  INV.INVENTORY_TYPE_CODE='REL' THEN
   inv.Repurchase_Date
  ELSE
  null
  END Repurchase_Date,

                 INV.DOCUMENT_REF_NO,

                 INV.SHAPE_TYPE_CODE SHAPE_TYPE,
                  INV.SHAPE_NO NO_OF_SHAPES,

  INV.sec_commodity_qnty_uom PACKAGE_TYPE,
  INV.SEC_COMMODITY_QNTY NO_OF_PACKAGES,
  CASE WHEN  INV.INVENTORY_TYPE_CODE='REL' THEN
  'RELEASED'
  ELSE
  'OUTSTANDING'
  END INVENTORY_STATUS,

                inv.cust_id Customer_ID,
                inv.commodity_id,
                inv.deal_id,
                inv.deal_step_id,
                inv.storage_location_id,  inv.inventory_type_code,
                  inv.inventory_status_code,
                INV.INVENTORY_ID,
                INV.CUSTODIAN_REF_NO CUSTODIAN_REF_NO,    
  INV.EXCHG_SYSTEM_CODE EXCHG_SYSTEM_CODE,
  INV.EXCHANGE_CODE_ID EXCHANGE_CODE_ID,  
  INV.EXCHG_SYSTEM_ID EXCHG_SYSTEM_ID
           FROM scbt_t_inventory_snapshot inv, scbt_t_sip_deal_smry_hst shist



           WHERE inv.bank_group_code = shist.bank_group_code
                       AND inv.cty_code = shist.cty_code
                       AND inv.cust_id = shist.cust_id



                       AND SUBSTR(inv.deal_id, 1, 11) = SUBSTR(shist.deal_id, 1, 11)
                       AND inv.goods_in_type_code = 'T'

                       AND inv.inventory_status_code IN ('01', '02')
                       AND inv.inventory_type_code IN ('MST', 'ROI', 'TRI', 'CRE','REL')

        AND SUBSTR (inv.deal_id, 1, 11) = SUBSTR (shist.deal_id, 1, 11)

                    AND (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) > 0
                       AND shist.deal_status_code NOT IN ('IRO', 'FRO', 'DCL', 'FER')
                       AND inv.deal_step_id IN
                          (SELECT MAX(hi.deal_step_id)
                              FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv1
                             WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')

                               AND step_code = 'SIPI'
                  
                               AND hi.step_status_code = '03'
                               AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv1.deal_id, 1, 11)
                             GROUP BY SUBSTR(hi.deal_id, 1, 11))
                       AND shist.deal_step_id IN
                           (SELECT MAX(hi.deal_step_id)
                              FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv2
                             WHERE hi.business_date <= TO_DATE('2014-02-28', 'YYYY-MM-DD')
                               AND step_code = 'SIPD'
                   
                               AND hi.step_status_code = '03'
                               AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv2.deal_id, 1, 11)
                             GROUP BY SUBSTR(hi.deal_id, 1, 11)) )
               WHERE BUSINESS_UNIT='GB'
