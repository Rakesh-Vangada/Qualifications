SELECT Scbf_Get_RM_Name(PRT.RM_CODE, PRT.CTY_CODE) AS RM_NAME,       
                      TXN.TXN_REF_ID AS TXN_REF,
                      TXN.TP_REF_ID AS TP_REF_ID,
                      Scbf_Get_Party_Name (HIST.BANK_GROUP_CODE, HIST.CUST_ID) AS party_name,           
                      TXN.PRODUCT_CODE AS PROD_CODE,
                      Scbf_C_Get_Code_Desc(TXN.BANK_GROUP_CODE, '*', '*', 'EN', 'CI124', TXN.PRODUCT_CODE, 1) AS PROD_CODE_DESC,            
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE, HIST.BU_CODE, 'EN', 'CI017', TXN.TXN_STEP_CODE, 1) AS STEP_CODE_DESC,
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE,HIST.BU_CODE, 'EN', 'CI103', HIST.STEP_STATUS_CODE, 1) AS STEP_STATUS_CODE_DESC,              
                      TXN.TXN_CCY_CODE  AS TXN_CODE,
                      TXN.TXN_CCY_NET_AMT AS TXN_CCY_AMT,            
                      HIST.MAKER_ID AS MAKER_ID, 
                      TO_CHAR (HIST.MAKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS maker_timestamp,
                      HIST.CHECKER_ID AS CHECKER_ID,  
                      TO_CHAR (HIST.CHECKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS checker_timestamp,
                      HIST.OFFERING_ID AS OFFER_ID, 
                      TO_CHAR (HIST.OFFERING_TIMESTAMP ,'dd-MM-yyyy HH24:mi:ss') AS offering_timestamp
                 FROM SCBT_T_DEAL_HIST HIST,SCBT_T_TXN_HST TXN,SCBT_R_PARTY_MST PRT, SCBT_R_USER_TBU_ACCS_MST USR
                WHERE PRT.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND PRT.CTY_CODE = TXN.CTY_CODE AND PRT.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND PRT.CTY_CODE = HIST.CTY_CODE
                  AND PRT.PARTY_ID=TXN.CUST_ID AND PRT.PARTY_ID=HIST.CUST_ID
                  AND USR.TBU_CODE = HIST.BU_CODE AND USR.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND USER_ID LIKE  '1231303'
                  AND USR.CTY_CODE = HIST.CTY_CODE AND HIST.STEP_CODE = 'CTL'
                  AND HIST.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND HIST.CTY_CODE = TXN.CTY_CODE AND HIST.DEAL_STEP_ID = TXN.DEAL_STEP_ID 
                  AND TXN.TXN_REC_ID NOT IN (SELECT EVENT_TXN_REC_ID FROM SCBT_T_TXN_EVENTS_DTLS E WHERE E.DEAL_STEP_ID = HIST.DEAL_STEP_ID 
                                                AND E.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND E.CTY_CODE = TXN.CTY_CODE AND E.EVENT_PAYMENT_METHOD = 'LOAN'
                                                AND HIST.STEP_STATUS_CODE <>'03')
                  AND HIST.STEP_STATUS_CODE IN ('01', '11', '09', '10','03')
                  AND HIST.BANK_GROUP_CODE = 'SCB' 
                  AND HIST.CTY_CODE ='SG'
                  AND TRUNC(HIST.MAKER_TIMESTAMP) > '01-Jan-2011' /* FROM DATE FROM SEARCH CRITERIA */
                  AND TRUNC(HIST.MAKER_TIMESTAMP) < '01-MAR-2014' /* TO DATE FROM SEARCH CRITERIA */                  
                  AND NVL(TXN.TXN_STATUS_CODE,'XX') NOT IN ('08','11')                          
            UNION ALL                           
               SELECT Scbf_Get_RM_Name(PRT.RM_CODE, PRT.CTY_CODE) AS RM_NAME,       
                      HIST.DEAL_STEP_ID AS TXN_REF,
                      '' AS TP_REF_ID,
                      PRT.PARTY_NAME AS PARTY_NAME,
                      '' AS prod_code,
                      '' AS PROD_CODE_DESC,
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE, HIST.BU_CODE, 'EN', 'CI017', HIST.STEP_CODE, 1) AS STEP_CODE_DESC,
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE,HIST.BU_CODE, 'EN', 'CI103', HIST.STEP_STATUS_CODE, 1) AS STEP_STATUS_CODE_DESC,
                      HIST.DEAL_STEP_CCY_CODE AS TXN_CODE, 
                      HIST.DEAL_STEP_CCY_AMT AS TXN_CCY_AMT,
                      HIST.MAKER_ID AS MAKER_iD, 
                      TO_CHAR (HIST.MAKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS maker_timestamp,
                      HIST.CHECKER_ID AS CHECKER_ID,  
                      TO_CHAR (HIST.CHECKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS checker_timestamp,
                      HIST.OFFERING_ID AS OFFER_ID, 
                      TO_CHAR (HIST.OFFERING_TIMESTAMP ,'dd-MM-yyyy HH24:mi:ss') AS offering_timestamp
                 FROM SCBT_T_DEAL_HIST HIST,SCBT_R_PARTY_MST PRT, SCBT_R_USER_TBU_ACCS_MST USR
                WHERE PRT.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND PRT.CTY_CODE = HIST.CTY_CODE
                  AND PRT.PARTY_ID=HIST.CUST_ID
                  AND HIST.STEP_CODE IN ('COL','COD','HFI') 
                  AND PRT.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND PRT.CTY_CODE = HIST.CTY_CODE AND PRT.PARTY_ID=HIST.CUST_ID
                  AND USR.TBU_CODE = HIST.BU_CODE AND USR.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND USR.USER_ID = '1231303'
                  AND USR.CTY_CODE = HIST.CTY_CODE
                  AND TRUNC(HIST.MAKER_TIMESTAMP) > '01-Jan-2011' /* FROM DATE FROM SEARCH CRITERIA */
                  AND TRUNC(HIST.MAKER_TIMESTAMP) < '01-MAR-2014' /* TO DATE FROM SEARCH CRITERIA */                  
                  AND HIST.STEP_STATUS_CODE IN ('01', '11', '09', '10','03')
                  AND HIST.BANK_GROUP_CODE = 'SCB' AND HIST.CTY_CODE ='SG'
            UNION ALL            
               SELECT Scbf_Get_RM_Name(PRT.RM_CODE, PRT.CTY_CODE) AS RM_NAME,       
                      TXN.TXN_REF_ID AS TXN_REF,
                      TXN.TP_REF_ID AS TP_ID,
                      prt.party_name AS party_name,
                      txn.PRODUCT_CODE AS prod_code,
                      Scbf_C_Get_Code_Desc('SCB',prt.CTY_CODE,'*','EN','CI124',Txn.PRODUCT_CODE,'1') AS PROD_NAME,                
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE, HIST.BU_CODE, 'EN', 'CI017', TXN.TXN_STEP_CODE, 1) AS STEP_CODE_DESC,
                      Scbf_C_Get_Code_Desc(HIST.BANK_GROUP_CODE, HIST.CTY_CODE,HIST.BU_CODE, 'EN', 'CI103', HIST.STEP_STATUS_CODE, 1) AS STEP_STATUS_CODE_DESC,              
                      TXN.TXN_CCY_CODE,
                      TXN.TXN_CCY_NET_AMT AS TXN_CCY_AMT,
                      HIST.MAKER_ID, 
                      TO_CHAR (HIST.MAKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS maker_timestamp,
                      HIST.CHECKER_ID,  
                      TO_CHAR (HIST.CHECKER_TIMESTAMP,'dd-MM-yyyy HH24:mi:ss') AS checker_timestamp,
                      HIST.OFFERING_ID, 
                      TO_CHAR (HIST.OFFERING_TIMESTAMP ,'dd-MM-yyyy HH24:mi:ss') AS offering_timestamp
                 FROM SCBT_T_DEAL_HIST HIST ,SCBT_R_PARTY_MST PRT ,SCBT_T_TXN_HST TXN,SCBT_R_USER_TBU_ACCS_MST USR
                WHERE PRT.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND PRT.CTY_CODE = HIST.CTY_CODE
                  AND PRT.PARTY_ID=HIST.CUST_ID
                  AND USR.TBU_CODE = HIST.BU_CODE AND USR.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND USR.USER_ID = '1231303'
                  AND USR.CTY_CODE = HIST.CTY_CODE
                  AND NOT EXISTS (SELECT COLL.DEAL_STEP_ID FROM SCBT_T_COLLATERAL_REGISTER_HST COLL
                                   WHERE HIST.BANK_GROUP_CODE=COLL.BANK_GROUP_CODE AND HIST.CTY_CODE = COLL.CTY_CODE AND HIST.DEAL_STEP_ID = COLL.DEAL_STEP_ID )
                                   AND NOT EXISTS (SELECT TXN.DEAL_STEP_ID FROM SCBT_T_TXN_HST TXN
                                   WHERE HIST.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND HIST.CTY_CODE = TXN.CTY_CODE AND HIST.DEAL_STEP_ID = TXN.DEAL_STEP_ID)                    
                  AND HIST.STEP_STATUS_CODE IN ('01', '11', '09', '10','03')
                  AND HIST.STEP_CODE = 'CTL'
                  AND HIST.BANK_GROUP_CODE = 'SCB' 
                  AND HIST.CTY_CODE ='SG'
                  AND PRT.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND PRT.CTY_CODE = TXN.CTY_CODE AND PRT.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE AND PRT.CTY_CODE = HIST.CTY_CODE
                  AND PRT.PARTY_ID=TXN.CUST_ID AND PRT.PARTY_ID=HIST.CUST_ID
                  AND EXISTS (SELECT 1 FROM SCBT_R_USER_TBU_ACCS_MST USR1 
                               WHERE USR1.BANK_GROUP_CODE=HIST.BANK_GROUP_CODE 
                               AND USR1.USER_ID = '1231303' 
                               AND USR1.TBU_CODE = HIST.BU_CODE AND USR1.CTY_CODE = HIST.CTY_CODE)
                  AND HIST.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND HIST.CTY_CODE = TXN.CTY_CODE AND HIST.DEAL_STEP_ID = TXN.DEAL_STEP_ID 
                  AND TXN.TXN_REC_ID NOT IN (SELECT EVENT_TXN_REC_ID FROM SCBT_T_TXN_EVENTS_DTLS E WHERE E.DEAL_STEP_ID = HIST.DEAL_STEP_ID 
                                                AND E.BANK_GROUP_CODE=TXN.BANK_GROUP_CODE AND E.CTY_CODE = TXN.CTY_CODE AND E.EVENT_PAYMENT_METHOD = 'LOAN')
                  AND HIST.STEP_STATUS_CODE IN ('01', '11', '09', '10','03')
                  AND HIST.BANK_GROUP_CODE = 'SCB' 
                  AND HIST.CTY_CODE ='SG'                 
                  AND TRUNC(HIST.MAKER_TIMESTAMP) > '01-Jun-2016' /* FROM DATE FROM SEARCH CRITERIA */
                  AND TRUNC(HIST.MAKER_TIMESTAMP) < '30-Jun-2016' /* TO DATE FROM SEARCH CRITERIA */                                    
                  AND NVL(TXN.TXN_STATUS_CODE,'XX') NOT IN ('08','11')            
