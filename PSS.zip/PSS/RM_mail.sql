select * from scbt_t_rpt_chnl_msg where step_id  = 'HK514T06939M0005';

select * from scbt_t_rpt_chnl_dtls where rec_id='33808739';

--remove mail id from RM maintenance for the RM code - GAK or whatever in order to disable the mail sending option.