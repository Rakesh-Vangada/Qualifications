----CAGG Report-------------------------

SELECT * FROM SCBT_T_IPS_CAGG_BASEL_REF;
SELECT * FROM SCBT_T_IPS_CAGG_FEED_MST;

----Exception Report-----------------------

SELECT * FROM SCBT_T_IPS_CAGG_FEED_MST_ERR;
