select * from SCBT_S_DAILY_PARAM where CTY_CODE in('SG','MY','TH','PH','CN','HK','TW','JP');--12:00
select * from SCBT_S_DAILY_PARAM where CTY_CODE in('VN','AE','BH','PK','LK','MO');--4:00
select * from SCBT_S_DAILY_PARAM where CTY_CODE in('OM','QA','JO','ID','IN','MU','NP','BD');--6:00 
select * from SCBT_S_DAILY_PARAM where CTY_CODE in('BW','TZ','KE','UG');--7:00 AM
select * from SCBT_S_DAILY_PARAM where CTY_CODE in('ZA','ZM','SL','CM','CI','NG','GH','GM');--7:00 AM
select * from SCBT_S_DAILY_PARAM where CTY_CODE in('US');--11:30
select * from SCBT_S_DAILY_PARAM where CTY_CODE = 'UK';--1:30


select distinct FILE_NAME from SCBT_T_IPS_TR_DATASCOPE where BUSINESS_DATE='15-Nov-2013'  order by BUSINESS_DATE desc;
select distinct FILE_NAME from SCBT_T_IPS_TR_DATA_STREAM where BUSINESS_DATE='15-Nov-2013' order by BUSINESS_DATE desc;
select distinct FILE_NAME from SCBT_T_IPS_TR_RMDS where BUSINESS_DATE='15-Nov-2013'  order by BUSINESS_DATE desc;

select * from SCBT_R_LOCAL_HOLIDAY_MST where year = '2013' and CTY_code = 'BD'

select * from scbt_t_txn_mst where cty_code = 'PK' and issue_date like '13-NOV-13%'