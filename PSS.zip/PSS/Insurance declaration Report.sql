Steps to generate the ins premium report in PG190.

Truncate the below tables:
===========================
truncate table scbt_t_ins_pre_tmp;
truncate table scbt_t_ins_prem_calc_tmp;

Run the below procedure:
========================

exec scbk_p_ins_prem.scbp_ins_pre_calc_new('1','2013-02-01 00:00:00','2013-02-28 00:00:00');

Check if any value is there below, if so then re-run the above steps after updating:
=====================================================================================
select distinct PURCHASE_PRICE_CCY_CODE from SCBT_T_SIP_DEAL_SMRY_MST where deal_id in (select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0)

update SCBT_T_SIP_DEAL_SMRY_MST set hedge_price_ccy_code='USD' where deal_id in (select distinct deal_id from scbt_t_ins_prem_calc_tmp where total_deal_value<=0)


After that we need to run the below query to generate the report:
-----------------------------------------------------------------

SELECT mst.cty_code AS BUSINESS_UNIT,
scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD099'    ,
                                                LOC.ADD_CTY_CODE   ,
                                                '1') Storage_Country,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD061'    ,
                                                LOC.LOCATION_CODE   ,
                                                '1') Storage_Location,
       scbf_get_storage_company_name(mst.bank_group_code,SUBSTR(tmp.storage_location_id,1,8)) Storage_Company_name,
       Scbf_Get_Storage_Location_Name(mst.bank_group_code,tmp.storage_location_id) Storage_Location,
       Scbf_Get_Commodity_Name(mst.bank_group_code,tmp.commodity_id) Commodity_name,
       mst.deal_type_code,
       mst.sip_deal_ref_no,
       mst.deal_start_date,
       mst.deal_end_Date,
       tmp.prem_start_date,
       tmp.prem_end_date,
       tmp.no_of_days,
       tmp.qty Quantity,
       scbf_c_get_code_desc(MST.BANK_GROUP_CODE,
                                                MST.CTY_CODE   ,
                                                '*'   ,
                                                'EN'  ,
                                                'CD016'    ,
                                                tmp.net_commodity_qnty_uom,
                                                '1') UOM,
       mst.hedge_price_ccy_amt,
       tmp.total_deal_value,
       tmp.storage_location_id,
       tmp.commodity_id
       FROM SCBT_T_INS_PREM_CALC_TMP TMP, SCBT_T_SIP_DEAL_SMRY_MST MST, SCBT_R_STORAGE_LOCATION_MST LOC
WHERE TMP.DEAL_ID = MST.DEAL_ID
AND TMP.BANK_GROUP_CODE=MST.BANK_GROUP_CODE
AND TMP.CUST_ID=MST.CUST_ID
AND LOC.STORAGE_LOC_ID=TMP.STORAGE_LOCATION_ID
AND LOC.BANK_GROUP_CODE=TMP.BANK_GROUP_CODE
and tmp.total_deal_value > 0
