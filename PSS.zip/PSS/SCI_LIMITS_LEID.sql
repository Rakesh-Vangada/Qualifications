-- GET_SCI_LIMIT_ID
SELECT DISTINCT lmt_le_id,LIMIT_SETUP_APPLN_REF,limit_type,lmt_id, n_lmt_outer_lmt_id,code_value_2,desc_1,n_lmt_crrncy_iso_code,n_lmt_amt,
            n_lmt_expry_date,n_lmt_tenor,n_lmt_tenor_basis_value,sci_orgn_value,n_lmt_prd_type_value,n_lmt_share_ind,n_lmt_advise_ind,
            n_lmt_cmmtd_ind,borrower_id,borrower_name,borrower_limitid,borrower_le_id,n_lmt_revolve_code_value 
            FROM(
                   SELECT l.lmt_le_id,p.LIMIT_SETUP_APPLN_REF,DECODE (l.n_lmt_outer_lmt_id,'0', 'Outer','', 'Outer','Inner') AS limit_type, 
                 l.lmt_id, l.n_lmt_outer_lmt_id,m.code_value_2,
                 Scbf_C_Get_Code_Desc(p.BANK_GROUP_CODE, nvl(b.bkl_cntry_iso_code,'*'),'*', 'EN', 'CD043', m.code_value_2, 1) as desc_1,
                 l.n_lmt_crrncy_iso_code,l.n_lmt_amt,l.n_lmt_expry_date,l.n_lmt_tenor,
                 l.n_lmt_tenor_basis_value,(b.bkl_cntry_iso_code || '/' || b.bkl_bkg_loctn_orgn_value) AS sci_orgn_value,l.n_lmt_prd_type_value,
                   l.n_lmt_share_ind,l.n_lmt_advise_ind,l.n_lmt_cmmtd_ind,'' AS borrower_id,'' AS borrower_name, '' AS borrower_limitid,
                   '' AS borrower_le_id,l.n_lmt_revolve_code_value 
                 FROM scbt_t_ips_sci_appr_limits l,scbt_t_ips_sci_stdc_value s,scbt_t_ips_sci_stdc_bkgloctn b,SCBT_R_MAP_INFO m,
                   SCBT_R_PARTY_MST p,    SCBT_R_PARTY_EXT_ID e
                 WHERE l.lmt_le_id LIKE '%11044697%' AND s.stv_std_code_num = l.lmt_prd_type_num AND s.stv_std_code_value = l.n_lmt_prd_type_value
                 AND b.bkl_loctn_id = l.n_lmt_bkg_loctn_id AND l.n_lmt_prd_type_value = m.code_value_1(+) 
                   AND m.map_id = 'MLM03' AND p.BANK_GROUP_CODE = 'SCB'
                   AND p.PARTY_ID LIKE '800000184' AND e.PARTY_ID = p.PARTY_ID
                   AND e.cty_code = '*' AND e.EXT_SYSTEM_ID = l.LMT_LE_ID AND e.EXT_SYSTEM_CODE = 'SC'
                   AND P.CTY_CODE = '*' AND NVL(l.ACTIVE_FLAG,'Y') = 'Y'
            )                                                                                                                 
            START WITH n_lmt_outer_lmt_id IS NULL CONNECT BY PRIOR lmt_id=n_lmt_outer_lmt_id
			
			
SELECT * FROM scbt_t_ips_sci_appr_limits WHERE lmt_le_id LIKE '%11204165%' and active_flag='Y'    -- 11247759 , 11204165


SELECT CUST_ID,CTY_CODE,SCBF_GET_PARTY_NAME('SCB',CUST_ID) AS CUST_NAME,SCBF_GET_LEID_ID('SCB',CUST_ID) AS LEID,
Scbf_C_Get_Code_Desc ('SCB','*','*','EN','CD014', LIMIT_TYPE_CODE,1) AS LIMIT_TYPE,
Scbf_C_Get_Code_Desc ('SCB','*','*','EN','CD042', LIMIT_CAT_CODE,1) AS LIMIT_CAT,
LIMIT_ID,EXT_LIMIT_ID,INNER_TO_ID,LIMIT_PRODUCT_CODE,LIMIT_NAME,LIMIT_CAT_CODE,SHORTFALL_OFFSET,
LIMIT_CCY_CODE,LIMIT_CCY_ACTIVE_AMT,APPROVED_LIMIT_CCY_CODE,LIMIT_CCY_APPROVED_AMT
FROM SCBT_R_CUST_PRODUCT_LIMIT CPL WHERE CPL.CTY_CODE='SG' 
AND EXT_LIMIT_ID IN (

SELECT DISTINCT lmt_le_id,LIMIT_SETUP_APPLN_REF,limit_type,lmt_id, n_lmt_outer_lmt_id,code_value_2,desc_1,n_lmt_crrncy_iso_code,n_lmt_amt,
            n_lmt_expry_date,n_lmt_tenor,n_lmt_tenor_basis_value,sci_orgn_value,n_lmt_prd_type_value,n_lmt_share_ind,n_lmt_advise_ind,
            n_lmt_cmmtd_ind,borrower_id,borrower_name,borrower_limitid,borrower_le_id,n_lmt_revolve_code_value 
            FROM(
                   SELECT l.lmt_le_id,p.LIMIT_SETUP_APPLN_REF,DECODE (l.n_lmt_outer_lmt_id,'0', 'Outer','', 'Outer','Inner') AS limit_type, 
                 l.lmt_id, l.n_lmt_outer_lmt_id,m.code_value_2,
                 Scbf_C_Get_Code_Desc(p.BANK_GROUP_CODE, nvl(b.bkl_cntry_iso_code,'*'),'*', 'EN', 'CD043', m.code_value_2, 1) as desc_1,
                 l.n_lmt_crrncy_iso_code,l.n_lmt_amt,l.n_lmt_expry_date,l.n_lmt_tenor,
                 l.n_lmt_tenor_basis_value,(b.bkl_cntry_iso_code || '/' || b.bkl_bkg_loctn_orgn_value) AS sci_orgn_value,l.n_lmt_prd_type_value,
                   l.n_lmt_share_ind,l.n_lmt_advise_ind,l.n_lmt_cmmtd_ind,'' AS borrower_id,'' AS borrower_name, '' AS borrower_limitid,
                   '' AS borrower_le_id,l.n_lmt_revolve_code_value 
                 FROM scbt_t_ips_sci_appr_limits l,scbt_t_ips_sci_stdc_value s,scbt_t_ips_sci_stdc_bkgloctn b,SCBT_R_MAP_INFO m,
                   SCBT_R_PARTY_MST p,    SCBT_R_PARTY_EXT_ID e ,SCBT_R_CUST_PRODUCT_LIMIT CPL
                 WHERE l.lmt_le_id=(SCBF_GET_LEID_ID('SCB',CPL.CUST_ID)) AND s.stv_std_code_num = l.lmt_prd_type_num AND s.stv_std_code_value = l.n_lmt_prd_type_value
                 AND b.bkl_loctn_id = l.n_lmt_bkg_loctn_id AND l.n_lmt_prd_type_value = m.code_value_1(+) 
                   AND m.map_id = 'MLM03' AND p.BANK_GROUP_CODE = 'SCB'
                   AND p.PARTY_ID=CPL.CUST_ID AND e.PARTY_ID = p.PARTY_ID
                   AND e.cty_code = '*' AND e.EXT_SYSTEM_ID = l.LMT_LE_ID AND e.EXT_SYSTEM_CODE = 'SC'
                   AND P.CTY_CODE = '*' AND NVL(l.ACTIVE_FLAG,'Y') = 'Y'
            )                                                                                                                 
            START WITH n_lmt_outer_lmt_id IS NULL CONNECT BY PRIOR lmt_id=n_lmt_outer_lmt_id

)


SELECT * FROM scbt_t_ips_sci_appr_limits WHERE lmt_le_id LIKE '%11204165%' and active_flag='Y'  