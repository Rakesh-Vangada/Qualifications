
---Daily Param---Business date check
select * from scbt_s_daily_param where cty_code in ('SG','MY','PH','TH','VN','ID')

---Record Lock---
select * from SCBT_T_SOFT_LOCK where user_id = ''

--Deal Step check
==================
select * from scbt_t_txn_hst t,scbt_t_deal_hist h where t.deal_id='SG957T02362' and t.deal_step_id = h.deal_step_id
order by t.deal_step_id desc

To check LIMIT MAINTENANCE
===========================
SELECT * FROM SCBT_T_LIMIT_MAINT m,SCBT_T_LIMIT_MAINT_DTLS d, SCBT_R_CUST_PRODUCT_LIMIT c
WHERE m.MAINT_STATUS_CODE = 'OPN' AND m.STEP_ID = d.STEP_ID AND c.cust_id = '800002479'
AND (m.SRC_CUST_ID = '800002479' OR m.dest_cust_id = '800002479')
AND c.limit_id = d.LIMIT_ID AND c.limit_id IN ('850')

--To check the PRICE FEED
==========================
SELECT  feed_id,COUNT(feed_id) FROM SCBT_R_COMMODITY_PRICE_HIST WHERE source_type_code = 'MAN' 
AND feed_owner_userid = '1315035' AND business_date = '01-June-2012' GROUP BY feed_id

select count(1) from scbt_r_commodity_price_mst where source_type_code ='MAN'  and vendor_last_update_date=to_date('24-Feb-2012','DD-Mon-YYYY');

select count(1) from scbt_r_commodity_price_hist where source_type_code ='MAN'  and vendor_last_update_date=to_date('24-Feb-2012','DD-Mon-YYYY');

--To check DATA SYNC
=====================
select table_name,num_rows from all_tables where table_name in ('SCBT_R_CUST_PRODUCT_LIMIT','SCBT_T_PROD_LIMIT_UTIL','SCBT_T_TXN_MST','SCBT_T_TXN_CR_LINKAGE_MST','SCBT_T_COLLATERAL_REGISTER_MST','SCBT_T_PARCEL_MST','SCBT_R_COMMODITY_MST','SCBT_T_DEAL_REGISTER_HDR_MST','SCBT_R_CUST_FACILITY_GRP','SCBT_R_BBC_DTLS_MST','SCBT_R_BBC_GENERAL_DTLS_MST')

--To check Replication Of GOLDEN GATE 
=====================================
Expected result: lag column should be 0000 for the DB to be in sync and status should be running. Check in 190 DB
select * from ggate_status

--To check OBJECT STATUS 
=========================
SELECT   object_type, status, COUNT (1)
    FROM dba_objects
   WHERE object_type IN
            ('SEQUENCE', 'PROCEDURE', 'LOB', 'PACKAGE''PACKAGE BODY', 'INDEX',
             'VIEW', 'TABLE', 'FUNCTION', 'TYPE')
     AND status = 'INVALID'
GROUP BY object_type, status

--Cash Margin Required:
=======================
--If cash required flag is Y, then CMR is not considered or else the same amount needs to be maintained as account balance.
select deal_id,cust_id,(CASH_MARGIN_CCY_AMT-nvl(CM_CCY_RELEASE_AMT,0)) from scbt_t_txn_mst where cust_id='800006600'

--Overall commodity held by a customer for a collateral type.
===========================================================
SELECT sum(net_commodity_qnty - utilised_qnty)
  FROM scbt_t_parcel_mst
 WHERE collateral_id IN (
                  SELECT collateral_id
                    FROM scbt_t_collateral_register_mst
                   WHERE cust_id = '800006600'
                         AND collateral_category <> 'REL')
   AND parcel_type_code <> 'MST' and collateral_type_code='IMDH'
   
   SELECT collateral_id, net_commodity_qnty, utilised_qnty, deal_id 
  FROM scbt_t_parcel_mst
 WHERE collateral_id IN (
                  SELECT collateral_id
                    FROM scbt_t_collateral_register_mst
                   WHERE cust_id = '800006600'
                         AND collateral_category <> 'REL')
   AND parcel_type_code <> 'MST' and collateral_type_code='IMDH'
