CREATE OR REPLACE PACKAGE BODY COCOOWNER.SCBK_P_COCOA_CDB IS
  /*-----------------------------------------------------------------------------------------
    **
    ** File Name : Scbk_P_Cocoa_Cdb.pks  -- Added by COCOA on 19-Jun-2012
    **
    **
    **
    ** Change History

   -- COCOAPERFTUNE_001 Performance Tuning Changes by Kannan on 19-Jun-2012 Start

    Issue =       Performance issue due to order of join and indexing are not properly handled.

    Fix   =       Query has been changed to fix above issue and Index has been added on SCBT_T_DEAL_REGISTER_HDR_MST table.
                  Since this function is called in almost all places, this will help in improving the performance.

   -- COCOAPERFTUNE_001 Performance Tuning Changes by Kannan on 19-Jun-2012 End

   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012 Start

   Issue =       Connect by prior clauses are having Table access full. Also cust id is not used in many places for customer dashboard queries.

   Fix   =       Tuning changes done to use the proper indexes and cust id in relevant places.

   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012 End
   -- Changes done by Anbalagan for NCV Issue in PREPROD on 27June2012:REF_27June2012
   -- Changes done by Anbalagan for NCV Issue in PREPROD on 23Aug2012:REF_23Aug012
   -- Changes done by Priya for LTV % calculation with new formula as part of enhancement:Ref_Oct2012 and Ref:02-Oct-2012
   -- Changes done by Anbalagan.MP for LTV % calculation with new formula as part of LTV enhancement: Ref:03-Oct-2012
   -- Changes done by Anbalagan.MP on 2nd Nov 2012 - as per Srini Mail RE: LTV formulate testing dated on 02-11-2012 REF_05-11-2-12_LTVChanges
   -- COCOAPERFTUNE_003 Performance Tuning Changes by Anbu on 14-Nov-2012 --Added BANK_GROUP_CODE,COUNTRY_CODE and DEAL_ID(some places)
   -- REF_27NOV2012 Logic changes done by Anbu on 27Nov w.r.t FW: Reg Env - Top UP for non LTV txn dated on Nov26 2012.
   -- REF_04DEC2012 - Unexpected Error issue to retreive PROD REF CODE
   -- REF05122012 - Function SCBF_C_GET_TOT_CASH_MARGIN changed as SCBF_C_GET_TOT_CASH_MARGIN_CD for performance issue
   -- REFTOPUPREQAMT - ref RE: LTV Changes - FSD Nov 19th Pramod mail 9:22PM
   -- REF_08DEC2012 Drawing step Issue for non LTV Transaction
   -- REF10DEC2012 - RE: Incident  Ticket: IM0000014080584  has been Accepted by ITSC Service Desk
   -- REF10122012 - Added for Performance tuning by Kannan 10-Dec-2012
   -- REFPERF10DEC2012 - Added for Performance tuning by Anbu 10-Dec-2012
   -- COCOAPERF_12122012 - Added for Performance tuning by Anbu 13-Dec-2012
   -- COCOAPERF_17122012 - Added for Performance tuning by Anbu 17-Dec-2012 Added bank group code,ctycode and custid
   -- COCOAPERF_18122012 Performance issue changes done by Anbu on 18 Dec 2012 -
   -- COCOAFUNC_18122012 Added outstanding amt greater than zero, because system is unneccesary checking for all transaction
   -- REF_CR03012013 -- Previously we are calculating CMR amt based on the limit id,
   -- now changed based on txn recid and ref id level ref: Issue -
   -- Cash Margin for transaction level maintenance dated on 03 Jan2013, 3:32 bhavisha mail
   -- REF_03012013 - changed to varchar2(16) for checking null
   -- REF_04012013 - topup amt display for limit transfer to limit transfer step
   -- COCOAREF_08012013 - Added for include collateral but not released
   -- COCOAREF_16012013 - Added for limit transfer in under deal dashboard
   -- COCOACR_16012013 - RE: Trafigura settlement error -IM0000014578000 suggest by Krishna
   -- COCOAFUNC_18012013 -- Incorrect Cash margin calculation from Bhavisha mail 18Jan2013
   -- COCOACR_06022013 -- [JIRA] (COCOA-652) Customer Dashboard : GCV Amount is shown as Zero
   -- COCOAFIX_13022013 RE: [JIRA] (COCOA-650) Cash Margin requirement doubled when amendment is done to move the limit (TP ref 514010868036)
   -- COCOACR_14022013 Changes done for the group level Ncv Amt and Gcv amt from master
   -- COCOAFUNC_25022013 -- we are considering OD we are changed as ABS of outstanding amount
   -- COCOA_29032013 -- round off issue FW: IM0000015083462 URGENT - Collateral Shortfall report
   -- COCOACR-11APR2013 -- COCOA JIRA 816
   -- COCOAISSSUE_26APR2013 -- Added for Limit transfer setup lgoic for HISTORY tables - Cash margin amount calculation
   -- COCOACR_10062013 RELC included in where clause for top up info tab in deal dashbaord
   -- COCOACR_10062013 included AND NVL(LIMIT_TRANSFER,'N') <> 'Y' in transaction historty table
   -- COCOAFIX_31072013 Ref Issue : FW: DIFFERENCE IN EFFECTIVE NCV *IM0000016429317*
   ----------------------------------------------------------------------------------------- */

  collateralCashSfallAmount NUMBER(17, 3);
  shortfallHONotOffsetAmt   NUMBER(17, 3);
  totalMinCashMarginReqAmt  NUMBER(17, 3);
  shortfallForTopup         NUMBER(17, 3);
  totalNonCleanExpAmt       NUMBER(17, 3);
  totalCustomerTopUpAmt     NUMBER(17, 3) := 0;
  --pkg_custid                SCBT_R_PARTY_MST.PARTY_ID%TYPE;  -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012


    G_EXPOSURE_CCY_CODE VARCHAR2(3);
    G_EXPOSURE_CCY_AMT  NUMBER(17, 3);

    G_GCV_CCY_CODE VARCHAR2(3);

    G_GCV_CCY_AMT  NUMBER(17, 3);

    G_NCV_CCY_CODE VARCHAR2(3);

    G_NCV_CCY_AMT  NUMBER(17, 3);
    G_CASHTOPUP_CCY_CODE VARCHAR2(3);

    G_CASHTOPUP_CCY_AMT  NUMBER(17, 3);
    G_CMR_CCY_CODE VARCHAR2(3);
    G_CMR_CCY_AMT  NUMBER(17, 3);
    G_LTV_FORMULA VARCHAR2(5);
    G_CASH_MARGIN_PERCNT NUMBER(17, 3);


   TYPE t_array IS TABLE OF VARCHAR2(50) INDEX BY BINARY_INTEGER;

    function SCBF_COCOA_ROUND_AMOUNT(bankgroupCode varchar2,Ccy varchar2,amtValue number) return number is
     roundedValue number;
      n_Parity INT;

     BEGIN
         begin
           SELECT CCY.CCY_PARITY INTO n_Parity
            FROM SCBT_R_GLOBAL_CCY_MST CCY
            WHERE CCY.BANK_GROUP_CODE = bankgroupCode
            AND CCY.CCY_CODE = Ccy;
         EXCEPTION
           WHEN OTHERS THEN
           NULL;
         END;

     roundedValue := 0;
     roundedValue := ROUND(NVL(amtValue,0),n_Parity);

     return(NVL(roundedValue,0));

    end SCBF_COCOA_ROUND_AMOUNT;

    FUNCTION SCBF_C_GET_ACCT_BALANCE(bankGroupCode IN VARCHAR2,
                                                    ctyCode       IN VARCHAR2,
                                                    custId        IN VARCHAR2,
                                                    destCCY       IN VARCHAR2,
                                                    roundFlag     IN VARCHAR2) RETURN NUMBER IS
          totalAccountBalanceAmt NUMBER;
         BEGIN


              SELECT SUM(
                     Scbf_Fetch_Exch_Rate(
                          bankGroupCode
                          , ctyCode
                          , ACC_CCY_ANTICIPATED_CCY
                          , NVL(ACC_CCY_ANTICIPATED_AMT,0),destCCY, roundFlag)
                          ) INTO totalAccountBalanceAmt
                     FROM scbt_t_cust_acc_smry_mst
                     WHERE bank_group_code = bankGroupCode
                     AND cty_code = ctyCode
                     AND cust_id = custId
                     AND acc_no IN
                        (  SELECT ACC_NO FROM Scbt_r_Cust_Acct_Maintenance
                               WHERE bank_group_code = bankGroupCode
                               AND cty_code = ctyCode
                               AND cust_id = custId
                               AND NVL(INCLUDE_FOR_CASH_COLLATERAL,'N') = 'Y'
                         );


                return totalAccountBalanceAmt;

   END SCBF_C_GET_ACCT_BALANCE;

   FUNCTION SCBF_GET_SPLIT_STRING_ON_DELIM(p_in_string VARCHAR2, p_delim VARCHAR2) RETURN t_array

   IS

      i       number :=0;
      pos     number :=0;
      lv_str  varchar2(1000) := p_in_string;

   strings t_array;

   BEGIN

      -- determine first chuck of string

      pos := instr(lv_str,p_delim,1,1);

      -- while there are chunks left, loop
   IF (pos>0) THEN

      WHILE ( pos != 0) LOOP

         -- increment counter

         i := i + 1;

         -- create array element for chuck of string
         if(i = 1) then
              strings(i) := substr(lv_str,1,pos-1);
         else
              strings(i) := substr(lv_str,1,pos-1);
         end if;
         -- remove chunk from string

         lv_str := substr(lv_str,pos+1,length(lv_str));

         -- determine next chunk

         pos := instr(lv_str,p_delim,1,1);

         -- no last chunk, add to array

         IF pos = 0 THEN

            strings(i+1) := lv_str;

         END IF;

      END LOOP;
   -- return array
   ELSE
   strings(1):=lv_str;
   END IF;

      RETURN strings;

   END SCBF_GET_SPLIT_STRING_ON_DELIM;


  PROCEDURE SCBP_P_GET_COMMODITY_SMRY(p_ret_code    IN OUT VARCHAR2,
                                      bankGroupCode IN VARCHAR2,
                                      ctyCode       IN VARCHAR2,
                                      custId        IN VARCHAR2,
                                      dealId        IN VARCHAR2,
                                      commodityId   IN VARCHAR2,
                                      finBasisCode  IN VARCHAR2,
                                      commPriceCcy  IN OUT VARCHAR2,
                                      commPriceAmt  IN OUT NUMBER,
                                      commPriceUOM  IN OUT VARCHAR2,
                                      commQty       IN OUT NUMBER,
                                      commQtyUOM    IN OUT VARCHAR2,
                                      equivCcy      IN OUT VARCHAR2,
                                      equivAmt      IN OUT NUMBER) IS
  TYPE ParcelIDType IS TABLE OF scbt_t_parcel_mst.parcel_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelUOMType IS TABLE OF scbt_t_parcel_mst.utilised_qnty_uom%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelNetQtyType IS TABLE OF scbt_t_parcel_mst.NET_COMMODITY_QNTY%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelUtilQtyType IS TABLE OF scbt_t_parcel_mst.UTILISED_QNTY%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyType IS TABLE OF scbt_t_parcel_mst.gcv_ccy_code%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyAmtType IS TABLE OF scbt_t_parcel_mst.gcv_ccy_amt%TYPE INDEX BY PLS_INTEGER;
  marketPrice      varchar2(3);
  manualPrice      varchar2(3);
  weightedAverage  varchar2(3);
  expCcy           varchar2(3);
  custExpCcy       varchar2(3);
  conversionFactor NUMBER(15,9);
  conversionFactor2 NUMBER(15,9);
  tmpCommPriceAmt  number(17,3);
  calcEquiv        boolean;
  parcelIdList        ParcelIDType;
  parcelNetQty        ParcelNetQtyType;
  parcelUtilQty       ParcelUtilQtyType;
  parcelGCVCcy        ParcelGCVCcyType;
  parcelGCVCcyAmt     ParcelGCVCcyAmtType;
  parcelUOM           ParcelUOMType;
  parcelHistNetQty    ParcelNetQtyType;
  parcelHistUtilQty   ParcelUtilQtyType;
  parcelHistUOM       ParcelUOMType;
  totalQuantity       number(17,3);
  totalGCV            number(17,3);
  BEGIN

       marketPrice := 'MRP';
       manualPrice := 'MNP';
       weightedAverage := 'WAV';
       conversionFactor := 0;
       conversionFactor2 := 0;
       calcEquiv := true;
       totalQuantity := 0;
       totalGCV := 0;
       p_ret_code := '0000';

         BEGIN
                  SELECT OVERALL_EXP_CURRENCY
                    INTO custExpCcy
                    FROM scbt_r_party_mst
                   WHERE bank_group_code = bankGroupCode
                     AND cty_code = ctyCode
                     AND party_id = custId;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            expCcy := 'USD';
        END;

       if(equivCcy = '' or equivCcy is NULL) then
              expCcy := custExpCcy;
       else
              expCcy := equivCcy;
       end if;

       -- If Basis is Market Price then fetch the Market Value
       if(finBasisCode = marketPrice ) then
        -- sak modified this block to fix the issue COCOA-919
           BEGIN
                SELECT FEED_PRICE_CCY, MARKET_PRICE, FEED_PRICE_UOM
                INTO commPriceCcy,commPriceAmt,commPriceUOM
                FROM (SELECT FEED_PRICE_CCY,
                NVL
                (SCBF_GET_MARKET_PRICE (CD.BANK_GROUP_CODE,
                                          CD.CTY_CODE,
                                          CD.COMMODITY_ID,
                                          CD.COMMODITY_PRICE_ID,
                                          ADJ.ADJUSTMENT_ID
                                         ),
                   0
                  ) AS MARKET_PRICE,
                 FEED_PRICE_UOM,
                 (((CASE WHEN NVL(ADJ.CUST_ID,'*') = '*' THEN '0' ELSE '1' END) || (CASE WHEN NVL(ADJ.BU_CODE,'*') = '*' THEN '0' ELSE '1' END))) AS SEQ
          FROM SCBT_R_COMMODITY_MST MST,SCBT_R_COMMODITY_DTLS CD,
               SCBT_R_COMMODITY_PRICE_MST CP,SCBT_R_COMMODITY_ADJ_DTLS ADJ
         WHERE CD.BANK_GROUP_CODE = MST.BANK_GROUP_CODE
           AND CD.BANK_GROUP_CODE = CP.BANK_GROUP_CODE
           AND PRICE_FEED_ID = CP.FEED_ID
           AND CD.BANK_GROUP_CODE = bankGroupCode
           AND CD.COMMODITY_ID = MST.COMMODITY_ID
           AND CD.COMMODITY_ID = commodityId
           AND CD.BANK_GROUP_CODE = ADJ.BANK_GROUP_CODE
           AND CD.COMMODITY_PRICE_ID = ADJ.COMMODITY_PRICE_ID
           AND MST.HUB_BU_CODE IN (SELECT HUB_BU_CODE
                                     FROM SCBT_R_TBU_MST
                                    WHERE TBU_CODE LIKE ctyCode || '%')
           AND (   NVL (MST.BU_CODE, '*') = '*'
                OR NVL (MST.BU_CODE, '*') LIKE ctyCode || '%'
               )
           AND (   NVL (ADJ.BU_CODE, '*') = '*'
                OR NVL (ADJ.BU_CODE, '*') LIKE ctyCode || '%'
               )
           AND NVL (ADJ.CUST_ID, '*') IN ('*', custId)
           AND CD.DELIV_SCHEDULE_CODE = 'CSH'
        UNION ALL
        SELECT DISTINCT PRICE.FEED_PRICE_CCY AS FEED_PRICE_CCY,
                        SCBF_GET_MARKET_PRICE
                                    (DTLS.BANK_GROUP_CODE,
                                     DTLS.CTY_CODE,
                                     DTLS.COMMODITY_ID,
                                     DTLS.COMMODITY_PRICE_ID,
                                     ''
                                    ) AS MARKET_PRICE,
                        PRICE.FEED_PRICE_UOM AS FEED_PRICE_UOM,
                                    ('00') AS SEQ
                   FROM SCBT_R_COMMODITY_MST MST,
                        SCBT_R_COMMODITY_DTLS DTLS,
                        SCBT_R_COMMODITY_PRICE_MST PRICE
                  WHERE DTLS.BANK_GROUP_CODE = PRICE.BANK_GROUP_CODE
                    AND DTLS.PRICE_FEED_ID = PRICE.FEED_ID
                    AND NVL (DTLS.INACTIVE_FLAG, 'N') <> 'Y'
                    AND MST.COMMODITY_ID = DTLS.COMMODITY_ID
                    AND DTLS.DELIV_SCHEDULE_CODE = 'CSH'
                    AND DTLS.BANK_GROUP_CODE = MST.BANK_GROUP_CODE
                    AND (   NVL (MST.BU_CODE, MST.CTY_CODE || '*') =
                                                           MST.CTY_CODE || '*'
                         OR NVL (MST.BU_CODE, MST.CTY_CODE || '*') = ctyCode
                        )
                    AND MST.COMMODITY_ID LIKE UPPER (commodityId)
                    AND MST.BANK_GROUP_CODE = bankGroupCode
                    AND DTLS.COMMODITY_PRICE_ID LIKE '%'
                    AND MST.COMMODITY_TYPE_CODE LIKE '%'
                    AND MST.COMMODITY_CAT_CODE LIKE '%'
                              ORDER BY SEQ DESC
                              ) WHERE ROWNUM=1;
           EXCEPTION
                   WHEN OTHERS THEN
                   NULL;
           END;

       end if;

       -- If Basis is Weighted Average
        if(finBasisCode = weightedAverage ) then

              BEGIN
                  SELECT PARCEL_ID, NVL(NET_COMMODITY_QNTY,0), NVL(UTILISED_QNTY,0),NET_COMMODITY_UOM
                      BULK COLLECT INTO parcelIdList, parcelNetQty, parcelUtilQty,parcelUOM
                      FROM SCBT_T_PARCEL_MST PM
                     WHERE BANK_GROUP_CODE = bankGroupCode and CTY_CODE = ctyCode
                       AND (PM.NET_COMMODITY_QNTY - PM.UTILISED_QNTY) > 0
                       AND PM.PARCEL_TYPE_CODE NOT IN ('MST', 'REL', 'RCV', 'CON')
                       AND PM.DEAL_ID like '%'||dealId||'%'
                       AND PM.COMMODITY_ID=commodityId;
               EXCEPTION
                   WHEN OTHERS THEN
                   NULL;
               END;


               For i in 1..parcelIdList.COUNT Loop
                 BEGIN
                     SELECT GCV_CCY_CODE,NVL(GCV_CCY_AMT ,0),NVL(NET_COMMODITY_QNTY,0),NVL(UTILISED_QNTY,0),NET_COMMODITY_UOM
                       BULK COLLECT INTO parcelGCVCcy,parcelGCVCcyAmt,parcelHistNetQty, parcelHistUtilQty,parcelHistUOM
                          FROM (
                                 SELECT DISTINCT PARCEL_ID,
                                        PH.DEAL_ID,
                                        GCV_CCY_CODE,
                                        GCV_CCY_AMT,
                                        NET_COMMODITY_QNTY,
                                        UTILISED_QNTY,
                                        NET_COMMODITY_UOM,
                                        DH.CHECKER_TIMESTAMP
                                   FROM SCBT_T_PARCEL_HST PH, SCBT_T_DEAL_HIST DH
                                  WHERE PH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                                   AND PH.CTY_CODE = DH.CTY_CODE
                                   AND DH.DEAL_ID = PH.DEAL_ID
                                   AND DH.DEAL_STEP_ID = PH.DEAL_STEP_ID
                                   AND PH.BANK_GROUP_CODE = bankGroupCode
                                   AND PH.CTY_CODE = ctyCode
                                   AND DH.STEP_STATUS_CODE = '03'
                                   AND PH.COMMODITY_ID=commodityId
                                   AND PH.PARCEL_TYPE_CODE IN ('PUR','SAL')
                                   AND DH.CUST_ID = custId
                                   AND PH.DEAL_ID like '%'||dealId||'%'
                                   AND PARCEL_ID = parcelIdList(i)
                                  ORDER BY DH.CHECKER_TIMESTAMP ASC
                                 ) where rownum=1;


                       for j in 1..parcelGCVCcy.COUNT LOOP

                          if( parcelUOM(i) <> commPriceUOM) then
                            conversionFactor := Scbf_C_Get_Param_Data('UC01',
                                                       '01',
                                                       'SCB',
                                                       '*',
                                                       '*',
                                                       '*',
                                                       parcelUOM(i),
                                                       commPriceUOM,
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '');

                              if(conversionFactor is null) then
                                 p_ret_code := '0001';
                              end if;


                             else
                                      conversionFactor := 1;
                             end if;

                             if( parcelHistUOM(j) <> commPriceUOM) then
                              conversionFactor2 := Scbf_C_Get_Param_Data('UC01',
                                                       '01',
                                                       'SCB',
                                                       '*',
                                                       '*',
                                                       '*',
                                                       parcelHistUOM(j),
                                                       commPriceUOM,
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '');

                              if(conversionFactor2 is null) then
                                 p_ret_code := '0001';
                              end if;


                             else
                                      conversionFactor2 := 1;
                             end if;

                             totalQuantity := NVL(totalQuantity,0) + ((parcelNetQty(i) - parcelUtilQty(i))*nvl(conversionFactor,1));
                             totalGCV := NVL(totalGCV,0) + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                            ctyCode,
                                                            parcelGCVCcy(j),
                                                            (((parcelNetQty(i) - parcelUtilQty(i))*nvl(conversionFactor,1))/((parcelHistNetQty(j) - parcelHistUtilQty(j))*nvl(conversionFactor2,1)))*(nvl(parcelGCVCcyAmt(j),0)),
                                                            custExpCcy,
                                                            'Y'),
                                                             0);
                        END LOOP;

                     EXCEPTION
                   WHEN OTHERS THEN
                     NUll;


                   END;


               end loop;

               commPriceCcy := custExpCcy;
               commPriceAmt := NVL(totalGCV,0) / NVL(totalQuantity,1);


        end if;

        tmpCommPriceAmt := commPriceAmt;

       -- If Quantity is Provided then calculate Equivalent Amount
       if (commQty != 0) THEN

          equivCcy := expCcy;


          if(commPriceUOM <> commQtyUOM) then
                conversionFactor := Scbf_C_Get_Param_Data('UC01',
                                                       '01',
                                                       'SCB',
                                                       '*',
                                                       '*',
                                                       '*',
                                                       commPriceUOM,
                                                       commQtyUOM,
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '');

                 if(conversionFactor is null) then
                     p_ret_code := '0002';
                 end if;
           else
               conversionFactor := 1;
           end if;

           tmpCommPriceAmt := nvl(commPriceAmt,0) / nvl(conversionFactor,1);

           equivAmt := nvl(commQty,0) * NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                    ctyCode,
                                                    commPriceCcy,
                                                    nvl(tmpCommPriceAmt,0),
                                                    expCcy,
                                                    'Y'),
                                                     0);

           calcEquiv := false;

       end if;

       -- If Equivalent Quantity is Provided then Calculate quantity
       if (equivAmt != 0 AND calcEquiv = true) THEN


             commQty :=   NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                    ctyCode,
                                                    equivCcy,
                                                    equivAmt,
                                                    commPriceCcy,
                                                    'Y'),
                                                     0) / tmpCommPriceAmt;
              commQtyUOM := commPriceUOM;


       end if;


       equivAmt      := Scbf_Round_Amount(bankGroupCode,
                                           equivCcy,
                                           equivAmt);
  END  SCBP_P_GET_COMMODITY_SMRY;


FUNCTION SCBF_GET_PROD_UTIL_AMT_BY_TYPE(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              prodCode      IN VARCHAR2,
                                              utilType      IN VARCHAR2) RETURN NUMBER IS

  totalChildLimitUtilAmt    SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  effUtilAmountForLimit     SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  parentLimiUtilAmt         SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  BEGIN
             totalChildLimitUtilAmt := 0;
             effUtilAmountForLimit := 0;
             parentLimiUtilAmt := 0;
              -- Total Immidiate Child Limit Utilisation
               BEGIN
                    SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,LIMIT_CCY_CODE,
                    NVL((CASE WHEN utilType = 'UM' THEN LIMIT_CCY_UTILISED_AMT
                              WHEN utilType = 'PI' THEN LIMIT_CCY_PEND_INC_AMT
                              WHEN utilType = 'PD' THEN LIMIT_CCY_PEND_DEC_AMT END) ,0),limitCcy,'Y'),0)) INTO totalChildLimitUtilAmt
                    FROM SCBT_T_PROD_LIMIT_UTIL
                    WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode
                    AND limit_id IN (SELECT DISTINCT limit_id  FROM Scbt_r_Cust_Product_Limit
                                    WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode
                                    AND CUST_ID = custId    -- COCOAPERF_12122012
                                    AND inner_to_id = (SELECT DISTINCT EXT_LIMIT_ID
                                                      FROM Scbt_r_Cust_Product_Limit
                                                      WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND LIMIT_ID=limitID
                                                      AND CUST_ID = custId));    -- COCOAPERF_12122012

                 EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;

                 -- Parent Limit Utilisation
                 BEGIN
                      SELECT NVL((CASE WHEN utilType = 'UM' THEN LIMIT_CCY_UTILISED_AMT
                              WHEN utilType = 'PI' THEN LIMIT_CCY_PEND_INC_AMT
                              WHEN utilType = 'PD' THEN LIMIT_CCY_PEND_DEC_AMT END),0) INTO parentLimiUtilAmt
                      FROM SCBT_T_PROD_LIMIT_UTIL
                      WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND LIMIT_ID = limitID;
                EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;
                 -- Effective Parent Limit Utilisation (Product Wise)
                 effUtilAmountForLimit := NVL(parentLimiUtilAmt,0) - NVL(totalChildLimitUtilAmt,0);

  return NVL(effUtilAmountForLimit,0);

  END SCBF_GET_PROD_UTIL_AMT_BY_TYPE;

  FUNCTION SCBF_GET_PROD_UTIL_AMOUNT(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              prodCode      IN VARCHAR2) RETURN NUMBER IS

  totalChildLimitUtilAmt    SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  effUtilAmountForLimit     SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  parentLimiUtilAmt         SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  BEGIN


             totalChildLimitUtilAmt := 0;
             effUtilAmountForLimit := 0;
             parentLimiUtilAmt := 0;

              -- Total Immidiate Child Limit Utilisation

               BEGIN
                    SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                         ctyCode,
                                                         LIMIT_CCY_CODE,
                                                         NVL(LIMIT_CCY_UTILISED_AMT,0),
                                                         limitCcy,
                                                         'Y'),
                                                          0))
                    INTO totalChildLimitUtilAmt
                    FROM SCBT_T_PROD_LIMIT_UTIL
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND limit_id IN (SELECT DISTINCT limit_id
                                       FROM Scbt_r_Cust_Product_Limit
                                        WHERE BANK_GROUP_CODE = bankGroupCode
                                        AND CTY_CODE = ctyCode
                                        AND CUST_ID = custId     -- COCOAPERF_12122012
                                        AND inner_to_id = (SELECT DISTINCT EXT_LIMIT_ID
                                               FROM Scbt_r_Cust_Product_Limit
                                                WHERE BANK_GROUP_CODE = bankGroupCode
                                                AND CTY_CODE = ctyCode
                                                AND CUST_ID = custId     -- COCOAPERF_12122012
                                                and LIMIT_ID = limitID));

                 EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;

                 -- Parent Limit Utilisation

                 BEGIN
                      SELECT NVL(LIMIT_CCY_UTILISED_AMT,0)
                      INTO parentLimiUtilAmt
                      FROM SCBT_T_PROD_LIMIT_UTIL
                      WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND LIMIT_ID = limitID;

                EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;

                 -- Effective Parent Limit Utilisation (Product Wise)
                 effUtilAmountForLimit := NVL(parentLimiUtilAmt,0) - NVL(totalChildLimitUtilAmt,0);

  return NVL(effUtilAmountForLimit,0);


  END SCBF_GET_PROD_UTIL_AMOUNT;


FUNCTION SCBF_GET_PROD_UTIL_AMT_WITH_CB(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              prodCode      IN VARCHAR2) RETURN NUMBER IS

  totalChildLimitUtilAmt    SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  effUtilAmountForLimit     SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  parentLimiUtilAmt         SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
  BEGIN


             totalChildLimitUtilAmt := 0;
             effUtilAmountForLimit := 0;
             parentLimiUtilAmt := 0;

              -- Total Immidiate Child Limit Utilisation

               BEGIN
                    SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                         ctyCode,
                                                         LIMIT_CCY_CODE,
                                                         NVL(LIMIT_CCY_UTILISED_AMT,0),
                                                         limitCcy,
                                                         'Y'),
                                                          0))
                    INTO totalChildLimitUtilAmt
                    FROM SCBT_T_PROD_LIMIT_UTIL
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND limit_id IN (SELECT DISTINCT limit_id
                                       FROM Scbt_r_Cust_Product_Limit
                                        WHERE BANK_GROUP_CODE = bankGroupCode
                                        AND CTY_CODE = ctyCode
                                        AND CUST_ID = custId     -- COCOAPERF_12122012
                                        and limit_cat_code <> 'CI'
                                        AND inner_to_id = (SELECT DISTINCT EXT_LIMIT_ID
                                               FROM Scbt_r_Cust_Product_Limit
                                                WHERE BANK_GROUP_CODE = bankGroupCode
                                                AND CTY_CODE = ctyCode
                                                AND CUST_ID = custId     -- COCOAPERF_12122012
                                                and LIMIT_ID = limitID));

                 EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;

                 -- Parent Limit Utilisation

                 BEGIN
                      SELECT NVL(LIMIT_CCY_UTILISED_AMT,0)
                      INTO parentLimiUtilAmt
                      FROM SCBT_T_PROD_LIMIT_UTIL
                      WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND LIMIT_ID = limitID;

                EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                 END;

                 -- Effective Parent Limit Utilisation (Product Wise)
                 effUtilAmountForLimit := NVL(parentLimiUtilAmt,0) - NVL(totalChildLimitUtilAmt,0);

  return NVL(effUtilAmountForLimit,0);


  END SCBF_GET_PROD_UTIL_AMT_WITH_CB;

  PROCEDURE SCBP_P_INSERT_INTO_STOP_LOSS(p_ret_code    IN OUT VARCHAR2,
                                         bankGroupCode IN VARCHAR2,
                                         ctyCode IN VARCHAR2,
                                         activityId IN VARCHAR2,
                                         dealStepID IN VARCHAR2,
                                         custId IN VARCHAR2,
                                         topupLevel IN VARCHAR2,
                                         txnRefID IN VARCHAR2,
                                         txnRecID IN VARCHAR2,
                                         limitID IN VARCHAR2,
                                         groupID IN VARCHAR2,
                                         LTVAmt IN NUMBER,
                                         shortfallCcy IN VARCHAR2,
                                         shortfallCcyAmt IN NUMBER,
                                         topUpReqFlag IN VARCHAR2,
                                         topUpReqCcy IN VARCHAR2,
                                         topUpReqAmt IN NUMBER,
                                         topUpReqPct IN NUMBER,
                                         populateHist IN VARCHAR2,
                                         txnStepCode  IN VARCHAR2,
                                         bussDate IN VARCHAR2) IS

   BEGIN

        --DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE CUST_ID = custId and DEAL_STEP_ID = dealStepID;
      if (dealStepID != 'N') then
              INSERT INTO SCBT_T_STOPLOSS_SUMMARY_MST(
                    BANK_GROUP_CODE,
                    CTY_CODE,
                    ACTIVITY_ID,
                    DEAL_STEP_ID,
                    CUST_ID,
                    TOPUP_LEVEL,
                    TXN_REF_ID,
                    TXN_REC_ID,
                    LIMIT_ID,
                    GROUP_ID,
                    LTV_CALC_PCT,
                    SHORTFALL_CCY_CODE,
                    SHORTFALL_CCY_AMT,
                    TOPUP_REQ_FLAG,
                    TOPUP_REQ_CCY_CODE,
                    TOPUP_REQ_CCY_AMT,
                    TOPUP_REQ_PCT,
                    TXN_STEP_CODE,
                    REC_ID,
                    EXPOSURE_CCY_CODE,
                    EXPOSURE_CCY_AMT,
                    GCV_CCY_CODE,
                    GCV_CCY_AMT,
                    CASHTOPUP_CCY_CODE,
                    CASHTOPUP_CCY_AMT,
                    BUSINESS_DATE,
                    CMR_CCY_CODE,
                    CMR_CCY_AMT,
                    CMR_PERCENT,
                    LTV_FORMULA,
                    NCV_CCY_CODE,
                    NCV_CCY_AMT
                    )
                    VALUES
                    (bankGroupCode,
                        ctyCode,
                         activityId,
                         dealStepID,
                         custId,
                         topupLevel,
                         txnRefID,
                         txnRecID,
                         limitID,
                         groupID,
                         LTVAmt,
                         shortfallCcy,
                         shortfallCcyAmt,
                         topUpReqFlag,
                         topUpReqCcy,
                         topUpReqAmt,
                         topUpReqPct,
                         txnStepCode,
                         SCBS_C_RECID.NEXTVAL,
                          G_EXPOSURE_CCY_CODE,
                                                           G_EXPOSURE_CCY_AMT,
                                                           G_GCV_CCY_CODE,
                                                           G_GCV_CCY_AMT,
                                                           G_CASHTOPUP_CCY_CODE,
                                                           G_CASHTOPUP_CCY_AMT,
                           bussDate,G_CMR_CCY_CODE,G_CMR_CCY_AMT,G_CASH_MARGIN_PERCNT,G_LTV_FORMULA
                           ,G_NCV_CCY_CODE,G_NCV_CCY_AMT);

               if(dealStepID != 'N' and populateHist = 'Y') then
               INSERT INTO SCBT_T_STOPLOSS_SUMMARY_HIST(
                    BANK_GROUP_CODE,
                    CTY_CODE,
                    ACTIVITY_ID,
                    DEAL_STEP_ID,
                    CUST_ID,
                    TOPUP_LEVEL,
                    TXN_REF_ID,
                    TXN_REC_ID,
                    LIMIT_ID,
                    GROUP_ID,
                    LTV_CALC_PCT,
                    SHORTFALL_CCY_CODE,
                    SHORTFALL_CCY_AMT,
                    TOPUP_REQ_FLAG,
                    TOPUP_REQ_CCY_CODE,
                    TOPUP_REQ_CCY_AMT,
                    TOPUP_REQ_PCT,
                    TXN_STEP_CODE,
                    REC_ID,
                    EXPOSURE_CCY_CODE,
                    EXPOSURE_CCY_AMT,
                    GCV_CCY_CODE,
                    GCV_CCY_AMT,
                    CASHTOPUP_CCY_CODE,
                    CASHTOPUP_CCY_AMT,
                    BUSINESS_DATE,
                    CMR_CCY_CODE,
                    CMR_CCY_AMT,
                    CMR_PERCENT,
                    LTV_FORMULA,
                    NCV_CCY_CODE,
                    NCV_CCY_AMT
                    )
                    VALUES
                    (bankGroupCode,
                        ctyCode,
                         activityId,
                         dealStepID,
                         custId,
                         topupLevel,
                         txnRefID,
                         txnRecID,
                         limitID,
                         groupID,
                         LTVAmt,
                         shortfallCcy,
                         shortfallCcyAmt,
                         topUpReqFlag,
                         topUpReqCcy,
                         topUpReqAmt,
                         topUpReqPct,
                         txnStepCode,
                         SCBS_C_RECID.NEXTVAL,
                         G_EXPOSURE_CCY_CODE,
                                                           G_EXPOSURE_CCY_AMT,
                                                           G_GCV_CCY_CODE,
                                                           G_GCV_CCY_AMT,
                                                           G_CASHTOPUP_CCY_CODE,
                                                           G_CASHTOPUP_CCY_AMT,
                           bussDate,G_CMR_CCY_CODE,G_CMR_CCY_AMT,G_CASH_MARGIN_PERCNT,G_LTV_FORMULA
                           ,G_NCV_CCY_CODE,G_NCV_CCY_AMT);

               end if;
            end if;
       COMMIT;

        G_EXPOSURE_CCY_CODE:='';
                                                           G_EXPOSURE_CCY_AMT:=0;
                                                           G_GCV_CCY_CODE:='';
                                                           G_GCV_CCY_AMT:=0;
                                                           G_CASHTOPUP_CCY_CODE:='';
                                                           G_CASHTOPUP_CCY_AMT:=0;
   p_ret_code := '0000';

   END SCBP_P_INSERT_INTO_STOP_LOSS;




    FUNCTION SCBF_GET_ADJ_AMT(adjFactor number,adjType varchar2) RETURN NUMBER IS
    BEGIN

       if(adjType = 'MINUS') then
          return ((-1)*adjFactor);
       else
           return (adjFactor);
       end if;

    END SCBF_GET_ADJ_AMT;

    FUNCTION SCBF_GET_CUST_TOPUP_AMT(bankGroupCode IN VARCHAR2,
                                                  ctyCode       IN VARCHAR2,
                                                  custId        IN VARCHAR2) RETURN NUMBER is
      totalTopupCcyAmt   number(17,3);
      custExpCcy         varchar2(3);
      BEGIN


      BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          custExpCcy := 'SGD';
      END;


                 BEGIN
                     SELECT SUM(DECODE(TOPUP_TYPE_CODE,'ADD',NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                           ctyCode,
                                                           TOPUP_CCY_CODE,
                                                           NVL(TOPUP_CCY_AMT,0),
                                                           custExpCcy,
                                                           'N'),   -- 'Y'), COCOACR_16012013
                                                            0),
                                                            -NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                           ctyCode,
                                                           TOPUP_CCY_CODE,
                                                           NVL(TOPUP_CCY_AMT,0),
                                                           custExpCcy,
                                                           'N'),   -- 'Y'), COCOACR_16012013
                                                            0)))
                     INTO totalTopupCcyAmt
                     FROM SCBT_T_TOPUP_ACTIVITY_MST
                     WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId;


                EXCEPTION
                         WHEN NO_DATA_FOUND THEN
                         NULL;
                END;


                return nvl(totalTopupCcyAmt,0);


    END SCBF_GET_CUST_TOPUP_AMT;

  FUNCTION SCBF_GET_TOPUP_AMT_GRP_LEVEL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              groupId       IN VARCHAR2,
                                              custExpCcy    IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
   totalTopupAmt  number(17,3);
   limitIdInGrp         varchar2(200);
   limitIDsToProcess    t_array;
   BEGIN

   totalTopupAmt := 0;

           BEGIN
             SELECT PROD_LIMIT_IDS
             INTO limitIdInGrp
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId     -- COCOAPERF_12122012
               AND FACILITY_GRP_ID = groupId
               AND GROUP_TYPE = 'LTV';


       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;


      limitIDsToProcess := SCBF_GET_SPLIT_STRING_ON_DELIM(limitIdInGrp,',');
      totalTopupAmt := 0;


       for limitCount in 1..limitIDsToProcess.COUNT LOOP


           totalTopupAmt := NVL(totalTopupAmt,0) +  SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,
                                                                                ctyCode,
                                                                                custId,
                                                                                '',
                                                                                '',
                                                                                '',
                                                                                limitIDsToProcess(limitCount),
                                                                                custExpCcy,
                                                                                custExpCcy,
                                                                                'F');

       end loop;

       return NVL(totalTopupAmt,0);

  END SCBF_GET_TOPUP_AMT_GRP_LEVEL;


    FUNCTION SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRefId      IN VARCHAR2,
                                              txnRecId      IN VARCHAR2,
                                              txnCcyCode    IN VARCHAR2,
                                              limitId       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              custExpCcy    IN VARCHAR2,
                                              topUpLevelReq IN VARCHAR2) RETURN NUMBER IS
    topupCcyAmt   number(17,3);
    --prod_ref_code SCBT_R_PRODUCT_MST.PROD_REF_CODE%TYPE; --REF_27NOV2012
    prod_ref_code Varchar2(16); --REF_03012013
    BEGIN


          if(topUpLevelReq ='T') then

          --REF_27NOV2012
          --REF_04DEC2012
              BEGIN

                  select NVL(p.PRODUCT_SUB_TYPE,'NONLC') INTO prod_ref_code   --REF_03012013
                         from scbt_r_product_mst p,scbt_t_txn_mst t
                  where t.PRODUCT_CODE = p.product_code
                         and t.bank_group_code = p.bank_group_code
                         and t.bank_group_code = bankGroupCode
                         and t.cty_code = ctyCode
                         and t.cust_id = custId
                         and t.txn_ref_id = txnRefId
                         and t.txn_rec_id = txnRecId;

              EXCEPTION  WHEN OTHERS THEN

                BEGIN
                  select NVL(p.PRODUCT_SUB_TYPE,'NONLC') INTO prod_ref_code   --REF_03012013
                         from scbt_r_product_mst p,scbt_t_txn_hst t,scbt_t_deal_hist h
                  where t.PRODUCT_CODE = p.product_code
                          and t.bank_group_code = p.bank_group_code
                          and t.BANK_GROUP_CODE = h.bank_group_code
                          and t.cty_code = h.cty_code
                          and h.deal_id = t.deal_id
                          and t.deal_step_id = h.deal_step_id
                          and h.step_status_code <> '03'
                          and t.cust_id = h.cust_id
                          and t.bank_group_code = bankGroupCode
                          and t.cty_code = ctyCode
                          and t.cust_id = custId
                          and t.txn_ref_id = txnRefId
                          and t.txn_rec_id = txnRecId;
                EXCEPTION
                      WHEN OTHERS THEN
                        prod_ref_code:='NONLC';    --REF_03012013
                END;


              END;



                 BEGIN

                   IF (prod_ref_code <> 'LC') THEN
                       SELECT SUM(DECODE(TOPUP_TYPE_CODE,'ADD',NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                 ctyCode,
                                                                 TOPUP_CCY_CODE,
                                                                 NVL(TOPUP_CCY_AMT,0),
                                                                 txnCcyCode,
                                                                 'N'),   -- 'Y'), COCOACR_16012013
                                                                  0),
                                                                  -NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                 ctyCode,
                                                                 TOPUP_CCY_CODE,
                                                                 NVL(TOPUP_CCY_AMT,0),
                                                                 txnCcyCode,
                                                                 'N'),   -- 'Y'), COCOACR_16012013
                                                                  0)))
                       INTO topupCcyAmt
                       FROM SCBT_T_TOPUP_ACTIVITY_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                       AND CTY_CODE = ctyCode
                       AND CUST_ID = custId
                       AND TOPUP_APPLICABLE ='T'
                       AND TXN_REF_ID = txnRefID;

                   ELSE

                       SELECT SUM(DECODE(TOPUP_TYPE_CODE,'ADD',NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                 ctyCode,
                                                                 TOPUP_CCY_CODE,
                                                                 NVL(TOPUP_CCY_AMT,0),
                                                                 txnCcyCode,
                                                                 'N'),   -- 'Y'), COCOACR_16012013
                                                                  0),
                                                                  -NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                 ctyCode,
                                                                 TOPUP_CCY_CODE,
                                                                 NVL(TOPUP_CCY_AMT,0),
                                                                 txnCcyCode,
                                                                 'N'),   -- 'Y'), COCOACR_16012013
                                                                  0)))
                       INTO topupCcyAmt
                       FROM SCBT_T_TOPUP_ACTIVITY_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                       AND CTY_CODE = ctyCode
                       AND CUST_ID = custId
                       AND TOPUP_APPLICABLE ='T'
                       AND TXN_REF_ID = txnRefID
                       AND TXN_REC_ID = txnRecID;

                   END IF;

                EXCEPTION
                         WHEN NO_DATA_FOUND THEN
                         NULL;
                END;

          elsif(topUpLevelReq ='F') then

                BEGIN
                   SELECT SUM(DECODE(TOPUP_TYPE_CODE,'ADD',NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                         ctyCode,
                                                         TOPUP_CCY_CODE,
                                                         NVL(TOPUP_CCY_AMT,0),
                                                         limitCcy,
                                                         'N'),   -- 'Y'), COCOACR_16012013
                                                          0),
                                                          -NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                         ctyCode,
                                                         TOPUP_CCY_CODE,
                                                         NVL(TOPUP_CCY_AMT,0),
                                                         limitCcy,
                                                         'N'),   -- 'Y'), COCOACR_16012013
                                                          0)))
                   INTO topupCcyAmt
                   FROM SCBT_T_TOPUP_ACTIVITY_MST
                   WHERE BANK_GROUP_CODE = bankGroupCode
                   AND CTY_CODE = ctyCode
                   AND CUST_ID = custId
                   AND TOPUP_APPLICABLE ='F'
                   AND LIMIT_ID = limitID;


              EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       NULL;
              END;


          elsif(topUpLevelReq ='C') then
             BEGIN
                 SELECT SUM(DECODE(TOPUP_TYPE_CODE,'ADD',NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                       ctyCode,
                                                       TOPUP_CCY_CODE,
                                                       NVL(TOPUP_CCY_AMT,0),
                                                       custExpCcy,
                                                       'N'),   -- 'Y'), COCOACR_16012013
                                                        0),
                                                        -NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                       ctyCode,
                                                       TOPUP_CCY_CODE,
                                                       NVL(TOPUP_CCY_AMT,0),
                                                       custExpCcy,
                                                       'N'),   -- 'Y'), COCOACR_16012013
                                                        0)))
                 INTO topupCcyAmt
                 FROM SCBT_T_TOPUP_ACTIVITY_MST
                 WHERE BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE = ctyCode
                 AND CUST_ID = custId
                 AND TOPUP_APPLICABLE ='C';


            EXCEPTION
                     WHEN NO_DATA_FOUND THEN
                     NULL;
            END;
          end if;


          return  nvl(topupCcyAmt,0);

    END SCBF_GET_TOPUP_AMT_BY_LEVEL;

     FUNCTION SCBF_GET_TXN_LEVEL_LTV_ENQ(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRefID      IN VARCHAR2,
                                              txnRecID      IN VARCHAR2,
                                              prodLimitId   IN VARCHAR2,
                                              txnCcyCode    IN VARCHAR2,
                                              txnOSAmt      IN NUMBER,
                                              dealStepId    IN VARCHAR2,
                                              sourceType    IN VARCHAR2,
                                              txnStepCode   IN VARCHAR2) RETURN NUMBER IS
     stopLossAppl   varchar2(1);
     BEGIN


          BEGIN
               SELECT STOP_LOSS_APPL_FLAG INTO stopLossAppl
               FROM SCBT_R_CUST_PRODUCT_LIMIT
               WHERE BANK_GROUP_CODE=bankGroupCode
               AND CTY_CODE=ctyCode
               AND CUST_ID = custId     -- COCOAPERF_12122012
               AND LIMIT_ID = prodLimitId;
         EXCEPTION
               WHEN OTHERS THEN
               NULL;
         END;

         if(stopLossAppl = 'T') then



         return SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,
                                                      ctyCode,
                                                      custId,
                                                      txnRefID,
                                                      txnRecId,
                                                      txnOSAmt,
                                                      txnCcyCode,
                                                      txnStepCode,
                                                      'N',
                                                      sourceType,
                                                      dealStepId,
                                                      '',
                                                      0,
                                                      txnCcyCode,
                                                      0,
                                                      0,
                                                      0,
                                                      'LTV');



         else
            return 0;
         end if;


     END SCBF_GET_TXN_LEVEL_LTV_ENQ;

    FUNCTION SCBF_GET_TXN_LEVEL_LTV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRefID      IN VARCHAR2,
                                              txnRecID      IN VARCHAR2,
                                              txnOSAmt      IN NUMBER,
                                              txnCcyCode    IN VARCHAR2,
                                              txnStepCode   IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              sourceType    IN VARCHAR2,
                                              dealStepId    IN VARCHAR2,
                                              adjFactor     IN VARCHAR2,
                                              adjAmount     IN NUMBER,
                                              custExpCcy    IN VARCHAR2,
                                              cmAmt         IN NUMBER,
                                              cmReleasedAmt IN NUMBER,
                                              cmNetAmt      IN NUMBER,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
    totalGcvAmt number(17,3) default 0;
    ltvPercentage number(17,3) default 0;
    topupAppl     varchar2(1);
    topupTypeCode varchar2(1);
    topupCcyCode  varchar2(1);
    topupCcyAmt   number(17,3) default 0;
    totalCov      number(17,3) default 0;
    facilityLevelLTVPercentage number(17,3) default 0;
    cashMarginAmt number(17,3) default 0;
    ltvFormula    varchar2(5);
    limitId    varchar2(16);
    parentTxnRecId varchar2(16);
    parentTxnRefId varchar2(16);


    BEGIN
      totalGcvAmt := 0;
      ltvPercentage := 0;
      topupCcyAmt := 0;

      -- Start Ref:03-Oct-2012
      BEGIN
          SELECT LTV_FORMULA
            INTO ltvFormula
            FROM SCBT_R_PARTY_MST
           WHERE BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND PARTY_ID = custId;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            ltvFormula := 'LTV1';
      END;


      BEGIN

      if(dealStepID ='M' OR dealStepID is null OR dealStepID='' OR dealStepID='UTIL') then
          SELECT DISTINCT PROD_LIMIT_ID
            INTO limitId
            FROM SCBT_T_TXN_MST
           WHERE BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND CUST_ID = custId
             AND TXN_REF_ID = txnRefID
             and txn_rec_id = txnRecID;
      else
          SELECT DISTINCT PROD_LIMIT_ID
            INTO limitId
            FROM SCBT_T_TXN_HST
           WHERE BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND CUST_ID = custId
             AND TXN_REF_ID = txnRefID
             and txn_rec_id = txnRecID
             and deal_step_id = dealStepID;

      end if;
        EXCEPTION
          WHEN OTHERS THEN
            limitId := '';
      END;

      -- REF_04012013
      BEGIN
      if(txnStepCode = 'LMTR') then
         SELECT parent_txn_rec_id, parent_txn_ref_id
         INTO parentTxnRecId,parentTxnRefId
         FROM SCBT_T_TXN_HST
         WHERE CUST_ID = custId
         AND TXN_REC_ID = txnRecID
         AND TXN_REF_ID = txnRefID
         AND BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode;
      end if;
        EXCEPTION
          WHEN OTHERS THEN
             null;
      END;

      --cashMarginAmt := SCBF_C_GET_TOT_CASH_MARGIN_CD(limitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId);  -- REF05122012  --REF_CR03012013
      cashMarginAmt := SCBF_C_TXN_LEVEL_CASH_MARGIN(limitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId,txnRefID,txnRecID);  --REF_CR03012013

      -- End Ref:03-Oct-2012
      totalGcvAmt := Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         txnCcyCode,
                                                                         txnRecID,
                                                                         txnCcyCode,
                                                                         dealStepId,
                                                                         sourceType,
                                                                         txnStepCode);

     --topupCcyAmt := SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,txnCcyCode,'','',custExpCcy,'T');  --REF_CR03012013
     if(txnStepCode = 'LMTR') then         -- Start REF_04012013
        topupCcyAmt := SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,parentTxnRefId,parentTxnRecId,txnCcyCode,limitId,custExpCcy,'N','T');   --REF_CR03012013
     else
        topupCcyAmt := SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,txnCcyCode,limitId,custExpCcy,'N','T');
     end if;                    -- End REF_04012013

     -- Start Ref:03-Oct-2012

      if(ltvFormula ='LTV2') then
          totalCov := nvl(txnOSAmt,0) - nvl(cashMarginAmt,0) - nvl(topupCcyAmt,0);
          if ( totalGCVAmt > 0) then
             ltvPercentage := (nvl(totalCov,0)/totalGCVAmt)*100;
          elsif (txnOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       elsif (ltvFormula ='LTV3') then
         totalCov := nvl(totalGCVAmt,0) + nvl(cashMarginAmt,0) + nvl(topupCcyAmt,0);
         if (totalCov > 0) then
             ltvPercentage := (nvl(txnOSAmt,0)/totalCov)*100;
         elsif (txnOSAmt > 0 and (totalCov) = 0) then
             ltvPercentage := 999.999;
         else
             ltvPercentage := 0;
         end if;
       else
         totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);
          if ( totalCov > 0) then
             ltvPercentage := (nvl(txnOSAmt,0)/totalCov)*100;
          elsif (txnOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       end if;

         if ltvFormula is null then
            ltvFormula := 'LTV1';
         else
            ltvFormula := ltvFormula;
         end if;
         G_LTV_FORMULA := ltvFormula;
         G_CMR_CCY_AMT  := cashMarginAmt;
         G_CMR_CCY_CODE  := txnCcyCode;

/*     totalCov := nvl(topupCcyAmt,0) + nvl(totalGcvAmt,0);


     if ( totalCov > 0) then
      ltvPercentage := (nvl(txnOSAmt,0)/totalCov)*100;
     elsif (txnOSAmt > 0 and (totalCov) = 0)  then
      ltvPercentage := 999.999;
     else
      ltvPercentage := 0;
     end if;*/

     -- End Ref:03-Oct-2012
      /*ltvPercentage  := SCBF_COCOA_ROUND_AMOUNT(bankGroupCode,
                                                   custExpCcy,
                                                   ltvPercentage);*/
      ltvPercentage := round(ltvPercentage,6);

      G_EXPOSURE_CCY_CODE:= txnCcyCode;
      G_EXPOSURE_CCY_AMT:=nvl(txnOSAmt,0);
      G_GCV_CCY_CODE :=txnCcyCode;
      G_GCV_CCY_AMT:=  nvl(totalGCVAmt,0);
      G_CASHTOPUP_CCY_CODE:=txnCcyCode;
      G_CASHTOPUP_CCY_AMT :=   nvl(topupCcyAmt,0);

      if(valueFlag = 'OS') then
          return nvl(txnOSAmt,0);
       elsif(valueFlag = 'GCV') then
          return nvl(totalGCVAmt,0);
       else
          return nvl(ltvPercentage,0);
     end if;

    END SCBF_GET_TXN_LEVEL_LTV;

   FUNCTION SCBF_GET_LIMIT_LEVEL_LTV_ENQ(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
   stopLossAppl   varchar2(1);
   custExpCcy   varchar2(3);
   begin

          BEGIN
               SELECT STOP_LOSS_APPL_FLAG INTO stopLossAppl
               FROM SCBT_R_CUST_PRODUCT_LIMIT
               WHERE BANK_GROUP_CODE=bankGroupCode
               AND CTY_CODE=ctyCode
               AND CUST_ID = custId -- COCOAPERF_12122012
               AND LIMIT_ID = limitID
               AND STOP_LOSS_APPL_FLAG ='F';
         EXCEPTION
               WHEN OTHERS THEN
               NULL;
         END;


         if (stopLossAppl ='F' ) then

              return SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,
                                              ctyCode,
                                              custId,
                                              limitID,
                                              limitCcy,
                                              piFlag,
                                              valueFlag);

         elsif (stopLossAppl ='G' ) then

         BEGIN
            SELECT OVERALL_EXP_CURRENCY
              INTO custExpCcy
              FROM scbt_r_party_mst
             WHERE bank_group_code = bankGroupCode
               AND cty_code = ctyCode
               AND party_id = custId;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              custExpCcy := 'SGD';
          END;

              return SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,
                                                    ctyCode,
                                                    custId,
                                                    limitID,
                                                    custExpCcy,
                                                    piFlag,
                                                    valueFlag);
         else

             return 0;

         end if;

   end SCBF_GET_LIMIT_LEVEL_LTV_ENQ;

   FUNCTION SCBF_GET_CUST_UNLINKED_GCV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
   TYPE LimidIDType    IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
   limitIdList          LimidIDType;
   totalUnlinkedGCVAmt  number(17,3);
   custExpCcy           varchar2(3);

   BEGIN
   totalUnlinkedGCVAmt := 0;

        BEGIN
          SELECT OVERALL_EXP_CURRENCY
            INTO custExpCcy
            FROM scbt_r_party_mst
           WHERE bank_group_code = bankGroupCode
             AND cty_code = ctyCode
             AND party_id = custId;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            custExpCcy := 'SGD';
        END;

       BEGIN
            SELECT DISTINCT LIMIT_ID
            BULK COLLECT INTO limitIdList
            FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE BANK_GROUP_CODE = bankGroupCode
            AND CTY_CODE = ctyCode
            AND CUST_ID = custId;

       EXCEPTION
             WHEN NO_DATA_FOUND THEN
              NULL;
       END;

       For i in 1..limitIdList.COUNT LOOP

           totalUnlinkedGCVAmt := totalUnlinkedGCVAmt + SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                      ctyCode,
                                                                                      custId,
                                                                                      limitIdList(i),
                                                                                      custExpCcy,
                                                                                      piFlag,
                                                                                      valueFlag);

       End Loop;

       return NVL(totalUnlinkedGCVAmt,0);


   END SCBF_GET_CUST_UNLINKED_GCV;


   FUNCTION SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
   totalUnlinkedGCVCcy  varchar2(3);
   totalUnlinkedGCVAmt  number(17,3);
   unlinkedGCVCcy       varchar2(3);
   unlinkedGCVAmt       number(17,3);
   business_type        varchar2(3);
   BEGIN

   unlinkedGCVAmt := 0;

       if (piFlag = 'N') then

       BEGIN
        SELECT SUM (NVL(scbf_fetch_exch_rate (bankGroupCode,
                                       ctyCode,
                                       total_gcv_ccy_code,
                                       total_gcv_ccy_amt,
                                       limitCcy,
                                       'Y'
                                      ), 0 )
                ) INTO unlinkedGCVAmt
                        FROM scbt_t_collateral_register_mst crm, scbt_t_deal_register_hdr_mst drh
                        WHERE crm.bank_group_code = drh.bank_group_code
                           AND crm.cty_code = drh.cty_code
                           AND crm.deal_id = drh.deal_id
                           AND crm.cust_id = drh.cust_id
                           AND crm.bank_group_code = bankGroupCode
                           AND crm.cty_code = ctyCode
                           AND drh.cust_id = custId
                           --AND (drh.business_type = 'FLC' OR drh.business_type = 'OD')  -- COCOAPERF_12122012
                           AND drh.business_type IN ('FLC','OD')  -- COCOAPERF_12122012
                           AND crm.collateral_category <> 'REL'
                           AND drh.prod_limit_id = limitID
                           AND crm.collateral_id NOT IN (
                                          SELECT crh.collateral_id
                                                FROM scbt_t_collateral_register_hst crh,
                                                         scbt_t_deal_hist dh,
                                                         scbt_t_deal_register_hdr_mst drh
                                           WHERE crh.bank_group_code = dh.bank_group_code
                                                 AND crh.bank_group_code = drh.bank_group_code
                                                 AND crh.cty_code = dh.cty_code
                                                 AND crh.cty_code = drh.cty_code
                                                 AND crh.cust_id = dh.cust_id
                                                 AND crh.cust_id = drh.cust_id
                                                 AND crh.deal_id = drh.deal_id
                                                 AND crh.deal_id = dh.deal_id   --COCOAPERFTUNE_003
                                                 AND crh.deal_step_id = dh.deal_step_id
                                                 AND dh.step_status_code IN ('02', '10', '14')
                                                 -- COCOAPERFTUNE_001     AND crh.cust_id = drh.cust_id   (duplicate entry)
                                                  -- COCOAPERFTUNE_001    AND crh.cust_id = dh.cust_id     (duplicate entry)
                                                 --AND (drh.business_type = 'FLC' OR drh.business_type = 'OD')  -- COCOAPERF_12122012
                                                 AND drh.business_type IN ('FLC','OD')  -- COCOAPERF_12122012
                                                 AND crh.bank_group_code = bankGroupCode  -- COCOAPERFTUNE_001 changed crm to crh
                                                 AND crh.cty_code = ctyCode  -- COCOAPERFTUNE_001 changed crm to crh
                                                 AND crh.cust_id = custId  -- COCOAPERFTUNE_001 added cust id (index)
                                                 AND drh.prod_limit_id = limitID);

       EXCEPTION
              WHEN NO_DATA_FOUND THEN
              NULL;
       END;



       elsif (piFlag = 'Y') then

       BEGIN

              SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                    ctyCode,
                                    TOTAL_GCV_CCY_CODE,
                                    TOTAL_GCV_CCY_AMT,
                                    limitCcy,
                                    'Y'),
                                     0))
                        INTO unlinkedGCVAmt
                        FROM SCBT_T_COLLATERAL_REGISTER_HST CRH,
                             SCBT_T_DEAL_HIST               DH,
                             SCBT_T_DEAL_REGISTER_HDR_MST   DRH
                        WHERE CRH.CUST_ID = DH.CUST_ID
                         AND CRH.CUST_ID = DRH.CUST_ID
                         AND CRH.DEAL_ID = DRH.DEAL_ID
                         AND crh.deal_id = dh.deal_id   --COCOAPERFTUNE_003
                         AND CRH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                         AND CRH.BANK_GROUP_CODE = DRH.BANK_GROUP_CODE
                         AND CRH.CTY_CODE = DRH.CTY_CODE
                         AND CRH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                         AND CRH.CTY_CODE = DH.CTY_CODE
                         AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                         --AND CRH.CUST_ID = DRH.CUST_ID  -- COCOAPERF_12122012
                         --AND CRH.CUST_ID = DH.CUST_ID    -- COCOAPERF_12122012
                         --AND (DRH.BUSINESS_TYPE = 'FLC' OR DRH.BUSINESS_TYPE = 'OD')  -- COCOAPERF_12122012
                         AND DRH.BUSINESS_TYPE IN ('FLC','OD')    -- COCOAPERF_12122012
                         AND CRH.COLLATERAL_CATEGORY <> 'REL'
                         AND CRH.BANK_GROUP_CODE = bankGroupCode
                         AND CRH.CTY_CODE = ctyCode
                         AND DRH.PROD_LIMIT_ID = limitID
                         AND CRH.CUST_ID = custId;  -- COCOAPERFTUNE_001 added cust id (index)



       EXCEPTION
              WHEN NO_DATA_FOUND THEN
              NULL;
       END;

       end if;



       return NVL(unlinkedGCVAmt,0);


   END SCBF_GET_FACILITY_UNLINKED_GCV;

  /********************Added for NCV value zero for facility level which is not linked */
  FUNCTION SCBF_GET_FACILITY_UNLINKED_NCV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS
   totalUnlinkedNCVCcy  varchar2(3);
   totalUnlinkedNCVAmt  number(17,3);
   unlinkedNCVCcy       varchar2(3);
   unlinkedNCVAmt       number(17,3);
   business_type        varchar2(3);
   BEGIN

   unlinkedNCVAmt := 0;

       if (piFlag = 'N') then

       BEGIN
        SELECT SUM (NVL(scbf_fetch_exch_rate (bankGroupCode,
                                       ctyCode,
                                       total_ncv_ccy_code,
                                       total_ncv_ccy_amt,
                                       limitCcy,
                                       'Y'
                                      ), 0 )
                ) INTO unlinkedNCVAmt
                        FROM scbt_t_collateral_register_mst crm, scbt_t_deal_register_hdr_mst drh
                        WHERE crm.bank_group_code = drh.bank_group_code
                           AND crm.cty_code = drh.cty_code
                           AND crm.deal_id = drh.deal_id
                           AND crm.cust_id = drh.cust_id
                           AND crm.bank_group_code = bankGroupCode
                           AND crm.cty_code = ctyCode
                           AND drh.cust_id = custId
                           --AND (drh.business_type = 'FLC' OR drh.business_type = 'OD')  -- COCOAPERF_12122012
                           AND drh.business_type IN ('FLC','OD') -- COCOAPERF_12122012
                           AND crm.collateral_category <> 'REL'
                           AND drh.prod_limit_id = limitID
                           AND crm.collateral_id NOT IN (
                                          SELECT crh.collateral_id
                                                FROM scbt_t_collateral_register_hst crh,
                                                         scbt_t_deal_hist dh,
                                                         scbt_t_deal_register_hdr_mst drh
                                           WHERE crh.bank_group_code = dh.bank_group_code
                                                 AND crh.bank_group_code = drh.bank_group_code
                                                 AND crh.cty_code = dh.cty_code
                                                 AND crh.cty_code = drh.cty_code
                                                 AND crh.cust_id = dh.cust_id
                                                 AND crh.cust_id = drh.cust_id
                                                 AND crh.deal_id = drh.deal_id
                                                 AND crh.deal_id = dh.deal_id   --COCOAPERFTUNE_003
                                                 AND crh.deal_step_id = dh.deal_step_id
                                                 AND dh.step_status_code IN ('02', '10', '14')
                                                 --AND (drh.business_type = 'FLC' OR drh.business_type = 'OD')  -- COCOAPERF_12122012
                                                 AND drh.business_type IN ('FLC','OD') -- COCOAPERF_12122012
                                                 AND crh.bank_group_code = bankGroupCode  -- COCOAPERFTUNE_001 changed crm to crh
                                                 AND crh.cty_code = ctyCode  -- COCOAPERFTUNE_001 changed crm to crh
                                                 AND crh.cust_id = custId  -- COCOAPERFTUNE_001 added cust id (index)
                                                 AND drh.prod_limit_id = limitID);

       EXCEPTION
              WHEN NO_DATA_FOUND THEN
              NULL;
       END;



       elsif (piFlag = 'Y') then

       BEGIN

              SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                    ctyCode,
                                    TOTAL_NCV_CCY_CODE,
                                    TOTAL_NCV_CCY_AMT,
                                    limitCcy,
                                    'Y'),
                                     0))
                        INTO unlinkedNCVAmt
                        FROM SCBT_T_COLLATERAL_REGISTER_HST CRH,
                             SCBT_T_DEAL_HIST               DH,
                             SCBT_T_DEAL_REGISTER_HDR_MST   DRH
                        WHERE CRH.CUST_ID = DH.CUST_ID
                         AND CRH.CUST_ID = DRH.CUST_ID
                         AND CRH.DEAL_ID = DRH.DEAL_ID
                         AND crh.deal_id = dh.deal_id   --COCOAPERFTUNE_003
                         AND CRH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                         AND CRH.BANK_GROUP_CODE = DRH.BANK_GROUP_CODE
                         AND CRH.CTY_CODE = DRH.CTY_CODE
                         AND CRH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                         AND CRH.CTY_CODE = DH.CTY_CODE
                         AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                         --AND CRH.CUST_ID = DRH.CUST_ID  -- COCOAPERF_12122012
                         --AND CRH.CUST_ID = DH.CUST_ID   -- COCOAPERF_12122012
                         --AND (DRH.BUSINESS_TYPE = 'FLC' OR DRH.BUSINESS_TYPE = 'OD')  -- COCOAPERF_12122012
                         AND DRH.BUSINESS_TYPE IN ('FLC','OD')  -- COCOAPERF_12122012
                         AND CRH.COLLATERAL_CATEGORY <> 'REL'
                         AND CRH.BANK_GROUP_CODE = bankGroupCode
                         AND CRH.CTY_CODE = ctyCode
                         AND DRH.PROD_LIMIT_ID = limitID
                         AND CRH.CUST_ID = custId;



       EXCEPTION
              WHEN NO_DATA_FOUND THEN
              NULL;
       END;

       end if;



       return NVL(unlinkedNCVAmt,0);


   END SCBF_GET_FACILITY_UNLINKED_NCV;

 /********************Added for NCV value zero for facility level which is not linked */


   FUNCTION SCBF_GET_GROUP_UNLINKED_GCV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              custExpCcy    IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS
   totalUnlinkedGCVCcy  varchar2(3);
   totalUnlinkedGCVAmt  number(17,3);
   unlinkedGCVCcy       varchar2(3);
   unlinkedGCVAmt       number(17,3);
   groupId              varchar2(16);
   limitIdInGrp         varchar2(200);
   limitIDsToProcess    t_array;
   BEGIN

   totalUnlinkedGCVAmt := 0;

           BEGIN
             SELECT FACILITY_GRP_ID,PROD_LIMIT_IDS
             INTO groupID,limitIdInGrp
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId         -- COCOAPERF_12122012
               --AND PROD_LIMIT_IDS LIKE '%' ||limitID ||'%'
               AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || limitID || ',', 1, 1 ) =( ',' || limitID || ',')
                AND GROUP_TYPE = 'LTV';


       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;


      limitIDsToProcess := SCBF_GET_SPLIT_STRING_ON_DELIM(limitIdInGrp,',');
      totalUnlinkedGCVAmt := 0;


      for limitCount in 1..limitIDsToProcess.COUNT LOOP


           totalUnlinkedGCVAmt := NVL(totalUnlinkedGCVAmt,0) +  SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                      ctyCode,
                                                                                      custId,
                                                                                      limitIDsToProcess(limitCount),
                                                                                      custExpCcy,
                                                                                      piFlag,
                                                                                      valueFlag);

       end loop;

       return NVL(totalUnlinkedGCVAmt,0);


   END SCBF_GET_GROUP_UNLINKED_GCV;

 /*************************End REF_23Aug012***********************/

    FUNCTION SCBF_GET_GROUP_UNLINKED_NCV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              vgroupId       IN VARCHAR2,
                                              custExpCcy    IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS
   totalUnlinkedNCVCcy  varchar2(3);
   totalUnlinkedNCVAmt  number(17,3);
   unlinkedNCVCcy       varchar2(3);
   unlinkedNCVAmt       number(17,3);
   groupId              varchar2(16);
   limitIdInGrp         varchar2(200);
   limitIDsToProcess    t_array;
   BEGIN

   totalUnlinkedNCVAmt := 0;

           BEGIN
             SELECT FACILITY_GRP_ID,PROD_LIMIT_IDS
             INTO groupID,limitIdInGrp
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId     -- COCOAPERF_12122012
               AND FACILITY_GRP_ID = vgroupId
               AND GROUP_TYPE = 'LTV';


       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;


      limitIDsToProcess := SCBF_GET_SPLIT_STRING_ON_DELIM(limitIdInGrp,',');
      totalUnlinkedNCVAmt := 0;


      for limitCount in 1..limitIDsToProcess.COUNT LOOP


           totalUnlinkedNCVAmt := NVL(totalUnlinkedNCVAmt,0) +  SCBF_GET_FACILITY_UNLINKED_NCV(bankGroupCode,
                                                                                      ctyCode,
                                                                                      custId,
                                                                                      limitIDsToProcess(limitCount),
                                                                                      custExpCcy,
                                                                                      piFlag);

       end loop;

       return NVL(totalUnlinkedNCVAmt,0);


   END SCBF_GET_GROUP_UNLINKED_NCV;

 /*************************End REF_23Aug012***********************/



   FUNCTION SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;
    facilityOSAmt            SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
    totalOSAmt               number(17,3);
    totalGCVAmt              number(17,3);
    totalAdjAmt              number(17,3);
    ltvPercentage            number(17,3);
    topupAppl     varchar2(1);
    buss_type     varchar2(10);
    topupTypeCode varchar2(1);
    topupCcyCode  varchar2(1);
    topupCcyAmt   number(17,3) default 0;
    totalCov number(17,3) default 0;
    gcvAmt number(17,3) default 0;
    facilityLevelLTVPercentage number(17,3) default 0;
    cashMarginAmt number(17,3) default 0;
    ltvFormula    varchar2(5);
    BEGIN

   BEGIN
        SELECT BUSINESS_TYPE
        INTO buss_type
        FROM Scbt_t_Deal_Register_Hdr_Mst
        WHERE BANK_GROUP_CODE = bankGroupCode
        AND CTY_CODE = ctyCode
        AND PROD_LIMIT_ID =  limitID
        AND CUST_ID = custId      -- COCOAPERF_12122012
        AND BUSINESS_TYPE = 'OD';
    EXCEPTION
         WHEN NO_DATA_FOUND THEN
         buss_type :='';
    END;


    BEGIN
         SELECT NVL(LOAN_TO_VALUE_PCT,0)
         INTO facilityLevelLTVPercentage
         FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND CUST_ID = custId
         and LIMIT_id = limitID
         AND STOP_LOSS_APPL_FLAG ='F';

    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;



          -- Start Ref:03-Oct-2012
          BEGIN
              SELECT LTV_FORMULA
                INTO ltvFormula
                FROM SCBT_R_PARTY_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE = ctyCode
                 AND PARTY_ID = custId;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                ltvFormula := 'LTV1';
          END;



            cashMarginAmt := SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID,limitCcy,bankGroupCode,ctyCode,'S',custId);  -- REF05122012
       -- End Ref:03-Oct-2012

       if(piFlag = 'N') then

       SELECT  TXN_REC_ID,
               NVL(OUTSTANDING, 0),
               TXN_CCY,
               CM_CCY,
               NVL(CASH_MARGIN, 0),
               STEP_STATUS_CODE,
               SOURCE,
               DEAL_STEP_ID,
               txn_step_code,
               CM_ADJ_AMT,
               CM_ADJ_AMT_FACTOR,
               CM_ORIGIN_AMT
               BULK COLLECT
          INTO txnRecIDList,
               txnCcyAmtList,
               txnCcyList,
               cashMarginCcyList,
               cashMarginCcyAmtList,
               step_code_list,
               sourceTypeList,
               txnDealStepIDList,
               txnStepCodeList,
               cashMarginAdjAmtList,
               cashMarginAdjFactorList,
               cashMarginOriginAmtList
          FROM (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                       --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11' -- COCOAFUNC_18122012
                       AND MST.prod_limit_id = limitID
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					             AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                UNION ALL    -- COCOAREF_08012013
                SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        MST.SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        MST.txn_step_code,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id = limitID
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
               );

        elsif (piFlag = 'A') then

                SELECT  TXN_REC_ID,
                 NVL(OUTSTANDING, 0),
                 TXN_CCY,
                 CM_CCY,
                 NVL(CASH_MARGIN, 0),
                 STEP_STATUS_CODE,
                 SOURCE,
                 DEAL_STEP_ID,
                 txn_step_code,
                 CM_ADJ_AMT,
                 CM_ADJ_AMT_FACTOR,
                 CM_ORIGIN_AMT
                 BULK COLLECT
            INTO txnRecIDList,
                 txnCcyAmtList,
                 txnCcyList,
                 cashMarginCcyList,
                 cashMarginCcyAmtList,
                 step_code_list,
                 sourceTypeList,
                 txnDealStepIDList,
                 txnStepCodeList,
                 cashMarginAdjAmtList,
                 cashMarginAdjFactorList,
                 cashMarginOriginAmtList FROM
                   (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND MST.prod_limit_id = limitID
                       --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11'   -- COCOAFUNC_18122012
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
                       AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11' -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                           AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE   --Performance ISsue 12Nov 2012
                           AND TH.CTY_CODE = DH.CTY_CODE
                           AND TH.DEAL_ID = DH.DEAL_ID
                           AND TH.CUST_ID = DH.CUST_ID                  --Performance ISsue 12Nov 2012
                           AND TH.PROD_LIMIT_ID = limitID  --REFPERF10DEC2012
                           AND TH.cust_id = custid)
                UNION ALL  --COCOAREF_08012013
                   SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id = limitID
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                        AND MST.TXN_REC_ID NOT IN
                        (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'
                           AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                           AND TH.CTY_CODE = DH.CTY_CODE
                           AND TH.DEAL_ID = DH.DEAL_ID
                           AND TH.CUST_ID = DH.CUST_ID
                           AND TH.PROD_LIMIT_ID = limitID
                           AND TH.cust_id = custid)
          UNION ALL
                   SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                         (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                         TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                         (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                         ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                         DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                         'H' AS SOURCE,
                         SHORTFALL_OFFSET_TYPE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID,
                         TH.txn_step_code
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.prod_limit_id = limitID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                           AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT') --REF10DEC2012
                           AND TH.bank_group_code = DH.bank_group_code --Performance ISsue 12Nov 2012
                           AND TH.cty_code = DH.cty_code --Performance ISsue 12Nov 2012
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid);

        elsif (piFlag = 'Y') then

                SELECT  TXN_REC_ID,
                 NVL(OUTSTANDING, 0),
                 TXN_CCY,
                 CM_CCY,
                 NVL(CASH_MARGIN, 0),
                 STEP_STATUS_CODE,
                 SOURCE,
                 DEAL_STEP_ID,
                 txn_step_code,
                 CM_ADJ_AMT,
                 CM_ADJ_AMT_FACTOR,
                 CM_ORIGIN_AMT
                 BULK COLLECT
            INTO txnRecIDList,
                 txnCcyAmtList,
                 txnCcyList,
                 cashMarginCcyList,
                 cashMarginCcyAmtList,
                 step_code_list,
                 sourceTypeList,
                 txnDealStepIDList,
                 txnStepCodeList,
                 cashMarginAdjAmtList,
                 cashMarginAdjFactorList,
                 cashMarginOriginAmtList FROM
                   (SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                         (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                         TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                         (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                         ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                         DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                         'H' AS SOURCE,
                         SHORTFALL_OFFSET_TYPE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID,
                         TH.txn_step_code
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE --Performance ISsue 12Nov 2012
                           AND TH.CTY_CODE = DH.CTY_CODE    --Performance ISsue 12Nov 2012
                           AND TH.prod_limit_id = limitID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT') --REF10DEC2012
                           -- AND NVL(TH.TXN_STATUS_CODE,'01') NOT IN ('08','11') --COCOAFUNC_18122012
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid);


        end if;



        totalOSAmt   := 0;
        totalGCVAmt  := 0;
        totalAdjAmt  := 0;
        totalCov := 0;
        facilityOSAmt:= 0;

        topupCcyAmt := SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitID,limitCcy,'','F');


        for i in 1..txnRecIDList.COUNT LOOP

            facilityOSAmt := facilityOSAmt +  NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                  ctyCode,
                                                                  txnCcyList(i),
                                                                  txnCcyAmtList(i),
                                                                  limitCcy,
                                                                  'Y'),
                                                                   0);

           totalGCVAmt := totalGCVAmt + Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         limitCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i),
                                                                         txnStepCodeList(i));


  /*
            totalAdjAmt := totalAdjAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                              ctyCode,
                                                              txnCcyList(i),
                                                              SCBF_GET_ADJ_AMT(cashMarginAdjFactorList(i),cashMarginAdjAmtList(i)),
                                                              limitCcy,
                                                              'N'),
                                                              0);            */

        end loop;


        gcvAmt := 0;
        gcvAmt := nvl(totalGCVAmt,0);


         if (piFlag = 'N') then
           totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitID,
                                                                                                    limitCcy,
                                                                                                    'N',
                                                                                                    'N');
       elsif (piFlag = 'Y') then
            totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitID,
                                                                                                    limitCcy,
                                                                                                    'Y',
                                                                                                    'N');
       elsif (piFlag = 'A') then
            totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitID,
                                                                                                    limitCcy,
                                                                                                    'Y',
                                                                                                    'N') +
                                                                      SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitID,
                                                                                                    limitCcy,
                                                                                                    'N',
                                                                                                    'N');
       end if;

       IF (buss_type = 'OD') THEN
              IF (facilityOSAmt < 0) THEN
                   facilityOSAmt := abs(facilityOSAmt);
               ELSE
                   facilityOSAmt := 0;
               END IF;
        END IF;

      totalOSAmt := totalOSAmt + facilityOSAmt;
      facilityOSAmt:= 0;



/*       totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);

       if ( totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/ totalCov)*100;
        elsif (totalOSAmt > 0 and (totalCov) = 0) then
             ltvPercentage := 999.999;
       else
             ltvPercentage := 0;
       end if;*/

     -- Start Ref:03-Oct-2012

      if(ltvFormula ='LTV2') then
          totalCov := nvl(totalOSAmt,0) - nvl(cashMarginAmt,0) - nvl(topupCcyAmt,0);
          if ( totalGCVAmt > 0) then
             ltvPercentage := (nvl(totalCov,0)/totalGCVAmt)*100;
          elsif (totalOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       elsif (ltvFormula ='LTV3') then
         totalCov := nvl(totalGCVAmt,0) + nvl(cashMarginAmt,0) + nvl(topupCcyAmt,0);
         if (totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
         elsif (totalOSAmt > 0 and (totalCov) = 0) then
             ltvPercentage := 999.999;
         else
             ltvPercentage := 0;
         end if;
       else
         totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);
          if ( totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
          elsif (totalOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       end if;
         if ltvFormula is null then
            ltvFormula := 'LTV1';
         else
            ltvFormula := ltvFormula;
         end if;

         G_LTV_FORMULA := ltvFormula;

         G_CMR_CCY_AMT  := cashMarginAmt;
         G_CMR_CCY_CODE  := limitCcy;

       -- End Ref:03-Oct-2012
/*        ltvPercentage  := SCBF_COCOA_ROUND_AMOUNT(bankGroupCode,
                                                   limitCcy,
                                                   ltvPercentage);
*/

      ltvPercentage := round(ltvPercentage,6);
      G_EXPOSURE_CCY_CODE:= limitCcy;
      G_EXPOSURE_CCY_AMT:=nvl(totalOSAmt,0);
      G_GCV_CCY_CODE :=limitCcy;
      G_GCV_CCY_AMT:=  nvl(totalGCVAmt,0);
      G_CASHTOPUP_CCY_CODE:=limitCcy;
      G_CASHTOPUP_CCY_AMT :=   nvl(topupCcyAmt,0);


     if(valueFlag = 'OS') then
          return nvl(totalOSAmt,0);
       elsif(valueFlag = 'GCV') then
          return nvl(gcvAmt,0);
       elsif(valueFlag = 'TGCV') then
        return nvl(totalGCVAmt,0);
       elsif(facilityLevelLTVPercentage > 0) then
          return nvl(ltvPercentage,0);
       else
          return 0;
     end if;

    END SCBF_GET_LIMIT_LEVEL_LTV;

    FUNCTION SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              custExpCcy    IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitIDInGroupType IS TABLE OF SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE INDEX BY PLS_INTEGER;
    TYPE FacilityGroupIDType IS TABLE OF SCBT_R_CUST_FACILITY_GRP.Facility_Grp_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;
    limitIdInGrp              SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
    groupID                   SCBT_R_CUST_FACILITY_GRP.Facility_Grp_Id%TYPE;
    facilityOSAmt            SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
    totalOSAmt               number(17,3);
    totalGCVAmt              number(17,3);
    totalAdjAmt              number(17,3);
    ltvPercentage            number(17,3);
    temptxnAmt            number(17,3);
    topupAppl     varchar2(1);
    topupTypeCode varchar2(1);
    topupCcyCode  varchar2(1);
    topupCcyAmt   number(17,3) default 0;
     buss_type     varchar2(10);
    limitIDsToProcess t_array;
    totalCov number(17,3) default 0;
    gcvAmt number(17,3) default 0;
    tempGcvAmt number(17,3) default 0;
    facilityLevelLTVPercentage number(17,3) default 0;
    cashMarginAmt number(17,3) default 0;
    ltvFormula    varchar2(5);
    BEGIN
        totalOSAmt   := 0;
        facilityOSAmt:= 0;
        totalGCVAmt  := 0;
        topupCcyAmt  := 0;
        temptxnAmt   := 0;
        BEGIN
             SELECT FACILITY_GRP_ID,PROD_LIMIT_IDS,NVL(LOAN_TO_VALUE_PCT,0)  -- COCOAFUNC_18122012
             INTO groupID,limitIdInGrp,facilityLevelLTVPercentage
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND CUST_ID = custId  -- COCOAPERF_12122012
             AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || limitID || ',', 1, 1 ) =( ',' || limitID || ',')
               --AND PROD_LIMIT_IDS LIKE '%' ||limitID ||'%'
             AND GROUP_TYPE = 'LTV';

       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                groupID := '';      -- COCOAFUNC_18122012
                NULL;
       END;

       -- COCOAPERF_18122012
/*         BEGIN

             SELECT FACILITY_GRP_ID
             INTO groupID
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || limitID || ',', 1, 1 ) =( ',' || limitID || ',')
               --AND PROD_LIMIT_IDS LIKE '%' ||limitID ||'%'
                AND GROUP_TYPE = 'LTV';

            SELECT NVL(LOAN_TO_VALUE_PCT,0)
               INTO facilityLevelLTVPercentage
               FROM SCBT_R_CUST_FACILITY_GRP
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId
               and FACILITY_GRP_ID = groupID
               AND GROUP_TYPE = 'LTV';

       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                groupID := '';
                NULL;
       END;
*/

          BEGIN
              SELECT LTV_FORMULA
                INTO ltvFormula
                FROM SCBT_R_PARTY_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE = ctyCode
                 AND PARTY_ID = custId;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                ltvFormula := 'LTV1';
          END;

      limitIDsToProcess := SCBF_GET_SPLIT_STRING_ON_DELIM(limitIdInGrp,',');
      totalCov := 0;

      for limitCount in 1..limitIDsToProcess.COUNT LOOP


      BEGIN
        SELECT BUSINESS_TYPE
        INTO buss_type
        FROM Scbt_t_Deal_Register_Hdr_Mst
        WHERE BANK_GROUP_CODE = bankGroupCode
        AND CTY_CODE = ctyCode
        AND CUST_ID = custId  -- COCOAPERF_12122012
        AND PROD_LIMIT_ID =  limitIDsToProcess(limitCount)
        AND BUSINESS_TYPE = 'OD';
      EXCEPTION
           WHEN NO_DATA_FOUND THEN
           buss_type :='';
      END;

      if(piFlag = 'N') then

       SELECT  TXN_REC_ID,
               NVL(OUTSTANDING, 0),
               TXN_CCY,
               CM_CCY,
               NVL(CASH_MARGIN, 0),
               STEP_STATUS_CODE,
               SOURCE,
               DEAL_STEP_ID,
               txn_step_code,
               CM_ADJ_AMT,
               CM_ADJ_AMT_FACTOR,
               CM_ORIGIN_AMT
               BULK COLLECT
          INTO txnRecIDList,
               txnCcyAmtList,
               txnCcyList,
               cashMarginCcyList,
               cashMarginCcyAmtList,
               step_code_list,
               sourceTypeList,
               txnDealStepIDList,
               txnStepCodeList,
               cashMarginAdjAmtList,
               cashMarginAdjFactorList,
               cashMarginOriginAmtList
          FROM (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND MST.prod_limit_id = limitIDsToProcess(limitCount)
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					             AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
            UNION ALL   -- COCOAREF_08012013
            SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        MST.SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        MST.txn_step_code
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND MST.prod_limit_id = limitIDsToProcess(limitCount)
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                      );

        elsif(piFlag = 'A') then

          SELECT  TXN_REC_ID,
               NVL(OUTSTANDING, 0),
               TXN_CCY,
               CM_CCY,
               NVL(CASH_MARGIN, 0),
               STEP_STATUS_CODE,
               SOURCE,
               DEAL_STEP_ID,
               txn_step_code,
               CM_ADJ_AMT,
               CM_ADJ_AMT_FACTOR,
               CM_ORIGIN_AMT
               BULK COLLECT
          INTO txnRecIDList,
               txnCcyAmtList,
               txnCcyList,
               cashMarginCcyList,
               cashMarginCcyAmtList,
               step_code_list,
               sourceTypeList,
               txnDealStepIDList,
               txnStepCodeList,
               cashMarginAdjAmtList,
               cashMarginAdjFactorList,
               cashMarginOriginAmtList
          FROM (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                      (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND MST.prod_limit_id = limitIDsToProcess(limitCount)
                       --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11'  -- COCOAFUNC_18122012
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					             AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE --Performance ISsue 12Nov 2012
                           AND TH.CTY_CODE = DH.CTY_CODE  --Performance ISsue 12Nov 2012
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND TH.prod_limit_id = limitIDsToProcess(limitCount)  -- COCOAPERF_12122012
                           AND TH.DEAL_ID = DH.DEAL_ID  -- COCOAPERF_12122012
                           AND TH.CUST_ID = DH.CUST_ID  -- COCOAPERF_12122012
                           AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT')  -- COCOAPERF_12122012 --AND TH.TXN_STEP_CODE != 'SETT'
                           --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND MST.cust_id = custid)
               UNION ALL  --COCOAREF_08012013
               SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                      (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id = limitIDsToProcess(limitCount)
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                           AND TH.CTY_CODE = DH.CTY_CODE
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND TH.prod_limit_id = limitIDsToProcess(limitCount)
                           AND TH.DEAL_ID = DH.DEAL_ID
                           AND TH.CUST_ID = DH.CUST_ID
                           AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT')
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND MST.cust_id = custid)
                UNION ALL
                SELECT TH.TXN_REC_ID,
                       TH.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                        (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                       TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                       TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                       DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                       'H' AS SOURCE,
                       SHORTFALL_OFFSET_TYPE,
                       DH.Deal_Step_Id AS DEAL_STEP_ID,
                       TH.txn_step_code
                  FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                WHERE TH.BANK_GROUP_CODE = bankGroupCode
                       AND TH.CTY_CODE = ctyCode
                       AND TH.prod_limit_id = limitIDsToProcess(limitCount)
                       AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE --Performance ISsue 12Nov 2012
                       AND TH.CTY_CODE = DH.CTY_CODE  --Performance ISsue 12Nov 2012
                       AND TH.CUST_ID=DH.CUST_ID
                       AND TH.DEAL_ID=DH.DEAL_ID
                       AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT')  -- COCOAPERF_12122012  --AND TH.TXN_STEP_CODE != 'SETT'
                       AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                       AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                       AND TH.cust_id = custid);

        elsif(piFlag = 'Y') then

        SELECT  TXN_REC_ID,
               NVL(OUTSTANDING, 0),
               TXN_CCY,
               CM_CCY,
               NVL(CASH_MARGIN, 0),
               STEP_STATUS_CODE,
               SOURCE,
               DEAL_STEP_ID,
               txn_step_code,
               CM_ADJ_AMT,
               CM_ADJ_AMT_FACTOR,
               CM_ORIGIN_AMT
               BULK COLLECT
          INTO txnRecIDList,
               txnCcyAmtList,
               txnCcyList,
               cashMarginCcyList,
               cashMarginCcyAmtList,
               step_code_list,
               sourceTypeList,
               txnDealStepIDList,
               txnStepCodeList,
               cashMarginAdjAmtList,
               cashMarginAdjFactorList,
               cashMarginOriginAmtList
          FROM (SELECT TH.TXN_REC_ID,
                       TH.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                       (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                       TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                       TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                       DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                       'H' AS SOURCE,
                       SHORTFALL_OFFSET_TYPE,
                       DH.Deal_Step_Id AS DEAL_STEP_ID,
                       TH.txn_step_code
                  FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                WHERE TH.BANK_GROUP_CODE = bankGroupCode
                       AND TH.CTY_CODE = ctyCode
                       AND TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE --Performance ISsue 12Nov 2012
                       AND TH.CTY_CODE = DH.CTY_CODE  --Performance ISsue 12Nov 2012
                       AND TH.prod_limit_id = limitIDsToProcess(limitCount)
                       AND TH.CUST_ID=DH.CUST_ID
                       AND TH.DEAL_ID=DH.DEAL_ID
                       AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT') -- COCOAPERF_12122012  --AND TH.TXN_STEP_CODE != 'SETT'
                       AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                       AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11')
                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                       AND TH.cust_id = custid);
        end if;

        facilityOSAmt:= 0;
        for i in 1..txnRecIDList.COUNT LOOP

          temptxnAmt := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        txnCcyList(i),
                                                        txnCcyAmtList(i),
                                                        custExpCcy,
                                                        'Y'),
                                                         0);

          facilityOSAmt := facilityOSAmt +  temptxnAmt;

          if txnDealStepIDList(i) is null or txnDealStepIDList(i) = '' then

           txnDealStepIDList(i) := 'UTIL';
           sourceTypeList(i) :='M';
          end if;
          totalGCVAmt := totalGCVAmt + Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         custExpCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i),
                                                                         txnStepCodeList(i));


            tempGcvAmt := tempGcvAmt + Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         custExpCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i),
                                                                         txnStepCodeList(i));
        end loop;

        IF (buss_type = 'OD') THEN
              IF (facilityOSAmt < 0) THEN
                   facilityOSAmt := abs(facilityOSAmt);
               ELSE
                   facilityOSAmt := 0;
               END IF;
        END IF;

        totalOSAmt := totalOSAmt + facilityOSAmt;
        facilityOSAmt:= 0;
        topupCcyAmt := NVL(topupCcyAmt,0) + NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDsToProcess(limitCount),custExpCcy,'','F'),0);

        gcvAmt := 0;
        gcvAmt := nvl(tempGcvAmt,0);


       if (piFlag = 'N') then
           totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitIDsToProcess(limitCount),
                                                                                                    custExpCcy,
                                                                                                    'N',
                                                                                                    'N');
       elsif (piFlag = 'Y') then
            totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitIDsToProcess(limitCount),
                                                                                                    custExpCcy,
                                                                                                    'Y',
                                                                                                    'N');
       elsif (piFlag = 'A') then
            totalGCVAmt := nvl(totalGCVAmt,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitIDsToProcess(limitCount),
                                                                                                    custExpCcy,
                                                                                                    'Y',
                                                                                                    'N') +
                                                                     SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitIDsToProcess(limitCount),
                                                                                                    custExpCcy,
                                                                                                    'N',
                                                                                                    'N');
       end if;

      END LOOP;


      cashMarginAmt := SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID,custExpCcy,bankGroupCode,ctyCode,'S',custId); -- REF05122012


/*      totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);

       if ( totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/ totalCov)*100;
       elsif (totalOSAmt > 0 and (totalCov) = 0) then
             ltvPercentage := 999.999;
       else
             ltvPercentage := 0;
       end if;*/


        if(ltvFormula ='LTV2') then
            totalCov := nvl(totalOSAmt,0) - nvl(cashMarginAmt,0) - nvl(topupCcyAmt,0);
            if ( totalGCVAmt > 0) then
               ltvPercentage := (nvl(totalCov,0)/totalGCVAmt)*100;
            elsif (totalOSAmt > 0 and (totalCov) = 0) then
              ltvPercentage := 999.999;
            else
               ltvPercentage := 0;
            end if;
         elsif (ltvFormula ='LTV3') then
           totalCov := nvl(totalGCVAmt,0) + nvl(cashMarginAmt,0) + nvl(topupCcyAmt,0);
           if (totalCov > 0) then
               ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
           elsif (totalOSAmt > 0 and (totalCov) = 0) then
               ltvPercentage := 999.999;
           else
               ltvPercentage := 0;
           end if;
         else
           totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);
            if ( totalCov > 0) then
               ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
            elsif (totalOSAmt > 0 and (totalCov) = 0) then
              ltvPercentage := 999.999;
            else
               ltvPercentage := 0;
            end if;
         end if;

 /*       ltvPercentage  := SCBF_COCOA_ROUND_AMOUNT(bankGroupCode,
                                                   custExpCcy,
                                                   ltvPercentage);*/


          ltvPercentage := round(ltvPercentage,6);

           if ltvFormula is null then
              ltvFormula := 'LTV1';
           else
              ltvFormula := ltvFormula;
           end if;

           G_LTV_FORMULA := ltvFormula;

           G_CMR_CCY_AMT  := cashMarginAmt;
           G_CMR_CCY_CODE  := custExpCcy;

      G_EXPOSURE_CCY_CODE:= custExpCcy;
      G_EXPOSURE_CCY_AMT:=nvl(totalOSAmt,0);
      G_GCV_CCY_CODE :=custExpCcy;
      G_GCV_CCY_AMT:=  nvl(totalGCVAmt,0);
      G_CASHTOPUP_CCY_CODE:=custExpCcy;
      G_CASHTOPUP_CCY_AMT :=   nvl(topupCcyAmt,0);

     if(valueFlag = 'OS') then
          return nvl(totalOSAmt,0);
     elsif(valueFlag = 'GCV') then
          return nvl(gcvAmt,0);
     elsif(valueFlag = 'TGCV') then
        return nvl(totalGCVAmt,0);
     elsif(valueFlag = 'TOP') then
          return nvl(topupCcyAmt,0);
     elsif(facilityLevelLTVPercentage > 0) then
          return nvl(ltvPercentage,0);
     else
          return 0;
     end if;

    END SCBF_GET_GROUP_LIMIT_LEVEL_LTV;

    FUNCTION SCBF_GET_CUST_LEVEL_LTV(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              valueFlag     IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE ProdLimitIDType IS TABLE OF Scbt_t_Txn_Mst.PROD_LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    ltvFormula                SCBT_R_PARTY_MST.LTV_FORMULA%TYPE;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;
    prodLimitList             ProdLimitIDType;
    facilityOSAmt            SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
    totalCMAmt               number(17,3);
    totalOSAmt               number(17,3);
    totalGCVAmt              number(17,3);
    totalAdjAmt              number(17,3);
    ltvPercentage            number(17,3);
    custExpCcy               varchar2(3);
    topupAppl                varchar2(1);
    topupTypeCode            varchar2(1);
    topupCcyCode             varchar2(1);
    topupCcyAmt              number(17,3);
    totalCov                 number(17,3);
    gcvAmt                   number(17,3);
    custLevelLTVPercentage   number(17,3);
    buss_type                varchar2(10);
    temptxnAmt               number(17,3);
    BEGIN


    BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;



    -- Customer Level Stop Loss Settings
    custLevelLTVPercentage := 0;

    BEGIN
         SELECT NVL(LOAN_TO_VALUE_PCT,0)
         INTO custLevelLTVPercentage
         FROM SCBT_R_PARTY_MST
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;


    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;

  -- Start Ref:02-Oct-2012
  BEGIN
      SELECT LTV_FORMULA
        INTO ltvFormula
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ltvFormula := 'LTV1';
    END;

  -- End Ref:02-Oct-2012


        if(piFlag = 'N') then

        SELECT  TXN_REC_ID,
               NVL(OUTSTANDING, 0),
               TXN_CCY,
               CM_CCY,
               NVL(CASH_MARGIN, 0),
               STEP_STATUS_CODE,
               SOURCE,
               DEAL_STEP_ID,
               txn_step_code,
               CM_ADJ_AMT,
               CM_ADJ_AMT_FACTOR,
               CM_ORIGIN_AMT,
               PROD_LIMIT_ID
               BULK COLLECT
          INTO txnRecIDList,
               txnCcyAmtList,
               txnCcyList,
               cashMarginCcyList,
               cashMarginCcyAmtList,
               step_code_list,
               sourceTypeList,
               txnDealStepIDList,
               txnStepCodeList,
               cashMarginAdjAmtList,
               cashMarginAdjFactorList,
               cashMarginOriginAmtList,
               prodLimitList
          FROM (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code,
                        PROD_LIMIT_ID
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                      --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11'   -- COCOAFUNC_18122012
                      AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					            AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0  -- COCOAFUNC_25022013
            UNION ALL    -- COCOAREF_08012013
                SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        MST.SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        MST.txn_step_code,
                        MST.PROD_LIMIT_ID
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)

               );

        elsif (piFlag = 'A') then

                SELECT  TXN_REC_ID,
                 NVL(OUTSTANDING, 0),
                 TXN_CCY,
                 CM_CCY,
                 NVL(CASH_MARGIN, 0),
                 STEP_STATUS_CODE,
                 SOURCE,
                 DEAL_STEP_ID,
                 txn_step_code,
                 CM_ADJ_AMT,
                 CM_ADJ_AMT_FACTOR,
                 CM_ORIGIN_AMT,
                 PROD_LIMIT_ID
                 BULK COLLECT
            INTO txnRecIDList,
                 txnCcyAmtList,
                 txnCcyList,
                 cashMarginCcyList,
                 cashMarginCcyAmtList,
                 step_code_list,
                 sourceTypeList,
                 txnDealStepIDList,
                 txnStepCodeList,
                 cashMarginAdjAmtList,
                 cashMarginAdjFactorList,
                 cashMarginOriginAmtList,
                 prodLimitList FROM
                   (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       --(NVL(MST.CASH_MARGIN_CCY_AMT,0) - NVL(MST.CM_CCY_RELEASE_AMT,0)) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code,
                        PROD_LIMIT_ID
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                       --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11' -- COCOAFUNC_18122012
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					             AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND TH.CUST_ID = DH.CUST_ID  -- COCOAPERF_12122012
                           AND TH.DEAL_ID = DH.DEAL_ID  -- COCOAPERF_12122012
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid)
              UNION ALL  --COCOAREF_08012013
              SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                        '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code,
                        PROD_LIMIT_ID
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                           AND TH.CTY_CODE=DH.CTY_CODE
                           AND TH.CUST_ID = DH.CUST_ID
                           AND TH.DEAL_ID = DH.DEAL_ID
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid)
                    UNION ALL
                   SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                         (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                         TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                         (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                         ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         --NVL(TH.CASH_MARGIN_CCY_AMT,0) - NVL(TH.CM_CCY_RELEASE_AMT,0) AS CASH_MARGIN,
                         TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                         DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                         'H' AS SOURCE,
                         SHORTFALL_OFFSET_TYPE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID,
                         TH.txn_step_code,
                         PROD_LIMIT_ID
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                           AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT') -- COCOAPERF_12122012 --AND TH.TXN_STEP_CODE != 'SETT'
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid);

        elsif (piFlag = 'Y') then

                SELECT  TXN_REC_ID,
                 NVL(OUTSTANDING, 0),
                 TXN_CCY,
                 CM_CCY,
                 NVL(CASH_MARGIN, 0),
                 STEP_STATUS_CODE,
                 SOURCE,
                 DEAL_STEP_ID,
                 txn_step_code,
                 CM_ADJ_AMT,
                 CM_ADJ_AMT_FACTOR,
                 CM_ORIGIN_AMT,
                 PROD_LIMIT_ID
                 BULK COLLECT
            INTO txnRecIDList,
                 txnCcyAmtList,
                 txnCcyList,
                 cashMarginCcyList,
                 cashMarginCcyAmtList,
                 step_code_list,
                 sourceTypeList,
                 txnDealStepIDList,
                 txnStepCodeList,
                 cashMarginAdjAmtList,
                 cashMarginAdjFactorList,
                 cashMarginOriginAmtList,
                 prodLimitList FROM
                   (SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                         (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                         TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                         (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                         ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                         ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                         --NVL(TH.CASH_MARGIN_CCY_AMT,0) - NVL(TH.CM_CCY_RELEASE_AMT,0) AS CASH_MARGIN,
                         TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                         DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                         'H' AS SOURCE,
                         SHORTFALL_OFFSET_TYPE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID,
                         TH.txn_step_code,
                         PROD_LIMIT_ID
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11')
                           AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT') -- COCOAPERF_12122012 --AND TH.TXN_STEP_CODE != 'SETT'
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid);
        end if;


       totalCMAmt:= 0;

/*        for i in 1..txnCcyAmtList.COUNT LOOP

            totalCMAmt := txnCcyAmtList(i);

        end loop;*/  -- CHanged by ANBU

        totalCMAmt := SCBF_C_CUST_LEVEL_CASH_MARGIN(custId,custExpCcy,bankGroupCode,ctyCode,'S');

        topupCcyAmt := SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId);

        facilityOSAmt:= 0;
        totalOSAmt   := 0;
        totalGCVAmt  := 0;
        totalAdjAmt  := 0;
        totalCov := 0;
        for i in 1..txnRecIDList.COUNT LOOP

          BEGIN
            SELECT BUSINESS_TYPE
            INTO buss_type
            FROM Scbt_t_Deal_Register_Hdr_Mst
            WHERE BANK_GROUP_CODE = bankGroupCode
            AND CTY_CODE = ctyCode
            AND PROD_LIMIT_ID =  prodLimitList(i)
            AND cust_id = custid -- COCOAPERFTUNE_001 Added cust_id to use index 19-JUN-2012
            AND BUSINESS_TYPE = 'OD';
          EXCEPTION
               WHEN NO_DATA_FOUND THEN
               buss_type :='';
          END;


          temptxnAmt := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                ctyCode,
                                                                txnCcyList(i),
                                                                txnCcyAmtList(i),
                                                                custExpCcy,
                                                                'Y'),
                                                                 0);

          facilityOSAmt := facilityOSAmt +  temptxnAmt;

           totalGCVAmt := totalGCVAmt + Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         custExpCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i),
                                                                         txnStepCodeList(i));

           DBMS_OUTPUT.PUT_LINE('totalGCVAmt...'||totalGCVAmt);



        end loop;

        IF (buss_type = 'OD') THEN
                      IF (facilityOSAmt < 0) THEN
                           facilityOSAmt := abs(facilityOSAmt);
                       ELSE
                           facilityOSAmt := 0;
                       END IF;
                END IF;

        totalOSAmt := totalOSAmt + facilityOSAmt;
        facilityOSAmt:= 0;
        gcvAmt := 0;
        gcvAmt := nvl(totalGCVAmt,0);

       if (piFlag = 'N') then
            totalGCVAmt := nvl(totalGCVAmt,0) + SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                   'N',
                                                                                                   'N');
       elsif (piFlag = 'Y') then
            totalGCVAmt := nvl(totalGCVAmt,0) + SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                   'Y',
                                                                                                   'N');
       elsif (piFlag = 'A') then
            totalGCVAmt := nvl(totalGCVAmt,0) + SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                   'Y',
                                                                                                   'N') +
                                                                     SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                   'N',
                                                                                                   'N');
       end if;


       -- Start Ref:02-Oct-2012

/*       totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);

       if ( totalCov > 0) then
            ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
       elsif (totalOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
       else
             ltvPercentage := 0;
       end if;*/


      if(ltvFormula ='LTV2') then
          totalCov := nvl(totalOSAmt,0) - nvl(totalCMAmt,0) - nvl(topupCcyAmt,0);
          if ( totalGCVAmt > 0) then
             ltvPercentage := (nvl(totalCov,0)/totalGCVAmt)*100;
          elsif (totalOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       elsif (ltvFormula ='LTV3') then
         totalCov := nvl(totalGCVAmt,0) + nvl(totalCMAmt,0) + nvl(topupCcyAmt,0);
         if (totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
         elsif (totalOSAmt > 0 and (totalCov) = 0) then
             ltvPercentage := 999.999;
         else
             ltvPercentage := 0;
         end if;
       else
         totalCov := nvl(topupCcyAmt,0) + nvl(totalGCVAmt,0);
          if ( totalCov > 0) then
             ltvPercentage := (nvl(totalOSAmt,0)/totalCov)*100;
          elsif (totalOSAmt > 0 and (totalCov) = 0) then
            ltvPercentage := 999.999;
          else
             ltvPercentage := 0;
          end if;
       end if;
         if ltvFormula is null then
            ltvFormula := 'LTV1';
         else
            ltvFormula := ltvFormula;
         end if;

         G_LTV_FORMULA := ltvFormula;
       -- End Ref:02-Oct-2012
/*        ltvPercentage  := SCBF_COCOA_ROUND_AMOUNT(bankGroupCode,
                                                   custExpCcy,
                                                   ltvPercentage);*/

    ltvPercentage := round(ltvPercentage,6);
    G_EXPOSURE_CCY_CODE:= custExpCcy;
    G_EXPOSURE_CCY_AMT:=nvl(totalOSAmt,0);

    G_GCV_CCY_CODE :=custExpCcy;

    G_GCV_CCY_AMT:=  nvl(totalGCVAmt,0);
    G_CASHTOPUP_CCY_CODE:=custExpCcy;
    G_CMR_CCY_AMT := totalCMAmt;
    G_CMR_CCY_CODE := custExpCcy;
    G_CASHTOPUP_CCY_AMT :=   nvl(topupCcyAmt,0);


     if(valueFlag = 'OS') then
        return nvl(totalOSAmt,0);
     elsif(valueFlag = 'GCV') then
        return nvl(gcvAmt,0);
     elsif(valueFlag = 'TGCV') then
        return nvl(totalGCVAmt,0);
     elsif(custLevelLTVPercentage > 0) then
        return nvl(ltvPercentage,0);
     else
        return 0;
     end if;

    END SCBF_GET_CUST_LEVEL_LTV;

  FUNCTION SCBF_GET_CUST_LEVEL_SHORTFALL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;

    totalOSAmt               number(17,3);
    totalNCVAmt              number(17,3);
    totalAdjAmt              number(17,3);
    custShortfallAmt         number(17,3);
    custExpCcy               varchar2(3);
    totalCMAmount            number(17,3);
    custLevelLTVPercentage   number(17,3);

    BEGIN


    BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;

      BEGIN
           SELECT LOAN_TO_VALUE_PCT INTO custLevelLTVPercentage
           FROM SCBT_R_PARTY_MST
           WHERE BANK_GROUP_CODE=bankGroupCode
           AND CTY_CODE = ctyCode
           AND PARTY_ID = custId;
      EXCEPTION
           WHEN NO_DATA_FOUND THEN
           NULL;
      END;

        if(custLevelLTVPercentage > 0) THEN
           custShortfallAmt := (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')/custLevelLTVPercentage)*100
                                                  - (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV') +
                                                  SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId));

        end if;

        if(custShortfallAmt > 0 ) then
           return abs(custShortfallAmt);
        else
           return 0;
        end if;



    END SCBF_GET_CUST_LEVEL_SHORTFALL;


  FUNCTION SCBF_GET_TXN_LEVEL_SHORTFALL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRefId      IN VARCHAR2,
                                              txnRecID      IN VARCHAR2,
                                              txnOSAmt      IN NUMBER,
                                              txnCcyCode    IN VARCHAR2,
                                              txnStepCode   IN VARCHAR2,
                                              piFlag        IN VARCHAR2,
                                              sourceType    IN VARCHAR2,
                                              dealStepId    IN VARCHAR2,
                                              adjFactor     IN VARCHAR2,
                                              adjAmount     IN NUMBER,
                                              custExpCcy    IN VARCHAR2,
                                              cmAmt         IN NUMBER,
                                              cmReleasedAmt IN NUMBER,
                                              cmNetAmt      IN NUMBER,
                                              prodLimitId   IN VARCHAR2) RETURN NUMBER IS
    totalNcvAmt number(17,3);
    txnShortfallAmt number(17,3);
    totalCMAmount number(17,3);
    facilityLevelLTVPercentage number(17,3);
    masterOrHistoryDealStepID varchar2(30);
    v_shortfall_offset SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
    ltvFormula    varchar2(5);
    cashMarginAmt number(17,3) default 0;


    BEGIN
      totalNcvAmt := 0;
      txnShortfallAmt := 0;
      totalCMAmount := 0;
      facilityLevelLTVPercentage := 0;

      BEGIN
           SELECT LOAN_TO_VALUE_PCT
               INTO facilityLevelLTVPercentage
             FROM SCBT_R_CUST_PRODUCT_LIMIT
             WHERE BANK_GROUP_CODE=bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND LIMIT_ID = prodLimitId
                AND STOP_LOSS_APPL_FLAG ='T';
      EXCEPTION
           WHEN NO_DATA_FOUND THEN
           NULL;
      END;

          -- Start Ref:03-Oct-2012
          BEGIN
              SELECT LTV_FORMULA
                INTO ltvFormula
                FROM SCBT_R_PARTY_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE = ctyCode
                 AND PARTY_ID = custId;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                ltvFormula := 'LTV1';
          END;

      if(dealStepId = 'N') then
        masterOrHistoryDealStepID := 'UTIL';
        BEGIN
          SELECT nvl(SHORTFALL_OFFSET_TYPE, '') into v_shortfall_offset
            from SCBT_T_TXN_MST
            WHERE BANK_GROUP_CODE=bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND PROD_LIMIT_ID = prodLimitId -- COCOAPERF_12122012
                AND TXN_REF_ID = txnRefId
                AND TXN_REC_ID = txnRecID;
        EXCEPTION
           WHEN OTHERS THEN
              v_shortfall_offset := '';
        END;
      else
        masterOrHistoryDealStepID := dealStepId;
        BEGIN
          SELECT nvl(SHORTFALL_OFFSET_TYPE, '') into v_shortfall_offset
            from SCBT_T_TXN_HST
            WHERE BANK_GROUP_CODE=bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND PROD_LIMIT_ID = prodLimitId -- COCOAPERF_12122012
                AND TXN_REF_ID = txnRefId
                AND TXN_REC_ID = txnRecID
                AND DEAL_STEP_ID = dealStepId;
        EXCEPTION
           WHEN OTHERS THEN
              v_shortfall_offset := '';
        END;
      end if;


     IF ( v_shortfall_offset in ('CBB', 'GBB') ) THEN
       txnShortfallAmt :=0;
     ELSIF (facilityLevelLTVPercentage > 0) THEN

       if(ltvFormula ='LTV2') then
       txnShortfallAmt := ((SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'OS')
                                              -- - SCBF_C_GET_TOT_CASH_MARGIN_CD(prodLimitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId)   -- REF05122012
                                              - SCBF_C_TXN_LEVEL_CASH_MARGIN(prodLimitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId,txnRefId,txnRecID)   --REF_CR03012013
                                              - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,txnCcyCode,'','',custExpCcy,'T')) /facilityLevelLTVPercentage)*100
                                              - SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'GCV');
       elsif(ltvFormula='LTV3') then
       txnShortfallAmt := (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'OS')/facilityLevelLTVPercentage)*100
                                              - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'GCV')
                                             -- + SCBF_C_GET_TOT_CASH_MARGIN_CD(prodLimitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId)   -- REF05122012
                                              + SCBF_C_TXN_LEVEL_CASH_MARGIN(prodLimitId,txnCcyCode,bankGroupCode,ctyCode,'S',custId,txnRefId,txnRecID)   -- REF_CR03012013
                                              + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,txnCcyCode,'','',custExpCcy,'T'));

       else
       txnShortfallAmt := (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'OS')/facilityLevelLTVPercentage)*100
                                              - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,
                                                txnOSAmt,txnCcyCode,txnStepCode,'N',sourceType,masterOrHistoryDealStepID,
                                                adjFactor,adjAmount,custExpCcy,cmAmt,0,0,'GCV')+
                                              SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefId,txnRecID,txnCcyCode,'','',custExpCcy,'T'));

       end if;

     END IF;

       if(txnShortfallAmt > 0 ) then
           return abs(nvl(txnShortfallAmt,0));
        else
           return 0;
        end if;



    END SCBF_GET_TXN_LEVEL_SHORTFALL;


   FUNCTION SCBF_GET_LIMIT_LEVEL_SHORTFALL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              limitCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;

    totalOSAmt               number(17,3);
    totalNcvAmt               number(17,3);
    custShortfallAmt         number(17,3);
    totalCMAmount            number(17,3);
    facilityLevelLTVPercentage number(17,3);
    ltvFormula    varchar2(5);

    BEGIN

       BEGIN
           SELECT LOAN_TO_VALUE_PCT INTO facilityLevelLTVPercentage
           FROM SCBT_R_CUST_PRODUCT_LIMIT
           WHERE BANK_GROUP_CODE=bankGroupCode
           AND CTY_CODE = ctyCode
           AND CUST_ID = custId
           and LIMIT_ID = limitID
           AND STOP_LOSS_APPL_FLAG ='F';
      EXCEPTION
           WHEN NO_DATA_FOUND THEN
           NULL;
      END;

          -- Start Ref:03-Oct-2012
          BEGIN
              SELECT LTV_FORMULA
                INTO ltvFormula
                FROM SCBT_R_PARTY_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE = ctyCode
                 AND PARTY_ID = custId;
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                ltvFormula := 'LTV1';
          END;


        if(facilityLevelLTVPercentage > 0) THEN

            if(ltvFormula='LTV2') then
                custShortfallAmt := ((SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','OS')
                                    - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID,limitCcy,bankGroupCode,ctyCode,'S',custId)   -- REF05122012
                                    - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitID,limitCcy,limitCcy,'F'))/facilityLevelLTVPercentage)*100
                                    - SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','TGCV');
            elsif(ltvFormula='LTV3') then
                custShortfallAmt := (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','OS')/facilityLevelLTVPercentage)*100
                                                - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','TGCV')
                                                + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID,limitCcy,bankGroupCode,ctyCode,'S',custId)   -- REF05122012
                                                + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitID,limitCcy,limitCcy,'F'));

            else
                custShortfallAmt := (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','OS')/facilityLevelLTVPercentage)*100
                                                - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,limitCcy,'A','TGCV')+
                                                SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitID,limitCcy,limitCcy,'F'));

            end if;

        end if;

        if(custShortfallAmt > 0 ) then
           return abs(nvl(custShortfallAmt,0));
        else
           return 0;
        end if;



    END SCBF_GET_LIMIT_LEVEL_SHORTFALL;

    FUNCTION SCBF_GET_GROUP_LEVEL_SHORTFALL(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              limitID       IN VARCHAR2,
                                              custExpCcy      IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS

    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitIDInGroupType IS TABLE OF SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE INDEX BY PLS_INTEGER;
    TYPE FacilityGroupIDType IS TABLE OF SCBT_R_CUST_FACILITY_GRP.Facility_Grp_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    txnRecIDList              TXNRecIDListType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;

    totalOSAmt               number(17,3);
    totalNcvAmt               number(17,3);
    custShortfallAmt         number(17,3);
    totalCMAmount            number(17,3);
    limitIdInGrp              SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
    groupID                   SCBT_R_CUST_FACILITY_GRP.Facility_Grp_Id%TYPE;
    limitIDsToProcess t_array;
    facilityLevelLTVPercentage number(17,3);

    BEGIN

    totalOSAmt               :=0;
    totalNcvAmt              :=0;
    custShortfallAmt         :=0;
    totalCMAmount            :=0;
      BEGIN
           SELECT LOAN_TO_VALUE_PCT INTO facilityLevelLTVPercentage
           FROM SCBT_R_CUST_FACILITY_GRP
           WHERE BANK_GROUP_CODE=bankGroupCode
           AND CTY_CODE = ctyCode
           AND CUST_ID = custId
           --and PROD_LIMIT_IDS LIKE '%' ||limitID ||'%'
           AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || limitID || ',', 1, 1 ) =( ',' || limitID || ',')
            AND GROUP_TYPE = 'LTV';
      EXCEPTION
           WHEN NO_DATA_FOUND THEN
           NULL;
      END;

      if(facilityLevelLTVPercentage > 0) then
         custShortfallAmt :=  (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,custExpCcy,'A','OS')/facilityLevelLTVPercentage)*100
                                            - (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,custExpCcy,'A','TGCV')+
                                            SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitID,custExpCcy,'A','TOP'));
      end if;

        if(custShortfallAmt > 0 ) then
           return abs(nvl(custShortfallAmt,0));
        else
           return 0;
        end if;



    END SCBF_GET_GROUP_LEVEL_SHORTFALL;

   FUNCTION SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode IN VARCHAR2,
                                       ctyCode       IN VARCHAR2,
                                       custId        IN VARCHAR2,
                                       custExpCcy    IN VARCHAR2,
                                       txnRecID      IN VARCHAR2,
                                       txnCcyCode    IN VARCHAR2,
                                       dealStepId    IN VARCHAR2,
                                       sourceType    IN VARCHAR2,
                                       stepCode      IN VARCHAR2) RETURN NUMBER IS
    totalNCV   NUMBER;
    TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
    TYPE ColleteralPCTType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.coverage_pct%TYPE INDEX BY PLS_INTEGER;
    gcvCcyCode                VARCHAR2(3) DEFAULT 0;
    gcvCcyAmt                 NUMBER(17, 3) DEFAULT 0;
    totalGcvAmt               NUMBER(17, 3) DEFAULT 0;
    tempGcvAmt               NUMBER(17, 3) DEFAULT 0;
    collateralIDList          CollateralIDType;
    collateralPCTList         ColleteralPCTType;
    BEGIN


          IF (sourceType = 'M') THEN
            BEGIN

            IF(dealStepId = 'UTIL') then

                SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                    INTO collateralIDList,collateralPCTList
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                   WHERE bank_group_code = bankGroupCode
                   AND cty_code = ctycode
                   AND CUST_ID = custId --REFPERF10DEC2012
                   AND txn_rec_id = txnRecID;

            else

              SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                INTO collateralIDList,collateralPCTList
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code = bankGroupCode
               AND cty_code = ctycode
               AND CUST_ID = custId --REFPERF10DEC2012
               AND txn_rec_id = txnRecID
               AND txn_rec_id not in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = bankGroupCode
                                      AND H1.cty_code = ctycode
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      --AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H2.CUST_ID=DH.CUST_ID -- COCOAPERF_12122012
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') <> '08'
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID
                                      AND DH.CUST_ID = custId --REFPERF10DEC2012
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      --AND NVL(H1.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                      AND H1.txn_step_code <> 'CANC');

              end if;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;

         ELSIF (sourceType = 'H') THEN
            BEGIN

            IF(stepCode = 'AMD') THEN
                  SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                    INTO collateralIDList,collateralPCTList
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                    WHERE bank_group_code = bankGroupCode
                    --and cty_code = cty_code -- COCOAPERF_12122012
                    AND CTY_CODE = ctyCode   -- COCOAPERF_12122012
                    AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D';

            ELSE
                SELECT collateral_id,coverage_pct BULK COLLECT
                    INTO collateralIDList,collateralPCTList FROM (
                SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                   WHERE bank_group_code = bankGroupCode
                   --and cty_code = cty_code -- COCOAPERF_12122012
                   AND CTY_CODE = ctyCode   -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID
                    AND CUST_ID = custId --REFPERF10DEC2012
                    AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                   UNION
                   SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                   WHERE bank_group_code = bankGroupCode
                    AND CUST_ID = custId --REFPERF10DEC2012
                   AND CTY_CODE = ctyCode   -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID
                   AND (collateral_id,txn_rec_id) NOT IN(
                           SELECT collateral_id,txn_rec_id
                            FROM Scbt_t_Txn_Cr_Linkage_hst
                            WHERE bank_group_code = bankGroupCode
                            --and cty_code = cty_code  -- COCOAPERF_12122012
                            AND CTY_CODE = ctyCode   -- COCOAPERF_12122012
                             AND CUST_ID = custId --REFPERF10DEC2012
                             AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                   ));


            END IF;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
          END IF;

          IF (collateralIDList.COUNT > 0) THEN
          FOR k IN 1 .. collateralIDList.COUNT LOOP

              IF (sourceType = 'M') THEN
                BEGIN
                  SELECT total_gcv_ccy_code, NVL(total_gcv_ccy_amt,0)
                    INTO gcvCcyCode, gcvCcyAmt
                    FROM scbt_t_collateral_register_mst
                   WHERE bank_group_code = bankGroupCode -- COCOAPERFTUNE_001 Added bank group code to use index 19-JUN-2012
                   AND CUST_ID = custId --REFPERF10DEC2012
                   --and cty_code = cty_code -- COCOAPERFTUNE_001 Added bank cty code to use index 19-JUN-2012
                   and cty_code = ctyCode   -- COCOAPERF_12122012
                   and collateral_id = collateralIDList(k);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              ELSIF (sourceType = 'H') THEN
                BEGIN
                  SELECT total_gcv_ccy_code,NVL( total_gcv_ccy_amt,0)
                    INTO gcvCcyCode, gcvCcyAmt
                    FROM scbt_t_collateral_register_hst
                   WHERE bank_group_code = bankGroupCode -- COCOAPERFTUNE_001 Added bank group code to use index 19-JUN-2012
                   --and cty_code = cty_code -- COCOAPERFTUNE_001 Added bank cty code to use index 19-JUN-2012
                   and cty_code = ctyCode   -- COCOAPERF_12122012
                   AND CUST_ID = custId   --REFPERF10DEC2012
                   and collateral_id = collateralIDList(k) AND deal_step_id = dealStepId;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              END IF;




          tempGcvAmt := ((NVL(collateralPCTList(k),0))/100) * NVL(gcvCcyAmt,0);
          totalGcvAmt := totalGcvAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                  ctyCode,
                                                                  gcvCcyCode,
                                                                  tempGcvAmt,
                                                                  custExpCcy,
                                                                  'Y'),
                                                                   0);

          END LOOP;
          END IF;

        RETURN ( totalGcvAmt);

    END SCBF_C_GET_GCV_BY_TXN_REC_ID;

  FUNCTION SCBF_C_GET_CMV_BY_TXN_REC_ID(bankGroupCode IN VARCHAR2,
                                       ctyCode       IN VARCHAR2,
                                       custId        IN VARCHAR2,
                                       custExpCcy    IN VARCHAR2,
                                       txnRecID      IN VARCHAR2,
                                       txnCcyCode    IN VARCHAR2,
                                       dealStepId    IN VARCHAR2,
                                       sourceType    IN VARCHAR2,
                                       stepCode      IN VARCHAR2) RETURN NUMBER IS
    totalNCV   NUMBER;
    TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
    TYPE ColleteralPCTType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.coverage_pct%TYPE INDEX BY PLS_INTEGER;
    cmvCcyCode                VARCHAR2(3) DEFAULT 0;
    cmvCcyAmt                 NUMBER(17, 3) DEFAULT 0;
    totalCmvAmt               NUMBER(17, 3) DEFAULT 0;
    tempCmvAmt               NUMBER(17, 3) DEFAULT 0;
    collateralIDList          CollateralIDType;
    collateralPCTList         ColleteralPCTType;
    BEGIN


          IF (sourceType = 'M') THEN
            BEGIN

            IF(dealStepId = 'UTIL') then

                SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                    INTO collateralIDList,collateralPCTList
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                   WHERE bank_group_code = bankGroupCode
                   AND cty_code = ctycode
                   AND CUST_ID = custId     -- COCOAPERF_12122012
                   AND txn_rec_id = txnRecID;

            else

              SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                INTO collateralIDList,collateralPCTList
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code = bankGroupCode
               AND cty_code = ctycode
               AND CUST_ID = custId --REFPERF10DEC2012
               AND txn_rec_id = txnRecID
               AND txn_rec_id not in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = bankGroupCode
                                      AND H1.cty_code = ctycode
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      --AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H2.CUST_ID=DH.CUST_ID -- COCOAPERF_12122012
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') <> '08'
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID
                                      AND DH.CUST_ID = custId --REFPERF10DEC2012
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      --AND NVL(H1.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                      AND H1.txn_step_code <> 'CANC');

              end if;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;

         ELSIF (sourceType = 'H') THEN
            BEGIN

            IF(stepCode = 'AMD') THEN
                  SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                    INTO collateralIDList,collateralPCTList
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                    WHERE bank_group_code = bankGroupCode
                    and cty_code = ctyCode   -- COCOAPERF_12122012
                    --and cty_code = cty_code -- COCOAPERF_12122012
                    AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D';

            ELSE
                SELECT collateral_id,coverage_pct BULK COLLECT
                    INTO collateralIDList,collateralPCTList FROM (
                SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                   WHERE bank_group_code = bankGroupCode
                   --and cty_code = cty_code -- COCOAPERF_12122012
                   and cty_code = ctyCode   -- COCOAPERF_12122012
                   AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                   UNION
                   SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                   WHERE bank_group_code = bankGroupCode
                   --and cty_code = cty_code -- COCOAPERF_12122012
                   and cty_code = ctyCode   -- COCOAPERF_12122012
                   AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND txn_rec_id = txnRecID
                   AND (collateral_id,txn_rec_id) NOT IN(
                           SELECT collateral_id,txn_rec_id
                            FROM Scbt_t_Txn_Cr_Linkage_hst
                            WHERE bank_group_code = bankGroupCode
                            --and cty_code = cty_code -- COCOAPERF_12122012
                            and cty_code = ctyCode   -- COCOAPERF_12122012
                            AND CUST_ID = custId     -- COCOAPERF_12122012
                             AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                   ));


            END IF;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
          END IF;

          IF (collateralIDList.COUNT > 0) THEN
          FOR k IN 1 .. collateralIDList.COUNT LOOP

              IF (sourceType = 'M') THEN
                BEGIN
                   SELECT total_cmv_ccy_code, NVL(total_cmv_ccy_amt,0)
                    INTO cmvCcyCode, cmvCcyAmt
                    FROM scbt_t_collateral_register_mst
                   WHERE collateral_id = collateralIDList(k)
                   AND BANK_GROUP_CODE= bankGroupCode
                   AND CTY_CODE = ctyCode
                   AND CUST_ID = custId;     -- COCOAPERF_12122012
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              ELSIF (sourceType = 'H') THEN
                BEGIN
                   SELECT total_cmv_ccy_code, NVL(total_cmv_ccy_amt,0)
                    INTO cmvCcyCode, cmvCcyAmt
                    FROM scbt_t_collateral_register_hst
                   WHERE collateral_id = collateralIDList(k)
                   AND BANK_GROUP_CODE= bankGroupCode
                   AND CTY_CODE = ctyCode
                   AND CUST_ID = custId     -- COCOAPERF_12122012
                   AND deal_step_id = dealStepId;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    NULL;
                END;
              END IF;




          tempCmvAmt := ((NVL(collateralPCTList(k),0))/100) * NVL(cmvCcyAmt,0);
          totalCmvAmt := totalCmvAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                  ctyCode,
                                                                  cmvCcyCode,
                                                                  tempCmvAmt,
                                                                  custExpCcy,
                                                                  'Y'),
                                                                   0);

          END LOOP;
          END IF;

        RETURN ( totalCmvAmt);

    END SCBF_C_GET_CMV_BY_TXN_REC_ID;


    FUNCTION SCBF_C_GET_NCV_FOR_DEALS(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              dealID        IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRecID      IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCcyList IS TABLE OF SCBT_T_TXN_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
     TYPE TXNDealStepList IS TABLE OF SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnCcyList            TXBCcyList;
    l_dealStepId           TXNDealStepList;
    l_collateralID         CollateralIDList;
    l_collCovAmt         CollCovAmtList;
    l_collCovCcy         CollCovCcyList;
    totalNCV               NUMBER;
    piTotalNCV             NUMBER;
    collateralNCVAmount    NUMBER;
    collateralNCVAmountCCy VARCHAR2(3);
    custExpCcy             VARCHAR2(3);
  BEGIN

    totalNCV := 0;
    piTotalNCV := 0;

     BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;


    -- Select the list of TXN Reference IDs for a given Limit ID

    -- For normal NCV Calculation
    IF (piFlag =  'N' OR piFlag = 'A' ) THEN
          SELECT TXN_REC_ID,TXN_CCY_CODE BULK COLLECT
            INTO l_txnIDList,l_txnCcyList
            FROM SCBT_T_TXN_MST
           WHERE BANK_GROUP_CODE = bankGroupCode
           AND CTY_CODE = ctyCode
           AND cust_id = custId
           AND deal_id = dealID
           AND txn_rec_id = txnRecID;

          FOR i IN 1 .. l_txnIDList.COUNT LOOP




              totalNCV := totalNCV + Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custID,
                                                                         custExpCcy,
                                                                         l_txnIDList(i),
                                                                         l_txnCcyList(i),
                                                                         '',
                                                                         'M',
                                                                         '');




          END LOOP;
    END IF;

    -- FOr pending increase NCV Calculation

    IF (piFlag =  'Y' OR piFlag = 'A' ) THEN

       SELECT TH.TXN_REC_ID,TH.DEAL_STEP_ID BULK COLLECT
              INTO l_txnIDList,l_dealStepId
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.DEAL_ID = DH.DEAL_ID   -- COCOAPERF_12122012
                   AND TH.CUST_ID = DH.CUST_ID   -- COCOAPERF_12122012
                   AND TH.TXN_REC_ID = txnRecID  -- COCOAPERF_12122012
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND TH.cust_id = custId
                   AND TH.deal_id = dealID;

        FOR i IN 1 .. l_txnIDList.COUNT LOOP


              piTotalNCV := piTotalNCV + Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custID,
                                                                         custExpCcy,
                                                                         l_txnIDList(i),
                                                                         l_txnCcyList(i),
                                                                         l_dealStepId(i),
                                                                         'H',
                                                                         '');


          END LOOP;

    END IF;

    IF(piFlag = 'Y') THEN
      RETURN (piTotalNCV);
    ELSIF (piFlag = 'N') THEN
      RETURN (totalNCV);
    ELSIF (piFlag = 'A') THEN
      RETURN (totalNCV + piTotalNCV);
    END IF;
  END SCBF_C_GET_NCV_FOR_DEALS;


  FUNCTION SCBF_C_GET_CM_FOR_DEALS(bankGroupCode IN VARCHAR2,
                                              ctyCode       IN VARCHAR2,
                                              dealID        IN VARCHAR2,
                                              custId        IN VARCHAR2,
                                              txnRecID      IN VARCHAR2,
                                              piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnIDPIList          TXBRefIDList;
    l_cashMarginAmt        TXBCashMarginAmtList;
    l_cashMarginPIAmt      TXBCashMarginAmtList;
    l_cashMarginCcy        TXBCashMarginCcyList;
    l_cashMarginPICcy      TXBCashMarginCcyList;
    totalCashMargin        SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPICashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
   BEGIN

          -- Master Cash Margins
       IF (piFlag = 'N') THEN
          SELECT TXN_REF_ID,CASH_MARGIN_CCY_CODE,NVL(CASH_MARGIN_CCY_AMT,0) BULK COLLECT
            INTO l_txnIDList,l_cashMarginCcy,l_cashMarginAmt
            FROM SCBT_T_TXN_MST
           WHERE BANK_GROUP_CODE = bankGroupCode
           AND CTY_CODE = ctyCode
           AND cust_id = custId
           AND deal_id = dealID
           AND txn_rec_id = txnRecID;
          --Initialize to zero on 09-APR-2011
          totalCashMargin :=0;
          FOR i IN 1 .. l_txnIDList.COUNT LOOP

           totalCashMargin := totalCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginCcy(i),
                                                        l_cashMarginAmt(i),
                                                        Scbf_Get_Exp_Ccy(bankGroupCode,ctyCode,custId),
                                                        'Y');

          END LOOP;
        END IF;

        IF (piFlag = 'Y') THEN
        -- PI Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,NVL(TH.CASH_MARGIN_CCY_AMT,0) BULK COLLECT
              INTO l_txnIDPIList,l_cashMarginPICcy,l_cashMarginPIAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = DH.CUST_ID      -- COCOAPERF_12122012
                   AND TH.DEAL_ID = DH.DEAL_ID      -- COCOAPERF_12122012
                   AND TH.TXN_REC_ID = txnRecID     -- COCOAPERF_12122012
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND TH.cust_id = custId
                   AND TH.deal_id = dealID;
              --Initialize to zero on 09-APR-2011
              totalPICashMargin :=0;
              FOR i IN 1 .. l_txnIDPIList.COUNT LOOP

                  totalPICashMargin := totalPICashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPICcy(i),
                                                        l_cashMarginPIAmt(i),
                                                        Scbf_Get_Exp_Ccy(bankGroupCode,ctyCode,custId),
                                                        'Y');

               END LOOP;
           END IF;

           IF (piFlag = 'Y') THEN
               RETURN totalPICashMargin;
           ELSIF (piFlag = 'N') THEN
                 RETURN totalCashMargin;
           ELSE
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           END IF;

   END SCBF_C_GET_CM_FOR_DEALS;

  FUNCTION SCBF_C_GET_TOT_CASH_MARGIN(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnIDPIList          TXBRefIDList;
    l_txnIDPDList          TXBRefIDList;
    l_cashMarginAmt        TXBCashMarginAmtList;
    l_cashMarginPIAmt      TXBCashMarginAmtList;
    l_cashMarginPDAmt      TXBCashMarginAmtList;
    l_cashMarginCcy        TXBCashMarginCcyList;
    l_cashMarginPICcy      TXBCashMarginCcyList;
    l_cashMarginPDCcy      TXBCashMarginCcyList;
    totalCashMargin        SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPICashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPDCashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;

  BEGIN

        -- Master Cash Margins
       IF (piFlag = 'N' or piFlag = 'S') THEN
          SELECT TXN_REF_ID,CASH_MARGIN_CCY_CODE,
          --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
          (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
          ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
          ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
          BULK COLLECT
            INTO l_txnIDList,l_cashMarginCcy,l_cashMarginAmt
            FROM SCBT_T_TXN_MST TM
           WHERE TM.BANK_GROUP_CODE = bankGroupCode
           AND TM.CTY_CODE = ctyCode
           AND TM.PROD_LIMIT_ID = limitID
               AND (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
          ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
          ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0
           AND NOT EXISTS(SELECT TXN_REC_ID FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
           AND TH.CTY_CODE = DH.CTY_CODE AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
           --AND DH.STEP_STATUS_CODE <> '03'
           AND DH.STEP_STATUS_CODE IN ( '02','10','14') -- Changed for CMR issue
                       AND TH.BANK_GROUP_CODE = bankGroupCode --COCOAPERFTUNE_003
                       AND TH.CTY_CODE = ctyCode
                       AND TH.DEAL_ID = DH.DEAL_ID       -- COCOAPERF_12122012
                       AND TH.CUST_ID = DH.CUST_ID       -- COCOAPERF_12122012
                       --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                       AND TH.PROD_LIMIT_ID = limitID
                       AND TH.TXN_REC_ID = TM.TXN_REC_ID);
          --Initialize to zero on 09-APR-2011
          totalCashMargin := 0;
          FOR i IN 1 .. l_txnIDList.COUNT LOOP

           totalCashMargin := totalCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginCcy(i),
                                                        l_cashMarginAmt(i),
                                                        limitCcyCode,
                                                        'Y');

          END LOOP;
        END IF;

        IF (piFlag = 'Y' OR piFlag = 'A' or piFlag = 'S') THEN
        -- PI Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,
            --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
              BULK COLLECT
              INTO l_txnIDPIList,l_cashMarginPICcy,l_cashMarginPIAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.DEAL_ID = DH.DEAL_ID       -- COCOAPERF_12122012
                   AND TH.CUST_ID = DH.CUST_ID       -- COCOAPERF_12122012
                   --AND (TH.TXN_STEP_CODE != 'SETT' AND TH.TXN_STEP_CODE != 'CANC') -- COCOAPERF_17122012
                   AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT', 'CANC') -- COCOAPERF_17122012
                   AND (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                   ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
                   ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND TH.PROD_LIMIT_ID = limitID;
     --Initialize to zero on 09-APR-2011
              totalPICashMargin := 0;
              FOR i IN 1 .. l_txnIDPIList.COUNT LOOP

                  totalPICashMargin := totalPICashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPICcy(i),
                                                        l_cashMarginPIAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;


        IF (piFlag = 'D') THEN
        -- PD Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,(NVL(CM_CCY_RELEASE_AMT,0))  BULK COLLECT
              INTO l_txnIDPDList,l_cashMarginPDCcy,l_cashMarginPDAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.DEAL_ID = DH.DEAL_ID       -- COCOAPERF_12122012
                   AND TH.CUST_ID = DH.CUST_ID       -- COCOAPERF_12122012
                   --AND (TH.TXN_STEP_CODE = 'SETT' OR TH.TXN_STEP_CODE = 'CANC') -- COCOAPERF_17122012
                   AND TH.TXN_STEP_CODE IN ('SETT','DETT','CANC')  -- COCOAPERF_17122012
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11')
                   AND TH.PROD_LIMIT_ID = limitID;
     --Initialize to zero on 09-APR-2011
              totalPDCashMargin := 0;
              FOR i IN 1 .. l_txnIDPDList.COUNT LOOP

                  totalPDCashMargin := totalPDCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPDCcy(i),
                                                        l_cashMarginPDAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;

           IF (piFlag = 'Y') THEN
               RETURN totalPICashMargin;
           ELSIF (piFlag = 'D') THEN
                 RETURN totalPDCashMargin;
           ELSIF (piFlag = 'N') THEN
                 RETURN totalCashMargin;
           ELSIF (piFlag = 'S') THEN
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           ELSE
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           END IF;

  END SCBF_C_GET_TOT_CASH_MARGIN;

FUNCTION SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2,
                                  custId        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnIDPIList          TXBRefIDList;
    l_txnIDPDList          TXBRefIDList;
    l_cashMarginAmt        TXBCashMarginAmtList;
    l_cashMarginPIAmt      TXBCashMarginAmtList;
    l_cashMarginPDAmt      TXBCashMarginAmtList;
    l_cashMarginCcy        TXBCashMarginCcyList;
    l_cashMarginPICcy      TXBCashMarginCcyList;
    l_cashMarginPDCcy      TXBCashMarginCcyList;
    totalCashMargin        SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPICashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPDCashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;

  BEGIN

        -- Master Cash Margins
       IF (piFlag = 'N' or piFlag = 'S') THEN
          SELECT TXN_REF_ID,CASH_MARGIN_CCY_CODE,
             --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
           BULK COLLECT
            INTO l_txnIDList,l_cashMarginCcy,l_cashMarginAmt
            FROM SCBT_T_TXN_MST TM
           WHERE TM.BANK_GROUP_CODE = bankGroupCode
           AND TM.CTY_CODE = ctyCode
           AND TM.PROD_LIMIT_ID = limitID
           AND TM.CUST_ID = custId
           	AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- Start COCOAPERF_18122012
					  AND ((TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) > 0
            OR (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0) -- End COCOAPERF_18122012
           AND NOT EXISTS  ( SELECT TXN_REC_ID
                             FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                             AND TH.CUST_ID = DH.CUST_ID
                             AND TH.DEAL_ID = DH.DEAL_ID
                             AND TH.CTY_CODE = DH.CTY_CODE
                             AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                             AND DH.STEP_STATUS_CODE IN ( '02','10','14') -- Changed for CMR issue
                             --AND TH.BANK_GROUP_CODE = TM.BANK_GROUP_CODE  -- Commented on 21-MAY-2012 for perf issue
                             AND TH.BANK_GROUP_CODE = bankGroupCode
                             --AND TH.CTY_CODE = TM.CTY_CODE -- Commented on 21-MAY-2012 for perf issue
                             AND TH.CTY_CODE = ctyCode
                             --AND TH.PROD_LIMIT_ID = limitID -- COCOAPERF_12122012 -- COCOAFIX_13022013
                             --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                             AND TH.CUST_ID = custId -- Added on 21-MAY-2012 for perf issue
                             AND TH.TXN_REC_ID = TM.TXN_REC_ID);

          --Initialize to zero on 09-APR-2011
          totalCashMargin := 0;
          FOR i IN 1 .. l_txnIDList.COUNT LOOP

           totalCashMargin := totalCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginCcy(i),
                                                        l_cashMarginAmt(i),
                                                        limitCcyCode,
                                                        'Y');

          END LOOP;
        END IF;

        IF (piFlag = 'Y' OR piFlag = 'A' or piFlag = 'S') THEN
        -- PI Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,
              --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
            BULK COLLECT
              INTO l_txnIDPIList,l_cashMarginPICcy,l_cashMarginPIAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   --AND (TH.TXN_STEP_CODE != 'SETT' AND TH.TXN_STEP_CODE != 'CANC') -- COCOAPERF_12122012
                   AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT','CANC')  -- COCOAPERF_12122012
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOAISSSUE_26APR2013
                   AND TH.PROD_LIMIT_ID = limitID;
     --Initialize to zero on 09-APR-2011
              totalPICashMargin := 0;
              FOR i IN 1 .. l_txnIDPIList.COUNT LOOP

                  totalPICashMargin := totalPICashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPICcy(i),
                                                        l_cashMarginPIAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;


        IF (piFlag = 'D') THEN
        -- PD Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,(NVL(CM_CCY_RELEASE_AMT,0))  BULK COLLECT
              INTO l_txnIDPDList,l_cashMarginPDCcy,l_cashMarginPDAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   --AND (TH.TXN_STEP_CODE = 'SETT' OR TH.TXN_STEP_CODE = 'CANC') -- COCOAPERF_12122012
                   AND TH.TXN_STEP_CODE  IN ('DSETT','SETT','CANC')  -- COCOAPERF_12122012
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11')
                   AND TH.PROD_LIMIT_ID = limitID;
     --Initialize to zero on 09-APR-2011
              totalPDCashMargin := 0;
              FOR i IN 1 .. l_txnIDPDList.COUNT LOOP

                  totalPDCashMargin := totalPDCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPDCcy(i),
                                                        l_cashMarginPDAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;

           IF (piFlag = 'Y') THEN
               RETURN totalPICashMargin;
           ELSIF (piFlag = 'D') THEN
                 RETURN totalPDCashMargin;
           ELSIF (piFlag = 'N') THEN
                 RETURN totalCashMargin;
           ELSIF (piFlag = 'S') THEN
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           ELSE
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           END IF;

  END SCBF_C_GET_TOT_CASH_MARGIN_CD;

--  REF_CR03012013

FUNCTION SCBF_C_TXN_LEVEL_CASH_MARGIN(limitID   VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2,
                                  custId        IN VARCHAR2,
                                  txnRefId      IN VARCHAR2,
                                  txnRecId      IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnIDPIList          TXBRefIDList;
    l_txnIDPDList          TXBRefIDList;
    l_cashMarginAmt        TXBCashMarginAmtList;
    l_cashMarginPIAmt      TXBCashMarginAmtList;
    l_cashMarginPDAmt      TXBCashMarginAmtList;
    l_cashMarginCcy        TXBCashMarginCcyList;
    l_cashMarginPICcy      TXBCashMarginCcyList;
    l_cashMarginPDCcy      TXBCashMarginCcyList;
    totalCashMargin        SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPICashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPDCashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;

  BEGIN

        -- Master Cash Margins
       IF (piFlag = 'N' or piFlag = 'S') THEN
          SELECT TXN_REF_ID,CASH_MARGIN_CCY_CODE,
            (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
            ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
             ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
           BULK COLLECT
            INTO l_txnIDList,l_cashMarginCcy,l_cashMarginAmt
            FROM SCBT_T_TXN_MST TM
           WHERE TM.BANK_GROUP_CODE = bankGroupCode
                 AND TM.CTY_CODE = ctyCode
                 AND TM.PROD_LIMIT_ID = limitID
                 AND TM.CUST_ID = custId
                 AND TM.TXN_REF_ID = txnRefId
                 AND TM.Txn_Rec_Id = txnRecId
           	     AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- Start COCOAPERF_18122012
					       AND ((TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) > 0
                     OR (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                     ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
                     ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0) -- End COCOAPERF_18122012
                 AND NOT EXISTS  ( SELECT TXN_REC_ID
                             FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                             AND TH.CUST_ID = DH.CUST_ID
                             AND TH.DEAL_ID = DH.DEAL_ID
                             AND TH.CTY_CODE = DH.CTY_CODE
                             AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                             AND DH.STEP_STATUS_CODE IN ( '02','10','14')
                             AND TH.TXN_REC_ID = TM.TXN_REC_ID
                             AND TH.BANK_GROUP_CODE = bankGroupCode
                             AND TH.CTY_CODE = ctyCode
                             AND TH.PROD_LIMIT_ID = limitID
                             AND TH.CUST_ID = custId
                             AND TH.TXN_REF_ID = txnRefId
                             AND TH.TXN_REC_ID = txnRecId);

          --Initialize to zero on 09-APR-2011
          totalCashMargin := 0;
          FOR i IN 1 .. l_txnIDList.COUNT LOOP

           totalCashMargin := totalCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginCcy(i),
                                                        l_cashMarginAmt(i),
                                                        limitCcyCode,
                                                        'Y');

          END LOOP;
        END IF;

        IF (piFlag = 'Y' OR piFlag = 'A' or piFlag = 'S') THEN
        -- PI Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
            BULK COLLECT
              INTO l_txnIDPIList,l_cashMarginPICcy,l_cashMarginPIAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.CUST_ID = DH.CUST_ID
                   AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT','CANC')
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOAISSSUE_26APR2013
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.TXN_REF_ID = txnRefId
                   AND TH.TXN_REC_ID = txnRecId
                   AND TH.PROD_LIMIT_ID = limitID;
     --Initialize to zero on 09-APR-2011
              totalPICashMargin := 0;
              FOR i IN 1 .. l_txnIDPIList.COUNT LOOP

                  totalPICashMargin := totalPICashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPICcy(i),
                                                        l_cashMarginPIAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;


        IF (piFlag = 'D') THEN
        -- PD Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,(NVL(CM_CCY_RELEASE_AMT,0))  BULK COLLECT
              INTO l_txnIDPDList,l_cashMarginPDCcy,l_cashMarginPDAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.CUST_ID = DH.CUST_ID
                   AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND TH.TXN_STEP_CODE  IN ('DSETT','SETT','CANC')
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11')
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.TXN_REF_ID = txnRefId
                   AND TH.TXN_REC_ID = txnRecId
                   AND TH.PROD_LIMIT_ID = limitID;

              totalPDCashMargin := 0;
              FOR i IN 1 .. l_txnIDPDList.COUNT LOOP

                  totalPDCashMargin := totalPDCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPDCcy(i),
                                                        l_cashMarginPDAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;

           IF (piFlag = 'Y') THEN
               RETURN totalPICashMargin;
           ELSIF (piFlag = 'D') THEN
                 RETURN totalPDCashMargin;
           ELSIF (piFlag = 'N') THEN
                 RETURN totalCashMargin;
           ELSIF (piFlag = 'S') THEN
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           ELSE
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           END IF;

  END SCBF_C_TXN_LEVEL_CASH_MARGIN;


-- Added for calculating Customer level cash margin

FUNCTION SCBF_C_CUST_LEVEL_CASH_MARGIN(custId   VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    l_txnIDList            TXBRefIDList;
    l_txnIDPIList          TXBRefIDList;
    l_txnIDPDList          TXBRefIDList;
    l_cashMarginAmt        TXBCashMarginAmtList;
    l_cashMarginPIAmt      TXBCashMarginAmtList;
    l_cashMarginPDAmt      TXBCashMarginAmtList;
    l_cashMarginCcy        TXBCashMarginCcyList;
    l_cashMarginPICcy      TXBCashMarginCcyList;
    l_cashMarginPDCcy      TXBCashMarginCcyList;
    totalCashMargin        SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPICashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;
    totalPDCashMargin      SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE;

  BEGIN

        -- Master Cash Margins
       IF (piFlag = 'N' or piFlag = 'S') THEN
          SELECT TXN_REF_ID,CASH_MARGIN_CCY_CODE,
             --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
           BULK COLLECT
            INTO l_txnIDList,l_cashMarginCcy,l_cashMarginAmt
            FROM SCBT_T_TXN_MST TM
           WHERE TM.BANK_GROUP_CODE = bankGroupCode
           AND TM.CTY_CODE = ctyCode
           AND TM.CUST_ID = custId
           	AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- Start COCOAPERF_18122012
					  AND ((TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) > 0
            OR (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0) -- End COCOAPERF_18122012
           AND NOT EXISTS  ( SELECT TXN_REC_ID
                             FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                             AND TH.CUST_ID = DH.CUST_ID
                             AND TH.DEAL_ID = DH.DEAL_ID
                             AND TH.CTY_CODE = DH.CTY_CODE
                             AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                             AND DH.STEP_STATUS_CODE IN ( '02','10','14') -- Changed for CMR issue
                             --AND TH.BANK_GROUP_CODE = TM.BANK_GROUP_CODE  -- Commented on 21-MAY-2012 for perf issue
                             AND TH.BANK_GROUP_CODE = bankGroupCode
                             --AND TH.CTY_CODE = TM.CTY_CODE -- Commented on 21-MAY-2012 for perf issue
                             AND TH.CTY_CODE = ctyCode
                             AND TH.CUST_ID = custId -- Added on 21-MAY-2012 for perf issue
                             --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                             AND TH.TXN_REC_ID = TM.TXN_REC_ID);

          --Initialize to zero on 09-APR-2011
          totalCashMargin := 0;
          FOR i IN 1 .. l_txnIDList.COUNT LOOP

           totalCashMargin := totalCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginCcy(i),
                                                        l_cashMarginAmt(i),
                                                        limitCcyCode,
                                                        'Y');

          END LOOP;
        END IF;

        IF (piFlag = 'Y' OR piFlag = 'A' or piFlag = 'S') THEN
        -- PI Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,
              --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
            BULK COLLECT
              INTO l_txnIDPIList,l_cashMarginPICcy,l_cashMarginPIAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   --AND (TH.TXN_STEP_CODE != 'SETT' AND TH.TXN_STEP_CODE != 'CANC') -- COCOAPERF_12122012
                   AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT','CANC')  -- COCOAPERF_12122012
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOAISSSUE_26APR2013
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11';
     --Initialize to zero on 09-APR-2011
              totalPICashMargin := 0;
              FOR i IN 1 .. l_txnIDPIList.COUNT LOOP

                  totalPICashMargin := totalPICashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPICcy(i),
                                                        l_cashMarginPIAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;


        IF (piFlag = 'D') THEN
        -- PD Cash Margins

            SELECT TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,(NVL(CM_CCY_RELEASE_AMT,0))  BULK COLLECT
              INTO l_txnIDPDList,l_cashMarginPDCcy,l_cashMarginPDAmt
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.CUST_ID = custId
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   --AND (TH.TXN_STEP_CODE = 'SETT' OR TH.TXN_STEP_CODE = 'CANC') -- COCOAPERF_12122012
                   AND TH.TXN_STEP_CODE IN ('SETT','DSETT','CANC')-- COCOAPERF_12122012
                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'02') NOT IN ('08','11');
     --Initialize to zero on 09-APR-2011
              totalPDCashMargin := 0;
              FOR i IN 1 .. l_txnIDPDList.COUNT LOOP

                  totalPDCashMargin := totalPDCashMargin + Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_cashMarginPDCcy(i),
                                                        l_cashMarginPDAmt(i),
                                                        limitCcyCode,
                                                        'Y');

               END LOOP;
           END IF;

           IF (piFlag = 'Y') THEN
               RETURN totalPICashMargin;
           ELSIF (piFlag = 'D') THEN
                 RETURN totalPDCashMargin;
           ELSIF (piFlag = 'N') THEN
                 RETURN totalCashMargin;
           ELSIF (piFlag = 'S') THEN
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           ELSE
              RETURN( NVL(totalCashMargin,0) + NVL(totalPICashMargin,0));
           END IF;

  END SCBF_C_CUST_LEVEL_CASH_MARGIN;



   FUNCTION SCBF_C_GET_OVERALL_CM_AMT(prodCode VARCHAR2,
                                  custId        VARCHAR2,
                                  limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    l_limitIDList            LimitIDList;
    l_limitCcyList           LimitCcyList;
    totalPICashMargin               NUMBER;
    BEGIN

       -- dbms_output.put_line('prodCode : ' || prodCode);


         IF (prodCode  = '*') THEN

         totalPICashMargin := 0;

          SELECT limit_id,limit_ccy_code BULK COLLECT INTO l_limitIDList,l_limitCcyList
            FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE bank_group_code = bankGroupCode
            AND cty_code = ctyCode
            AND limit_cat_code ='O'
            AND cust_id = custId;

         FOR i IN 1..l_limitIDList.COUNT LOOP
                         totalPICashMargin := totalPICashMargin +  Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_limitCcyList(i),
                                                        SCBF_C_CM_WRAPPER_CD(l_limitIDList(i),l_limitCcyList(i),bankGroupCode,ctyCode,piFlag,custId),
                                                        limitCcyCode,
                                                        'Y');
         END LOOP;

         RETURN  totalPICashMargin;

         ELSE
           RETURN  SCBF_C_CM_WRAPPER_CD(limitID,limitCcyCode,bankGroupCode,ctyCode,piFlag,custId);
         END IF;

    END SCBF_C_GET_OVERALL_CM_AMT;

   FUNCTION SCBF_C_GET_OVERALL_NCV_AMT(prodCode VARCHAR2,
                                  custId        VARCHAR2,
                                  limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    l_limitIDList            LimitIDList;
    l_limitCcyList           LimitCcyList;
    totalNCV               NUMBER;
    BEGIN

        --dbms_output.put_line('prodCode : ' || prodCode);

         --pkg_custid     := custid; -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

         IF (prodCode  = '*') THEN

         totalNCV := 0;

          SELECT limit_id,limit_ccy_code BULK COLLECT INTO l_limitIDList,l_limitCcyList
            FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE bank_group_code = bankGroupCode
            AND cty_code = ctyCode
            AND limit_cat_code ='O'
            AND cust_id = custId;

         FOR i IN 1..l_limitIDList.COUNT LOOP
              totalNCV := totalNCV +  Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                        ctyCode,
                                                        l_limitCcyList(i),
                                                        SCBF_C_NCV_WRAPPER(l_limitIDList(i),l_limitCcyList(i),bankGroupCode,ctyCode,piFlag),
                                                        limitCcyCode,
                                                        'Y');
         END LOOP;

         RETURN  totalNCV;

         ELSE
           RETURN  SCBF_C_NCV_WRAPPER(limitID,limitCcyCode,bankGroupCode,ctyCode,piFlag);
         END IF;

    END SCBF_C_GET_OVERALL_NCV_AMT;

    FUNCTION SCBF_C_NCV_WRAPPER(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    childLimitIDList LimitIDList;
    childLimitIDCcyList LimitCcyList;
    p_lmid LimitIDList;
    p_limitCcy LimitCcyList;
    l_lmcnt NUMBER;
    l_lmid  SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;
    totalNCV NUMBER;
    exitCode NUMBER;
    BEGIN

          totalNCV := 0;

        BEGIN

                SELECT     limit_id, limit_ccy_code
                BULK COLLECT INTO p_lmid, p_limitccy
                FROM    scbt_r_cust_product_limit
                WHERE   bank_group_code = bankgroupcode
                AND     cty_code = ctycode
                --AND     cust_id = pkg_custid    -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                START WITH limit_id = limitid
                CONNECT BY PRIOR ext_limit_id = inner_to_id
                AND     bank_group_code = bankgroupcode -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                AND     cty_code = ctycode;      -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
               -- AND     cust_id = pkg_custid;   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

        EXCEPTION
                WHEN OTHERS THEN
                        NULL;
        END;

          FOR i in 1..p_lmid.COUNT LOOP
             totalNCV := totalNCV + NVL(SCBF_C_GET_TOT_NCV_AMT(p_lmid(i),p_limitCcy(i),bankGroupCode,ctyCode,piFlag),0);
          END LOOP;



           return totalNCV;

    END SCBF_C_NCV_WRAPPER;


    -- Added for Facility Level NCV Calculation in customer dash baord
    FUNCTION SCBF_C_FACILITY_LEVEL_NCV_AMT(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    childLimitIDList LimitIDList;
    childLimitIDCcyList LimitCcyList;
    p_lmid LimitIDList;
    p_limitCcy LimitCcyList;
    l_lmcnt NUMBER;
    l_lmid  SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;
    totalNCV NUMBER;
    exitCode NUMBER;
    BEGIN

          totalNCV := 0;

        BEGIN

                SELECT     limit_id, limit_ccy_code
                BULK COLLECT INTO p_lmid, p_limitccy
                FROM    scbt_r_cust_product_limit
                WHERE   bank_group_code = bankgroupcode
                AND     cty_code = ctycode
                AND     limit_id = limitid;

        EXCEPTION
                WHEN OTHERS THEN
                        NULL;
        END;

          FOR i in 1..p_lmid.COUNT LOOP
             totalNCV := totalNCV + NVL(SCBF_C_GET_TOT_NCV_AMT(p_lmid(i),p_limitCcy(i),bankGroupCode,ctyCode,piFlag),0);
          END LOOP;



           return totalNCV;

    END SCBF_C_FACILITY_LEVEL_NCV_AMT;


     FUNCTION SCBF_C_CM_WRAPPER(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    childLimitIDList LimitIDList;
    childLimitIDCcyList LimitCcyList;
    p_lmid LimitIDList;
    p_limitCcy LimitCcyList;
    l_lmcnt NUMBER;
    l_lmid  SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;
    totalCM NUMBER;
    exitCode NUMBER;
    custid      SCBT_R_PARTY_MST.PARTY_ID%TYPE; -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
    BEGIN

  --      IF pkg_custid IS NULL       -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
  --      THEN                        -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

               BEGIN
                        SELECT cust_id
                        INTO custid
                        FROM scbt_r_cust_product_limit
                        WHERE bank_group_code = bankgroupcode
                        AND cty_code = ctycode
                        AND limit_id = limitid;
                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                        --custExpCcy := 'SGD';            -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                        custid := NULL; -- something seriously wrong... if the code comes here...
                END;
 --       ELSE                                        -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
   --             custid := pkg_custid;               -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
  --      END IF;                                     -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012


          totalCM := 0;

          if piFlag = 'S' then
                 return SCBF_C_GET_TOT_CASH_MARGIN(limitID,limitCcyCode,bankGroupCode,ctyCode,piFlag);
          end if;

          BEGIN
                SELECT limit_id,limit_ccy_code
                BULK COLLECT INTO p_lmid,p_limitCcy
                FROM SCBT_R_CUST_PRODUCT_LIMIT
                WHERE bank_group_code = bankGroupCode
                and cty_code = ctyCode
                --AND     cust_id = pkg_custid   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                START WITH limit_id= limitID
                CONNECT BY PRIOR ext_limit_id = inner_to_id
                AND     bank_group_code = bankgroupcode -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                AND     cty_code = ctycode;      -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                --AND     cust_id = pkg_custid;   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

          EXCEPTION
                WHEN OTHERS THEN
                     NULL;
          END;

          FOR i in 1..p_lmid.COUNT LOOP
              totalCM := totalCM + SCBF_C_GET_TOT_CASH_MARGIN(p_lmid(i),p_limitCcy(i),bankGroupCode,ctyCode,piFlag);
          END LOOP;

           return totalCM;

    END SCBF_C_CM_WRAPPER;


   FUNCTION SCBF_C_CM_WRAPPER_CD(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2,
                                  custId IN VARCHAR2 ) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    childLimitIDList LimitIDList;
    childLimitIDCcyList LimitCcyList;
    p_lmid LimitIDList;
    p_limitCcy LimitCcyList;
    l_lmcnt NUMBER;
    l_lmid  SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;
    totalCM NUMBER;
    exitCode NUMBER;
    BEGIN

          totalCM := 0;

          if piFlag = 'S' then
                 return SCBF_C_GET_TOT_CASH_MARGIN_CD(limitID,limitCcyCode,bankGroupCode,ctyCode,piFlag,custId);
          end if;

          BEGIN
                SELECT limit_id,limit_ccy_code
                BULK COLLECT INTO p_lmid,p_limitCcy
                FROM SCBT_R_CUST_PRODUCT_LIMIT
                WHERE bank_group_code = bankGroupCode
                and cty_code = ctyCode
                and cust_id = custId
                START WITH limit_id= limitID
                CONNECT BY PRIOR ext_limit_id = inner_to_id
                AND     bank_group_code = bankgroupcode -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                AND     cty_code = ctycode      -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                AND     cust_id = custid;   -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

          EXCEPTION
                WHEN OTHERS THEN
                     NULL;
          END;

          FOR i in 1..p_lmid.COUNT LOOP
              totalCM := totalCM + SCBF_C_GET_TOT_CASH_MARGIN_CD(p_lmid(i),p_limitCcy(i),bankGroupCode,ctyCode,piFlag,custId);
          END LOOP;

           return totalCM;

    END SCBF_C_CM_WRAPPER_CD;

   FUNCTION SCBF_C_GET_TOT_NCV_AMT(limitID       VARCHAR2,
                                  limitCcyCode  VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE TXBRefIDList IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXBCcyList IS TABLE OF SCBT_T_TXN_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeList IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNDealStepList IS TABLE OF SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovAmtList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CollCovCcyList IS TABLE OF SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    l_txnIDList            TXBRefIDList;
      l_txnCcyList            TXBCcyList;
      l_txnStepCode           TXNStepCodeList;
    l_dealStepId           TXNDealStepList;
    l_collateralID         CollateralIDList;
    l_collCovAmt         CollCovAmtList;
    l_collCovCcy         CollCovCcyList;
    totalNCV               NUMBER;
    collateralNCVAmount    NUMBER;
    collateralNCVAmountCCy VARCHAR2(3);
    custId                 VARCHAR2(16);
    custExpCcy             VARCHAR2(3);
    sourceTypeList         strArray;

  BEGIN

    totalNCV := 0;

    -- Select the list of TXN Reference IDs for a given Limit ID
   -- IF pkg_custid IS NULL THEN         -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                          -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
            BEGIN
                 SELECT cust_id
                   INTO custid
                   FROM scbt_r_cust_product_limit
                  WHERE bank_group_code = bankgroupcode
                    AND cty_code = ctycode
                    AND limit_id = limitID;
             EXCEPTION
              WHEN NO_DATA_FOUND THEN
                --custExpCcy := 'SGD';            -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
                custid := NULL; -- something seriously wrong... if the code comes here...
            END;
   -- ELSE                                        -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
   ----         custid := pkg_custid;               -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
   -- END IF;                                     -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012

    BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;

    -- For normal NCV Calculation
    IF (piFlag =  'N') THEN
        SELECT txn_rec_id, txn_ccy_code, txn_step_code
        BULK COLLECT INTO l_txnidlist, l_txnccylist, l_txnstepcode
        FROM (SELECT txn_rec_id, txn_ccy_code, txn_step_code
          FROM scbt_t_txn_mst
         WHERE bank_group_code = bankgroupcode
           AND cty_code = ctycode
           AND cust_id =  custid      -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
           AND NVL (shortfall_offset_type, ' ') <> 'CL'
           --AND NVL(TXN_STATUS_CODE,'02') <> '11' -- COCOAFUNC_18122012
           AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					 AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
           AND prod_limit_id = limitID
      UNION ALL -- COCOAREF_08012013
        SELECT MST.txn_rec_id, MST.txn_ccy_code, MST.txn_step_code
          FROM scbt_t_txn_mst MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
        WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
           AND MST.CTY_CODE=TCL.CTY_CODE
           AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
           AND CR.CTY_CODE=TCL.CTY_CODE
           AND MST.CUST_ID=TCL.CUST_ID
           AND MST.DEAL_ID=TCL.DEAL_ID
           AND CR.CUST_ID=TCL.CUST_ID
           AND CR.DEAL_ID=TCL.DEAL_ID
           AND MST.TXN_REC_ID=TCL.TXN_REC_ID
           AND MST.TXN_REF_ID=TCL.TXN_REF_ID
           AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
           AND MST.bank_group_code = bankgroupcode
           AND MST.cty_code = ctycode
           AND MST.cust_id =  custid
           AND MST.prod_limit_id = limitID
           AND NVL (MST.shortfall_offset_type, ' ') <> 'CL'
           AND NVL(MST.LIMIT_TRANSFER,'N') <> 'Y'
           AND NVL(MST.TXN_STATUS_CODE,'01') NOT IN ('05','11')
					 AND (MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)) = 0
           AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
           );

          FOR i IN 1 .. l_txnIDList.COUNT LOOP



              totalNCV := totalNCV + Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         limitCcyCode,
                                                                         l_txnIDList(i),
                                                                         l_txnCcyList(i),
                                                                         '',
                                                                         'M',
                                                                         l_txnStepCode(i));




          END LOOP;

/* Added for OD unlinked NCV Amount */
          totalNCV := nvl(totalNCV,0) +  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_NCV(bankGroupCode,
                                                                                                   ctyCode,
                                                                                                   custId,
                                                                                                    limitID,
                                                                                                    limitCcyCode,
                                                                                                    'N');


    END IF;

    -- FOr pending increase NCV Calculation

    IF (piFlag =  'Y') THEN

        SELECT th.txn_rec_id, txn_ccy_code, th.deal_step_id
        BULK COLLECT INTO l_txnidlist, l_txnccylist, l_dealstepid
          FROM scbt_t_txn_hst th, scbt_t_deal_hist dh
         WHERE th.bank_group_code = dh.bank_group_code
           AND th.cty_code = dh.cty_code
           AND th.cust_id = dh.cust_id     --REF10122012
           AND th.deal_id = dh.deal_id     --REF10122012
           AND th.bank_group_code = bankgroupcode
           AND th.cty_code = ctycode
           AND th.deal_step_id = dh.deal_step_id
           AND NVL (th.shortfall_offset_type, ' ') <> 'CL'
           AND dh.step_status_code IN ('02', '10', '14')
           AND NVL(th.TXN_STATUS_CODE,'01')<>'11'
           AND NVL(th.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
           AND th.cust_id =  custid       -- COCOAPERFTUNE_002 Performance Tuning Changes by Kannan on 22-Jun-2012
           AND th.prod_limit_id = limitID;

        FOR i IN 1 .. l_txnIDList.COUNT LOOP


              totalNCV := totalNCV +  Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custID,
                                                                         limitCcyCode,
                                                                         l_txnIDList(i),
                                                                         l_txnCcyList(i),
                                                                         l_dealStepId(i),
                                                                         'H',
                                                                         '');


          END LOOP;

    END IF;

-- For shortfall NCV Calculation
    IF (piFlag =  'A') THEN

-- Removed unneccesry select query suggested by Krishna

    SELECT  DISTINCT TXN_REC_ID,
                 TXN_CCY,
                 SOURCE,
                 DEAL_STEP_ID
                 BULK COLLECT
            INTO l_txnIDList,
                 l_txnCcyList,
                 sourceTypeList,
                 l_dealStepId
                 FROM
                   (SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = bankGroupCode
                       AND MST.CTY_CODE = ctyCode
                       AND MST.cust_id = custid
                       AND MST.prod_limit_id = limitID
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					             AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND TH.DEAL_ID=DH.DEAL_ID       --COCOAPERFTUNE_003
                           AND TH.CUST_ID=DH.CUST_ID       --COCOAPERFTUNE_003
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.PROD_LIMIT_ID = limitID   -- COCOAPERF_12122012
                           AND TH.cust_id = custid)
           UNION ALL --COCOAREF_08012013
           SELECT MST.TXN_REC_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                        'M' AS SOURCE,
                        '' AS DEAL_STEP_ID
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = bankGroupCode
                        AND MST.CTY_CODE = ctyCode
                        AND MST.cust_id = custid
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        AND MST.prod_limit_id = limitID
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                       AND MST.TXN_REC_ID NOT IN
                       (SELECT TXN_REC_ID
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                         WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                           AND TH.CTY_CODE=DH.CTY_CODE
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'
                           AND TH.PROD_LIMIT_ID = limitID
                           AND TH.cust_id = custid)
              UNION ALL
                   SELECT TH.TXN_REC_ID,
                         TH.TXN_CCY_CODE AS TXN_CCY,
                         'H' AS SOURCE,
                         DH.Deal_Step_Id AS DEAL_STEP_ID
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.prod_limit_id = limitID
                           AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                           AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT')  -- COCOAPERF_12122012 --AND TH.TXN_STEP_CODE != 'SETT'
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           --AND NVL(TH.TXN_STATUS_CODE,'02') <> '11'  -- COCOAFUNC_18122012
                           AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid);



        FOR i IN 1 .. l_txnIDList.COUNT LOOP
              totalNCV := totalNCV
                      +  Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(
                                bankGroupCode
                                , ctyCode
                                , custID
                                , limitCcyCode
                                , l_txnIDList(i)  -- l_txnIDList(i)
                                , l_txnCcyList(i)  -- l_txnCcyList(i)
                                , l_dealStepId(i)  -- l_dealStepId(i)
                                , sourceTypeList(i)
                                , '');
       END LOOP;



        /*

       SELECT TH.TXN_REC_ID,TXN_CCY_CODE,TH.DEAL_STEP_ID BULK COLLECT
              INTO l_txnIDList,l_txnCcyList,l_dealStepId
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = bankGroupCode
                   AND TH.CTY_CODE = ctyCode
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   AND NVL(TH.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   --AND NVL(TH.TXN_STATUS_CODE,'02') <> '08'
                   AND TH.PROD_LIMIT_ID = limitID;

        FOR i IN 1 .. l_txnIDList.COUNT LOOP


              totalNCV := totalNCV +  Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custID,
                                                                         limitCcyCode,
                                                                         l_txnIDList(i),
                                                                         l_txnCcyList(i),
                                                                         l_dealStepId(i),
                                                                         'H',
                                                                         '');


          END LOOP;
         */
     END IF;

    RETURN(totalNCV);
  END SCBF_C_GET_TOT_NCV_AMT;

  /* Start- Added for Group facility***********/
  FUNCTION SCBF_C_GET_GROUP_NCV_AMT(groupId VARCHAR2,
                                  custId        VARCHAR2,
                                  bankGroupCode IN VARCHAR2,
                                  ctyCode       IN VARCHAR2,
                                  piFlag        IN VARCHAR2) RETURN NUMBER IS
    TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE LimitProdList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_product_Code%TYPE INDEX BY PLS_INTEGER;
    l_limitIDList            LimitIDList;
    l_limitCcyList           LimitCcyList;
    l_limitProdList	     LimitProdList;
    totalNCV               NUMBER;
    -- COCOACR_14022013
    TYPE TxnCcyListType IS TABLE OF Scbt_t_Txn_Mst.txn_ccy_code%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnStepListType IS TABLE OF Scbt_t_Txn_Mst.txn_step_code%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    txnCcyList                  TxnCcyListType;
    txnStepList                 TxnStepListType;
    txnRecIDList                TxnRecIDListType;

    BEGIN


         totalNCV := 0;

          SELECT LIMIT_PRODUCT_CODE,LIMIT_ID,LIMIT_CCY_CODE
          	BULK COLLECT INTO l_limitProdList,l_limitIDList,l_limitCcyList
          	from SCBT_R_CUST_PRODUCT_LIMIT
          	where cust_id=custId and stop_loss_appl_flag='G' and bank_group_code=bankGroupCode and cty_code=ctyCode
		and exists (SELECT prod_limit_ids FROM SCBT_R_CUST_FACILITY_GRP
		where cust_id=custId
    and bank_group_code=bankGroupCode and cty_code=ctyCode  -- COCOAPERF_12122012
    and facility_grp_id=groupId );

         FOR i IN 1..l_limitIDList.COUNT LOOP

       BEGIN

        SELECT txn_rec_id, txn_ccy_code, txn_step_code
        BULK COLLECT INTO txnRecIDList, txnCcyList, txnStepList
        FROM (SELECT txn_rec_id, txn_ccy_code, txn_step_code
          FROM scbt_t_txn_mst
         WHERE bank_group_code = bankGroupCode
           AND cty_code = ctyCode
           AND cust_id =  custId
           AND NVL (shortfall_offset_type, ' ') <> 'CL'
           AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
					 AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
           AND prod_limit_id = l_limitIDList(i)
      UNION ALL
        SELECT MST.txn_rec_id, MST.txn_ccy_code, MST.txn_step_code
          FROM scbt_t_txn_mst MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
        WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
           AND MST.CTY_CODE=TCL.CTY_CODE
           AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
           AND CR.CTY_CODE=TCL.CTY_CODE
           AND MST.CUST_ID=TCL.CUST_ID
           AND MST.DEAL_ID=TCL.DEAL_ID
           AND CR.CUST_ID=TCL.CUST_ID
           AND CR.DEAL_ID=TCL.DEAL_ID
           AND MST.TXN_REC_ID=TCL.TXN_REC_ID
           AND MST.TXN_REF_ID=TCL.TXN_REF_ID
           AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
           AND MST.bank_group_code = bankGroupCode
           AND MST.cty_code = ctyCode
           AND MST.cust_id =  custId
           AND MST.prod_limit_id = l_limitIDList(i)
           AND NVL (MST.shortfall_offset_type, ' ') <> 'CL'
           AND NVL(MST.LIMIT_TRANSFER,'N') <> 'Y'
           AND NVL(MST.TXN_STATUS_CODE,'01') NOT IN ('05','11')
					 AND (MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)) = 0
           AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
           );

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;

            BEGIN

                 FOR j IN 1..txnRecIDList.COUNT LOOP
                   IF txnRecIDList(j) IS NOT NULL THEN
                          totalNCV := totalNCV + Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                           ctyCode,
                                                                           custId,
                                                                           txnCcyList(j),
                                                                           txnRecIDList(j),
                                                                           l_limitCcyList(i),
                                                                           'UTIL',
                                                                           'M',
                                                                           txnStepList(j));
                   END IF;
                 END LOOP;




            EXCEPTION WHEN OTHERS THEN
              NULL;

            END;


/*              totalNCV := totalNCV +  SCBF_C_GET_OVERALL_NCV_AMT(l_limitProdList(i),
                            						custId,
                            						l_limitIDList(i),
                            						l_limitCcyList(i),
                            						bankGroupCode,
                                        ctyCode,'N');*/
         END LOOP;

         RETURN  totalNCV;

    END SCBF_C_GET_GROUP_NCV_AMT;

   /* END- Added for Group facility***********/



   FUNCTION SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode IN VARCHAR2,
                                       ctyCode       IN VARCHAR2,
                                       custId        IN VARCHAR2,
                                       custExpCcy    IN VARCHAR2,
                                       txnRecID      IN VARCHAR2,
                                       txnCcyCode    IN VARCHAR2,
                                       dealStepId    IN VARCHAR2,
                                       sourceType    IN VARCHAR2,
                                       stepCode      IN VARCHAR2) RETURN NUMBER IS
    totalNCV   NUMBER;
    TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
    TYPE ColleteralPCTType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.coverage_pct%TYPE INDEX BY PLS_INTEGER;
    ncvCcyCode                VARCHAR2(3) DEFAULT 0;
    ncvCcyAmt                 NUMBER(17, 3) DEFAULT 0;
    totalNcvAmt               NUMBER(17, 3) DEFAULT 0;
    tempNcvAmt               NUMBER(17, 3) DEFAULT 0;
    collateralIDList          CollateralIDType;
    collateralPCTList         ColleteralPCTType;
    BEGIN


          IF (sourceType = 'M') THEN
            BEGIN

            IF(dealStepId = 'UTIL') then

             SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                INTO collateralIDList,collateralPCTList
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code=bankGroupCode
                  AND cust_id = custId   --REFPERF10DEC2012
                 AND cty_code = ctycode
                 AND txn_rec_id = txnRecID;
            else

              SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                INTO collateralIDList,collateralPCTList
                FROM Scbt_t_Txn_Cr_Linkage_Mst
               WHERE bank_group_code=bankGroupCode
                  AND cty_code = ctycode
                  AND txn_rec_id = txnRecID
                  AND cust_id = custId   --REFPERF10DEC2012
                  AND txn_rec_id not in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = bankGroupCode
                                      AND H1.cty_code = ctycode
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      --AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H2.CUST_ID=DH.CUST_ID -- COCOAPERF_12122012
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') <> '08'
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID
                                      AND DH.cust_id = custId   --REFPERF10DEC2012
                                      --AND NVL(H1.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      AND H1.txn_step_code <> 'CANC');
              end if;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;

         ELSIF (sourceType = 'H') THEN
            BEGIN

            IF(stepCode = 'AMD') THEN
                  SELECT collateral_id,NVL(coverage_pct,0) BULK COLLECT
                    INTO collateralIDList,collateralPCTList
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                    WHERE bank_group_code=bankGroupCode
                      AND CUST_ID = custId     --REFPERF10DEC2012
                      AND cty_code = ctycode
                      AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D';

            ELSE
                SELECT collateral_id,coverage_pct BULK COLLECT
                    INTO collateralIDList,collateralPCTList FROM (
                SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_hst
                    WHERE bank_group_code=bankGroupCode
                    AND cty_code = ctycode
                    AND cust_id = custId   --REFPERF10DEC2012
                    AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                   UNION
                   SELECT collateral_id,NVL(coverage_pct,0) AS coverage_pct
                    FROM Scbt_t_Txn_Cr_Linkage_Mst
                    WHERE bank_group_code=bankGroupCode
                      AND cty_code = ctycode
                      AND cust_id = custId   --REFPERF10DEC2012
                      AND txn_rec_id = txnRecID
                      AND (collateral_id,txn_rec_id) NOT IN(
                               SELECT collateral_id,txn_rec_id
                                FROM Scbt_t_Txn_Cr_Linkage_hst
                                WHERE bank_group_code=bankGroupCode
                              AND cty_code = ctycode
                              AND cust_id = custId   --REFPERF10DEC2012
                              AND txn_rec_id = txnRecID AND deal_step_id = dealStepId AND NVL(OP_CODE,'O') <> 'D'
                       ));


            END IF;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;
          END IF;
         IF (collateralIDList.COUNT > 0) THEN
          FOR k IN 1 .. collateralIDList.COUNT LOOP

              IF (sourceType = 'M') THEN
                BEGIN
                  SELECT total_ncv_ccy_code, NVL(total_ncv_ccy_amt,0)
                    INTO ncvCcyCode, ncvCcyAmt
                    FROM scbt_t_collateral_register_mst
                    WHERE bank_group_code=bankGroupCode
                    AND cty_code = ctycode
                    AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND collateral_id = collateralIDList(k);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                   ncvCcyAmt:=0;
                END;
              ELSIF (sourceType = 'H') THEN
                BEGIN
                  SELECT total_ncv_ccy_code,NVL( total_ncv_ccy_amt,0)
                    INTO ncvCcyCode, ncvCcyAmt
                    FROM scbt_t_collateral_register_hst
                    WHERE bank_group_code=bankGroupCode
                    AND CUST_ID = custId     -- COCOAPERF_12122012
                    AND cty_code = ctycode
                    AND collateral_id = collateralIDList(k) AND deal_step_id = dealStepId;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN  -- COCOAFIX_31072013
                  BEGIN
                    SELECT total_ncv_ccy_code, NVL(total_ncv_ccy_amt,0)
                      INTO ncvCcyCode, ncvCcyAmt
                      FROM scbt_t_collateral_register_mst
                      WHERE bank_group_code=bankGroupCode
                      AND cty_code = ctycode
                      AND CUST_ID = custId
                      AND collateral_id = collateralIDList(k);
                  EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                     ncvCcyAmt:=0;
                  END;
                END;
              END IF;




          tempNcvAmt := ((NVL(collateralPCTList(k),100))/100) * NVL(ncvCcyAmt,0); -- REF_27June2012
          totalNcvAmt := totalNcvAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                  ctyCode,
                                                                  ncvCcyCode,
                                                                  tempNcvAmt,
                                                                  custExpCcy,
                                                                  'Y'),
                                                                   0);

          END LOOP;
          END IF;

        RETURN ( totalNcvAmt);

    END SCBF_C_GET_NCV_BY_TXN_REF_ID;

/*-------------------------------------------------------------------------------------------*/

    FUNCTION SCBF_GET_CLIENT_ACC_BAL(p_bank_group_code IN VARCHAR2,
                                     p_cty_code        IN VARCHAR2,
                                     p_deal_step_id    IN VARCHAR2) RETURN NUMBER IS
      v_clt_lnk_bal                  SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_ANTICIPATED_AMT%TYPE;

      v_lnk_ccy_code                 SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_CODE%TYPE;
      v_lnk_account_no               SCBT_T_CUST_ACC_SMRY_MST.ACC_NO%TYPE;
      v_lnk_ccy_amt                  SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_ANTICIPATED_AMT%TYPE;
      v_lnk_acc_no                   SCBT_R_CUST_PRODUCT_LIMIT.Overdraft_Facility_Accno%TYPE;
      v_limit_ccy_code               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;
      v_cust_id                      SCBT_R_CUST_PRODUCT_LIMIT.CUST_ID%TYPE;
      v_count                        INT;

    BEGIN

         -- RETRIEVE THE LIMIT ID USED FOR THIS DEAL STEP ID AND ITS LINKED ACCOUNTS --

         v_clt_lnk_bal := 0;

         SELECT COUNT(*), S.OVERDRAFT_FACILITY_ACCNO, S.LIMIT_CCY_CODE, S.CUST_ID
           INTO v_count, v_lnk_acc_no, v_limit_ccy_code, v_cust_id
           FROM SCBT_T_PROD_LIMIT_REQ_LOG R,
                    SCBT_R_CUST_PRODUCT_LIMIT S,
                      SCBT_T_PROD_LIMIT_REQ_LOG_DTL D
          WHERE R.BANK_GROUP_CODE  = p_bank_group_code
            AND R.CTY_CODE                   = p_cty_code
            AND D.BANK_GROUP_CODE  = R.BANK_GROUP_CODE
            AND D.CTY_CODE                   = R.CTY_CODE
            AND R.BUS_EVENT_REF_NO = p_deal_step_id
            AND R.REQ_TYPE_CODE    = 'NEW'
            AND R.REQ_STATUS_CODE  = 'PEND'
            AND R.INIT_REQ_ID        = D.INIT_REQ_ID
            AND S.BANK_GROUP_CODE  = R.BANK_GROUP_CODE
            AND S.CTY_CODE         = R.CTY_CODE
            AND S.LIMIT_ID                   = D.PROD_LIMIT_ID
            AND S.SHORTFALL_OFFSET = 'CBB'
       GROUP BY S.LIMIT_CCY_CODE, S.OVERDRAFT_FACILITY_ACCNO, S.CUST_ID;

         IF (v_count > 0) THEN

             IF v_lnk_acc_no IS NULL THEN

                v_clt_lnk_bal := NULL;

             END IF;

         ELSE

            v_clt_lnk_bal := NULL;

         END IF;

         IF (v_count > 0) AND (v_lnk_acc_no IS NOT NULL) THEN

             v_lnk_ccy_code  := scbf_get_exp_ccy(p_bank_group_code, p_cty_code, v_cust_id);
             FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_lnk_acc_no))) LOOP

                 v_lnk_ccy_code   := SUBSTR(c1.column_value,1,3);
                 v_lnk_account_no := SUBSTR(c1.column_value,5);

                 SELECT SUM(A.ACC_CCY_ANTICIPATED_AMT)
                   INTO v_lnk_ccy_amt
                   FROM SCBT_T_CUST_ACC_SMRY_MST A,
                        SCBT_R_CUST_ACCT_MAINTENANCE M
                  WHERE A.BANK_GROUP_CODE = p_bank_group_code
                    AND A.CTY_CODE        = p_cty_code
                    AND A.CUST_ID         = v_cust_id
                    AND A.ACC_NO          = v_lnk_account_no
                    AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
                    AND M.CTY_CODE        = A.CTY_CODE
                    AND M.CUST_ID         = A.CUST_ID
                    AND M.ACC_NO          = A.ACC_NO
                    AND M.ACC_CCY_CODE    = A.ACC_CCY_CODE --sak acc cur code added
                    AND A.ACC_CCY_CODE    = v_lnk_ccy_code
                    AND M.INCLUDE_FOR_CASH_COLLATERAL = 'Y';


                 IF v_lnk_ccy_amt > 0 THEN

                    IF v_lnk_ccy_code <> v_limit_ccy_code THEN

                       v_clt_lnk_bal := v_clt_lnk_bal + NVL(Scbf_Tls_Exch_Rate(p_bank_group_code, -- BANK GROUP CODE
                                                                                           p_cty_code,        -- COUNTRY CODE
                                                                                       v_lnk_ccy_code,    -- FROM CURR CODE
                                                                                 v_lnk_ccy_amt,     -- FROM AMOUNT
                                                                                       v_limit_ccy_code,  -- TO CURR CODE
                                                                                 'N'),0);           -- ROUNG FLAG

                    ELSE

                       v_clt_lnk_bal := v_clt_lnk_bal + v_lnk_ccy_amt;

                    END IF;

                 END IF;

             END LOOP;

             RETURN (v_clt_lnk_bal);

         END IF;

         RETURN (v_clt_lnk_bal);

         EXCEPTION

         WHEN NO_DATA_FOUND THEN
              v_clt_lnk_bal := NULL;
              RETURN (v_clt_lnk_bal);
              NULL;

    END SCBF_GET_CLIENT_ACC_BAL;

/*-------------------------------------------------------------------------------------------*/
    PROCEDURE Scbp_P_Get_Coll_Position_Sfall(p_ret_code    IN OUT VARCHAR2,
                                           bankGroupCode IN VARCHAR2,
                                           ctyCode       IN VARCHAR2,
                                           custId        IN VARCHAR2,
                                           dealId        IN VARCHAR2,
                                           dealStepId    IN VARCHAR2,
                                           txnFlag       IN VARCHAR2,
                                           populateHist   IN VARCHAR2) IS
    TYPE OTECcyType IS TABLE OF SCBT_T_FIN_CR_MST.OTE_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE OTECcyAmtType IS TABLE OF SCBT_T_FIN_CR_MST.OTE_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE AABCcyType IS TABLE OF SCBT_T_FIN_CR_MST.AAB_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE AABCcyAmtType IS TABLE OF SCBT_T_FIN_CR_MST.AAB_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE AntiACBalCcyType IS TABLE OF scbt_t_cust_acc_smry_mst.acc_ccy_anticipated_ccy%TYPE INDEX BY PLS_INTEGER;
    TYPE AntiACBalCcyAmtType IS TABLE OF scbt_t_cust_acc_smry_mst.acc_ccy_anticipated_amt%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnRefIDType IS TABLE OF Scbt_t_Txn_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnRecIDType IS TABLE OF Scbt_t_Txn_Mst.txn_rec_id%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnStepCodeType IS TABLE OF Scbt_t_Txn_Mst.txn_step_code%TYPE INDEX BY PLS_INTEGER;
    TYPE RecordSourceType IS TABLE OF Scbt_t_Txn_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CashMarginCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CashMarginCcyType IS TABLE OF Scbt_t_Txn_Mst.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
    TYPE ColleteralPCTType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.coverage_pct%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE ShortfallOffSetPCType IS TABLE OF Scbt_t_Txn_Mst.SHORTFALL_OFFSET_TYPE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDList IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    custExpCcy                VARCHAR2(3);
    oteCcyList                OTECcyType;
    oteCcyAmtList             OTECcyAmtType;
    aabCcyList                AABCcyType;
    aabCcyAmtList             AABCcyAmtType;
    oteCcyPosList             OTECcyType;
    oteCcyPosAmtList          OTECcyAmtType;
    aabCcyPosList             AABCcyType;
    aabCcyPosAmtList          AABCcyAmtType;
    antiACBalCcyList          AntiACBalCcyType;
    antiACBalCcyAmtList       AntiACBalCcyAmtType;
    antiACBalCcyNegList       AntiACBalCcyType;
    antiACBalCcyAmtNegList    AntiACBalCcyAmtType;
    antiACBalCcyPosList       AntiACBalCcyType;
    antiACBalCcyAmtPosList    AntiACBalCcyAmtType;
    antiACBalCcyCstBalList    AntiACBalCcyType;
    antiACBalCcyCstBalAmtList AntiACBalCcyAmtType;
    custAccountBalCcyList     AntiACBalCcyType;
    custAccountBalAmtList     AntiACBalCcyAmtType;
    txnRefIDList              TxnRefIDType;
    txnRecIDList              TxnRecIDType;
    sourceType                RecordSourceType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    txnNCRefIDList            TxnRefIDType;
    txnNCCcyAmtList           TxnCcyAmtType;
    txnNCCcyList              TxnCcyType;
    cashMarginCcyAmtList      CashMarginCcyAmtType;
    cashMarginCcyList         CashMarginCcyType;
    minCashMarginCcyAmtList   CashMarginCcyAmtType;
    minCashMarginCcyList      CashMarginCcyType;
    txnHORefIDList            TxnRefIDType;
    txnHOCcyAmtList           TxnCcyAmtType;
    txnHOCcyList              TxnCcyType;
    cashHOMarginCcyAmtList    CashMarginCcyAmtType;
    cashHOMarginCcyList       CashMarginCcyType;
    txnCHRefIDList            TxnRefIDType;
    txnCHCcyAmtList           TxnCcyAmtType;
    txnCHCcyList              TxnCcyType;
    cashCHMarginCcyAmtList    CashMarginCcyAmtType;
    cashCHMarginCcyList       CashMarginCcyType;
    txnFORefIDList            TxnRefIDType;
    txnFOCcyAmtList           TxnCcyAmtType;
    txnFOCcyList              TxnCcyType;
    cashFOMarginCcyAmtList    CashMarginCcyAmtType;
    cashFOMarginCcyList       CashMarginCcyType;
    totalOTECcyAmt            NUMBER(17, 3) DEFAULT 0;
    totalAABCcyAmt            NUMBER(17, 3) DEFAULT 0;
    totalOTEPosCcyAmt         NUMBER(17, 3) DEFAULT 0;
    totalAABPosCcyAmt         NUMBER(17, 3) DEFAULT 0;
    totalAntiACBalAmt         NUMBER(17, 3) DEFAULT 0;
    totalTxnAmt               NUMBER(17, 3) DEFAULT 0;
    totalFOTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalHOTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalCHTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalNcvAmt               NUMBER(17, 3) DEFAULT 0;
    totalFONcvAmt             NUMBER(17, 3) DEFAULT 0;
    totalHONcvAmt             NUMBER(17, 3) DEFAULT 0;
    totalCHNcvAmt             NUMBER(17, 3) DEFAULT 0;
    ncvCcyCode                VARCHAR2(3) DEFAULT 0;
    ncvCcyAmt                 NUMBER(17, 3) DEFAULT 0;
    ncvFOCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvFOCcyAmt               NUMBER(17, 3) DEFAULT 0;
    ncvHOCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvHOCcyAmt               NUMBER(17, 3) DEFAULT 0;
    ncvCHCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvCHCcyAmt               NUMBER(17, 3) DEFAULT 0;
    collateralSfallAmt        NUMBER(17, 3) DEFAULT 0;
    collateralFOS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralFOS2fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralHOS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralHOS2fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralCHS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    totalShorFallAmt          NUMBER(17, 3) DEFAULT 0;
    sfallNotOffsetAmt         NUMBER(17, 3) DEFAULT 0;
    sfallHONotOffsetAmt       NUMBER(17, 3) DEFAULT 0;
    overdraftCustACCNegAmt    NUMBER(17, 3) DEFAULT 0;
    overdraftCustACCPosAmt    NUMBER(17, 3) DEFAULT 0;
    sfallApplForHO1Amt        NUMBER(17, 3) DEFAULT 0;
    sfallApplForHO2Amt        NUMBER(17, 3) DEFAULT 0;
    sfallApplForCHAmt         NUMBER(17, 3) DEFAULT 0;
    custAccBalanceAmt         NUMBER(17, 3) DEFAULT 0;
    amtOfCHShortfallAmt       NUMBER(17, 3) DEFAULT 0;
    totalMinCshMrgnReqAmt     NUMBER(17, 3) DEFAULT 0;
    tolarencePercentage       NUMBER(17, 3) DEFAULT 0;
    tolarenceWarnPtage        NUMBER(17, 3) DEFAULT 0;
    permCashSfallAmt          NUMBER(17, 3) DEFAULT 0;
    permCashSfallWarnAmt      NUMBER(17, 3) DEFAULT 0;
    totalCashDepBalAmt        NUMBER(17, 3) DEFAULT 0;
    cashTopUpReqToMeetAmt     NUMBER(17, 3) DEFAULT 0;
    cashTopUpReqAmt           NUMBER(17, 3) DEFAULT 0;
    avblCashAmt               NUMBER(17, 3) DEFAULT 0;
    tempCheckAmt              NUMBER(17, 3) DEFAULT 0;
    clientAccBalanceAmt       NUMBER(17, 3);
    topUpApproachingFlag      VARCHAR2(1);
    minCshMrgnReqMetFlag      VARCHAR2(1);
    cashTopupReqFlag          VARCHAR2(1);
    avblCashFlag              VARCHAR2(1);
    collateralIDList          CollateralIDType;
    collateralPCTList         ColleteralPCTType;
    collateralHOIDList        CollateralIDType;
    collateralHOPCTList       ColleteralPCTType;
    collateralFOIDList        CollateralIDType;
    collateralFOPCTList       ColleteralPCTType;
    collateralCHIDList        CollateralIDType;
    collateralCHPCTList       ColleteralPCTType;
    step_code_list            StepCodePCType;
    sourcetypelist            strArray;
    shortFallOffsetTypeList   ShortfallOffSetPCType;
    totalCashAvblForOffsetAmt NUMBER(17, 3) DEFAULT 0;
    FOShortfall               NUMBER(17, 3) DEFAULT 0;
    FOExcess                  NUMBER(17, 3) DEFAULT 0;
    FOTxnAmt                  NUMBER(17, 3) DEFAULT 0;
    FONCV                     NUMBER(17, 3) DEFAULT 0;

    HOShortfall               NUMBER(17, 3) DEFAULT 0;
    HOExcess                  NUMBER(17, 3) DEFAULT 0;
    HOTxnAmt                  NUMBER(17, 3) DEFAULT 0;
    HONCV                     NUMBER(17, 3) DEFAULT 0;

    CHShortfall               NUMBER(17, 3) DEFAULT 0;
    CHExcess                  NUMBER(17, 3) DEFAULT 0;
    CHTxnAmt                  NUMBER(17, 3) DEFAULT 0;
    CHNCV                     NUMBER(17, 3) DEFAULT 0;

    tempTxnAmount             NUMBER(17, 3) DEFAULT 0;
    tempNCVAmount             NUMBER(17, 3) DEFAULT 0;
    tempCMAmount              NUMBER(17, 3) DEFAULT 0;
    tempTotalCMAmount         NUMBER(17, 3) DEFAULT 0;
    tempTotalExcess           NUMBER(17, 3) DEFAULT 0;
    tempTotalShortfall        NUMBER(17, 3) DEFAULT 0;
    txnDealStepIDList         DealStepIDList;

    PITxnAmt                  NUMBER(17, 3) DEFAULT 0;
    PINCV                     NUMBER(17, 3) DEFAULT 0;
    PIExcess                  NUMBER(17, 3) DEFAULT 0;
    PIShortfall               NUMBER(17, 3) DEFAULT 0;

    FOCMAmount              NUMBER(17, 3) DEFAULT 0;
    HOCMAmount              NUMBER(17, 3) DEFAULT 0;
    CHCMAmount              NUMBER(17, 3) DEFAULT 0;

    totalPDCashMarginAmt    NUMBER(17,3) DEFAULT 0;
    txnStepCodeList         TxnStepCodeType;

  BEGIN

    BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;

    -- SHORTFALLS
    BEGIN
      SELECT OTE_CCY_CODE, NVL(OTE_CCY_AMT, 0) BULK COLLECT
        INTO oteCcyList, oteCcyAmtList
        FROM scbt_t_fin_cr_mst
       WHERE OTE_CCY_AMT < 0
         AND cust_id = custId;
      SELECT AAB_CCY_CODE, NVL(AAB_CCY_AMT, 0) BULK COLLECT
        INTO aabCcyList, aabCcyAmtList
        FROM scbt_t_fin_cr_mst
       WHERE AAB_CCY_AMT < 0
         AND cust_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    -- CALCULATION EXCEL SHEET CELL: Unrealised Losses on TPA Hedge Accounts
    -- Total OTE Amount from customer financial collateral capture
    IF (oteCcyList.COUNT > 0) THEN
      FOR i IN 1 .. oteCcyList.COUNT LOOP
        totalOTECcyAmt := totalOTECcyAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                    ctyCode,
                                                                    oteCcyList(i),
                                                                    oteCcyAmtList(i),
                                                                    custExpCcy,
                                                                    'Y'),
                                               0);
      END LOOP;
    END IF;

    -- CALCULATION EXCEL SHEET CELL: Collateral Shortfall on Transactional   Financings
    -- Total Anticipated Acount Balance Amount from customer financial collateral capture
    IF (aabCcyList.COUNT > 0) THEN
      FOR j IN 1 .. aabCcyList.COUNT LOOP
        totalAABCcyAmt := totalAABCcyAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                    ctyCode,
                                                                    aabCcyList(j),
                                                                    aabCcyAmtList(j),
                                                                    custExpCcy,
                                                                    'N'),
                                                                      0);


      END LOOP;
    END IF;

    -- CALCULATION EXCEL SHEET CELL:Collateral Shortfall on Transactional   Financings

    -- Collateral Shortfall

            BEGIN
                SELECT TXN_REF_ID,
                       TXN_REC_ID,
                       NVL(OUTSTANDING, 0),
                       TXN_CCY,
                       CM_CCY,
                       NVL(CASH_MARGIN, 0),
                       STEP_STATUS_CODE,
                       SOURCE,
                       SHORTFALL_OFFSET_TYPE,
                       DEAL_STEP_ID,
                       txn_step_code
                       BULK COLLECT
                  INTO txnRefIDList,
                       txnRecIDList,
                       txnCcyAmtList,
                       txnCcyList,
                       cashMarginCcyList,
                       cashMarginCcyAmtList,
                       step_code_list,
                       sourceTypeList,
                       shortFallOffsetTypeList,
                       txnDealStepIDList,
                       txnStepCodeList
                  FROM (SELECT MST.TXN_REF_ID,
                               MST.TXN_REC_ID,
                               MST.TXN_CCY_CODE AS TXN_CCY,
                               --(NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                               (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                               MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                               --(NVL(MST.CASH_MARGIN_CCY_AMT,0) - NVL(MST.CM_CCY_RELEASE_AMT,0)) AS CASH_MARGIN,
                               (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                               ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                               ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                                '03' AS STEP_STATUS_CODE,
                                'M' AS SOURCE,
                                SHORTFALL_OFFSET_TYPE,
                                '' AS DEAL_STEP_ID,
                                txn_step_code
                          FROM SCBT_T_TXN_MST MST
                         WHERE MST.BANK_GROUP_CODE = bankGroupCode
                               AND MST.CTY_CODE = ctyCode
                               AND cust_id = custid
                               AND MST.DEAL_ID = dealId   -- COCOAPERF_12122012
                               AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					                     AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                               --AND MST.TXN_STEP_CODE <> 'CSETT' and MST.TXN_STEP_CODE <> 'DSETT' -- COCOAPERF_12122012
                               AND MST.TXN_STEP_CODE NOT IN ('CSETT','DSETT') -- COCOAPERF_12122012
                               AND MST.TXN_REC_ID NOT IN
                               (SELECT TXN_REC_ID
                                  FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                                 WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                   AND TH.CTY_CODE = ctyCode
                                   AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                                   AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                                   AND TH.DEAL_ID=DH.DEAL_ID       --COCOAPERFTUNE_003
                                   AND TH.CUST_ID=DH.CUST_ID       --COCOAPERFTUNE_003
                                   AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                   AND TH.DEAL_ID = dealId   -- COCOAPERF_12122012
                                   AND TH.DEAL_STEP_ID = dealStepId  -- COCOAPERF_12122012
                                   --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                   AND TH.cust_id = custid)
                        UNION ALL
                        SELECT TH.TXN_REF_ID,
                               TH.TXN_REC_ID,
                               TH.TXN_CCY_CODE AS TXN_CCY,
                               --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                               (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                               TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                              -- NVL(TH.CASH_MARGIN_CCY_AMT,0) - NVL(TH.CM_CCY_RELEASE_AMT,0) AS CASH_MARGIN,
                              (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                              ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                                ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                               DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                               'H' AS SOURCE,
                               SHORTFALL_OFFSET_TYPE,
                               DH.Deal_Step_Id AS DEAL_STEP_ID,
                               TH.txn_step_code
                          FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                        WHERE TH.BANK_GROUP_CODE = bankGroupCode
                               AND TH.CTY_CODE = ctyCode
                               AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                               AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                               AND TH.DEAL_ID=DH.DEAL_ID
                               AND TH.CUST_ID=DH.CUST_ID
                               AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                               --AND TH.TXN_STEP_CODE <> 'CSETT' and TH.TXN_STEP_CODE <> 'DSETT' -- COCOAPERF_12122012
                               AND TH.TXN_STEP_CODE NOT IN ('CSETT','DSETT') -- COCOAPERF_12122012
                               AND TH.DEAL_ID = dealId   -- COCOAPERF_12122012
                               AND TH.DEAL_STEP_ID = dealStepId  -- COCOAPERF_12122012
                               AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                               AND DH.STEP_STATUS_CODE IN( '02','10','14')
                               AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                               AND TH.cust_id = custid);

            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;


    IF (txnRefIDList.COUNT > 0) THEN
      FOR i IN 1 .. txnRefIDList.COUNT LOOP

      IF txnStepCodeList(i) != 'SETT' THEN

         -- Overall Calculations
         tempTxnAmount := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                   ctyCode,
                                                   txnCcyList(i),
                                                   txnCcyAmtList(i),
                                                   custExpCcy,
                                                   'Y'),
                                                    0);

         /*tempNCVAmount := tempNCVAmount + SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         custExpCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i));*/

          tempNCVAmount:=    SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                         ctyCode,
                                                                         custId,
                                                                         custExpCcy,
                                                                         txnRecIDList(i),
                                                                         txnCcyList(i),
                                                                         txnDealStepIDList(i),
                                                                         sourceTypeList(i),
                                                                         txnStepCodeList(i));
         totalTxnAmt := totalTxnAmt + tempTxnAmount;
         totalNcvAmt := totalNcvAmt + tempNCVAmount;
         tempCMAmount := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                 ctyCode,
                                                 cashMarginCcyList(i),
                                                 cashMarginCcyAmtList(i),
                                                 custExpCcy,
                                                 'Y'),
                                                  0);


         IF (sourceTypeList(i) = 'H') THEN

             PITxnAmt := PITxnAmt + tempTxnAmount;
             PINCV := PINCV + tempNCVAmount;

              IF ( PINCV > PITxnAmt) THEN

                  PIExcess := PIExcess + (PINCV - PITxnAmt);

             ELSIF ((PINCV + tempCMAmount) < PITxnAmt) THEN

                  PIShortfall := PIShortfall + (PITxnAmt - (PINCV + tempCMAmount));

             END IF;

         END IF;


         -- Total Cash Margin Amount
         tempTotalCMAmount := tempTotalCMAmount + tempCMAmount;


         -- FO Calculations
         IF (shortFallOffsetTypeList(i)='FO') THEN
           --Removed self addition as suggested by Srini
     --Date: 05-APR-2011
--            FOTxnAmt := FOTxnAmt + tempTxnAmount;
--            FONCV    := FONCV + tempNCVAmount;
--            FOCMAmount := FOCMAmount + tempCMAmount;
           FOTxnAmt := tempTxnAmount;
           FONCV    := tempNCVAmount;
           FOCMAmount := tempCMAmount;


          --added by srini
           IF ( FONCV > FOTxnAmt) THEN

               FOExcess := FOExcess + (FONCV - FOTxnAmt);

           ELSIF ((FONCV + FOCMAmount) < FOTxnAmt) THEN

               FOShortfall := FOShortfall + (FOTxnAmt - (FONCV + FOCMAmount));

           END IF;



         END IF;


         -- HO Calculations

         IF (shortFallOffsetTypeList(i)='HO') THEN
           --Removed self addition as suggested by Srini
     --Date: 05-APR-2011
--            HOTxnAmt := HOTxnAmt + tempTxnAmount;
--            HONCV    := HONCV + tempNCVAmount;
--            HOCMAmount := HOCMAmount + tempCMAmount;
           HOTxnAmt := tempTxnAmount;
           HONCV    := tempNCVAmount;
           HOCMAmount := tempCMAmount;

            IF ( HONCV > HOTxnAmt) THEN

           HOExcess := HOExcess + (HONCV - HOTxnAmt);

         ELSIF ((HONCV + HOCMAmount) < HOTxnAmt) THEN

           HOShortfall := HOShortfall + (HOTxnAmt - (HONCV + HOCMAmount));

         END IF;

        END IF;




        -- CH Calculations
         IF (shortFallOffsetTypeList(i)='CH') THEN
           --Removed self addition as suggested by Srini
     --Date: 05-APR-2011
--            CHTxnAmt := CHTxnAmt + tempTxnAmount;
--            CHNCV    := CHNCV + tempNCVAmount;
--            CHCMAmount := CHCMAmount + tempCMAmount;
           CHTxnAmt := tempTxnAmount;
           CHNCV    := tempNCVAmount;
           CHCMAmount := tempCMAmount;
         END IF;

             IF ( CHNCV > CHTxnAmt) THEN

               CHExcess := CHExcess + (CHNCV - CHTxnAmt);

             ELSIF ((CHNCV + CHCMAmount) < CHTxnAmt) THEN

               CHShortfall := CHShortfall + (CHTxnAmt - (CHNCV + CHCMAmount));

             END IF;

       END IF;
        END LOOP;
       END IF;

       totalMinCashMarginReqAmt := tempTotalCMAmount;
     /* totalMinCashMarginReqAmt := nvl(totalMinCashMarginReqAmt,0) + SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId);
      */

      if(dealStepId = 'N') then
          BEGIN
           SELECT SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                 ctyCode,
                                                  CASH_MARGIN_CCY_CODE,
                                                  (CASE
                                                                                        WHEN TH.TXN_STEP_CODE = 'CANC' THEN
                                                                                         NVL((SELECT CM_CCY_RELEASE_AMT
                                                                                    FROM SCBT_T_TXN_MST
                                                          WHERE BANK_GROUP_CODE = TH.BANK_GROUP_CODE
                                                          AND CTY_CODE = TH.CTY_CODE
                                                          AND TXN_REF_ID = TH.TXN_REF_ID
                                                          AND TXN_REC_ID = TH.TXN_REC_ID),
                                                                                        0)
                                                                                         WHEN TH.TXN_STEP_CODE = 'SETT' OR TH.TXN_STEP_CODE = 'DSETT' THEN
                                                                                               nvl(CM_CCY_RELEASE_AMT,0)
                                                     ELSE
                                                         0
                                                                                         END
                                                                                ),
                                                  custExpCcy,
                                                  'Y'),
                                                    0))
                  INTO totalPDCashMarginAmt
                  FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                 WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                       AND TH.CTY_CODE = DH.CTY_CODE
                       AND TH.BANK_GROUP_CODE = bankGroupCode
                       AND TH.CTY_CODE = ctyCode
                       AND TH.CUST_ID = custId
                       AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                       AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                       AND TH.DEAL_ID=DH.DEAL_ID       --COCOAPERFTUNE_003
                       AND TH.CUST_ID=DH.CUST_ID       --COCOAPERFTUNE_003
                       AND TH.Deal_Step_Id = DH.Deal_Step_Id
                       --AND (TH.TXN_STEP_CODE = 'SETT' OR TH.TXN_STEP_CODE = 'CANC' OR TH.TXN_STEP_CODE = 'DSETT') -- COCOAPERF_12122012
                       AND TH.TXN_STEP_CODE IN ('SETT','CANC','DSETT') -- COCOAPERF_12122012
                       AND TH.DEAL_ID = dealId   -- COCOAPERF_12122012
                       AND TH.DEAL_STEP_ID = dealStepId  -- COCOAPERF_12122012
                       AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                       AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                       AND DH.STEP_STATUS_CODE IN( '02','10','14');
           EXCEPTION
                    WHEN OTHERS THEN
                    NULL;
           END;

             totalMinCashMarginReqAmt := nvl(totalMinCashMarginReqAmt,0) + NVL(totalPDCashMarginAmt,0);
       END IF;


      tempTotalExcess :=CHExcess+HOExcess+FOExcess;
      tempTotalShortfall:=CHShortfall+HOShortfall+FOShortfall;


      -- Overall Shortfall and Excess
   -- Commented as suggested by SRINI
   -- Date: 05-APR-2011
--          if ( totalNcvAmt > totalTxnAmt) then
--
--            tempTotalExcess := tempTotalExcess + (totalNcvAmt - totalTxnAmt);
--
--          elsif ((totalNcvAmt + tempCMAmount) < totalTxnAmt) then
--
--            tempTotalShortfall := tempTotalShortfall + (totalTxnAmt - (totalNcvAmt + tempTotalCMAmount));
--
--          end if;

      -- FO Shortfall and Excess

      /*

      Commented as by SRINI
         if ( FONCV > FOTxnAmt) then

           FOExcess := FOExcess + (FONCV - FOTxnAmt);

         elsif ((FONCV + FOCMAmount) < FOTxnAmt) then

           FOShortfall := FOShortfall + (FOTxnAmt - (FONCV + FOCMAmount));

         end if;


     -- HO Shortfall and Excess

         if ( HONCV > HOTxnAmt) then

           HOExcess := HOExcess + (HONCV - HOTxnAmt);

         elsif ((HONCV + HOCMAmount) < HOTxnAmt) then

           HOShortfall := HOShortfall + (HOTxnAmt - (HONCV + HOCMAmount));

         end if;


      -- Cash Only (CH) Shortfall and Excess
         if ( CHNCV > CHTxnAmt) then

           CHExcess := CHExcess + (CHNCV - CHTxnAmt);

         elsif ((CHNCV + CHCMAmount) < CHTxnAmt) then

           CHShortfall := CHShortfall + (CHTxnAmt - (CHNCV + CHCMAmount));

         end if;   */




    -- Get Anticipated Negetive Balances for a customer from customer account summary
    BEGIN
      SELECT acc_ccy_anticipated_ccy, ABS(NVL(acc_ccy_anticipated_amt,0)) BULK COLLECT
        INTO antiACBalCcyList, antiACBalCcyAmtList
        FROM scbt_t_cust_acc_smry_mst
       WHERE cust_id = custId
         AND BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode                -- COCOAPERF_12122012
         AND acc_ccy_anticipated_amt < 0;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    IF (antiACBalCcyList.COUNT > 0) THEN
      FOR i IN 1 .. antiACBalCcyList.COUNT LOOP
        totalAntiACBalAmt := totalAntiACBalAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                          ctyCode,
                                                                          antiACBalCcyList(i),
                                                                          antiACBalCcyAmtList(i),
                                                                          custExpCcy,
                                                                          'Y'),
                                                     0);
      END LOOP;
    END IF;



    -- CALCULATION EXCEL SHEET CELL:A) Shortfall applicable for "Full Offset"
    -- CALCULATION EXCEL SHEET CELL:A1) Excess Collateral on Transactions   Financings

    -- Shortfall applicable for Full Offset (FO)

        totalFOTxnAmt := FOTxnAmt;
        totalFONcvAmt := FONCV;


        collateralFOS1fallAmt := FOShortfall;
        collateralFOS2fallAmt := FOExcess;






    -- CALCULATION EXCEL SHEET CELL:B) Shortfall applicable for "Hedge Offset" + A2)

    -- Shortfall applicable for Hedge Offset (HO)
        totalHOTxnAmt := HOTxnAmt;
        totalHONcvAmt := HONCV;


        collateralHOS1fallAmt := HOShortfall;


        collateralHOS2fallAmt := HOExcess;



        totalCHTxnAmt := HOTxnAmt;
        totalCHNcvAmt := HONCV;

     -- Shortfall applicable for Cash Offset (CH)
        collateralCHS1fallAmt := CHShortfall;
        collateralFOS2fallAmt := FOExcess + CHExcess;



        collateralCashSfallAmount := collateralCHS1fallAmt;

        -- CALCULATION EXCEL SHEET CELL : A2) Amount of shortfall NOT offset by A1)

        -- Amount of Shortfall not Offset for FO
        IF (NVL(collateralFOS2fallAmt, 0) < ABS(NVL(collateralFOS1fallAmt, 0))) THEN
          sfallNotOffsetAmt := ABS(NVL(collateralFOS1fallAmt, 0) -
                                   NVL(collateralFOS2fallAmt, 0));
        ELSE
           sfallNotOffsetAmt := 0;
        END IF;

        -- Positive OTE and AAB Balances
        BEGIN
          SELECT OTE_CCY_CODE, OTE_CCY_AMT BULK COLLECT
            INTO oteCcyPosList, oteCcyPosAmtList
            FROM scbt_t_fin_cr_mst
           WHERE OTE_CCY_AMT > 0
             AND cust_id = custId;

          SELECT AAB_CCY_CODE, AAB_CCY_AMT BULK COLLECT
            INTO aabCcyPosList, aabCcyPosAmtList
            FROM scbt_t_fin_cr_mst
           WHERE AAB_CCY_AMT > 0
             AND cust_id = custId;

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;

        -- Total Positive OTE Amount from customer financial collateral capture
        IF (oteCcyPosList.COUNT > 0) THEN
          FOR i IN 1 .. oteCcyPosList.COUNT LOOP
            totalOTEPosCcyAmt := totalOTEPosCcyAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                              ctyCode,
                                                                              oteCcyPosList(i),
                                                                              oteCcyPosAmtList(i),
                                                                              custExpCcy,
                                                                              'Y'),
                                                         0);
          END LOOP;
        END IF;

        -- Total Positive Anticipated Acount Balance Amount from customer financial collateral capture
        IF (aabCcyPosList.COUNT > 0) THEN
          FOR j IN 1 .. aabCcyPosList.COUNT LOOP
            totalAABPosCcyAmt := totalAABPosCcyAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                              ctyCode,
                                                                              aabCcyPosList(j),
                                                                              aabCcyPosAmtList(j),
                                                                              custExpCcy,
                                                                              'Y'),
                                                         0);
          END LOOP;
        END IF;

        -- Overdraft Account Total Anticipated Balance of the Customer

        BEGIN
          SELECT NVL(acc_ccy_anticipated_amt,0), acc_ccy_anticipated_ccy BULK COLLECT
            INTO antiACBalCcyNegList, antiACBalCcyAmtNegList
            FROM scbt_t_cust_acc_smry_mst
           WHERE cust_id = custId
             AND BANK_GROUP_CODE = bankGroupCode  -- COCOAPERF_12122012
             AND CTY_CODE = ctyCode    -- COCOAPERF_12122012
             AND acc_ccy_anticipated_amt < 0
             AND acc_no IN (SELECT OVERDRAFT_FACILITY_ACCNO
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                             WHERE cust_id = custId  -- COCOAPERF_12122012
                             AND BANK_GROUP_CODE = bankGroupCode   -- COCOAPERF_12122012
                             AND CTY_CODE = ctyCode
                             AND shortfall_offset = 'HO');

        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;

        IF (antiACBalCcyNegList.COUNT > 0) THEN
          FOR j IN 1 .. antiACBalCcyNegList.COUNT LOOP
            overdraftCustACCNegAmt := overdraftCustACCNegAmt +
                                      NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                               ctyCode,
                                                               antiACBalCcyNegList(j),
                                                               antiACBalCcyAmtNegList(j),
                                                               custExpCcy,
                                                               'Y'),
                                          0);
          END LOOP;
        END IF;

        sfallApplForHO1Amt := NVL(overdraftCustACCNegAmt, 0) +
                              NVL(sfallNotOffsetAmt, 0) +
                              NVL(collateralHOS1fallAmt, 0) +
                              NVL(totalOTECcyAmt, 0) + NVL(totalAABCcyAmt, 0);

        BEGIN
          SELECT NVL(acc_ccy_anticipated_amt, 0), acc_ccy_anticipated_ccy BULK COLLECT
            INTO antiACBalCcyPosList, antiACBalCcyAmtPosList
            FROM scbt_t_cust_acc_smry_mst
           WHERE cust_id = custId
             AND BANK_GROUP_CODE = bankGroupCode -- COCOAPERF_12122012
             AND CTY_CODE = ctyCode  -- COCOAPERF_12122012
             AND acc_ccy_anticipated_amt > 0
             AND acc_no IN (SELECT OVERDRAFT_FACILITY_ACCNO
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                             WHERE cust_id = custId
                              AND BANK_GROUP_CODE = bankGroupCode --COCOAPERFTUNE_003
                              AND CTY_CODE = ctyCode  --COCOAPERFTUNE_003
                              AND shortfall_offset = 'HO');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;

        IF (antiACBalCcyPosList.COUNT > 0) THEN
          FOR j IN 1 .. antiACBalCcyPosList.COUNT LOOP
            overdraftCustACCPosAmt := overdraftCustACCPosAmt +
                                      NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                               ctyCode,
                                                               antiACBalCcyPosList(j),
                                                               antiACBalCcyAmtPosList(j),
                                                               custExpCcy,
                                                               'Y'),
                                          0);
          END LOOP;
        END IF;

        sfallApplForHO2Amt := NVL(HOExcess, 0) +
                              NVL(overdraftCustACCPosAmt, 0) +
                              NVL(totalOTEPosCcyAmt, 0) +
                              NVL(totalAABPosCcyAmt, 0);


        -- Amount of Shortfall not Offset for HO

        IF (NVL(sfallApplForHO2Amt, 0) < ABS(NVL(sfallApplForHO1Amt, 0))) THEN
          sfallHONotOffsetAmt := NVL(sfallApplForHO1Amt, 0) -
                                     NVL(sfallApplForHO2Amt, 0);
        ELSE
          sfallHONotOffsetAmt := 0;
        END IF;

        shortfallHONotOffsetAmt := sfallHONotOffsetAmt;

        -- Shorfall Applicable for Cash Only Offset

        sfallApplForCHAmt := NVL(collateralCHS1fallAmt, 0) +
                             NVL(shortfallHONotOffsetAmt, 0);

        -- All non Hedge Offset Customer Accounts
        BEGIN
          SELECT acc_ccy_anticipated_amt, acc_ccy_anticipated_ccy BULK COLLECT
            INTO antiACBalCcyCstBalAmtList, antiACBalCcyCstBalList

            FROM (SELECT *
                    FROM scbt_t_cust_acc_smry_mst
                   WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                   AND acc_ccy_anticipated_amt > 0
                  MINUS
                  SELECT *
                    FROM scbt_t_cust_acc_smry_mst
                   WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                   AND acc_ccy_anticipated_amt > 0
                     AND acc_no  IN (SELECT OVERDRAFT_FACILITY_ACCNO
                                      FROM SCBT_R_CUST_PRODUCT_LIMIT
                                     WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                                       AND shortfall_offset = 'HO'))
           WHERE  acc_no IN
             (SELECT acc_no
                FROM scbt_r_cust_acct_maintenance
               WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                 AND UPPER(NVL(include_for_cash_collateral,'N')) = 'Y');
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;

        IF (antiACBalCcyCstBalList.COUNT > 0) THEN
          FOR j IN 1 .. antiACBalCcyCstBalList.COUNT LOOP
            custAccBalanceAmt := custAccBalanceAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                              ctyCode,
                                                                              antiACBalCcyCstBalList(j),
                                                                              antiACBalCcyCstBalAmtList(j),
                                                                              custExpCcy,
                                                                              'Y'),
                                                                               0);
          END LOOP;
        END IF;

        /* CALL THIS FUNCTION TO CHECK WHETHER THE FACILITY ID USED IS CLIENT BORROWING BASE FACILITY
           AND TO GENERATE THEIR LINKED ACCOUNT BALANCE IN THE FACILITY CURRENCY*/

        IF dealStepId IS NOT NULL THEN

           clientAccBalanceAmt := NULL;

           clientAccBalanceAmt := SCBF_GET_CLIENT_ACC_BAL(bankGroupCode,
                                                          ctyCode,
                                                          dealStepId);

        END IF;

        -- Net Cash Only Offset Shortfall Amount
  -- Changes made to calculate Total Cash Available to Offset as per Client Position Model Version 13.xlsx
  -- Date: 05-APR-2011
        --if(custAccBalanceAmt > tempTotalCMAmount) then
        -- totalCashAvblForOffsetAmt := custAccBalanceAmt - tempTotalCMAmount;
        --else
        -- totalCashAvblForOffsetAmt := custAccBalanceAmt;
        --end if;

        /*OVERRIDE CUSTOMER BALANCE WITH THE LINKED ACCOUNT BALANCE IF THE FACILITY USED IS CBB */

        IF clientAccBalanceAmt IS NOT NULL THEN

           custAccBalanceAmt := clientAccBalanceAmt;

        END IF;

        IF( (custAccBalanceAmt - totalMinCashMarginReqAmt) > 0) THEN
          totalCashAvblForOffsetAmt := custAccBalanceAmt - totalMinCashMarginReqAmt;
        ELSE
          totalCashAvblForOffsetAmt := 0;
        END IF;

  -- Amount of shortfall NOT offset
  -- Changes made to calculate Amount of shortfall NOT offset as per Client Position Model Version 13.xlsx
  -- Date: 05-APR-2011
--         IF (NVL(totalCashAvblForOffsetAmt, 0) > ABS(NVL(sfallApplForCHAmt, 0))) THEN
--           amtOfCHShortfallTempAmt := ABS(NVL(sfallApplForCHAmt, 0));
--         ELSE
--           amtOfCHShortfallTempAmt := NVL(totalCashAvblForOffsetAmt, 0);
--         END IF;
--
--         IF NVL(amtOfCHShortfallTempAmt, 0) < ABS(NVL(sfallApplForCHAmt, 0)) THEN
--           amtOfCHShortfallAmt := NVL(sfallApplForCHAmt, 0) - NVL(amtOfCHShortfallTempAmt, 0);
--         ELSE
--           amtOfCHShortfallAmt := 0;--
--         END IF;

     IF (NVL(totalCashAvblForOffsetAmt, 0) < ABS(NVL(sfallApplForCHAmt, 0))) THEN
        amtOfCHShortfallAmt := sfallApplForCHAmt - totalCashAvblForOffsetAmt;
     ELSE
        amtOfCHShortfallAmt:= 0;
     END IF;

       -- Total Shortfall Amount

        collateralSfallAmt := tempTotalShortfall +
                              NVL(totalAntiACBalAmt, 0);

        totalShorfallAmt := NVL(totalOTECcyAmt, 0) + NVL(totalAABCcyAmt, 0) +
                            NVL(collateralSfallAmt, 0);

       shortfallForTopup := amtOfCHShortfallAmt;

        IF (totalShorfallAmt < 0) THEN
           totalShorfallAmt := 0;
        END IF;

         IF (collateralSfallAmt < 0) THEN
           collateralSfallAmt := 0;
        END IF;

        -- Round Amounts to Exposure Currency

        totalOTECcyAmt        := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalOTECcyAmt);
        totalAABCcyAmt        := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalAABCcyAmt);
        collateralSfallAmt    := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   collateralSfallAmt);
        totalShorfallAmt      := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalShorfallAmt);
        collateralFOS1fallAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   collateralFOS1fallAmt);
        collateralFOS2fallAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   collateralFOS2fallAmt);
        sfallNotOffsetAmt     := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   sfallNotOffsetAmt);
        sfallApplForHO1Amt    := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   sfallApplForHO1Amt);
        sfallApplForHO2Amt    := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   sfallApplForHO2Amt);
        sfallHONotOffsetAmt   := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   sfallHONotOffsetAmt);
        sfallApplForCHAmt     := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   sfallApplForCHAmt);
        custAccBalanceAmt     := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   custAccBalanceAmt);
        amtOfCHShortfallAmt   := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   amtOfCHShortfallAmt);

        permCashSfallAmt      := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   permCashSfallAmt);
        totalMinCshMrgnReqAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalMinCshMrgnReqAmt);
        totalCashDepBalAmt    := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalCashDepBalAmt);
        cashTopUpReqToMeetAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   cashTopUpReqToMeetAmt);
        cashTopUpReqAmt       := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   cashTopUpReqAmt);
        avblCashAmt           := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   avblCashAmt);

        totalMinCashMarginReqAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalMinCashMarginReqAmt);
        totalCashAvblForOffsetAmt := Scbf_Round_Amount(bankGroupCode,
                                                   custExpCcy,
                                                   totalCashAvblForOffsetAmt);

        -- Insert at release into History the current position

     /*   if (populateHist = 'Y') then

             INSERT INTO SCBT_T_CUST_SHORTFALL_SMRY_HST
            (BANK_GROUP_CODE,
             CTY_CODE,
             CUST_ID,
             OVERALL_EXP_CCY_CODE,
             LOSS_ON_TPA_HEDGE_ACC_AMT,
             TPA_HEDGE_ACC_DEBT_BAL_AMT,
             COLL_SHORTFALL_TXN_ODFIN_AMT,
             TOTAL_SHORTFALL_AMT,
             SHORTFALL_APPL_FULLOFFSET_AMT,
             COLL_EXCESS_TXN_ODFIN_AMT,
             NET_FULLOFFSET_SHORTFALL_AMT,
             SHORTFALL_APPL_HEDGEOFFSET_AMT,
             TOTAL_HEDGE_COLL_AMT,
             NET_HEDGEOFFSET_SHORTFALL_AMT,
             SHORTFALL_APPL_CASHOFFSET_AMT,
             TOTAL_CASH_MARGIN_REQ_AMT,
             TOTAL_CASH_COLL_AMT,
             TOTAL_CASH_AVBL_FOR_OFFSET_AMT,
             NET_CASHOFFSET_SHORTFALL_AMT,
             DEAL_STEP_ID)
          VALUES
            (bankGroupCode,
             ctyCode,
             custId,
             custExpCcy,
             totalOTECcyAmt,
             totalAABCcyAmt,
             collateralSfallAmt,
             totalShorfallAmt,
             collateralFOS1fallAmt,
             collateralFOS2fallAmt,
             sfallNotOffsetAmt,
             sfallApplForHO1Amt,
             sfallApplForHO2Amt,
             sfallHONotOffsetAmt,
             sfallApplForCHAmt,
             totalMinCashMarginReqAmt,
             custAccBalanceAmt,
             totalCashAvblForOffsetAmt,
             amtOfCHShortfallAmt,
             dealStepId);
        End IF;*/

        -- Insert into Shortfall / Topups Summary Master and History Table Based on Transaction Flag

       IF clientAccBalanceAmt IS NULL THEN
           DELETE FROM SCBT_T_CUST_SHORTFALL_SMRY_MST
               WHERE bank_group_code = bankGroupCode
                 AND cty_code = ctyCode
                 AND cust_id = custId;
              INSERT INTO SCBT_T_CUST_SHORTFALL_SMRY_MST
                (BANK_GROUP_CODE,
                 CTY_CODE,
                 CUST_ID,
                 OVERALL_EXP_CCY_CODE,
                 LOSS_ON_TPA_HEDGE_ACC_AMT,
                 TPA_HEDGE_ACC_DEBT_BAL_AMT,
                 COLL_SHORTFALL_TXN_ODFIN_AMT,
                 TOTAL_SHORTFALL_AMT,
                 SHORTFALL_APPL_FULLOFFSET_AMT,
                 COLL_EXCESS_TXN_ODFIN_AMT,
                 NET_FULLOFFSET_SHORTFALL_AMT,
                 SHORTFALL_APPL_HEDGEOFFSET_AMT,
                 TOTAL_HEDGE_COLL_AMT,
                 NET_HEDGEOFFSET_SHORTFALL_AMT,
                 SHORTFALL_APPL_CASHOFFSET_AMT,
                 TOTAL_CASH_MARGIN_REQ_AMT,
                 TOTAL_CASH_COLL_AMT,
                 TOTAL_CASH_AVBL_FOR_OFFSET_AMT,
                 NET_CASHOFFSET_SHORTFALL_AMT)
              VALUES
                (bankGroupCode,
                 ctyCode,
                 custId,
                 custExpCcy,
                 totalOTECcyAmt,
                 totalAABCcyAmt,
                 collateralSfallAmt,
                 totalShorfallAmt,
                 collateralFOS1fallAmt,
                 collateralFOS2fallAmt,
                 sfallNotOffsetAmt,
                 sfallApplForHO1Amt,
                 sfallApplForHO2Amt,
                 sfallHONotOffsetAmt,
                 sfallApplForCHAmt,
                 totalMinCashMarginReqAmt,
                 custAccBalanceAmt,
                 totalCashAvblForOffsetAmt,
                 amtOfCHShortfallAmt);

       END IF;


        COMMIT;

        p_ret_code := '0000';

    END Scbp_P_Get_Coll_Position_Sfall;

   PROCEDURE Scbp_P_Get_Coll_Position_Topup(p_ret_code    IN OUT VARCHAR2,
                                           bankGroupCode IN VARCHAR2,
                                           ctyCode       IN VARCHAR2,
                                           custId        IN VARCHAR2,
                                           dealId        IN VARCHAR2,
                                           dealStepID    IN VARCHAR2,
                                           txnFlag       IN VARCHAR2,
                                           populateHist   IN VARCHAR2) IS
    TYPE OTECcyType IS TABLE OF SCBT_T_FIN_CR_MST.OTE_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE OTECcyAmtType IS TABLE OF SCBT_T_FIN_CR_MST.OTE_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE AABCcyType IS TABLE OF SCBT_T_FIN_CR_MST.AAB_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE AABCcyAmtType IS TABLE OF SCBT_T_FIN_CR_MST.AAB_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE AntiACBalCcyType IS TABLE OF scbt_t_cust_acc_smry_mst.acc_ccy_anticipated_ccy%TYPE INDEX BY PLS_INTEGER;
    TYPE AntiACBalCcyAmtType IS TABLE OF scbt_t_cust_acc_smry_mst.acc_ccy_anticipated_amt%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnRefIDType IS TABLE OF Scbt_t_Txn_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
    TYPE RecordSourceType IS TABLE OF Scbt_t_Txn_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CashMarginCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE CashMarginCcyType IS TABLE OF Scbt_t_Txn_Mst.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
     TYPE StopLossPCTType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_PCT%TYPE INDEX BY PLS_INTEGER;
     TYPE StopLossCcyCodeType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
     TYPE StopLossCcyAmtType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
     TYPE StopLossFlagType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_APPL_FLAG%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE StepCodePCType IS TABLE OF SCBT_T_DEAL_HIST.STEP_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE DealStepIDListType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_STEP_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
    TYPE ProductLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
    TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
    custExpCcy                VARCHAR2(3);
    oteCcyList                OTECcyType;
    oteCcyAmtList             OTECcyAmtType;
    aabCcyList                AABCcyType;
    aabCcyAmtList             AABCcyAmtType;
    oteCcyPosList             OTECcyType;
    oteCcyPosAmtList          OTECcyAmtType;
    aabCcyPosList             AABCcyType;
    aabCcyPosAmtList          AABCcyAmtType;
    antiACBalCcyList          AntiACBalCcyType;
    antiACBalCcyAmtList       AntiACBalCcyAmtType;
    antiACBalCcyNegList       AntiACBalCcyType;
    antiACBalCcyAmtNegList    AntiACBalCcyAmtType;
    antiACBalCcyPosList       AntiACBalCcyType;
    antiACBalCcyAmtPosList    AntiACBalCcyAmtType;
    antiACBalCcyCstBalList    AntiACBalCcyType;
    antiACBalCcyCstBalAmtList AntiACBalCcyAmtType;
    custAccountBalCcyList     AntiACBalCcyType;
    custAccountBalAmtList     AntiACBalCcyAmtType;
    sourceType                RecordSourceType;
    txnCcyAmtList             TxnCcyAmtType;
    txnCcyList                TxnCcyType;
    txnNCRefIDList            TxnRefIDType;
    txnNCCcyAmtList           TxnCcyAmtType;
    txnNCCcyList              TxnCcyType;

    minCashMarginCcyAmtList   CashMarginCcyAmtType;
    minCashMarginCcyList      CashMarginCcyType;
    txnHORefIDList            TxnRefIDType;
    txnHOCcyAmtList           TxnCcyAmtType;
    txnHOCcyList              TxnCcyType;
    cashHOMarginCcyAmtList    CashMarginCcyAmtType;
    cashHOMarginCcyList       CashMarginCcyType;
    txnCHRefIDList            TxnRefIDType;
    txnCHCcyAmtList           TxnCcyAmtType;
    txnCHCcyList              TxnCcyType;
    cashCHMarginCcyAmtList    CashMarginCcyAmtType;
    cashCHMarginCcyList       CashMarginCcyType;
    txnFORefIDList            TxnRefIDType;
    txnFOCcyAmtList           TxnCcyAmtType;
    txnFOCcyList              TxnCcyType;
    cashFOMarginCcyAmtList    CashMarginCcyAmtType;
    cashFOMarginCcyList       CashMarginCcyType;
    totalOTECcyAmt            NUMBER(17, 3) DEFAULT 0;
    totalAABCcyAmt            NUMBER(17, 3) DEFAULT 0;
    totalOTEPosCcyAmt         NUMBER(17, 3) DEFAULT 0;
    totalAABPosCcyAmt         NUMBER(17, 3) DEFAULT 0;
    totalAntiACBalAmt         NUMBER(17, 3) DEFAULT 0;
    totalTxnAmt               NUMBER(17, 3) DEFAULT 0;
    totalFOTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalHOTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalCHTxnAmt             NUMBER(17, 3) DEFAULT 0;
    totalNcvAmt               NUMBER(17, 3) DEFAULT 0;
    totalFONcvAmt             NUMBER(17, 3) DEFAULT 0;
    totalHONcvAmt             NUMBER(17, 3) DEFAULT 0;
    totalCHNcvAmt             NUMBER(17, 3) DEFAULT 0;
    ncvCcyCode                VARCHAR2(3) DEFAULT 0;
    ncvCcyAmt                 NUMBER(17, 3) DEFAULT 0;
    ncvFOCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvFOCcyAmt               NUMBER(17, 3) DEFAULT 0;
    ncvHOCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvHOCcyAmt               NUMBER(17, 3) DEFAULT 0;
    ncvCHCcyCode              VARCHAR2(3) DEFAULT 0;
    ncvCHCcyAmt               NUMBER(17, 3) DEFAULT 0;
    collateralSfallAmt        NUMBER(17, 3) DEFAULT 0;
    collateralFOS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralFOS2fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralHOS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralHOS2fallAmt     NUMBER(17, 3) DEFAULT 0;
    collateralCHS1fallAmt     NUMBER(17, 3) DEFAULT 0;
    totalShorFallAmt          NUMBER(17, 3) DEFAULT 0;
    sfallNotOffsetAmt         NUMBER(17, 3) DEFAULT 0;
    sfallHONotOffsetAmt       NUMBER(17, 3) DEFAULT 0;
    overdraftCustACCNegAmt    NUMBER(17, 3) DEFAULT 0;
    overdraftCustACCPosAmt    NUMBER(17, 3) DEFAULT 0;
    sfallApplForHO1Amt        NUMBER(17, 3) DEFAULT 0;
    sfallApplForHO2Amt        NUMBER(17, 3) DEFAULT 0;
    sfallApplForCHAmt         NUMBER(17, 3) DEFAULT 0;
    custAccBalanceAmt         NUMBER(17, 3) DEFAULT 0;
    amtOfCHShortfallTempAmt   NUMBER(17, 3) DEFAULT 0;
    totalMinCshMrgnReqAmt     NUMBER(17, 3) DEFAULT 0;
    tolarencePercentage       NUMBER(17, 3) DEFAULT 0;
    tolarenceWarnPtage        NUMBER(17, 3) DEFAULT 0;
    permCashSfallAmt          NUMBER(17, 3) DEFAULT 0;
    permCashSfallWarnAmt      NUMBER(17, 3) DEFAULT 0;
    totalCashDepBalAmt        NUMBER(17, 3) DEFAULT 0;
    cashTopUpReqToMeetAmt     NUMBER(17, 3) DEFAULT 0;
    cashTopUpReqAmt           NUMBER(17, 3) DEFAULT 0;
    avblCashAmt               NUMBER(17, 3) DEFAULT 0;
    tempCheckAmt              NUMBER(17, 3) DEFAULT 0;
    topUpApproachingFlag      VARCHAR2(1);
    minCshMrgnReqMetFlag      VARCHAR2(1);
    cashTopupReqFlag          VARCHAR2(1);
    avblCashFlag              VARCHAR2(1);
    v_count                   INT;
    v_bb_flag                 VARCHAR2(1);
    v_clt_lnk_bal             SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_ANTICIPATED_AMT%TYPE;
    collateralIDList          CollateralIDType;
    collateralHOIDList        CollateralIDType;
    collateralFOIDList        CollateralIDType;
    collateralCHIDList        CollateralIDType;


    stopLossPctList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_PCT%TYPE;
    stopLossCcyList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_CODE%TYPE;
    stopLossCcyAmtList        SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_AMT%TYPE;
    stopLossFlagList          SCBT_R_CUST_PRODUCT_LIMIT.Stop_Loss_Appl_Flag%TYPE;

    custStopLossPctList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_PCT%TYPE;
    custStopLossCcyList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_CODE%TYPE;
    custStopLossCcyAmtList        SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_AMT%TYPE;

    custLevelLTVAmt               number(17,3);
    custLevelShortfallAmt         number(17,3);
    custLevelLTVPercentage        number(17,3);

    facilityLevelReq              boolean;
    stopLossReqForCust            varchar2(1);
    stopLossReqForCustAmt         number(17,3);
    stopLossReqForCustPct         number(17,3);

    facilityLevelLTVAmt               number(17,3);
    facilityLevelShortfallAmt         number(17,3);
    facilityLevelLTVPercentage        number(17,3);

    custLevelReq                      boolean;
    stopLossReqForFacility            varchar2(1);
    stopLossReqForFacilityAmt         number(17,3);
    stopLossReqForFacilityPct         number(17,3);
    limitIDList                       SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
    limitCcyList                       SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;

    txnRefIDList              TxnRefIDType;
    txnRecIDList              TXNRecIDListType;
    cashMarginCcyList         TXNCashMarginCcyList;
    cashMarginCcyAmtList      TXNCashMarginAmtList;
    cashMarginAdjAmtList      TXNCashMarginAdjAmtList;
    cashMarginAdjFactorList   TXNCashMarginFactorList;
    cashMarginOriginAmtList   TXNCashMarginOriginAmtList;
    txnDealStepIDList         DealStepIDListType;
    txnStepCodeList           TXNStepCodeListType;
    step_code_list            StepCodePCType;
    prodLimitIdList           ProductLimitIdType;
     tempProdLimitIdList     ProductLimitIdType;

    sourcetypelist            strArray;
    pReturnValue              number;
    groupID                   varchar2(16);
    limitListCount            number;
    existingProdLimits        t_array;
    totalShortfallAmount       number(17,3);
    allowCalc                  varchar2(1);
    v_shortfall_offset             SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
    v_overdraft_facility_accno     SCBT_R_CUST_PRODUCT_LIMIT.Overdraft_Facility_Accno%TYPE;
    v_lnk_ccy_amt                  SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_ANTICIPATED_AMT%TYPE;
    v_lnk_ccy_code                 SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_CODE%TYPE;
    v_lnk_account_no               SCBT_T_CUST_ACC_SMRY_MST.Acc_No%TYPE;
    v_limit_id                     SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
    ltvFormula                    varchar2(5);


  BEGIN
    custLevelLTVAmt               := 0;
    custLevelShortfallAmt         := 0;
    custLevelLTVPercentage        := 0;
    stopLossReqForCustAmt         := 0;
    stopLossReqForCustPct         := 0;
    facilityLevelLTVAmt           := 0;
    facilityLevelShortfallAmt     := 0;
    facilityLevelLTVPercentage    := 0;
    stopLossReqForFacilityAmt     := 0;
    stopLossReqForFacilityPct     := 0;
    custLevelReq                  := false;
    facilityLevelReq              := false;
    pReturnValue                  := '0001';
    totalShortfallAmount:=0;
    limitListCount                := 0;
    allowCalc                     := 'Y';

    BEGIN
      SELECT OVERALL_EXP_CURRENCY,LTV_FORMULA
        INTO custExpCcy,ltvFormula
        FROM scbt_r_party_mst
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND party_id = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;

    -- CHECK WHETHER THE FACILITY ID IS CLIENT BORRWOING BASE --
    BEGIN

         v_bb_flag  := 'N';

         SELECT COUNT(*)
           INTO v_count
           FROM SCBT_T_PROD_LIMIT_REQ_LOG R,
                    SCBT_R_CUST_PRODUCT_LIMIT S,
                      SCBT_T_PROD_LIMIT_REQ_LOG_DTL D
          WHERE R.BANK_GROUP_CODE  = bankGroupCode
            AND R.CTY_CODE                   = ctyCode
            AND D.BANK_GROUP_CODE  = R.BANK_GROUP_CODE
            AND D.CTY_CODE                   = R.CTY_CODE
            AND R.BUS_EVENT_REF_NO = dealStepID
            AND R.REQ_TYPE_CODE    = 'NEW'
            AND R.REQ_STATUS_CODE  = 'PEND'
            AND R.INIT_REQ_ID        = D.INIT_REQ_ID
            AND S.BANK_GROUP_CODE  = R.BANK_GROUP_CODE
            AND S.CTY_CODE         = R.CTY_CODE
            AND S.LIMIT_ID                   = D.PROD_LIMIT_ID
            AND S.SHORTFALL_OFFSET IN ('CBB','GBB');

         IF (v_count > 0) THEN

             v_bb_flag    := 'Y';

             v_clt_lnk_bal := NVL(SCBF_GET_CLIENT_ACC_BAL(bankGroupCode,
                                                          ctyCode,
                                                          dealStepId),0);

         END IF;

         EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 v_bb_flag := 'N';
         END;

    -- Customer Level Stop Loss Settings

    BEGIN
         SELECT NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),NVL(LOAN_TO_VALUE_PCT,0)
         INTO custStopLossPctList,custStopLossCcyList,custStopLossCcyAmtList,custLevelLTVPercentage
         FROM SCBT_R_PARTY_MST
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;


    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;

    -- Customer Level Stop Loss Value Calculations
    if (nvl(custStopLossPctList,0) = 0 and nvl(custStopLossCcyAmtList,0) = 0) then
         custLevelReq := false;
    else
         custLevelReq := true;
    end if;

    if (custLevelReq = true) then

       if(custLevelLTVPercentage <> 0) then

       if(ltvFormula ='LTV2') then
           totalShortfallAmount:=((SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')
                                  - SCBF_C_CUST_LEVEL_CASH_MARGIN(custId,custExpCcy,bankGroupCode,ctyCode,'S')
                                  - SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId))/custLevelLTVPercentage)*100
                                  - SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV');

       elsif(ltvFormula ='LTV3') then
           totalShortfallAmount:=(SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')/custLevelLTVPercentage)*100
                                            - (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV')
                                            + SCBF_C_CUST_LEVEL_CASH_MARGIN(custId,custExpCcy,bankGroupCode,ctyCode,'S')
                                            + SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId));

       else
           totalShortfallAmount:=(SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')/custLevelLTVPercentage)*100
                                            - (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV') +
                                            SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId));

       end if;

           if(totalShortfallAmount < 0) then
              totalShortfallAmount := 0;
           end if;

       end if;

       custLevelLTVAmt := SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','LTV');

       if(custStopLossPctList > 0) then
          if( custLevelLTVAmt > custStopLossPctList ) then
              stopLossReqForCust := 'Y';
              stopLossReqForCustAmt := nvl(totalShortfallAmount,0);
          --REFTOPUPREQAMT
          elsif((custLevelLTVPercentage<custLevelLTVAmt) and (custLevelLTVAmt<custStopLossPctList)) then
              stopLossReqForCust := 'N';
              stopLossReqForCustAmt := nvl(totalShortfallAmount,0);
          elsif(custLevelLTVPercentage>custLevelLTVAmt) then
              stopLossReqForCust := 'N';
              stopLossReqForCustAmt :=0;

           end if;
       elsif(custStopLossCcyAmtList > 0) then

           custLevelShortfallAmt:=totalShortfallAmount;
           custStopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                ctyCode,
                                                custStopLossCcyList,
                                                custStopLossCcyAmtList,
                                                custExpCcy,
                                                'Y'),
                                                 0);

           --REFTOPUPREQAMT
           if( custLevelShortfallAmt > custStopLossCcyAmtList ) then
                   stopLossReqForCust := 'Y';
                   stopLossReqForCustAmt := nvl(custLevelShortfallAmt,0) ;
           elsif((0< custLevelShortfallAmt) and (custLevelShortfallAmt < custStopLossCcyAmtList)) then
                   stopLossReqForCust := 'N';
                   stopLossReqForCustAmt := nvl(custLevelShortfallAmt,0) ;
           elsif(custLevelShortfallAmt=0) then
                   stopLossReqForCust := 'N';
                   stopLossReqForCustAmt :=0;
          end if;

       end if;

       --REFTOPUPREQAMT
/*        if( totalShortfallAmount > 0 ) then
              stopLossReqForCust := 'Y';
              stopLossReqForCustAmt := nvl(totalShortfallAmount,0) ;
        else
            stopLossReqForCust := 'N';
        end if;*/

       BEGIN

       if(dealStepID != 'N' ) then
              DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE CUST_ID = custId and TOPUP_LEVEL = 'C'/*and DEAL_STEP_ID = dealStepID*/;
       end if;

       stopLossReqForCustPct:=0;

       IF v_bb_flag = 'N' THEN

           SCBP_P_INSERT_INTO_STOP_LOSS
                (pReturnValue,
                 bankGroupCode,
                 ctyCode,
                 '',
                 dealStepID,
                 custId,
                 'C',
                 '',
                 '',
                 '',
                 '',
                 custLevelLTVAmt,
                 custExpCcy,
                 totalShortfallAmount,
                 stopLossReqForCust,
                 custExpCcy,
                 stopLossReqForCustAmt,
                 stopLossReqForCustPct,
                 populateHist,
                 '',
                 '');
       END IF;

       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;

    -- COCOACR-11APR2013
    ELSE
       if(dealStepID != 'N' ) then
              DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE = ctyCode AND CUST_ID = custId and TOPUP_LEVEL = 'C'/*and DEAL_STEP_ID = dealStepID*/;
       end if;

    end if;

    -- Find the Transactions for the Deal Step ID
     BEGIN
         SELECT TH.TXN_REF_ID,TH.TXN_REC_ID,
                           TH.TXN_CCY_CODE AS TXN_CCY,
                           --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                           DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)) AS OUTSTANDING,
                           TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                           --NVL(TH.CASH_MARGIN_CCY_AMT,0) - NVL(TH.CM_CCY_RELEASE_AMT,0) AS CASH_MARGIN,
                           (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                           ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                           ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                           TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                           TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                           TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                           DH.STEP_STATUS_CODE AS STEP_STATUS_CODE,
                           DH.Deal_Step_Id AS DEAL_STEP_ID,
                           TH.txn_step_code,
                           TH.PROD_LIMIT_ID
                            BULK COLLECT INTO
                             txnRefIDList,
                             txnRecIDList,
                             txnCcyList,
                             txnCcyAmtList,
                             cashMarginCcyList,
                             cashMarginCcyAmtList,
                             cashMarginAdjAmtList,
                             cashMarginAdjFactorList,
                             cashMarginOriginAmtList,
                             step_code_list,
                             txnDealStepIDList,
                             txnStepCodeList,
                             prodLimitIdList
                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                    WHERE TH.BANK_GROUP_CODE = bankGroupCode
                           AND TH.CTY_CODE = ctyCode
                           AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                           AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                           AND TH.CUST_ID=DH.CUST_ID
                           AND TH.DEAL_ID=DH.DEAL_ID
                           AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT','CSETT','RELC')  --REF10DEC2012 --COCOACR_10062013
                           AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                           AND DH.STEP_STATUS_CODE IN( '02','10','14')
                           AND TH.cust_id = custid
                           AND TH.DEAL_ID = dealId  -- COCOAPERF_12122012
                           AND TH.DEAL_STEP_ID=dealStepID
                           AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' --COCOAREF_16012013
                           --Added below condition to consider rollover transaction only...Change date 13-Jul-2012
                           AND NVL(TH.TXN_STATUS_CODE,'01')<>'11';

       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;



   if (prodLimitIdList.COUNT = 0) then

      BEGIN
           SELECT PROD_LIMIT_ID
           BULK COLLECT INTO prodLimitIdList
                  FROM SCBT_T_DEAL_REGISTER_HDR_HST
                  WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId -- COCOAPERF_12122012
                    AND BUSINESS_TYPE = 'FLC'
                   AND DEAL_ID = dealId;

      EXCEPTION
                WHEN NO_DATA_FOUND THEN
                NULL;
       END;

    end if;


   if(dealStepID != 'N' and prodLimitIdList.COUNT > 0) then
            DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE=bankGroupCode and CTY_CODE=ctyCode
            AND CUST_ID = custId and DEAL_STEP_ID = dealStepID and TOPUP_LEVEL != 'C';
    end if;


    -- Facility Level Stop Loss Settings
   FOR i in 1..prodLimitIdList.COUNT LOOP


       facilityLevelLTVAmt := 0;
       facilityLevelShortfallAmt := 0;
       stopLossReqForFacility := 0;
       stopLossReqForFacilityAmt := 0;
       stopLossReqForFacilityPct := 0;


    BEGIN
         SELECT LIMIT_ID,LIMIT_CCY_CODE,NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),STOP_LOSS_APPL_FLAG,NVL(LOAN_TO_VALUE_PCT,0)
         INTO limitIDList,limitCcyList,stopLossPctList,stopLossCcyList,stopLossCcyAmtList,stopLossFlagList,facilityLevelLTVPercentage
         FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND CUST_ID = custId
         and LIMIT_id = prodLimitIdList(i);

    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;

    if(stopLossFlagList = 'G') then
      BEGIN
             SELECT FACILITY_GRP_ID
             INTO groupID
             FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId -- COCOAPERF_12122012
               --AND PROD_LIMIT_IDS LIKE '%' ||prodLimitIdList(i) ||'%'
               AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || prodLimitIdList(i) || ',', 1, 1 ) =( ',' || prodLimitIdList(i) || ',')
                AND GROUP_TYPE = 'LTV';



            SELECT NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),NVL(LOAN_TO_VALUE_PCT,0)
               INTO stopLossPctList,stopLossCcyList,stopLossCcyAmtList,facilityLevelLTVPercentage
               FROM SCBT_R_CUST_FACILITY_GRP
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId
               and FACILITY_GRP_ID = groupID
               AND GROUP_TYPE = 'LTV';

       EXCEPTION
                WHEN NO_DATA_FOUND THEN
                groupID := '';
                NULL;
       END;
    end if;

    -- Check if dupklicate faQcility level or group level

     if ((stopLossFlagList ='F' or stopLossFlagList = 'G') and i > 1) then

       for j in 1..existingProdLimits.COUNT LOOP
           if(existingProdLimits(j) = limitIDList) then
             allowCalc :='N';
           else
             allowCalc :='Y';
           end if;
       END LOOP;

     end if;

    -- Facility / Txn Level Stop Loss Value Calculations
    if (nvl(stopLossPctList,0) = 0 and nvl(stopLossCcyAmtList,0) = 0) then
         facilityLevelReq := false;
    else
         facilityLevelReq := true;
    end if;

    if (facilityLevelReq = true and allowCalc ='Y') then

             if(facilityLevelLTVPercentage <> 0) then
               if(stopLossFlagList = 'F') then
               limitListCount := limitListCount + 1;
               existingProdLimits(limitListCount) := limitIDList;

               -- Changes done by Anbu on 2nd Nov 2012


                 if (ltvFormula = 'LTV2') then
                     totalShortfallAmount:=((SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')
                                            - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId)   -- REF05122012
                                            - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'))/facilityLevelLTVPercentage)*100
                                                  - SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV');

                 elsif(ltvFormula = 'LTV3') then
                     totalShortfallAmount:=(SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')/facilityLevelLTVPercentage)*100
                                                  - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV')
                                                  + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId)  -- REF05122012
                                                  + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'));

                 else
                     totalShortfallAmount:=(SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')/facilityLevelLTVPercentage)*100
                                                  - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV')+
                                                  SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'));

                 end if;

  /*             totalShortfallAmount:=(((SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')
                                             - (SCBF_C_GET_TOT_CASH_MARGIN(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S'))
                                             - (SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F')))/facilityLevelLTVPercentage * 100)
                                             - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV')));
  */

              elsif(stopLossFlagList = 'T') then

                  BEGIN

                        if (ltvFormula = 'LTV2') then
                              totalShortfallAmount:= ((SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')
                                                            - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T')
                                                            -- - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId))/facilityLevelLTVPercentage)*100    -- REF05122012
                                                            - SCBF_C_TXN_LEVEL_CASH_MARGIN(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId,txnRefIDList(i),txnRecIDList(i)))/facilityLevelLTVPercentage)*100    -- REF_CR03012013
                                                            - SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV');
                        elsif (ltvFormula = 'LTV3') then
                              totalShortfallAmount:= (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')/facilityLevelLTVPercentage)*100
                                                            - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV')
                                                            --+ SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId)    -- REF05122012
                                                            + SCBF_C_TXN_LEVEL_CASH_MARGIN(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId,txnRefIDList(i),txnRecIDList(i))     --REF_CR03012013
                                                            + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'));

                        else
                              totalShortfallAmount:= (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')/facilityLevelLTVPercentage)*100
                                                            - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV')+
                                                            SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'));

                        end if;
                  EXCEPTION
                           WHEN OTHERS THEN
                           NULL;
                  END;
               elsif(stopLossFlagList = 'G') then
               limitListCount := limitListCount + 1;
               existingProdLimits(limitListCount) := limitIDList;

                   if (ltvFormula = 'LTV2') then
                   totalShortfallAmount:= ((SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','OS')
                                          - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,custExpCcy,bankGroupCode,ctyCode,'S',custId)    -- REF05122012
                                          - SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TOP'))/facilityLevelLTVPercentage)*100
                                          - SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TGCV');

                   elsif (ltvFormula = 'LTV3') then
                   totalShortfallAmount:= (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','OS')/facilityLevelLTVPercentage)*100
                                                - (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TGCV')
                                                + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,custExpCcy,bankGroupCode,ctyCode,'S',custId)  -- REF05122012
                                                + SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TOP'));


                   else
                   totalShortfallAmount:= (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','OS')/facilityLevelLTVPercentage)*100
                                                - (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TGCV')+
                                                SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','TOP'));

                   end if;
                end if;
              else
               totalShortfallAmount := 0;
              end if;


              if(totalShortfallAmount < 0) then
                totalShortfallAmount := 0;
              end if;

       -- Facility Level  or Txn Level
       -- Always calculate LTV %

       if(stopLossFlagList = 'G') then
             facilityLevelLTVAmt := SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'A','LTV');

       elsif(stopLossFlagList = 'F') then
             facilityLevelLTVAmt := SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','LTV');

       elsif(stopLossFlagList = 'T') then
             BEGIN
             facilityLevelLTVAmt := SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                              txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','H',dealStepId,
                                              cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'LTV');

             EXCEPTION
                   WHEN OTHERS THEN
                   NULL;
             END;

       end if;


       if(stopLossPctList > 0) then


          if( facilityLevelLTVAmt > stopLossPctList ) then
              stopLossReqForFacility := 'Y';
          --REFTOPUPREQAMT
/*             facilityLevelShortfallAmt := totalShortfallAmount;
               stopLossReqForFacilityAmt := facilityLevelShortfallAmt;*/
               stopLossReqForFacilityAmt := totalShortfallAmount;
          elsif((facilityLevelLTVPercentage < facilityLevelLTVAmt) and (facilityLevelLTVAmt < stopLossPctList)) then
               stopLossReqForFacilityAmt :=totalShortfallAmount;
               stopLossReqForFacility := 'N';
          elsif(facilityLevelLTVPercentage > facilityLevelLTVAmt) then
               stopLossReqForFacilityAmt :=0;
               stopLossReqForFacility := 'N';
          end if;

       elsif(stopLossCcyAmtList > 0) then

          if(stopLossFlagList = 'F') then

               facilityLevelShortfallAmt := totalShortfallAmount;
               stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                ctyCode,
                                                stopLossCcyList,
                                                stopLossCcyAmtList,
                                                limitCcyList,
                                                'Y'),
                                                 0);

          elsif(stopLossFlagList = 'G') then

              facilityLevelShortfallAmt := totalShortfallAmount;
              stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                ctyCode,
                                                stopLossCcyList,
                                                stopLossCcyAmtList,
                                                custExpCcy,
                                                'Y'),
                                                 0);


          elsif(stopLossFlagList = 'T') then

               facilityLevelShortfallAmt := totalShortfallAmount;
               stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                ctyCode,
                                                stopLossCcyList,
                                                stopLossCcyAmtList,
                                                txnCcyList(i),
                                                'Y'),
                                                 0);


          end if;

          if( facilityLevelShortfallAmt > stopLossCcyAmtList ) then
              stopLossReqForFacility := 'Y';
              stopLossReqForFacilityAmt := nvl(facilityLevelShortfallAmt,0);
          --REFTOPUPREQAMT
          elsif((0<facilityLevelShortfallAmt) and (facilityLevelShortfallAmt < stopLossCcyAmtList)) then
              stopLossReqForFacility := 'N';
              stopLossReqForFacilityAmt := nvl(facilityLevelShortfallAmt,0);
          elsif(facilityLevelShortfallAmt=0) then
              stopLossReqForFacility := 'N';
              stopLossReqForFacilityAmt := 0;
          end if;

       end if;

      --REFTOPUPREQAMT
/*       if( totalShortfallAmount > 0 ) then
              stopLossReqForFacility := 'Y';
              stopLossReqForFacilityAmt := nvl(totalShortfallAmount,0);
      else
          stopLossReqForFacility := 'N';
      end if;*/

      stopLossReqForFacilityPct:=0;

       IF v_bb_flag = 'N' THEN

           if(stopLossFlagList = 'F') then

             SCBP_P_INSERT_INTO_STOP_LOSS(p_ret_code,
                                                bankGroupCode,
                                               ctyCode,
                                               '',
                                               dealStepID,
                                               custId,
                                               stopLossFlagList,
                                               '',
                                               '',
                                               limitIDList,
                                               '',
                                               facilityLevelLTVAmt,
                                               limitCcyList,
                                               totalShortfallAmount,
                                               stopLossReqForFacility,
                                               limitCcyList,
                                               stopLossReqForFacilityAmt,
                                               stopLossReqForFacilityPct,
                                               populateHist,
                                               '',
                                               '');
            elsif (stopLossFlagList = 'G') then
                   SCBP_P_INSERT_INTO_STOP_LOSS(p_ret_code,
                                               bankGroupCode,
                                               ctyCode,
                                               '',
                                               dealStepID,
                                               custId,
                                               stopLossFlagList,
                                               '',
                                               '',
                                               '',
                                               groupID,
                                               facilityLevelLTVAmt,
                                               custExpCcy,
                                               totalShortfallAmount,
                                               stopLossReqForFacility,
                                               custExpCcy,
                                               stopLossReqForFacilityAmt,
                                               stopLossReqForFacilityPct,
                                               populateHist,
                                               '',
                                               '');
            elsif (stopLossFlagList = 'T') then
            BEGIN
             SCBP_P_INSERT_INTO_STOP_LOSS(p_ret_code,
                                                bankGroupCode,
                                               ctyCode,
                                               '',
                                               dealStepID,
                                               custId,
                                               stopLossFlagList,
                                               txnRefIDList(i),
                                               txnRecIDList(i),
                                               limitIDList,
                                               '',
                                               facilityLevelLTVAmt,
                                               txnCcyList(i),
                                               totalShortfallAmount,
                                               stopLossReqForFacility,
                                               txnCcyList(i),
                                               stopLossReqForFacilityAmt,
                                               stopLossReqForFacilityPct,
                                               populateHist,
                                               txnStepCodeList(i),
                                               '');
             EXCEPTION
              WHEN NO_DATA_FOUND THEN
                NULL;
            END;

            end if;

        END IF;

    end if;

    END LOOP;




    -- Shorfall Applicable for Cash Only Offset

    sfallApplForCHAmt := NVL(collateralCashSfallAmount, 0) +
                         NVL(shortfallHONotOffsetAmt, 0);


    -- All non Hedge Offset Customer Accounts
    BEGIN
      SELECT NVL(acc_ccy_anticipated_amt,0), acc_ccy_anticipated_ccy BULK COLLECT
        INTO antiACBalCcyCstBalAmtList, antiACBalCcyCstBalList
        FROM (SELECT *
                FROM scbt_t_cust_acc_smry_mst
               WHERE cust_id = custId
               AND BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode -- COCOAPERF_12122012
              MINUS
              SELECT *
                FROM scbt_t_cust_acc_smry_mst
               WHERE cust_id = custId
               AND BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode   -- COCOAPERF_12122012
                 AND acc_no  IN (SELECT OVERDRAFT_FACILITY_ACCNO
                                  FROM SCBT_R_CUST_PRODUCT_LIMIT
                                 WHERE cust_id = custId
                                 AND BANK_GROUP_CODE = bankGroupCode --COCOAPERFTUNE_003
                                 AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
                                 AND shortfall_offset = 'HO'));
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    IF (antiACBalCcyCstBalList.COUNT > 0) THEN
      FOR j IN 1 .. antiACBalCcyCstBalList.COUNT LOOP
        custAccBalanceAmt := custAccBalanceAmt + NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                          ctyCode,
                                                                          antiACBalCcyCstBalList(j),
                                                                          antiACBalCcyCstBalAmtList(j),
                                                                          custExpCcy,
                                                                          'Y'),
                                                     0);
      END LOOP;
    END IF;



    -- Param Values for Tolarence Percentage and Tolarence Warning Percentage

    tolarencePercentage := Scbf_C_Get_Param_Data('CP01',
                                                 '01',
                                                 'SCB',
                                                 '*',
                                                 custId,
                                                 '*',
                                                 '*',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '');

    tolarenceWarnPtage  := Scbf_C_Get_Param_Data('CP01',
                                                 '02',
                                                 'SCB',
                                                 '*',
                                                 custId,
                                                 '*',
                                                 '*',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '',
                                                 '');

    BEGIN
         SELECT  SUM(NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                            ctyCode,
                            LIMIT_CCY_CODE,
                            LIMIT_CCY_ACTIVE_AMT,
                            custExpCcy,
                            'Y'),0)) INTO totalNonCleanExpAmt FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND cust_id = custId
         AND limit_cat_code ='O';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        NULL;
    END;


    permCashSfallAmt     := NVL(totalNonCleanExpAmt, 0) *
                            (NVL(tolarencePercentage, 0) / 100);
    permCashSfallWarnAmt := NVL(totalNonCleanExpAmt, 0) *
                            (NVL(tolarenceWarnPtage, 0) / 100);



    totalMinCshMrgnReqAmt := totalMinCashMarginReqAmt;

    -- Total Cash And Deposit Balances of Customer
    --Below changes made for SHORTFALL_OFFSET 'CBB' START
    BEGIN

     /*
      SELECT DISTINCT LD.PROD_LIMIT_ID into v_limit_id
      FROM SCBT_T_PROD_LIMIT_REQ_LOG L, SCBT_T_PROD_LIMIT_REQ_LOG_DTL LD
       where L.BANK_GROUP_CODE  = bankGroupCode
             AND L.CTY_CODE = ctyCode
             AND LD.BANK_GROUP_CODE = L.BANK_GROUP_CODE
             AND LD.CTY_CODE = L.CTY_CODE
             AND LD.INIT_REQ_ID = L.INIT_REQ_ID
             AND L.BUS_EVENT_REF_NO =dealStepID
             AND LD.DEAL_ID = dealId;
    */

    /*
      SELECT DISTINCT TXN_HIST.PROD_LIMIT_ID into v_limit_id
         FROM SCBT_T_TXN_HST TXN_HIST
         where TXN_HIST.BANK_GROUP_CODE  = bankGroupCode
             AND TXN_HIST.CTY_CODE = ctyCode
             AND TXN_HIST.CUST_ID = custId
             AND TXN_HIST.DEAL_ID = dealId
             AND TXN_HIST.DEAL_STEP_ID = dealStepID;


       SELECT nvl(SHORTFALL_OFFSET, ''), OVERDRAFT_FACILITY_ACCNO
        into v_shortfall_offset, v_overdraft_facility_accno
          from SCBT_R_CUST_PRODUCT_LIMIT
             where bank_group_code=bankGroupCode
             AND cty_code = ctyCode
             AND cust_id = custId
             AND LIMIT_ID = v_limit_id
             AND limit_cat_code ='O';
             --and overdraft_facility_accno is not null;
        */

      SELECT nvl(SHORTFALL_OFFSET, ''), OVERDRAFT_FACILITY_ACCNO
        into v_shortfall_offset, v_overdraft_facility_accno
          from SCBT_R_CUST_PRODUCT_LIMIT
             where bank_group_code=bankGroupCode
             AND cty_code = ctyCode
             AND cust_id = custId
             --AND LIMIT_ID = v_limit_id
             AND LIMIT_ID in (
                 SELECT DISTINCT TXN_HIST.PROD_LIMIT_ID
                 FROM SCBT_T_TXN_HST TXN_HIST
                 where TXN_HIST.BANK_GROUP_CODE  = bankGroupCode
                     AND TXN_HIST.CTY_CODE = ctyCode
                     AND TXN_HIST.CUST_ID = custId
                     AND TXN_HIST.DEAL_ID = dealId
                     AND TXN_HIST.DEAL_STEP_ID = dealStepID
                     and TXN_HIST.TXN_STATUS_CODE <>'08'
             )
             AND limit_cat_code ='O';

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
          v_shortfall_offset := NULL;
          v_overdraft_facility_accno := NULL;
    END;

    IF v_shortfall_offset IS NOT NULL AND v_shortfall_offset = 'CBB' AND v_overdraft_facility_accno IS NOT NULL THEN

       FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_overdraft_facility_accno))) LOOP
              v_lnk_ccy_code   := SUBSTR(c1.column_value,1,3);
              v_lnk_account_no := SUBSTR(c1.column_value,5);
         SELECT SUM(A.ACC_CCY_ANTICIPATED_AMT)
                     INTO v_lnk_ccy_amt
                     FROM SCBT_T_CUST_ACC_SMRY_MST A,
                          SCBT_R_CUST_ACCT_MAINTENANCE M
                    WHERE A.BANK_GROUP_CODE = bankGroupCode
                      AND A.CTY_CODE        = ctyCode
                      AND A.CUST_ID         = custId
                      AND A.ACC_NO          = v_lnk_account_no
                      AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
                      AND M.CTY_CODE        = A.CTY_CODE
                      AND M.CUST_ID         = A.CUST_ID
                      AND M.ACC_NO          = A.ACC_NO
                      AND A.ACC_CCY_CODE    = v_lnk_ccy_code
                      AND M.ACC_CCY_CODE    = A.ACC_CCY_CODE --sak acc cur code added
                      AND M.INCLUDE_FOR_CASH_COLLATERAL = 'Y';


                   IF v_lnk_ccy_amt > 0 THEN

                      IF v_lnk_ccy_code <> custExpCcy THEN

                         totalCashDepBalAmt := totalCashDepBalAmt + NVL(Scbf_Tls_Exch_Rate(bankGroupCode, -- BANK GROUP CODE
                                                                                           ctyCode,        -- COUNTRY CODE
                                                                                       v_lnk_ccy_code,    -- FROM CURR CODE
                                                                                 v_lnk_ccy_amt,     -- FROM AMOUNT
                                                                                       custExpCcy,  -- TO CURR CODE
                                                                                 'N'),0);           -- ROUNG FLAG

                      ELSE

                         totalCashDepBalAmt := totalCashDepBalAmt + v_lnk_ccy_amt;

                      END IF;

                   END IF;
            END LOOP;

                 --Below changes made for SHORTFALL_OFFSET 'CBB' END
    ELSE

        BEGIN
          SELECT acc_ccy_anticipated_ccy, NVL(acc_ccy_anticipated_amt, 0) BULK COLLECT
            INTO custAccountBalCcyList, custAccountBalAmtList
            FROM scbt_t_cust_acc_smry_mst
           WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
             AND acc_ccy_anticipated_amt > 0
             AND acc_no NOT IN (SELECT NVL(overdraft_facility_accno,' ')
                                  FROM SCBT_R_CUST_PRODUCT_LIMIT
                                 WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                                   AND shortfall_offset = 'HO')


             AND acc_no IN
                 (SELECT acc_no
                    FROM scbt_r_cust_acct_maintenance
                   WHERE bank_group_code = bankGroupCode AND cty_code = ctyCode AND cust_id = custId
                     AND UPPER(NVL(include_for_cash_collateral,'N')) = 'Y');


        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            NULL;
        END;

        IF (custAccountBalCcyList.COUNT > 0) THEN
          FOR j IN 1 .. custAccountBalCcyList.COUNT LOOP
            totalCashDepBalAmt := totalCashDepBalAmt +
                                  Scbf_Round_Amount(bankGroupCode,
                                                    custExpCcy,
                                                    NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                                             ctyCode,
                                                                             custAccountBalCcyList(j),
                                                                             custAccountBalAmtList(j),
                                                                             custExpCcy,
                                                                             'Y'),
                                                        0));
          END LOOP;
        END IF;

    END IF;

    -- Top Up Approaching Flag

    IF (ABS(shortfallForTopup) > permCashSfallWarnAmt) THEN
      topUpApproachingFlag := 'Y';
    ELSE
      topUpApproachingFlag := 'N';
    END IF;

    IF (tolarenceWarnPtage = 0) THEN
      topUpApproachingFlag := 'A';
    END IF;

    -- Minimum Cash Margin Requirement Met


    IF ((NVL(totalMinCshMrgnReqAmt,0) + NVL(SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId),0)) <= totalCashDepBalAmt) THEN
      minCshMrgnReqMetFlag := 'Y';
    ELSE
      minCshMrgnReqMetFlag := 'N';
    END IF;

    -- Total Cash Topup Required to meet cash margin requriement

    IF (minCshMrgnReqMetFlag = 'N') THEN
      cashTopUpReqToMeetAmt := (NVL(totalMinCshMrgnReqAmt, 0) + NVL(SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId),0)) -
                               NVL(totalCashDepBalAmt, 0);
    ELSE
      cashTopUpReqToMeetAmt := 0;
    END IF;

    -- Cash Topup Required



    IF (NVL(minCshMrgnReqMetFlag, 0) = 'N' OR
       (ABS(NVL(shortfallForTopup, 0)) > NVL(permCashSfallAmt, 0))) THEN
      cashTopupReqFlag := 'Y';
    ELSE
      cashTopupReqFlag := 'N';
    END IF;

    -- Amount of Cash Topup Required
 -- Calculation has been changed on 05-APR-2011 based on Client Position Model Version 13.xlsx
--     IF (ABS(NVL(amtOfCHShortfallAmt, 0)) > NVL(permCashSfallAmt, 0)) THEN
--       IF (ABS(NVL(amtOfCHShortfallAmt, 0)) < NVL(cashTopUpReqToMeetAmt, 0)) THEN
--         cashTopUpReqAmt := NVL(cashTopUpReqToMeetAmt, 0);
--       ELSE
--         cashTopUpReqAmt := ABS(NVL(amtOfCHShortfallAmt, 0));
--       END IF;
--     ELSE
--       cashTopUpReqAmt := NVL(permCashSfallAmt, 0);
--     END IF;

 /*   IF (ABS(NVL(shortfallForTopup, 0)) > NVL(permCashSfallAmt, 0)) THEN
        cashTopUpReqAmt := ABS(shortfallForTopup) + NVL(cashTopUpReqToMeetAmt, 0);
    ELSE*/
        cashTopUpReqAmt := NVL(cashTopUpReqToMeetAmt, 0);
/*    END IF;*/




    -- Cash Available Flag and Cash Available

    IF (NVL(sfallApplForCHAmt, 0) > NVL(totalMinCshMrgnReqAmt, 0)) THEN
      tempCheckAmt := NVL(sfallApplForCHAmt, 0);
    ELSE
      tempCheckAmt := NVL(totalMinCshMrgnReqAmt, 0);
    END IF;

    IF (NVL(shortfallForTopup, 0) < 0) THEN
      avblCashFlag := 'N';
    ELSE
      IF ((ABS(NVL(custAccBalanceAmt, 0)) - NVL(tempCheckAmt, 0)) > 0) THEN
        avblCashFlag := 'Y';
        avblCashAmt  := ABS(NVL(custAccBalanceAmt, 0)) -
                        NVL(tempCheckAmt, 0);
      ELSE
        avblCashFlag := 'N';
      END IF;
    END IF;


    -- Total Customer Toup Amount

    totalCustomerTopUpAmt := NVL(SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId),0);


    -- Rounding to exposure currency

     permCashSfallAmt         := Scbf_Round_Amount(bankGroupCode,custExpCcy,permCashSfallAmt);
     totalMinCshMrgnReqAmt    := Scbf_Round_Amount(bankGroupCode,custExpCcy,totalMinCshMrgnReqAmt);
     totalCashDepBalAmt       := Scbf_Round_Amount(bankGroupCode,custExpCcy,totalCashDepBalAmt);
     cashTopUpReqToMeetAmt    := Scbf_Round_Amount(bankGroupCode,custExpCcy,cashTopUpReqToMeetAmt);
     cashTopUpReqAmt          := Scbf_Round_Amount(bankGroupCode,custExpCcy,cashTopUpReqAmt);
     avblCashAmt              := Scbf_Round_Amount(bankGroupCode,custExpCcy,avblCashAmt);



    -- Insert into Topup Summary Master and History Table Based on Transaction Flag

      IF (v_bb_flag = 'Y') then

          totalCashDepBalAmt  := Scbf_Round_Amount(bankGroupCode,custExpCcy,v_clt_lnk_bal);

      END IF;

      if (populateHist = 'Y') then

       BEGIN
            DELETE FROM SCBT_T_CUST_TOPUP_SMRY_HST
              WHERE  BANK_GROUP_CODE = bankGroupCode
                 AND CTY_CODE    = ctyCode
                 AND CUST_ID     = custId
                 AND DEAL_STEP_ID = dealStepID;
            EXCEPTION
            WHEN OTHERS THEN
            NULL;
       END;

       BEGIN
         INSERT INTO Scbt_t_Cust_Topup_Smry_Hst
              (BANK_GROUP_CODE,
               CTY_CODE,
               CUST_ID,
               OVERALL_EXP_CCY_CODE,
               ALLOWED_CASH_SHORTFALL_AMT,
               TOPUP_WARNING_FLAG,
               TOTAL_MIN_CMR_AMT,
               TOTAL_ACC_BAL_AMT,
               MIN_CMR_MET_FALG,
               CASH_REQ_TO_MIN_CMR_AMT,
               CASH_TOPUP_REQ_FALG,
               CASH_TOPUP_REQ_AMT,
               CASH_AVAIL_FALG,
               CASH_AVAIL_AMT,
               DEAL_STEP_ID,
               CUST_TOPUP_CCY_AMT)
            VALUES
              (bankGroupCode,
               ctyCode,
               custId,
               custExpCcy,
               permCashSfallAmt,
               topUpApproachingFlag,
               totalMinCshMrgnReqAmt,
               totalCashDepBalAmt,
               minCshMrgnReqMetFlag,
               cashTopUpReqToMeetAmt,
               cashTopupReqFlag,
               cashTopUpReqAmt,
               avblCashFlag,
               avblCashAmt,
               dealStepID,
               totalCustomerTopUpAmt
               );
             EXCEPTION
             WHEN OTHERS THEN
             NULL;
       END;

    End if;


    DELETE FROM SCBT_T_CUST_TOPUP_SMRY_MST
       WHERE bank_group_code = bankGroupCode
         AND cty_code = ctyCode
         AND cust_id = custId;

      INSERT INTO SCBT_T_CUST_TOPUP_SMRY_MST
        (BANK_GROUP_CODE,
         CTY_CODE,
         CUST_ID,
         OVERALL_EXP_CCY_CODE,
         ALLOWED_CASH_SHORTFALL_AMT,
         TOPUP_WARNING_FLAG,
         TOTAL_MIN_CMR_AMT,
         TOTAL_ACC_BAL_AMT,
         MIN_CMR_MET_FALG,
         CASH_REQ_TO_MIN_CMR_AMT,
         CASH_TOPUP_REQ_FALG,
         CASH_TOPUP_REQ_AMT,
         CASH_AVAIL_FALG,
         CASH_AVAIL_AMT,
         CUST_TOPUP_CCY_AMT)
      VALUES
        (bankGroupCode,
         ctyCode,
         custId,
         custExpCcy,
         permCashSfallAmt,
         topUpApproachingFlag,
         totalMinCshMrgnReqAmt,
         totalCashDepBalAmt,
         minCshMrgnReqMetFlag,
         cashTopUpReqToMeetAmt,
         cashTopupReqFlag,
         cashTopUpReqAmt,
         avblCashFlag,
         avblCashAmt,
         totalCustomerTopUpAmt);

    COMMIT;

    p_ret_code := '0000';

  END Scbp_P_Get_Coll_Position_Topup;






  PROCEDURE Scbp_P_Coll_Pos_Wrapper(p_ret_code    IN OUT VARCHAR2,
                                    bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    dealId        IN VARCHAR2,
                                    dealStepID    IN VARCHAR2,
                                    txnFlag       IN VARCHAR2,
                                    populateHist   IN VARCHAR2) IS
  BEGIN
    Scbp_P_Get_Coll_Position_Sfall(p_ret_code,
                                   bankGroupCode,
                                   ctyCode,
                                   custId,
                                   dealId,
                                   dealStepID,
                                   txnFlag,
                                   populateHist);

    Scbp_P_Get_Coll_Position_Topup(p_ret_code,
                                   bankGroupCode,
                                   ctyCode,
                                   custId,
                                   dealId,
                                   dealStepID,
                                   txnFlag,
                                   populateHist);
  END Scbp_P_Coll_Pos_Wrapper;



  PROCEDURE SCBP_P_LTV_CALCULATION(   bankGroupCode IN VARCHAR2
                                    , ctyCode       IN VARCHAR2
                                    , custId        IN VARCHAR2
                                    , levelFlag     IN VARCHAR2
                                    ) IS
  TYPE buCustIdType IS TABLE OF SCBT_R_PARTY_MST.PARTY_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitIDListType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE INDEX BY PLS_INTEGER;
  TYPE strArray IS VARRAY(9999999) OF VARCHAR2(20);
  TYPE TxnRefIDType IS TABLE OF Scbt_t_Txn_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNRecIDListType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNCashMarginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNCashMarginAdjAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNCashMarginFactorList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ADJ%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNCashMarginOriginAmtList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_ORIGN_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNCashMarginCcyList IS TABLE OF SCBT_T_TXN_MST.CASH_MARGIN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE TXNStepCodeListType IS TABLE OF SCBT_T_TXN_MST.Txn_Step_Code%TYPE INDEX BY PLS_INTEGER;
  TYPE ProductLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE INDEX BY PLS_INTEGER;
  TYPE TxnCcyAmtType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_NET_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE TxnCcyType IS TABLE OF Scbt_t_Txn_Mst.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;

  custExpCcy                    SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  bussDate                      SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
  bussDateAsString              VARCHAR2(10);
  recordID                      SCBT_T_IPS_CAGG_FEED_MST.REC_ID%TYPE;
  buCustIdList                  buCustIdType;
  limitIDList                   SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
  limitCcyList                  SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;
  stopLossPctList               SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_PCT%TYPE;
  stopLossCcyList               SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_CODE%TYPE;
  stopLossCcyAmtList            SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_AMT%TYPE;
  stopLossFlagList              SCBT_R_CUST_PRODUCT_LIMIT.Stop_Loss_Appl_Flag%TYPE;

  custStopLossPctList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_PCT%TYPE;
  custStopLossCcyList           SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_CODE%TYPE;
  custStopLossCcyAmtList        SCBT_R_CUST_PRODUCT_LIMIT.STOP_LOSS_CCY_AMT%TYPE;

  custLevelLTVAmt               number(17,3);
  custLevelShortfallAmt         number(17,3);
  custLevelLTVPercentage        number(17,3);

  facilityLevelReq              boolean;
  showLimitLevel                boolean;
  stopLossReqForCust            varchar2(1);
  stopLossReqForCustAmt         number(17,3);
  stopLossReqForCustPct         number(17,3);

  facilityLevelLTVAmt           number(17,3);
  facilityLevelShortfallAmt     number(17,3);
  facilityLevelLTVPercentage    number(17,3);

  custLevelReq                  boolean;
  stopLossReqForFacility        varchar2(1);
  stopLossReqForFacilityAmt     number(17,3);
  stopLossReqForFacilityPct     number(17,3);
  sourcetypelist                strArray;
  pReturnValue                  number;
  groupID                       varchar2(16);
  limitListCount                number;
  existingProdLimits            t_array;
  totalShortfallAmount          number(17,3);
  allowCalc                     varchar2(1);
  custOsAmt                     number(17,3);
  cashTopupAmt                  number(17,3);
  cashMarginAmt                 number(17,3);
  custLvlCntForLTV              number;
  txnRefIDList                  TxnRefIDType;
  txnRecIDList                  TXNRecIDListType;
  cashMarginCcyList             TXNCashMarginCcyList;
  cashMarginCcyAmtList          TXNCashMarginAmtList;
  cashMarginAdjAmtList          TXNCashMarginAdjAmtList;
  cashMarginAdjFactorList       TXNCashMarginFactorList;
  cashMarginOriginAmtList       TXNCashMarginOriginAmtList;
  txnStepCodeList               TXNStepCodeListType;
  prodLimitIdList               ProductLimitIdType;
  txnCcyAmtList                 TxnCcyAmtType;
  txnCcyList                    TxnCcyType;
  cashMarginPctList             SCBT_R_CUST_PRODUCT_LIMIT.CASH_MARGIN_PCT%TYPE;
  ltvFormula                    varchar2(5);
  custLevelGCVAmt               number(17,3);
  maxAdvRate                    SCBT_R_CUST_COLLAT_LIMIT.MAX_ADV_RATE%TYPE;
  --custProdLimitId               SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE;
  custLevelNCVAmt               number(17,3);
  TYPE CustTxnRecIdType IS TABLE OF Scbt_t_Txn_Mst.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE CustDealIdType IS TABLE OF Scbt_t_Txn_Mst.DEAL_ID%TYPE INDEX BY PLS_INTEGER;
  custTxnRecIdList              CustTxnRecIdType;
  custDealIdList                CustDealIdType;
  customerLevelGCVAmt           number(17,3);
  --prod_ref_code SCBT_R_PRODUCT_MST.PROD_REF_CODE%TYPE; --REF_08DEC2012
  prod_ref_code varchar2(16); --REF_03012013
  txnGcvAmt                     number(17,3);



  BEGIN

   -- Customer Exposure Currency
   BEGIN
      SELECT OVERALL_EXP_CURRENCY,LTV_FORMULA
        INTO custExpCcy,ltvFormula
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;



    allowCalc := 'Y';
    limitListCount := 0;

    -- Business Date
    BEGIN
        SELECT BUSINESS_DATE INTO bussDate FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    -- Record ID Generation
    bussDateAsString := TO_CHAR(bussDate, 'DDMMYYYY');
    recordID := 'CO' || bussDateAsString;


    -- Customer Level Stop Loss Settings

    BEGIN
         SELECT NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),NVL(LOAN_TO_VALUE_PCT,0)
         INTO custStopLossPctList,custStopLossCcyList,custStopLossCcyAmtList,custLevelLTVPercentage
         FROM SCBT_R_PARTY_MST
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;


    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;

    -- Customer Level
    IF levelFlag = 'C' THEN
         -- Customer Level Stop Loss Value Calculations
        if (nvl(custStopLossPctList,0) = 0 and nvl(custStopLossCcyAmtList,0) = 0) then
             custLevelReq := false;
        else
             custLevelReq := true;
        end if;

        showLimitLevel := true;
    end if;

    if (custLevelReq = true) then


           if(custLevelLTVPercentage <> 0) then
              if(ltvFormula ='LTV2') then

                 totalShortfallAmount:=((SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')
                                                 - SCBF_C_CUST_LEVEL_CASH_MARGIN(custId,custExpCcy,bankGroupCode,ctyCode,'S')
                                                 - SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId))/custLevelLTVPercentage)*100
                                                 - SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV');


              elsif(ltvFormula ='LTV3') then
                 totalShortfallAmount:=(SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')/custLevelLTVPercentage)*100
                                                  - (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV')
                                                  + SCBF_C_CUST_LEVEL_CASH_MARGIN(custId,custExpCcy,bankGroupCode,ctyCode,'S')
                                                  + SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId));


              else
                 totalShortfallAmount:=(SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','OS')/custLevelLTVPercentage)*100
                                                  - (SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','TGCV') +
                                                  SCBF_GET_CUST_TOPUP_AMT(bankGroupCode,ctyCode,custId));


              end if;
               if(totalShortfallAmount < 0) then
                  totalShortfallAmount := 0;
           end if;

       end if;
           custLevelLTVAmt := SCBF_GET_CUST_LEVEL_LTV(bankGroupCode,ctyCode,custId,'A','LTV');

           if(custStopLossPctList > 0) then
              if( custLevelLTVAmt > custStopLossPctList ) then
                  stopLossReqForCust := 'Y';
                  stopLossReqForCustAmt := nvl(totalShortfallAmount,0);
              --REFTOPUPREQAMT
              elsif((custLevelLTVPercentage <custLevelLTVAmt) and (custLevelLTVAmt<custStopLossPctList)) then
                  stopLossReqForCust := 'N';
                  stopLossReqForCustAmt := nvl(totalShortfallAmount,0);
              elsif(custLevelLTVPercentage > custLevelLTVAmt) then
                  stopLossReqForCust := 'N';
                  stopLossReqForCustAmt := 0;
              end if;
           elsif(custStopLossCcyAmtList > 0) then

               custLevelShortfallAmt:=totalShortfallAmount;
               custStopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                    ctyCode,
                                                    custStopLossCcyList,
                                                    custStopLossCcyAmtList,
                                                    custExpCcy,
                                                    'Y'),
                                                     0);

              if( custLevelShortfallAmt > custStopLossCcyAmtList ) then
                  stopLossReqForCust := 'Y';
                  stopLossReqForCustAmt := nvl(custLevelShortfallAmt,0) ;
              --REFTOPUPREQAMT
              elsif((0<custLevelShortfallAmt) and (custLevelShortfallAmt < custStopLossCcyAmtList)) then
                  stopLossReqForCust := 'N';
                  stopLossReqForCustAmt := nvl(custLevelShortfallAmt,0);
              elsif(custLevelShortfallAmt=0) then
                  stopLossReqForCust := 'N';
                  stopLossReqForCustAmt := 0;
              end if;

           end if;

           --REFTOPUPREQAMT
/*            if( totalShortfallAmount > 0 ) then
                  stopLossReqForCust := 'Y';
                  stopLossReqForCustAmt := nvl(totalShortfallAmount,0) ;
            else
                stopLossReqForCust := 'N';
            end if;*/

    	     BEGIN

    		      SELECT TXN_REC_ID,DEAL_ID
    		      BULK COLLECT INTO custTxnRecIdList,custDealIdList
    		      FROM (SELECT TXN_REC_ID,DEAL_ID FROM SCBT_T_TXN_MST
    		      WHERE BANK_GROUP_CODE=bankGroupCode
    		      AND CTY_CODE=ctyCode
              AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
              AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
    		      AND CUST_ID=custId
              UNION ALL -- COCOAREF_08012013
              SELECT MST.TXN_REC_ID,MST.DEAL_ID
                     FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
              WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                     AND MST.CTY_CODE=TCL.CTY_CODE
                     AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                     AND CR.CTY_CODE=TCL.CTY_CODE
                     AND MST.CUST_ID=TCL.CUST_ID
                     AND MST.DEAL_ID=TCL.DEAL_ID
                     AND CR.CUST_ID=TCL.CUST_ID
                     AND CR.DEAL_ID=TCL.DEAL_ID
                     AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                     AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                     AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
    		             AND MST.BANK_GROUP_CODE=bankGroupCode
          		       AND MST.CTY_CODE=ctyCode
                     AND MST.CUST_ID=custId
                     AND NVL(MST.LIMIT_TRANSFER,'N') <> 'Y'
                     AND NVL(MST.TXN_STATUS_CODE,'01') NOT IN ('05','11')
                     AND (MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)) = 0
                     AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
              );
    		      --AND TXN_STEP_CODE != 'SETT'; -- COCOAPERF_12122012


           EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                 NULL;
           END;

           customerLevelGCVAmt :=0;
            FOR i in 1..custTxnRecIdList.COUNT LOOP
                customerLevelGCVAmt := customerLevelGCVAmt + SCBF_C_GET_NCV_FOR_DEALS(bankGroupCode,ctyCode,custDealIdList(i),custId,custTxnRecIdList(i),'N');
            END LOOP;

           G_NCV_CCY_AMT := customerLevelGCVAmt;

           BEGIN


           DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
           AND CUST_ID = custId and TOPUP_LEVEL = 'C' AND DEAL_STEP_ID='M';


           stopLossReqForCustPct:=0;

               SCBP_P_INSERT_INTO_STOP_LOSS
                    (pReturnValue,
                     bankGroupCode,
                     ctyCode,
                     '',
                     'M',
                     custId,
                     'C',
                     custId,
                     '',
                     '',
                     '',
                     custLevelLTVAmt,
                     custExpCcy,
                     totalShortfallAmount,
                     stopLossReqForCust,
                     custExpCcy,
                     stopLossReqForCustAmt,
                     stopLossReqForCustPct,
                     'Y',
                     '',
                     bussDate);
           EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                    NULL;
           END;
    -- COCOACR-11APR2013
    ELSE

       DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
       AND CUST_ID = custId and TOPUP_LEVEL = 'C' AND DEAL_STEP_ID='M';

   END IF;



    --CUST LEVEL END


     -- Find the Transactions for the Deal Step ID
     if(showLimitLevel = true) then

           BEGIN
               SELECT TXN_REF_ID,TXN_REC_ID,TXN_CCY,OUTSTANDING, CM_CCY, CASH_MARGIN,
                                 CM_ADJ_AMT,CM_ADJ_AMT_FACTOR,CM_ORIGIN_AMT,txn_step_code,LIMITID
                                  BULK COLLECT INTO
                                   txnRefIDList,
                                   txnRecIDList,
                                   txnCcyList,
                                   txnCcyAmtList,
                                   cashMarginCcyList,
                                   cashMarginCcyAmtList,
                                   cashMarginAdjAmtList,
                                   cashMarginAdjFactorList,
                                   cashMarginOriginAmtList,
                                   txnStepCodeList,
                                   prodLimitIdList
                        FROM (   SELECT TH.TXN_REF_ID,TH.TXN_REC_ID,
                                 TH.TXN_CCY_CODE AS TXN_CCY,
                                 --(NVL(TH.TXN_CCY_NET_AMT,0) - NVL(TH.TXN_CCY_UTIL_AMT,0))AS OUTSTANDING,
                                 (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                 TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                                 --NVL(TH.CASH_MARGIN_CCY_AMT,0) - NVL(TH.CM_CCY_RELEASE_AMT,0) AS CASH_MARGIN,
                                 (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                 ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                                 ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                                 TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                                 TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                                 TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                                 TH.txn_step_code AS txn_step_code,
                                 TH.PROD_LIMIT_ID AS LIMITID
                            FROM SCBT_T_TXN_MST TH
                          WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                 AND TH.CTY_CODE = ctyCode
                                 AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') --COCOAFUNC_18122012
                                 --AND TH.TXN_STEP_CODE NOT IN ('DSETT' ,'SETT')   --COCOAPERFTUNE_003
                                 AND (ABS(TH.TXN_CCY_NET_AMT)-NVL(TH.TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                                 AND TH.cust_id = custId
               UNION ALL -- COCOAREF_08012013
               SELECT TH.TXN_REF_ID,TH.TXN_REC_ID,
                                 TH.TXN_CCY_CODE AS TXN_CCY,
                                 (NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                 TH.CASH_MARGIN_CCY_CODE AS CM_CCY,
                                 (CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                 ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                                 ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                                 TH.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                                 TH.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                                 TH.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT,
                                 TH.txn_step_code AS txn_step_code,
                                 TH.PROD_LIMIT_ID AS LIMITID
                     FROM SCBT_T_TXN_MST TH,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                    WHERE TH.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND TH.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND TH.CUST_ID=TCL.CUST_ID
                        AND TH.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND TH.TXN_REC_ID=TCL.TXN_REC_ID
                        AND TH.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND TH.BANK_GROUP_CODE = bankGroupCode
                        AND TH.CTY_CODE = ctyCode
                        AND TH.cust_id = custId
                        AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y'
                        AND NVL(TH.TXN_STATUS_CODE,'01') NOT IN ('05','11')
                        AND (TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)) =0
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                   );

             EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      NULL;
             END;



          DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
          AND CUST_ID = custId and DEAL_STEP_ID = 'M' and TOPUP_LEVEL != 'C';

            -- Facility Level Stop Loss Settings
          FOR i in 1..prodLimitIdList.COUNT LOOP


             facilityLevelLTVAmt := 0;
             facilityLevelShortfallAmt := 0;
             stopLossReqForFacility := 0;
             stopLossReqForFacilityAmt := 0;
             stopLossReqForFacilityPct := 0;


          BEGIN
               SELECT LIMIT_ID,LIMIT_CCY_CODE,NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),STOP_LOSS_APPL_FLAG,NVL(LOAN_TO_VALUE_PCT,0),NVL(CASH_MARGIN_PCT,0)
               INTO limitIDList,limitCcyList,stopLossPctList,stopLossCcyList,stopLossCcyAmtList,stopLossFlagList,facilityLevelLTVPercentage,cashMarginPctList
               FROM SCBT_R_CUST_PRODUCT_LIMIT
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND CUST_ID = custId
               and LIMIT_id = prodLimitIdList(i);

          EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                   NULL;
          END;

          if(stopLossFlagList = 'G') then
            BEGIN
                   SELECT FACILITY_GRP_ID
                   INTO groupID
                   FROM SCBT_R_CUST_FACILITY_GRP
                   WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId   -- COCOAPERF_12122012
                     --AND PROD_LIMIT_IDS LIKE '%' ||prodLimitIdList(i) ||'%'
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || prodLimitIdList(i) || ',', 1, 1 ) =( ',' || prodLimitIdList(i) || ',')
                      AND GROUP_TYPE = 'LTV';



                  SELECT NVL(STOP_LOSS_PCT,0),STOP_LOSS_CCY_CODE,NVL(STOP_LOSS_CCY_AMT,0),NVL(LOAN_TO_VALUE_PCT,0)
                     INTO stopLossPctList,stopLossCcyList,stopLossCcyAmtList,facilityLevelLTVPercentage
                     FROM SCBT_R_CUST_FACILITY_GRP
                     WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId
                     and FACILITY_GRP_ID = groupID
                     AND GROUP_TYPE = 'LTV';

             EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      groupID := '';
                      NULL;
             END;
          end if;

          -- Check if dupklicate faQcility level or group level

           if ((stopLossFlagList ='F' or stopLossFlagList = 'G') and i > 1) then

             for j in 1..existingProdLimits.COUNT LOOP
                 if(existingProdLimits(j) = limitIDList) then
                     allowCalc :='N';
                 else
                     allowCalc :='Y';
                 end if;
             END LOOP;
           end if;

          -- Facility / Txn Level Stop Loss Value Calculations
          if (nvl(stopLossPctList,0) = 0 and nvl(stopLossCcyAmtList,0) = 0) then
               facilityLevelReq := false;
          else
               facilityLevelReq := true;
          end if;

          if (facilityLevelReq = true /*and allowCalc ='Y'*/) then

                         if(facilityLevelLTVPercentage <> 0) then
                             if(stopLossFlagList = 'F') then
                             limitListCount := limitListCount + 1;
                             existingProdLimits(limitListCount) := limitIDList;


                               if(ltvFormula ='LTV2') then
                                   totalShortfallAmount:=((SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')
                                                          - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId)  -- REF05122012
                                                          - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'))/facilityLevelLTVPercentage)*100
                                                          - SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV');

                               elsif (ltvFormula ='LTV3') then
                                   totalShortfallAmount:=(SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')/facilityLevelLTVPercentage)*100
                                                                - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV')
                                                                + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId)  -- REF05122012
                                                                + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'));


                               else
                                   totalShortfallAmount:=(SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','OS')/facilityLevelLTVPercentage)*100
                                                                - (SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','TGCV')+
                                                                SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,'','','',limitIDList,limitCcyList,custExpCcy,'F'));


                               end if;
                             cashMarginAmt := cashMarginAmt + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId);     -- REF05122012

                             cashTopupAmt := NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'F'),0);


                            elsif(stopLossFlagList = 'T') then

                            --COCOACR_06022013
                            txnGcvAmt := SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV');

                            -- Changed by Anbu calculation is as per customer dashboard LTV shortfall amt in UTIL tab
                            -- changed UTIL to '' for the function SCBF_GET_TXN_LEVEL_LTV
                              if(ltvFormula ='LTV2') then
                                  totalShortfallAmount:= ((SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')
                                                                - SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T')
                                                                -- - SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId))/facilityLevelLTVPercentage)*100   -- REF05122012
                                                                - SCBF_C_TXN_LEVEL_CASH_MARGIN(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId, txnRefIDList(i),txnRecIDList(i)))/facilityLevelLTVPercentage)*100   -- REF_CR03012013
                                                                - txnGcvAmt;
/*                                                                - SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',    --COCOACR_06022013
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV');*/
                              elsif(ltvFormula ='LTV3') then
                                  totalShortfallAmount:= (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')/facilityLevelLTVPercentage)*100
                                                                  - (txnGcvAmt
/*                                                                - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',  --COCOACR_06022013
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV')*/
                                                                -- + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId)  -- REF05122012
                                                                + SCBF_C_TXN_LEVEL_CASH_MARGIN(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId, txnRefIDList(i),txnRecIDList(i)) -- REF_CR03012013
                                                                + SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'));

                              else
                                  totalShortfallAmount:= (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',  --COCOACR_06022013
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'OS')/facilityLevelLTVPercentage)*100
                                                                  - (txnGcvAmt +
/*                                                                - (SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                                  txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','',
                                                                  cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'GCV')+*/
                                                                SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'));

                              end if;
 /*                           totalShortfallAmount := NVL(SCBF_GET_TXN_LEVEL_SHORTFALL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                            txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'N','M','N',
                                                            cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),cashMarginCcyAmtList(i),0,limitIDList),0);
 */
                             --cashMarginAmt := cashMarginAmt + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,txnCcyList(i),bankGroupCode,ctyCode,'S',custId);     -- REF05122012

                             cashTopupAmt := NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'),0);

                             elsif(stopLossFlagList = 'G') then
                             limitListCount := limitListCount + 1;
                             existingProdLimits(limitListCount) := limitIDList;
                             --COCOACR_14022013
                             txnGcvAmt := SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','TGCV');

                             cashMarginAmt := cashMarginAmt + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,custExpCcy,bankGroupCode,ctyCode,'S',custId);    -- REF05122012
                             if(ltvFormula ='LTV2') then
                             totalShortfallAmount:= ((SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','OS')
                                                     - SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','TOP')
                                                     - cashMarginAmt)/facilityLevelLTVPercentage)*100
                                                     - txnGcvAmt;

                             elsif(ltvFormula = 'LTV3') then
                             totalShortfallAmount:= (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','OS')/facilityLevelLTVPercentage)*100
                                                          - (txnGcvAmt
                                                          + cashMarginAmt
                                                          + SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','TOP'));

                             else
                             totalShortfallAmount:= (SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','OS')/facilityLevelLTVPercentage)*100
                                                          - (txnGcvAmt +
                                                          SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','TOP'));

                             end if;
                             --cashMarginAmt := cashMarginAmt + SCBF_C_GET_TOT_CASH_MARGIN_CD(limitIDList,limitCcyList,bankGroupCode,ctyCode,'S',custId);

                             end if;

                       else
                       totalShortfallAmount := 0;
                       end if;


                          if(totalShortfallAmount < 0) then
                            totalShortfallAmount := 0;
                          end if;

                    G_CMR_CCY_CODE := custExpCcy;
                    G_CMR_CCY_AMT := cashMarginAmt;
                    G_CASHTOPUP_CCY_AMT := cashTopupAmt;


                    if ltvFormula is null then
                         ltvFormula := 'LTV1';
                    else
                         ltvFormula := ltvFormula;
                    end if;

                    G_LTV_FORMULA := ltvFormula;


                   -- Facility Level  or Txn Level
                   -- Always calculate LTV %

                   if(stopLossFlagList = 'G') then
                         facilityLevelLTVAmt := SCBF_GET_GROUP_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,custExpCcy,'N','LTV');

                   elsif(stopLossFlagList = 'F') then
                         facilityLevelLTVAmt := SCBF_GET_LIMIT_LEVEL_LTV(bankGroupCode,ctyCode,custId,limitIDList,limitCcyList,'A','LTV');

                         cashTopupAmt := NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'F'),0);

                   elsif(stopLossFlagList = 'T') then
                         facilityLevelLTVAmt := SCBF_GET_TXN_LEVEL_LTV(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),
                                                          txnCcyAmtList(i),txnCcyList(i),txnStepCodeList(i),'A','M','UTIL',
                                                          cashMarginAdjFactorList(i),cashMarginAdjAmtList(i),custExpCcy,cashMarginCcyAmtList(i),0,0,'LTV');

                         cashTopupAmt := NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',custExpCcy,'T'),0);
                   end if;


                   if(stopLossPctList > 0) then


                      if( facilityLevelLTVAmt > stopLossPctList ) then
                          stopLossReqForFacility := 'Y';
                          --REFTOPUPREQAMT
/*                           facilityLevelShortfallAmt := totalShortfallAmount;
                           stopLossReqForFacilityAmt := facilityLevelShortfallAmt;*/
                           stopLossReqForFacilityAmt := totalShortfallAmount;
                      elsif((facilityLevelLTVPercentage < facilityLevelLTVAmt) and (facilityLevelLTVAmt < stopLossPctList)) then
                          stopLossReqForFacilityAmt :=totalShortfallAmount;
                          stopLossReqForFacility := 'N';
                      elsif(facilityLevelLTVPercentage > facilityLevelLTVAmt) then
                          stopLossReqForFacilityAmt :=0;
                          stopLossReqForFacility := 'N';
                      end if;

                   elsif(stopLossCcyAmtList > 0) then

                      if(stopLossFlagList = 'F') then

                           facilityLevelShortfallAmt := totalShortfallAmount;
                           stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                            ctyCode,
                                                            stopLossCcyList,
                                                            stopLossCcyAmtList,
                                                            limitCcyList,
                                                            'Y'),
                                                             0);


                      elsif(stopLossFlagList = 'G') then

                          facilityLevelShortfallAmt := totalShortfallAmount;
                          stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                            ctyCode,
                                                            stopLossCcyList,
                                                            stopLossCcyAmtList,
                                                            custExpCcy,
                                                            'Y'),
                                                             0);

                      elsif(stopLossFlagList = 'T') then

                           facilityLevelShortfallAmt := totalShortfallAmount;
                           stopLossCcyAmtList := NVL(Scbf_Fetch_Exch_Rate(bankGroupCode,
                                                            ctyCode,
                                                            stopLossCcyList,
                                                            stopLossCcyAmtList,
                                                            txnCcyList(i),
                                                            'Y'),
                                                             0);

                      end if;

                      if( facilityLevelShortfallAmt > stopLossCcyAmtList ) then
                          stopLossReqForFacility := 'Y';
                          stopLossReqForFacilityAmt := nvl(facilityLevelShortfallAmt,0);
                      --REFTOPUPREQAMT
                      elsif( (0<facilityLevelShortfallAmt) and (facilityLevelShortfallAmt < stopLossCcyAmtList) ) then
                          stopLossReqForFacility := 'N';
                          stopLossReqForFacilityAmt := nvl(facilityLevelShortfallAmt,0);
                      elsif(facilityLevelShortfallAmt=0) then
                          stopLossReqForFacility := 'N';
                          stopLossReqForFacilityAmt :=0;
                      end if;

                   end if;
                  --REFTOPUPREQAMT
/*                  if( totalShortfallAmount > 0 ) then
                      stopLossReqForFacility := 'Y';
                      stopLossReqForFacilityAmt := nvl(totalShortfallAmount,0);
                  else
                      stopLossReqForFacility := 'N';
                  end if;
*/
                  stopLossReqForFacilityPct:=0;


                   custLevelGCVAmt := Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                                             ctyCode,
                                                                                             custId,
                                                                                             txnCcyList(i),
                                                                                             txnRecIDList(i),
                                                                                             txnCcyList(i),
                                                                                             'UTIL',
                                                                                             'M',
                                                                                             '');

                   --G_GCV_CCY_AMT := custLevelGCVAmt;
                   --COCOA_29032013
                      if(stopLossFlagList = 'F') then
                          totalShortfallAmount  := Scbf_Round_Amount(bankGroupCode,limitCcyList,totalShortfallAmount);
                      elsif(stopLossFlagList = 'G') then
                          totalShortfallAmount  := Scbf_Round_Amount(bankGroupCode,custExpCcy,totalShortfallAmount);
                      elsif(stopLossFlagList = 'T') then
                          totalShortfallAmount  := Scbf_Round_Amount(bankGroupCode, txnCcyList(i),totalShortfallAmount);
                      end if;


                   if(stopLossFlagList = 'F') then

                      DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
                      AND CUST_ID = custId and TOPUP_LEVEL = 'F' AND DEAL_STEP_ID='M'
                      AND LIMIT_ID =limitIDList;


                     SCBP_P_INSERT_INTO_STOP_LOSS(pReturnValue,
                                                        bankGroupCode,
                                                       ctyCode,
                                                       '',
                                                       'M',
                                                       custId,
                                                       stopLossFlagList,
                                                       '',
                                                       '',
                                                       limitIDList,
                                                       '',
                                                       facilityLevelLTVAmt,
                                                       limitCcyList,
                                                       totalShortfallAmount,
                                                       stopLossReqForFacility,
                                                       limitCcyList,
                                                       stopLossReqForFacilityAmt,
                                                       stopLossReqForFacilityPct,
                                                       'Y',
                                                       '',
                                                       bussDate);
                    elsif (stopLossFlagList = 'G') then

                    G_GCV_CCY_AMT := txnGcvAmt;

                      DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode --COCOAPERFTUNE_003
                      AND CUST_ID = custId and TOPUP_LEVEL = 'G' AND DEAL_STEP_ID='M'
                      AND GROUP_ID =groupID;

                           SCBP_P_INSERT_INTO_STOP_LOSS(pReturnValue,
                                                       bankGroupCode,
                                                       ctyCode,
                                                       '',
                                                       'M',
                                                       custId,
                                                       stopLossFlagList,
                                                       '',
                                                       '',
                                                       '',
                                                       groupID,
                                                       facilityLevelLTVAmt,
                                                       custExpCcy,
                                                       totalShortfallAmount,
                                                       stopLossReqForFacility,
                                                       custExpCcy,
                                                       stopLossReqForFacilityAmt,
                                                       stopLossReqForFacilityPct,
                                                       'Y',
                                                       '',
                                                       bussDate);
                    elsif (stopLossFlagList = 'T') then

                    G_GCV_CCY_AMT := txnGcvAmt;
                     SCBP_P_INSERT_INTO_STOP_LOSS(pReturnValue,
                                                        bankGroupCode,
                                                       ctyCode,
                                                       '',
                                                       'M',
                                                       custId,
                                                       stopLossFlagList,
                                                       txnRefIDList(i),
                                                       txnRecIDList(i),
                                                       limitIDList,
                                                       '',
                                                       facilityLevelLTVAmt,
                                                       txnCcyList(i),
                                                       totalShortfallAmount,
                                                       stopLossReqForFacility,
                                                       txnCcyList(i),
                                                       stopLossReqForFacilityAmt,
                                                       stopLossReqForFacilityPct,
                                                       'Y',
                                                       txnStepCodeList(i),
                                                       bussDate);

                    end if;



            ELSE


                        --Added by Anbu
               BEGIN

                   SELECT count(1) INTO custLvlCntForLTV  FROM SCBT_R_CUST_PRODUCT_LIMIT
                   WHERE BANK_GROUP_CODE=bankGroupCode
                   AND CTY_CODE=ctyCode
                   AND CUST_ID=custId
                   AND LIMIT_ID = prodLimitIdList(i) -- COCOAPERF_12122012
                   AND STOP_LOSS_APPL_FLAG IS NULL;

               EXCEPTION
                 WHEN NO_DATA_FOUND THEN
                 NULL;
               END;




            if(custLvlCntForLTV > 0) then


            --REF_08DEC2012
             BEGIN

                  select NVL(p.PRODUCT_SUB_TYPE,'NONLC') INTO prod_ref_code    --REF_03012013
                         from scbt_r_product_mst p,scbt_t_txn_mst t
                  where t.PRODUCT_CODE = p.product_code
                         and t.bank_group_code = p.bank_group_code
                         and t.bank_group_code = bankGroupCode
                         and t.cty_code = ctyCode
                         and t.cust_id = custId
                         and t.txn_ref_id = txnRefIDList(i)
                         and t.txn_rec_id = txnRecIDList(i);

              EXCEPTION  WHEN OTHERS THEN

                BEGIN
                  select NVL(p.PRODUCT_SUB_TYPE,'NONLC') INTO prod_ref_code     --REF_03012013
                         from scbt_r_product_mst p,scbt_t_txn_hst t,scbt_t_deal_hist h
                  where t.PRODUCT_CODE = p.product_code
                          and t.bank_group_code = p.bank_group_code
                          and t.BANK_GROUP_CODE = h.bank_group_code
                          and t.cty_code = h.cty_code
                          and h.deal_id = t.deal_id
                          and t.deal_step_id = h.deal_step_id
                          and h.step_status_code <> '03'
                          and t.cust_id = h.cust_id
                          and t.bank_group_code = bankGroupCode
                          and t.cty_code = ctyCode
                          and t.cust_id = custId
                          and t.txn_ref_id = txnRefIDList(i)
                          and t.txn_rec_id = txnRecIDList(i);
                EXCEPTION
                      WHEN OTHERS THEN
                        prod_ref_code:='NONLC';  --REF_03012013
                END;


              END;




                BEGIN

                if(prod_ref_code <> 'LC') then


                      SELECT  sum(NVL(OUTSTANDING, 0)),
                           sum(NVL(CASH_MARGIN, 0)) INTO custOsAmt, cashMarginAmt
                      FROM (SELECT sum(NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                                     ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_MST MST
            				  WHERE MST.BANK_GROUP_CODE = bankGroupCode
                                   AND MST.CTY_CODE = ctycode
                                   AND MST.cust_id = custId
      -- Ref_Oct2012               AND MST.PROD_LIMIT_ID in (select limit_id from scbt_r_cust_product_limit
      --                           where  BANK_GROUP_CODE = bankGroupCode
      --                           AND CTY_CODE = ctycode AND cust_id = custId
      --                           AND STOP_LOSS_APPL_FLAG IS NULL)
                                   AND MST.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                   --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11' -- COCOAFUNC_18122012
                                   AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					                         AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                                   AND MST.TXN_REF_ID = txnRefIDList(i)
                                   AND MST.TXN_REC_ID NOT IN
                                   (SELECT TXN_REC_ID
                                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                                     WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                       AND TH.CTY_CODE = ctycode
                                       AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                                       AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                                       AND TH.DEAL_ID=DH.DEAL_ID       --COCOAPERFTUNE_003
                                       AND TH.CUST_ID=DH.CUST_ID       --COCOAPERFTUNE_003
                                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                       AND TH.TXN_REF_ID = txnRefIDList(i)   -- COCOAPERF_12122012
                                      -- AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                       AND TH.cust_id = custId)
                    UNION ALL --COCOAREF_08012013
                    SELECT sum(NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                                     ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                              WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                                  AND MST.CTY_CODE=TCL.CTY_CODE
                                  AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                                  AND CR.CTY_CODE=TCL.CTY_CODE
                                  AND MST.CUST_ID=TCL.CUST_ID
                                  AND MST.DEAL_ID=TCL.DEAL_ID
                                  AND CR.CUST_ID=TCL.CUST_ID
                                  AND CR.DEAL_ID=TCL.DEAL_ID
                                  AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                                  AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                                  AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                                  AND MST.BANK_GROUP_CODE = bankGroupCode
                                  AND MST.CTY_CODE = ctyCode
                                  AND MST.cust_id = custid
                                  AND MST.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                  AND MST.TXN_REF_ID = txnRefIDList(i)
                                  AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                                  AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
          					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                                  AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                                   AND MST.TXN_REC_ID NOT IN
                                   (SELECT TXN_REC_ID
                                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                                     WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                       AND TH.CTY_CODE = ctycode
                                       AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                                       AND TH.CTY_CODE=DH.CTY_CODE
                                       AND TH.DEAL_ID=DH.DEAL_ID
                                       AND TH.CUST_ID=DH.CUST_ID
                                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                       AND TH.TXN_REF_ID = txnRefIDList(i)
                                       AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'
                                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                       AND TH.cust_id = custId)
                      UNION ALL
                            SELECT sum(NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                                   ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
              				  WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                   AND TH.CTY_CODE = ctycode
                                   AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE --COCOAPERFTUNE_003
                                   AND TH.CTY_CODE=DH.CTY_CODE     --COCOAPERFTUNE_003
                                   AND TH.CUST_ID=DH.CUST_ID
                                   AND TH.DEAL_ID=DH.DEAL_ID
                                   AND TH.TXN_STEP_CODE NOT IN  ('SETT','DSETT') -- COCOAPERF_12122012  --AND TH.TXN_STEP_CODE !='SETT',
                                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                                   AND TH.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
      -- Ref_Oct2012               AND TH.PROD_LIMIT_ID in (select limit_id from scbt_r_cust_product_limit
      --                           where  BANK_GROUP_CODE = bankGroupCode
      --                           AND CTY_CODE = ctycode AND cust_id = custId
      --                           AND STOP_LOSS_APPL_FLAG IS NULL)
                                   AND TH.TXN_REF_ID = txnRefIDList(i)
                                   AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                   AND TH.cust_id = custId);
                  else

                      SELECT  sum(NVL(OUTSTANDING, 0)),
                           sum(NVL(CASH_MARGIN, 0)) INTO custOsAmt, cashMarginAmt
                      FROM (SELECT sum(NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                                     ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_MST MST
            				  WHERE MST.BANK_GROUP_CODE = bankGroupCode
                                   AND MST.CTY_CODE = ctycode
                                   AND MST.cust_id = custId
                                   AND MST.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                   --AND NVL(MST.TXN_STATUS_CODE,'02') <> '11' -- COCOAFUNC_18122012
                                   AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- COCOAFUNC_18122012
					                         AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 -- COCOAFUNC_25022013
                                   AND MST.TXN_REF_ID = txnRefIDList(i)
                                   AND MST.TXN_REC_ID = txnRecIDList(i)
                                   AND MST.TXN_REC_ID NOT IN
                                   (SELECT TXN_REC_ID
                                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                                     WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                       AND TH.CTY_CODE = ctycode
                                       AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                                       AND TH.CTY_CODE=DH.CTY_CODE
                                       AND TH.DEAL_ID=DH.DEAL_ID
                                       AND TH.CUST_ID=DH.CUST_ID
                                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                       AND TH.TXN_REF_ID = txnRefIDList(i)     -- COCOAPERF_12122012
                                       AND TH.TXN_REC_ID = txnRecIDList(i)     -- COCOAPERF_12122012
                                       --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                       AND TH.cust_id = custId)
                    UNION ALL      --COCOAREF_08012013
                    SELECT sum(NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                                     ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                              WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                                  AND MST.CTY_CODE=TCL.CTY_CODE
                                  AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                                  AND CR.CTY_CODE=TCL.CTY_CODE
                                  AND MST.CUST_ID=TCL.CUST_ID
                                  AND MST.DEAL_ID=TCL.DEAL_ID
                                  AND CR.CUST_ID=TCL.CUST_ID
                                  AND CR.DEAL_ID=TCL.DEAL_ID
                                  AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                                  AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                                  AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                                  AND MST.BANK_GROUP_CODE = bankGroupCode
                                  AND MST.CTY_CODE = ctyCode
                                  AND MST.cust_id = custid
                                  AND NVL(LIMIT_TRANSFER,'N') <> 'Y'
                                  AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11')
          					              AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0
                                  AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                                  AND MST.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                   AND MST.TXN_REF_ID = txnRefIDList(i)
                                   AND MST.TXN_REC_ID = txnRecIDList(i)
                                   AND MST.TXN_REC_ID NOT IN
                                   (SELECT TXN_REC_ID
                                      FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
                                     WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                       AND TH.CTY_CODE = ctycode
                                       AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                                       AND TH.CTY_CODE=DH.CTY_CODE
                                       AND TH.DEAL_ID=DH.DEAL_ID
                                       AND TH.CUST_ID=DH.CUST_ID
                                       AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                       AND TH.TXN_REF_ID = txnRefIDList(i)
                                       AND TH.TXN_REC_ID = txnRecIDList(i)
                                       AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'
                                       AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                       AND TH.cust_id = custId)
                       UNION ALL
                            SELECT sum(NVL(DECODE(TH.SCB_ROLE,'AG',TH.SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0),TH.TXN_CCY_NET_AMT-NVL(TH.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                                   sum(CASE WHEN NVL(TH.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                   ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) - NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0))
                                   ELSE ((NVL(TH.CASH_MARGIN_ORIGN_AMT,0) + NVL(TH.CASH_MARGIN_ADJ_AMT,0)) - NVL(TH.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN
                              FROM SCBT_T_TXN_HST TH, SCBT_T_DEAL_HIST DH
              				  WHERE TH.BANK_GROUP_CODE = bankGroupCode
                                   AND TH.CTY_CODE = ctycode
                                   AND TH.BANK_GROUP_CODE=DH.BANK_GROUP_CODE
                                   AND TH.CTY_CODE=DH.CTY_CODE
                                   AND TH.CUST_ID=DH.CUST_ID
                                   AND TH.DEAL_ID=DH.DEAL_ID
                                   AND TH.TXN_STEP_CODE NOT IN ('SETT','DSETT') -- COCOAPERF_12122012 --AND TH.TXN_STEP_CODE !='SETT',
                                   AND NVL(TH.LIMIT_TRANSFER,'N') <> 'Y' -- COCOACR_10062013
                                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                                   AND TH.SHORTFALL_OFFSET_TYPE NOT IN ('CBB','GBB','CL')
                                   AND TH.TXN_REF_ID = txnRefIDList(i)
                                   AND TH.TXN_REC_ID = txnRecIDList(i)
                                   AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                                   AND TH.cust_id = custId);


                  end if;

                 EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       custOsAmt := 0;
                       cashMarginAmt := 0;
                       NULL;
                END;
                       totalShortfallAmount :=0;

                /*BEGIN
                  SELECT DISTINCT PROD_LIMIT_ID
                    INTO custProdLimitId
                    FROM SCBT_T_TXN_HST
                   WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId
                     AND TXN_REF_ID = txnRefIDList(i);
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                    custProdLimitId := '';
                END;     */


                          -- Max Adv Rate
                BEGIN

                  SELECT DISTINCT PM.MAX_ADV_RATE_PCT INTO maxAdvRate
                  FROM SCBT_T_PARCEL_MST PM,SCBT_T_TXN_CR_LINKAGE_MST TCL
                  WHERE TCL.BANK_GROUP_CODE=PM.BANK_GROUP_CODE
                        AND TCL.CTY_CODE=PM.CTY_CODE
                        AND TCL.COLLATERAL_ID=PM.COLLATERAL_ID
                        AND PM.BANK_GROUP_CODE = bankGroupCode  --COCOAPERFTUNE_003
                        AND PM.CTY_CODE = ctyCode               --COCOAPERFTUNE_003
                        AND TCL.CUST_ID = custId     -- COCOAPERF_12122012
                        AND TCL.TXN_REC_ID = txnRecIDList(i)  -- COCOAPERF_12122012
                        AND TCL.TXN_REF_ID=txnRefIDList(i);

                EXCEPTION
                  WHEN OTHERS THEN
                    maxAdvRate := '0.00';
                END;

                G_CASH_MARGIN_PERCNT := maxAdvRate;



                          stopLossReqForCustAmt := 0;

                          cashTopupAmt :=  NVL(SCBF_GET_TOPUP_AMT_BY_LEVEL(bankGroupCode,ctyCode,custId,txnRefIDList(i),txnRecIDList(i),txnCcyList(i),'','',txnCcyList(i),'T'),0);

                          facilityLevelLTVAmt := Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(bankGroupCode,
                                                                                             ctyCode,
                                                                                             custId,
                                                                                             txnCcyList(i),
                                                                                             txnRecIDList(i),
                                                                                             txnCcyList(i),
                                                                                             'UTIL',
                                                                                             'M',
                                                                                             '');

                          custLevelNCVAmt := SCBF_C_GET_NCV_BY_TXN_REF_ID(bankGroupCode,
                                                                              ctyCode,
                                                                              custId,
                                                                              txnCcyList(i),
                                                                              txnRecIDList(i),
                                                                              txnCcyList(i),
                                                                              'UTIL',
                                                                              'M',
                                                                              '');
                          totalShortfallAmount := NVL(custLevelNCVAmt,0)
                                          + NVL(cashTopupAmt,0)
                                          + NVL(cashMarginAmt,0)
                                          - NVL(custOsAmt,0);





                            if( totalShortfallAmount > 0 ) then
                                  stopLossReqForCust := 'Y';
                                  stopLossReqForCustAmt := nvl(totalShortfallAmount,0) ;
                            else
                                stopLossReqForCust := 'N';
                            end if;

                           stopLossReqForCustPct:=0;
                           G_EXPOSURE_CCY_CODE := txnCcyList(i);
                           G_EXPOSURE_CCY_AMT := custOsAmt;
                           G_CMR_CCY_CODE := txnCcyList(i);
                           G_CASHTOPUP_CCY_CODE := txnCcyList(i);
                           G_CASHTOPUP_CCY_AMT := cashTopupAmt;
                           G_CMR_CCY_AMT := cashMarginAmt;
                           G_GCV_CCY_CODE := txnCcyList(i);
                           G_GCV_CCY_AMT := facilityLevelLTVAmt;
                           G_NCV_CCY_CODE := txnCcyList(i);
                           G_NCV_CCY_AMT := custLevelNCVAmt;


                      DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode  --COCOAPERFTUNE_003
                      AND CUST_ID = custId and TOPUP_LEVEL = 'NONLTV' AND DEAL_STEP_ID='M'
                      AND TXN_REF_ID =txnRefIDList(i) AND TXN_REC_ID =txnRecIDList(i);

                      SCBP_P_INSERT_INTO_STOP_LOSS(pReturnValue,
                                                        bankGroupCode,
                                                       ctyCode,
                                                       '',
                                                       'M',
                                                       custId,
                                                       'NONLTV',
                                                       txnRefIDList(i),
                                                       txnRecIDList(i),
                                                       limitIDList,
                                                       '',
                                                       '',
                                                       txnCcyList(i),
                                                       totalShortfallAmount,
                                                       stopLossReqForFacility,
                                                       txnCcyList(i),
                                                       stopLossReqForFacilityAmt,
                                                       stopLossReqForFacilityPct,
                                                       'Y',
                                                       txnStepCodeList(i),
                                                       bussDate);
              end if;

          end if;

          END LOOP;

          end if;
    COMMIT;
   END SCBP_P_LTV_CALCULATION;




  PROCEDURE SCBP_P_CUST_COLL_POS(p_ret_code    IN OUT VARCHAR2,
                                    bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2) IS
    TYPE CustomerIDList  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.CUST_ID%TYPE;
    custIDList        CustomerIDList;
    runningSeq        NUMBER(8);
    BEGIN

  SELECT DISTINCT CUST_ID BULK COLLECT INTO custIDList FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE BANK_GROUP_CODE=bankGroupCode AND CTY_CODE=ctyCode;

      runningSeq := 1;

	BEGIN
        INSERT INTO SCBT_T_IPS_CAGG_FEED_HIST SELECT * FROM SCBT_T_IPS_CAGG_FEED_MST WHERE BANK_GROUP_CODE = bankGroupCode and
            CTY_CODE = ctyCode ;
	EXCEPTION WHEN OTHERS THEN
	  NULL;
	END;
    -- Delete from Master to insert new records

    DELETE FROM SCBT_T_IPS_CAGG_FEED_MST WHERE BANK_GROUP_CODE = bankGroupCode and CTY_CODE = ctyCode;

    -- Clean Up Stop Loss Master
    DELETE FROM SCBT_T_STOPLOSS_SUMMARY_MST WHERE BANK_GROUP_CODE = bankGroupCode and CTY_CODE = ctyCode and deal_step_id='M';

     FOR i IN 1..custIDList.COUNT LOOP
        Scbp_P_Get_Coll_Position_Sfall(p_ret_code,
                                       bankGroupCode,
                                       ctyCode,
                                       custIDList(i),
                                       'N',
                                       'N',
                                       'N',
                                       'N');

         SCBK_P_CAGG_FEED.SCBP_P_COLL_AGGREGATOR_FEED(bankGroupCode,ctyCode,custIDList(i),runningSeq);

         SCBP_P_LTV_CALCULATION(bankGroupCode,ctyCode,custIDList(i),'C');

     END LOOP;

     COMMIT;
     p_ret_code := '0000';

  END SCBP_P_CUST_COLL_POS;


  FUNCTION SCBF_C_GET_TOT_COLL_COV(txnRefID VARCHAR2,
                                   txnCcyCode VARCHAR2,
                                   bankGroupCode IN VARCHAR2,ctyCode IN VARCHAR2,
                                   piFlag IN VARCHAR2)  RETURN NUMBER IS
  totalCovAmt        SCBT_T_TXN_CR_LINKAGE_MST.TXN_CCY_COVERAGE_AMT%TYPE;

  BEGIN

       SELECT SUM(NVL(TXN_CCY_COVERAGE_AMT,0)) INTO totalCovAmt
               FROM SCBT_T_TXN_CR_LINKAGE_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                AND TXN_REF_ID = txnRefID;

       RETURN(totalCovAmt);

  END SCBF_C_GET_TOT_COLL_COV;

END SCBK_P_COCOA_CDB;
/
