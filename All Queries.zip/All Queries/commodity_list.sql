Select Step_Status_Code,Feed_Owner_Userid, Price_Source_Code, Feed_Id, Feed_Name,FEED_PRICE_CCY, FEED_PRICE_AMT,FEED_PRICE_UOM,
            PRICE_DESC, Vendor_Feed_Id, Cty_Code  From
            Scbt_R_Commodity_Price_Hist Where Step_Status_Code In ('01', '11','02') 
            And Bank_Group_Code='SCB'
              And Feed_Owner_Userid Like Upper('SYSTEM')
            And Upper(Price_Source_Code) Like Upper('T-RTR') 
              And Upper(Feed_Id) Like Upper('%')
              And Upper(Feed_Name) Like Upper('%') 
              And Nvl(Upper(Vendor_Feed_Id),'%') Like Upper('%')
              AND FEED_PRICE_AMT LIKE('%')
              And Upper(FEED_PRICE_CCY) Like Upper('%')
              And Upper(FEED_PRICE_UOM) Like Upper('%')      
              And Upper(nvl(PRICE_DESC,'%')) Like Upper('%')
              UNION ALL
            Select '03',Feed_Owner_Userid, Price_Source_Code, Feed_Id, Feed_Name,
            FEED_PRICE_CCY, FEED_PRICE_AMT,FEED_PRICE_UOM,PRICE_DESC, Vendor_Feed_Id,Cty_Code From
            Scbt_R_Commodity_Price_Mst Mst Where Bank_Group_Code='SCB'  
              and FEED_OWNER_USERID like upper('SYSTEM')
            And Upper(Price_Source_Code) Like Upper('T-RTR') 
              And Upper(Feed_Id) Like Upper('%') 
              And Upper(Feed_Name) Like Upper('%') 
              And nvl(Upper(Vendor_Feed_Id),'%') Like Upper('%')  
             AND FEED_OWNER_USERID NOT IN   (select FEED_OWNER_USERID from
            Scbt_R_Commodity_Price_Hist Where Step_Status_Code In ('01', '11','02') And Feed_Id = Mst.Feed_Id And 
            Bank_Group_Code=Mst.Bank_Group_Code)
            and mst.BANK_GROUP_CODE= 'SCB'
            AND FEED_PRICE_AMT LIKE ('%')
            And Upper(FEED_PRICE_CCY) Like Upper('%')
              And Upper(FEED_PRICE_UOM) Like Upper('%')
              And Upper(nvl(PRICE_DESC,'%')) Like Upper('%')