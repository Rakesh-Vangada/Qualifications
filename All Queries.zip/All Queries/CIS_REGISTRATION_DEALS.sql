SELECT 
			    CTY_CODE,
				NVL2(BUSINESS_DATE,to_char(BUSINESS_DATE,'DD-MM-YYYY'),BUSINESS_DATE) AS BUSINESS_DATE,
				(select PARTY_ID from scbt_r_party_ext_id where UPPER(ext_system_code)='CIS' and upper(ext_system_id)=upper(CIS_CUST_ID) AND CTY_CODE=CIS.CTY_CODE) as custId,
			    Scbf_Get_Party_Name (BANK_GROUP_CODE,(select PARTY_ID from scbt_r_party_ext_id where UPPER(ext_system_code)='CIS' and upper(ext_system_id)=upper(CIS_CUST_ID) AND CTY_CODE=CIS.CTY_CODE)) AS CUST_NAME,
				CIS_DEAL_REF,
                    (SELECT CODE_VALUE_2 from scbt_r_map_info WHERE UPPER(MAP_ID)=UPPER('DEAL ACTION') AND UPPER(CODE_VALUE_1)=UPPER(DEAL_LEG))
                AS DEAL_LEG,
                CASE 
                WHEN DEAL_TYPE='CONTANGO' THEN 'CONT'
                ELSE
                DEAL_TYPE 
                END AS DEAL_TYPE,
                NVL2(DEAL_LEVEL,'L'||DEAL_LEVEL,DEAL_LEVEL) AS DEAL_LEVEL,
                COMMODITY AS CIS_COMMODITY,
                PURCHASE_PRICE_CCY,
                PURCHASE_PRICE,
                NET_QTY,
                NVL2(Scbf_C_Get_Code_Desc (BANK_GROUP_CODE,CTY_CODE, '*','EN','CD016',NET_QTY_UOM,1),NET_QTY_UOM,
                (SELECT CODE_VALUE_2 from scbt_r_map_info WHERE UPPER(MAP_ID)=UPPER('CIS UOM') AND UPPER(CODE_VALUE_1)=UPPER(NET_QTY_UOM))),
                --NET_QTY_UOM,
                --EXCHANGE_CODE,
                NVL2(Scbf_C_Get_Code_Desc (BANK_GROUP_CODE,CTY_CODE, '*','EN','CD007',EXCHANGE_CODE,1),EXCHANGE_CODE,
                (SELECT CODE_VALUE_2 from scbt_r_map_info WHERE UPPER(MAP_ID)=UPPER('CIS EXCHANGE') AND UPPER(CODE_VALUE_1)=UPPER(EXCHANGE_CODE))),
                COCOA_DEAL_REF,
                NVL2(START_DATE,to_char(START_DATE,'DD-MM-YYYY'),START_DATE) AS START_DATE,
                NVL2(END_DATE,to_char(END_DATE,'DD-MM-YYYY'),END_DATE) AS END_DATE,
                NVL2(HEDGE_DATE,to_char(HEDGE_DATE,'DD-MM-YYYY'),END_DATE) AS HEDGE_DATE,
                CONTRACT_SIZE,
                HEDGE_PRICE,
                ACTION_TYPE,
                IS_PROCESSED,
                MSG_ID,
                'COMMODITY='||COMMODITY|| ',EXCHANGE=' || EXCHANGE_CODE||':'||REMARKS as REMARKS,
                CIS_CUST_ID,
                HEDGE_PRICE_CCY,
                PHYSICAL_PREMIUM_PRICE,
                (select  NVL((Scbf_C_Get_Code_Desc(BANK_GROUP_CODE,CTY_CODE, '*', 'EN', 'CD066',COMMODITY_CODE, 1)),COMMODITY_NAME) from scbt_r_commodity_mst comm where upper(commodity_code)=upper(COMMODITY) and upper(exch_code)=upper(EXCHANGE_CODE) and upper(comm.cty_code)=upper(cis.cty_code) and rownum<2 )AS commodity_name,
                CIS_rollover_REF,
                APPR_NOT_REQUIRED    
            FROM 
                SCBT_T_IPS_CIS_SIP_DEAL cis
                WHERE (IS_PROCESSED is null or IS_PROCESSED='N') and BANK_GROUP_CODE = 'SCB' and CTY_CODE in ('*','HK')
                and (upper(ACTION_TYPE)=upper('Validated') or upper(ACTION_TYPE)=upper('VALD'))
                AND UPPER(cis.CIS_DEAL_REF) LIKE UPPER('%')  
                --AND cis.CIS_DEAL_REF IN ('LTC-155','SPCU-045','TIC-474')
                order by MSG_ID DESC -- 4017
				
				
				SELECT SIPD.CIS_DEAL_REF,IN_MSG.MSG_ID,IN_MSG.MSG_TYPE,IN_MSG.RECV_DATE,SIPD.BUSINESS_DATE,SIPD.CIS_CUST_ID,SIPD.ACTION_TYPE,SIPD.IS_PROCESSED,
SIPD.DEAL_LEG,SIPD.MUREX_REF_NO  
FROM SCBT_T_IPS_CIS_IN_MSG IN_MSG
LEFT OUTER JOIN SCBT_T_IPS_CIS_SIP_DEAL SIPD
ON SIPD.MSG_ID = IN_MSG.MSG_ID
WHERE IN_MSG.MSG_TYPE='ONLINE' 
AND (SIPD.IS_PROCESSED is null or SIPD.IS_PROCESSED='N') 
AND SIPD.BANK_GROUP_CODE = 'SCB' AND SIPD.CTY_CODE in ('*','HK')
AND (UPPER(SIPD.ACTION_TYPE)=UPPER('Validated') or UPPER(SIPD.ACTION_TYPE)=UPPER('VALD'))
AND IN_MSG.RECV_DATE > '01-MAR-2014' --IN_MSG.MSG_CONTENT LIKE '%LTC-155%' 
ORDER BY IN_MSG.RECV_DATE DESC