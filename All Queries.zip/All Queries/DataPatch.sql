====================================== 12 Feb 2013 =====================================================================
UPDATE SCBT_R_PARAM_DEFN SET accs_by_whom='07,01,02,04,06,05' WHERE param_code_id = 'CI140' and accs_by_whom ='07,01,02,04,06';

SELECT * FROM SCBT_R_PARAM_DEFN WHERE param_code_id IN ('CI140') and accs_by_whom ='07,01,02,04,06';

UPDATE SCBT_R_PARAM_DEFN SET accs_by_whom='07,01,02,04,06,05' WHERE param_code_id = 'CI140' and accs_by_whom ='07,01,02,04,06';

=================================

SELECT * FROM SCBT_T_PARCEL_HST WHERE PARCEL_ID='PP00041801';

SELECT UTILISED_QNTY FROM SCBT_T_PARCEL_MST WHERE PARCEL_ID='PP00041801'; 

SELECT * FROM SCBT_T_PARCEL_HST WHERE deal_step_id = 'PK415F00030M0041' and PARCEL_ID='PP00034964'  order by to_number(REC_ID) desc;

SELECT * FROM SCBT_T_PARCEL_MST WHERE PARCEL_ID='PP00034964';

SELECT * FROM SCBT_T_PARCEL_HST WHERE deal_step_id = 'PK415F00030M0041' and (PARCEL_ID='PP00034964' or link_PARCEL_ID='PP00034964')

select 355.97-17 from dual; --338.97
=========================
SCBT_R_CUST_ACCT_MAINTENANCE
SCBT_R_CUST_ACCT_HIST

10.145.135.114


select Scbf_C_Get_Code_Desc('SCB', '*', '*', 'EN', 'CD081', '*', 1) from dual;


SELECT *        FROM scbt_r_code_data code
      WHERE code.bank_group_code = 'SCB'
        AND code.cty_code = '*' 
        AND code.tbu_code = '*' 
        AND code.lang_code = 'EN'
        AND code.code_id = 'CI140'
   AND code.code_value like '%';

SELECT DECODE ('1', '1', code.desc_1, code.desc_2)
       as val
       FROM scbt_r_code_data code
      WHERE code.bank_group_code = 'SCB'
        AND code.cty_code = '' 
        AND code.tbu_code = '*' 
        AND code.lang_code = 'EN'
        AND code.code_id = 'CI140'
   AND code.code_value like '%';
   
   
select * from SCBT_T_DEAL_HIST where deal_id='US777F00017' and 

SELECT * FROM SCBT_T_PARCEL_MST WHERE DEAL_ID='US777F00017' and DOCUMENT_NO LIKE 'Stock Pile number 260' and parcel_type_code='REL';

SELECT * FROM SCBT_T_PARCEL_HST WHERE DEAL_ID='US777F00017' and (PARCEL_ID='PS00044040' or link_PARCEL_ID='PS00044040') and parcel_type_code='REL';

SELECT * FROM SCBT_T_PARCEL_HST WHERE DEAL_ID='US777F00017' and DOCUMENT_NO LIKE 'Stock Pile number 260A'

select * from SCBT_R_INS_HIST where cty_code='AE'

select * from SCBT_R_INS_MST where cty_code='AE'

SELECT * FROM SCBT_R_CODE_DATA WHERE CODE_ID IN('CI140') AND CODE_VALUE='ALLIANCXXX'

SELECT * FROM SCBT_R_TBU_MST where TBU_CODE in('CN121','CN333')

