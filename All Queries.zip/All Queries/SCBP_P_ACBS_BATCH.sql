CREATE OR REPLACE PACKAGE BODY COCOOWNER.SCBP_P_ACBS_BATCH IS
  PROCEDURE SCBP_P_ACBS_RECON_BATCH(p_file_name IN VARCHAR2) AS
    o_return VARCHAR2(10);
    CURSOR ACBS_REC IS
      SELECT BANK_GROUP_CODE,
             CTY_CODE,
             ARM_CODE,
             RM_NAME,
             CUSTOMER_NAME,
             COCOA_TXN_REF_NUMBER,
             LOAN_CUSTOMER_ID,
             BUSINESS_DATE,
             PORTFOLIO_DESCRIPTION,
             GL_UNIT,
             CUSTOMER_LE_ID,
             CORE_BANK_ID,
             FACILITY_ID,
             PRODUCT_CODE_ID,
             PRODUCT_CODE,
             PURPOSE_DESCRIPTION,
             LOAN_ID,
             CURRENCY,
             PRINCIPAL_AMOUNT,
             VALUE_DATE,
             RE_PRICING_START_DATE,
             RE_PRICING_END_DATE,
             TENOR,
             FINAL_MATURITY_DATE,
             INVESTOR_BASE_RATE,
             LIQUIDITY_PREMIUM,
             TOTAL_INVESTOR_RATE,
             INTEREST_BASIS,
             BASE_RATE,
             CUSTOMER_MARGIN,
             RESERVE_MARGIN,
             INTEREST_RATE_A_I_R,
             YEAR_BASIS_CODE,
             INTEREST_ACCRUED,
             DAILY_ACCRUAL_AMOUNT_AS,
             INTEREST_AT_MATURITY,
             FILENAME,
             PROCESSED_TIMESTAMP,
             DEBUGMSG
        FROM SCBT_T_IPS_ACBS_LOG
       WHERE FILENAME = p_file_name; --CTY_CODE = p_cty_code AND BUSINESS_DATE=p_business_date;
    each_acbsRec              SCBT_T_IPS_ACBS_LOG%rowtype;
    msg                       VARCHAR2(200);
    v_newStepCreated          VARCHAR(10);
    v_tp_ref_no               VARCHAR2(20);
     v_tp_ref_no_temp               VARCHAR2(20);
    p_biz_date                DATE;
    p_cty_code                VARCHAR2(10);
    v_cocoa_cust_name         varchar(100);
    v_cocoa_txn_ref_no        SCBT_T_TXN_MST.TXN_REF_ID%TYPE;
    v_cocoa_customerId        SCBT_T_TXN_MST.CUST_ID%TYPE;
    v_cocoa_customerLeId      scbt_r_party_ext_id.ext_system_id%TYPE;
    v_cocoa_productCode       SCBT_T_TXN_MST.PRODUCT_CODE%TYPE;
    v_cocoa_acbs_productCode  VARCHAR2(20);
    v_temp_principalAmount    SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
    v_cocoa_principalAmount   SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
    v_txnUtilAmt              SCBT_T_TXN_MST.TXN_CCY_UTIL_AMT%TYPE;
    v_cocoa_finalMaturityDate SCBT_T_TXN_MST.MATURITY_DATE%TYPE;
    v_cocoa_ccy_code          SCBT_T_TXN_MST.TXN_CCY_CODE%TYPE;
    v_cocoa_cmt_mgr_pwid      VARCHAR2(16 BYTE);
    v_cocoa_cmt_mgr           VARCHAR2(35 BYTE);
    V_COUNT                   NUMBER(10);
    allisgood                 NUMBER(2) := 0;
    v_error_msg               VARCHAR2(200);
    v_debug                   VARCHAR2(2000);
    /*Error Messages*/
  BEGIN
    /* TODO implementation required */
    v_debug  := v_debug || 'Starting the ACBS Batch.....';
    o_return := '000';
     DBMS_OUTPUT.ENABLE(1000000);
     --dbms_output.disable;


    --BUSINESS_DATE example CCA_ACBC_GLOBAL-06072012-1-SG.dat
    p_biz_date := TO_DATE(SUBSTR(p_file_name,
                                 INSTR(p_file_name, '-') + 1,
                                 8),
                          'DDMMYYYY');

    --CTY CODE
    p_cty_code := SUBSTR(p_file_name, INSTR(p_file_name, '.dat') - 2, 2);
    /*
    Housing keeping code for
    ACBS_RECON_HIST and
    ACBS_RECON_MST
    */
    /* DELETE RECORDS FROM MASTER and HISTORY TABLE FOR THIS BUSINESS DATE */
    DELETE FROM SCBT_T_IPS_ACBS_RECON_HIST
     WHERE BUSINESS_DATE = p_biz_date and CTY_CODE=p_cty_code;
    DELETE FROM SCBT_T_IPS_ACBS_RECON_MST WHERE BUSINESS_DATE = p_biz_date and CTY_CODE=p_cty_code;
    /* RECON TABLE WILL HAVE DETAILS FOR THE LAST 15 DAYS AND REST OTHER WILL BE MOVED
    TO HISTORY */
    DELETE FROM SCBT_T_IPS_ACBS_RECON_MST
     WHERE BUSINESS_DATE < (p_biz_date - 15);
    FOR each_acbsRec IN ACBS_REC LOOP
      /*
      Initialization block
      */

      msg                       :='';
      v_newStepCreated          :='';
      v_tp_ref_no               :='';
      v_cocoa_cust_name         :='';
      v_cocoa_txn_ref_no        :='';
      v_cocoa_customerId        :='';
      v_cocoa_customerLeId      :='';
      v_cocoa_productCode       :='';
      v_cocoa_acbs_productCode  :='';
      v_temp_principalAmount    :='';
      v_cocoa_principalAmount   :='';
      v_cocoa_finalMaturityDate :='';
      v_cocoa_ccy_code          :='';
      v_cocoa_cmt_mgr_pwid      :='';
      v_cocoa_cmt_mgr           :='';
      V_COUNT                   :=0;
      allisgood                 := 0;
      v_error_msg               :='';
      v_debug                   :='';
      v_tp_ref_no_temp          :='';
      v_txnUtilAmt :=0;
      BEGIN
        dbms_output.put_line('COCOA_TXN_REF_NUMBER=>' ||
                             each_acbsRec.COCOA_TXN_REF_NUMBER ||
                             ' CUSTOMER_LE_ID==> ' ||
                             each_acbsRec.CUSTOMER_LE_ID ||
                             ' PRODUCT_CODE_ID==> ' ||
                             each_acbsRec.PRODUCT_CODE_ID ||
                             ' PRINCIPAL_AMOUNT==> ' ||
                             each_acbsRec.PRINCIPAL_AMOUNT ||
                              ' LOAN ID==> ' ||
                             each_acbsRec.LOAN_ID ||
                             ' FINAL_MATURITY_DATE==> ' ||
                             each_acbsRec.FINAL_MATURITY_DATE);
        /*PROCEDURE  ACBS_UPDATE_RECON_TABLE (ACBS_REC in IPS_ACBS_LOG%ROWTYPE,COCOA_PRODUCT_CODE  in VARCHAR2,COCOA_TXN_CCY_AMT  in NUMBER,COCOA_MATURITY_DATE  in DATE,COCOA_CCY_CODE in  VARCHAR2,COCOA_CUST_LE_ID  in VARCHAR2,msg in VARCHAR2);*/
        v_debug := v_debug || '#' || 'COCOA_TXN_REF_NUMBER=>' ||
                   each_acbsRec.COCOA_TXN_REF_NUMBER ||
                   ', CUSTOMER_LE_ID==> ' || each_acbsRec.CUSTOMER_LE_ID ||
                   ', PRODUCT_CODE_ID==> ' || each_acbsRec.PRODUCT_CODE_ID ||
                   ', PRINCIPAL_AMOUNT==> ' || Each_Acbsrec.Principal_Amount ||
                   ', LOAN ID==> ' || Each_Acbsrec.Loan_Id ||
                   ', CURRENCY==>'||each_acbsRec.CURRENCY||
                   ', FINAL_MATURITY_DATE==> ' ||  each_acbsRec.FINAL_MATURITY_DATE;

        IF (each_acbsRec.COCOA_TXN_REF_NUMBER IS NULL) THEN
          v_error_msg := SCBP_P_ACBS_BATCH.g_error_missing_txn;
          v_debug     := v_debug || '#' || 'COCOA_TXN_REF_NUMBER is null in the feed';
          SCBP_P_ACBS_UPDATE_RECON(each_acbsRec,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  v_error_msg);
        ELSE
          /* if more rows are returned than may raise TOO many rows exception*/

          SELECT COUNT(*)
            INTO V_COUNT
            FROM SCBT_T_TXN_MST txn
           WHERE txn.TXN_REF_ID = each_acbsRec.COCOA_TXN_REF_NUMBER;
          /*     */
          /* if no matching record found in cocoa*/
          v_debug := v_debug || '#' || 'matching txn count ' || V_COUNT;
          IF (V_COUNT < 1 OR V_COUNT > 1) THEN
            v_error_msg := SCBP_P_ACBS_BATCH.g_error_incorrect_txn;
            SCBP_P_ACBS_UPDATE_RECON(each_acbsRec,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    NULL,
                                    v_error_msg);
          ELSE
            /* if there is a record found , match the remaing fields*/
            SELECT txn.TXN_REF_ID,
                   txn.CUST_ID,
                   txn.PRODUCT_CODE,
                   txn.TXN_CCY_AMT,
                   txn.MATURITY_DATE,
                   txn.txn_ccy_code,
                   txn.tp_ref_id,
                   txn.TXN_CCY_UTIL_AMT
              INTO v_cocoa_txn_ref_no,
                   v_cocoa_customerId,
                   v_cocoa_productCode,
                   v_cocoa_principalAmount,
                   v_cocoa_finalMaturityDate,
                   v_cocoa_ccy_code,
                   v_tp_ref_no,
                   v_txnUtilAmt
              FROM SCBT_T_TXN_MST txn
             WHERE txn.TXN_REF_ID = each_acbsRec.COCOA_TXN_REF_NUMBER;
            /* mapping the customer id*/
            V_Debug := V_Debug || '#' ||
                       ' getting values from cocoa'
                       ||' v_cocoa_customerId=>' ||V_Cocoa_Customerid
                       || ', v_cocoa_productCode==> ' ||V_Cocoa_Productcode
                       || ', v_cocoa_principalAmount==> ' || V_Cocoa_Principalamount
                       || ', v_cocoa_finalMaturityDate==> ' || V_Cocoa_Finalmaturitydate
                       ||', TXN_CCY_UTIL_AMT==> '||  v_txnUtilAmt
                       || 'v_cocoa_ccy_code==> ' || V_Cocoa_Ccy_Code
                       || ', v_tp_ref_no=>' || v_tp_ref_no;

            SELECT COUNT(ext_system_id)
              INTO V_COUNT
              FROM scbt_r_party_ext_id p_ext
             WHERE p_ext.ext_system_code = 'SC'
               AND p_ext.party_id = v_cocoa_customerId;
            v_debug := v_debug || '#' ||
                       ' mapping count v_cocoa_customerId ' || V_COUNT;
            IF (V_COUNT = 1) THEN
              SELECT p_ext.ext_system_id
                INTO v_cocoa_customerLeId
                FROM scbt_r_party_ext_id p_ext
               WHERE p_ext.ext_system_code = 'SC'
                 AND p_ext.party_id = v_cocoa_customerId;
            ELSE
              v_cocoa_customerLeId := '';
            END IF;

            v_debug := v_debug || '#' ||
                       'after cust maping  v_cocoa_customerLeId ' ||
                       v_cocoa_customerLeId;

            v_debug := v_debug || '#' || 'BEFORE product code maping' ||
                       v_cocoa_productCode;
        /*    SELECT COUNT(code_value_2)
              INTO V_COUNT
              FROM SCBT_R_MAP_INFO
             WHERE MAP_ID = 'MLM03'
               AND code_value_1 = each_acbsRec.PRODUCT_CODE_ID ;
            IF (V_COUNT = 1) THEN
              SELECT code_value_2
                INTO v_cocoa_acbs_productCode
                FROM SCBT_R_MAP_INFO
               WHERE MAP_ID = 'MLM03'
                 AND code_value_1 = each_acbsRec.PRODUCT_CODE_ID;
            ELSE
              v_cocoa_acbs_productCode := '';
            END IF;*/
            /*
            productCode:= scbf_c_get_param_data('ACBS','01','SCB',p_cty_code,NULL,NULL,productCode,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
            dbms_output.put_line('after product code maping    '||productCode);
            */
            v_debug := v_debug || '#' || 'v_txnUtilAmt =' ||
                       v_txnUtilAmt;
                       if(v_txnUtilAmt is null OR v_txnUtilAmt='')THEN
                       v_txnUtilAmt:=0.0;
                       END IF;
              v_cocoa_principalAmount:= to_number(v_cocoa_principalAmount)- to_number(v_txnUtilAmt);
            v_debug := v_debug || '#' || 'v_cocoa_principalAmount =' ||
                       v_cocoa_principalAmount;

            v_temp_principalAmount := to_number(REPLACE(each_acbsRec.PRINCIPAL_AMOUNT,
                                                        ','));
            v_debug                := v_debug || '#' ||
                                      'v_temp_principalAmount =' ||
                                      v_temp_principalAmount;

            IF (NVL(each_acbsRec.CURRENCY, 'X') !=
               NVL(v_cocoa_ccy_code, 'Y')) THEN
              v_debug     := v_debug || '#' || 'currency not matching';
              v_error_msg := v_error_msg ||
                             SCBP_P_ACBS_BATCH.g_error_mismatch_currency;
              allisgood   := 1;
            End If;
            IF (each_acbsRec.LOAN_ID is NULL OR LENGTH(each_acbsRec.LOAN_ID)!=11 ) THEN
              v_debug     := v_debug || '#' || 'invalid loan id';
              v_error_msg := v_error_msg ||
                             SCBP_P_ACBS_BATCH. g_error_invalid_loanId;
              allisgood   := 1;
            END IF;
            IF (v_temp_principalAmount != v_cocoa_principalAmount) THEN
              v_debug     := v_debug || '#' || ' amount not matching';
              v_error_msg := v_error_msg ||
                             SCBP_P_ACBS_BATCH.g_error_mismatch_amount;
              allisgood   := 1;
            END IF;
            IF (each_acbsRec.FINAL_MATURITY_DATE !=
               v_cocoa_finalMaturityDate) THEN
              v_debug     := v_debug || '#' || 'maturity date not matching';
              v_error_msg := v_error_msg ||
                             SCBP_P_ACBS_BATCH.g_error_mismatch_maturityDate;
              allisgood   := 1;
            END IF;
            IF (NVL(each_acbsRec.CUSTOMER_LE_ID, 'X') !=
               NVL(v_cocoa_customerLeId, 'Y')) THEN
              v_debug     := v_debug || '#' || 'cust not matching';
              v_error_msg := v_error_msg ||
                             SCBP_P_ACBS_BATCH.g_error_mismatch_clientId;
              allisgood   := 1;
            END IF;
            /* if everything is ok*/
            IF allisgood = 0 THEN
            v_tp_ref_no_temp:=each_acbsRec.LOAN_ID;
              IF ((v_tp_ref_no IS NULL OR v_tp_ref_no = '') OR (v_tp_ref_no!=v_tp_ref_no_temp)) THEN

                v_debug := v_debug || '#' || 'creating the step TP_REF_ID=' ||
                           each_acbsRec.LOAN_CUSTOMER_ID ||
                           'for TXN_REF_ID=' ||
                           each_acbsRec.COCOA_TXN_REF_NUMBER;
                SCBP_P_CREATE_NEW_STEP('SCB',
                                p_cty_code,
                                v_tp_ref_no_temp,
                                'ACBS',
                                each_acbsRec.COCOA_TXN_REF_NUMBER,
                                v_newStepCreated);
                IF (v_newStepCreated = NULL) THEN
                  v_error_msg := SCBP_P_ACBS_BATCH.g_Notprocessed;
                  v_debug     := v_debug || '#' || 'step creation failed';
                ELSE
                  v_error_msg := SCBP_P_ACBS_BATCH.g_processed;
                  v_debug     := v_debug || '#' || 'step creation success';
                END IF;
                ELSE
                v_debug     := v_debug || '#' ||'all is good no need to update';

              END IF;
            ELSE
              /*ACBS_REC in SCBT_T_IPS_ACBS_LOG%ROWTYPE,COCOA_PRODUCT_CODE  in VARCHAR2,COCOA_TXN_CCY_AMT  in NUMBER,COCOA_MATURITY_DATE  in DATE,COCOA_CCY_CODE in  VARCHAR2,COCOA_CUST_LE_ID  in VARCHAR2,msg in VARCHAR2*/
              SELECT COUNT(CMT_MGR_PWID)
                INTO V_COUNT
                FROM SCBT_R_PARTY_MST pmst, scbt_r_user_mst umst
               WHERE pmst.PARTY_ID = v_cocoa_customerId
                 AND pmst.cty_code = p_cty_code
                 AND umst.user_id = pmst.CMT_MGR_PWID;
              v_debug := v_debug || '#' || ' cmt manager count =' ||
                         V_COUNT;
              IF (V_COUNT = 1) THEN
                SELECT umst.user_id, umst.user_name, pmst.party_name
                  INTO v_cocoa_cmt_mgr_pwid,
                       v_cocoa_cmt_mgr,
                       v_cocoa_cust_name
                  FROM SCBT_R_PARTY_MST pmst, scbt_r_user_mst umst
                 WHERE pmst.PARTY_ID = v_cocoa_customerId
                   AND pmst.cty_code = p_cty_code
                   AND umst.user_id = pmst.CMT_MGR_PWID;
              ELSE
                v_cocoa_cmt_mgr_pwid := '';
                v_cocoa_cmt_mgr      := '';
                v_cocoa_cust_name    := '';
                v_error_msg          := v_error_msg ||
                                        SCBP_P_ACBS_BATCH.g_error_notfound_cmt_mgr;
                v_debug              := v_debug || '#' || ' default values';
              END IF;
              v_debug := v_debug || '#' ||
                         'updating ACBS_UPDATE_RECON_TABLE ';
              SCBP_P_ACBS_UPDATE_RECON(each_acbsRec,
                                      v_cocoa_productCode,
                                      v_cocoa_principalAmount,
                                      v_cocoa_finalMaturityDate,
                                      v_cocoa_ccy_code,
                                      v_cocoa_customerId,
                                      v_cocoa_cmt_mgr_pwid,
                                      v_cocoa_cmt_mgr,
                                      v_cocoa_cust_name,
                                      v_error_msg);
            END IF;
          END IF;
          /*else ending*/
        END IF;
        /* outer ELSE ending*/
        /*dbms_output.put_line(each_acbsRec.RM_NAME || ' ' ||each_acbsRec.COCOA_TXN_REF_NUMBER );*/
      EXCEPTION
        WHEN OTHERS THEN
          -- handles all other errors
          dbms_output.put_line('Exception occured for this record' ||
                               each_acbsRec.COCOA_TXN_REF_NUMBER ||
                               v_debug);
          v_error_msg := 'Exception occured for this record' ||
                         each_acbsRec.COCOA_TXN_REF_NUMBER;
          v_debug     := v_debug || '#' || v_error_msg;
          SCBP_P_ACBS_UPDATE_RECON(each_acbsRec,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  v_error_msg);
      END;
      dbms_output.put_line('End of record processing' || v_debug);
      v_debug := v_debug || '#' || 'End of record processing';
      SCBP_P_ACBS_IPS_ACBS_LOG(each_acbsRec, p_biz_date, v_debug);
      Commit;

    END LOOP;
    /*  match from cocoa to ACBS feed*/
    BEGIN
      /*check if u can use distinct here for avoiding duplicate txn_ref_id*/
      dbms_output.put_line(' match from cocoa to ACBS feed ');
      FOR COCOA_TXN IN (SELECT txn.bank_group_code    bank_group_code,
                              txn.txn_ref_id    txn_ref_id,
                               txn.product_code  product_code,
                               txn.cty_code      cty_code,
                               txn.txn_ccy_amt   amt,
                               txn.maturity_date maturity_date,
                               txn.txn_ccy_code  ccy,
                               txn.cust_id       cust_id
                          FROM scbt_t_txn_mst txn
                         WHERE (txn.cust_id, txn.product_code, txn.cty_code,
                                txn.bank_group_code) IN
                               (SELECT cpt.cust_id,
                                       cpt.limit_product_code,
                                       cpt.cty_code,
                                       cpt.bank_group_code
                                  FROM SCBT_R_CUST_PRODUCT_LIMIT cpt
                                 WHERE cpt.cty_code = p_cty_code AND cpt.bank_group_code='SCB'
                                   AND NVL(scbf_c_get_param_data('TP13',
                                                                 '01',
                                                                 cpt.bank_group_code,
                                                                 cpt.cty_code,
                                                                 cpt.cust_id,
                                                                 NULL,
                                                                 cpt.limit_product_code,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL,
                                                                 NULL),
                                           'X') = 'ACBS')
                           AND txn.txn_status_code <> '11') LOOP
        dbms_output.put_line('for eachs');
        v_cocoa_customerLeId := '';
        v_cocoa_cmt_mgr_pwid := '';
        v_cocoa_cmt_mgr      := '';
        v_cocoa_cust_name    := '';
        SELECT COUNT(*)
          INTO V_COUNT
          FROM SCBT_T_IPS_ACBS_LOG
         WHERE business_date = p_biz_date AND filename=p_file_name
           AND cty_code = p_cty_code
           AND cocoa_txn_ref_number = COCOA_TXN.txn_ref_id;
        dbms_output.put_line('V_COUNT' || V_COUNT || ' cust id' ||
                             COCOA_TXN.cust_id || ' txn=' ||
                             COCOA_TXN.txn_ref_id);
        IF (V_COUNT = 0) THEN
              SELECT COUNT(*)
                INTO V_COUNT
                FROM scbt_r_party_ext_id p_ext
               WHERE p_ext.ext_system_code = 'SC'
                 AND p_ext.party_id = COCOA_TXN.cust_id;
              dbms_output.put_line('ext_system_id' || V_COUNT);
              /*IF (V_COUNT = 1) THEN
                SELECT p_ext.ext_system_id
                  INTO v_cocoa_customerLeId
                  FROM scbt_r_party_ext_id p_ext
                 WHERE p_ext.ext_system_code = 'SC'
                   AND p_ext.party_id = COCOA_TXN.cust_id;
              END IF;*/
              dbms_output.put_line('v_cocoa_customerLeId' ||
                                   v_cocoa_customerLeId);
              msg := 'cocoa txn_ref_id is missing ' || COCOA_TXN.txn_ref_id;
              SELECT COUNT(CMT_MGR_PWID)
                INTO V_COUNT
                FROM SCBT_R_PARTY_MST pmst, scbt_r_user_mst umst
               WHERE pmst.PARTY_ID = COCOA_TXN.cust_id
                 AND pmst.cty_code = p_cty_code
                 AND umst.user_id = pmst.CMT_MGR_PWID;
              dbms_output.put_line('CMT_MGR_PWID' || V_COUNT);
              IF (V_COUNT = 1) THEN
                SELECT umst.user_id, umst.user_name, pmst.party_name
                  INTO v_cocoa_cmt_mgr_pwid, v_cocoa_cmt_mgr, v_cocoa_cust_name
                  FROM SCBT_R_PARTY_MST pmst, scbt_r_user_mst umst
                 WHERE pmst.PARTY_ID = COCOA_TXN.cust_id
                   AND pmst.cty_code = p_cty_code
                   AND umst.user_id = pmst.CMT_MGR_PWID;
              END IF;
              v_error_msg := SCBP_P_ACBS_BATCH.g_error_in_cocoa_not_in_acbs;
              SCBP_P_COCOA_UPDATE_RECON(COCOA_TXN.BANK_GROUP_CODE,
                                        COCOA_TXN.CTY_CODE,
                                        COCOA_TXN.txn_ref_id,
                                       COCOA_TXN.product_code,
                                       COCOA_TXN.amt,
                                       COCOA_TXN.maturity_date,
                                       COCOA_TXN.ccy,
                                       COCOA_TXN.cust_id,
                                       v_cocoa_cmt_mgr_pwid,
                                       v_cocoa_cmt_mgr,
                                       v_cocoa_cust_name,
                                       p_biz_date,
                                       p_file_name,
                                       v_error_msg);
              dbms_output.put_line('cocoa ref id ==' || COCOA_TXN.txn_ref_id);
        END IF;
      END LOOP;
    EXCEPTION
      WHEN OTHERS THEN
        -- handles all other errors
        dbms_output.put_line('Exception occured while matching records from cocoa to ACBS feed');
        o_return := '999 ';
    END;
    dbms_output.put_line('End of ACBS Batch.....');
  EXCEPTION
    WHEN OTHERS THEN
      -- handles all other errors
      dbms_output.put_line('Exception occured in the procedure while running this file' ||
                           p_file_name);
      o_return := '999 ';
      /*dbms_output.put_line('Exception accured while running this batch.....');*/
  END SCBP_P_ACBS_RECON_BATCH;
  PROCEDURE SCBP_P_ACBS_UPDATE_RECON(ACBS_REC            IN SCBT_T_IPS_ACBS_LOG%rowtype,
                                    COCOA_PRODUCT_CODE  IN VARCHAR2,
                                    COCOA_TXN_CCY_AMT   IN NUMBER,
                                    COCOA_MATURITY_DATE IN DATE,
                                    COCOA_CCY_CODE      IN VARCHAR2,
                                    COCOA_CUST_LE_ID    IN VARCHAR2,
                                    CMT_MGR_PWID        IN VARCHAR2,
                                    CMT_MGR_NAME        IN VARCHAR2,
                                    COCOA_CUST_NAME     IN VARCHAR2,
                                    msg                 IN VARCHAR2) AS
  BEGIN
    /* TODO implementation required */
    dbms_output.put_line('update one');
    INSERT INTO SCBT_T_IPS_ACBS_RECON_HIST
      (ARM_CODE,
       RM_NAME,
       CUSTOMER_NAME,
       COCOA_TXN_REF_NUMBER,
       LOAN_CUSTOMER_ID,
       BUSINESS_DATE,
       PORTFOLIO_DESCRIPTION,
       GL_UNIT,
       CUSTOMER_LE_ID,
       CORE_BANK_ID,
       FACILITY_ID,
       PRODUCT_CODE_ID,
       PRODUCT_CODE,
       PURPOSE_DESCRIPTION,
       LOAN_ID,
       CURRENCY,
       PRINCIPAL_AMOUNT,
       VALUE_DATE,
       RE_PRICING_START_DATE,
       RE_PRICING_END_DATE,
       TENOR,
       FINAL_MATURITY_DATE,
       INVESTOR_BASE_RATE,
       LIQUIDITY_PREMIUM,
       TOTAL_INVESTOR_RATE,
       INTEREST_BASIS,
       BASE_RATE,
       CUSTOMER_MARGIN,
       RESERVE_MARGIN,
       INTEREST_RATE_A_I_R,
       YEAR_BASIS_CODE,
       INTEREST_ACCRUED,
       DAILY_ACCRUAL_AMOUNT_AS,
       INTEREST_AT_MATURITY,
       CTY_CODE,
       BANK_GROUP_CODE,
       FILENAME,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       PROCESSED_TIMESTAMP,
       ERROR_MSG,
       AGING)
    VALUES
      (ACBS_REC.ARM_CODE,
       ACBS_REC.RM_NAME,
       COCOA_CUST_NAME,
       ACBS_REC.COCOA_TXN_REF_NUMBER,
       ACBS_REC.LOAN_CUSTOMER_ID,
       ACBS_REC.BUSINESS_DATE,
       ACBS_REC.PORTFOLIO_DESCRIPTION,
       ACBS_REC.GL_UNIT,
       ACBS_REC.CUSTOMER_LE_ID,
       ACBS_REC.CORE_BANK_ID,
       ACBS_REC.FACILITY_ID,
       ACBS_REC.PRODUCT_CODE_ID,
       ACBS_REC.PRODUCT_CODE,
       ACBS_REC.PURPOSE_DESCRIPTION,
       ACBS_REC.LOAN_ID,
       ACBS_REC.CURRENCY,
       ACBS_REC.PRINCIPAL_AMOUNT,
       ACBS_REC.VALUE_DATE,
       ACBS_REC.RE_PRICING_START_DATE,
       ACBS_REC.RE_PRICING_END_DATE,
       ACBS_REC.TENOR,
       ACBS_REC.FINAL_MATURITY_DATE,
       ACBS_REC.INVESTOR_BASE_RATE,
       ACBS_REC.LIQUIDITY_PREMIUM,
       ACBS_REC.TOTAL_INVESTOR_RATE,
       ACBS_REC.INTEREST_BASIS,
       ACBS_REC.BASE_RATE,
       ACBS_REC.CUSTOMER_MARGIN,
       ACBS_REC.RESERVE_MARGIN,
       ACBS_REC.INTEREST_RATE_A_I_R,
       ACBS_REC.YEAR_BASIS_CODE,
       ACBS_REC.INTEREST_ACCRUED,
       ACBS_REC.DAILY_ACCRUAL_AMOUNT_AS,
       ACBS_REC.INTEREST_AT_MATURITY,
       ACBS_REC.CTY_CODE,
       ACBS_REC.BANK_GROUP_CODE,
       ACBS_REC.FILENAME,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       sysdate,
       msg,
       SCBP_F_TXNALLREADYEXISTS(ACBS_REC.COCOA_TXN_REF_NUMBER,msg,ACBS_REC.BUSINESS_DATE));
    dbms_output.put_line('update two');
    INSERT INTO SCBT_T_IPS_ACBS_RECON_MST
      (ARM_CODE,
       RM_NAME,
       CUSTOMER_NAME,
       COCOA_TXN_REF_NUMBER,
       LOAN_CUSTOMER_ID,
       BUSINESS_DATE,
       PORTFOLIO_DESCRIPTION,
       GL_UNIT,
       CUSTOMER_LE_ID,
       CORE_BANK_ID,
       FACILITY_ID,
       PRODUCT_CODE_ID,
       PRODUCT_CODE,
       PURPOSE_DESCRIPTION,
       LOAN_ID,
       CURRENCY,
       PRINCIPAL_AMOUNT,
       VALUE_DATE,
       RE_PRICING_START_DATE,
       RE_PRICING_END_DATE,
       TENOR,
       FINAL_MATURITY_DATE,
       INVESTOR_BASE_RATE,
       LIQUIDITY_PREMIUM,
       TOTAL_INVESTOR_RATE,
       INTEREST_BASIS,
       BASE_RATE,
       CUSTOMER_MARGIN,
       RESERVE_MARGIN,
       INTEREST_RATE_A_I_R,
       YEAR_BASIS_CODE,
       INTEREST_ACCRUED,
       DAILY_ACCRUAL_AMOUNT_AS,
       INTEREST_AT_MATURITY,
       CTY_CODE,
       BANK_GROUP_CODE,
       FILENAME,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       PROCESSED_TIMESTAMP,
       ERROR_MSG,
       AGING)
    VALUES
      (ACBS_REC.ARM_CODE,
       ACBS_REC.RM_NAME,
       COCOA_CUST_NAME,
       ACBS_REC.COCOA_TXN_REF_NUMBER,
       ACBS_REC.LOAN_CUSTOMER_ID,
       ACBS_REC.BUSINESS_DATE,
       ACBS_REC.PORTFOLIO_DESCRIPTION,
       ACBS_REC.GL_UNIT,
       ACBS_REC.CUSTOMER_LE_ID,
       ACBS_REC.CORE_BANK_ID,
       ACBS_REC.FACILITY_ID,
       ACBS_REC.PRODUCT_CODE_ID,
       ACBS_REC.PRODUCT_CODE,
       ACBS_REC.PURPOSE_DESCRIPTION,
       ACBS_REC.LOAN_ID,
       ACBS_REC.CURRENCY,
       ACBS_REC.PRINCIPAL_AMOUNT,
       ACBS_REC.VALUE_DATE,
       ACBS_REC.RE_PRICING_START_DATE,
       ACBS_REC.RE_PRICING_END_DATE,
       ACBS_REC.TENOR,
       ACBS_REC.FINAL_MATURITY_DATE,
       ACBS_REC.INVESTOR_BASE_RATE,
       ACBS_REC.LIQUIDITY_PREMIUM,
       ACBS_REC.TOTAL_INVESTOR_RATE,
       ACBS_REC.INTEREST_BASIS,
       ACBS_REC.BASE_RATE,
       ACBS_REC.CUSTOMER_MARGIN,
       ACBS_REC.RESERVE_MARGIN,
       ACBS_REC.INTEREST_RATE_A_I_R,
       ACBS_REC.YEAR_BASIS_CODE,
       ACBS_REC.INTEREST_ACCRUED,
       ACBS_REC.DAILY_ACCRUAL_AMOUNT_AS,
       ACBS_REC.INTEREST_AT_MATURITY,
       ACBS_REC.CTY_CODE,
       ACBS_REC.BANK_GROUP_CODE,
       ACBS_REC.FILENAME,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       sysdate,
       msg,
       SCBP_F_TXNALLREADYEXISTS(ACBS_REC.COCOA_TXN_REF_NUMBER,msg,ACBS_REC.BUSINESS_DATE));
    NULL;
  END SCBP_P_ACBS_UPDATE_RECON;
  PROCEDURE SCBP_P_COCOA_UPDATE_RECON(
                                    BANK_GROUP_CODE        VARCHAR2,
                                    CTY_CODE                VARCHAR2,
                                    COCOA_TXN_REF_NUMBER IN VARCHAR2,
                                     COCOA_PRODUCT_CODE   IN VARCHAR2,
                                     COCOA_TXN_CCY_AMT    IN NUMBER,
                                     COCOA_MATURITY_DATE  IN DATE,
                                     COCOA_CCY_CODE       IN VARCHAR2,
                                     COCOA_CUST_LE_ID     IN VARCHAR2,
                                     CMT_MGR_PWID         IN VARCHAR2,
                                     CMT_MGR_NAME         IN VARCHAR2,
                                     COCOA_CUST_NAME      IN VARCHAR2,
                                     BUSINESS_DATE        IN VARCHAR2,
                                     filename             IN VARCHAR2,
                                     msg                  IN VARCHAR2) AS
  BEGIN
    /* TODO implementation required */
    dbms_output.put_line('update one');
    INSERT INTO SCBT_T_IPS_ACBS_RECON_HIST
      (BANK_GROUP_CODE,
        CTY_CODE,
       COCOA_TXN_REF_NUMBER,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       CUSTOMER_NAME,
       BUSINESS_DATE,
       FILENAME,
       PROCESSED_TIMESTAMP,
       ERROR_MSG,
       AGING)
    VALUES
      (BANK_GROUP_CODE,
      CTY_CODE,
      COCOA_TXN_REF_NUMBER,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       COCOA_CUST_NAME,
       BUSINESS_DATE,
       filename,
       sysdate,
       msg,
        SCBP_F_TXNALLREADYEXISTS(COCOA_TXN_REF_NUMBER,msg,BUSINESS_DATE));
    dbms_output.put_line('update two');
    INSERT INTO SCBT_T_IPS_ACBS_RECON_MST
      (BANK_GROUP_CODE,
      CTY_CODE,
      COCOA_TXN_REF_NUMBER,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       CUSTOMER_NAME,
       BUSINESS_DATE,
       FILENAME,
       PROCESSED_TIMESTAMP,
       ERROR_MSG,
       AGING)
    VALUES
      (BANK_GROUP_CODE,
      CTY_CODE,
      COCOA_TXN_REF_NUMBER,
       COCOA_PRODUCT_CODE,
       COCOA_TXN_CCY_AMT,
       COCOA_MATURITY_DATE,
       COCOA_CCY_CODE,
       COCOA_CUST_LE_ID,
       CMT_MGR_PWID,
       CMT_MGR_NAME,
       COCOA_CUST_NAME,
       BUSINESS_DATE,
       filename,
       sysdate,
       msg,
         SCBP_F_TXNALLREADYEXISTS(COCOA_TXN_REF_NUMBER,msg,BUSINESS_DATE));
    NULL;
  END SCBP_P_COCOA_UPDATE_RECON;
  PROCEDURE SCBP_P_CREATE_NEW_STEP(p_back_group_code IN VARCHAR2,
                            p_cty_code        IN VARCHAR2,
                            p_tp_ref_no       IN VARCHAR2,
                            p_tp_sys_code     IN VARCHAR2,
                            p_txn_ref_id      IN VARCHAR2,
                            o_return          OUT VARCHAR2) AS
    v_tbu_code            VARCHAR2(6);
    v_latest_deal_step_id VARCHAR2(20);
    v_txn_rec_id          VARCHAR2(20);
    p_bu_code             VARCHAR2(10);
    p_deal_id             VARCHAR2(20);


  BEGIN
   SAVEPOINT            SAVE_POINT_NEW_STEP;
    o_return              := NULL;
    p_bu_code             := SUBSTR(p_txn_ref_id, 1, 5);
    v_tbu_code            := SUBSTR(p_bu_code, 3);
    p_deal_id             := SUBSTR(p_txn_ref_id, 1, 11);
    v_latest_deal_step_id := GENERATESTEPID(p_back_group_code,
                                            p_cty_code,
                                            v_tbu_code,
                                            p_deal_id,
                                            'M');
    IF v_latest_deal_step_id IS NOT NULL THEN
      INSERT INTO scbt_t_deal_hist
        (BANK_GROUP_CODE,
         CTY_CODE,
         BU_CODE,
         CUST_ID,
         DEAL_ID,
         DEAL_STEP_ID,
         BUSINESS_DATE,
         VALUE_DATE,
         STEP_CODE,
         SUB_STEP_CODE,
         STEP_STATUS_CODE,
         MAKER_ID,
         MAKER_TIMESTAMP,
         CHECKER_ID,
         CHECKER_TIMESTAMP,
         OFFERING_ID,
         OFFERING_TIMESTAMP,
         MANUAL_EXCEPTION_FLAG,
         MANUAL_EXCEPTION_REASON,
         EXCEPTION_PRE_APPROVED_FLAG,
         EXCEPTION_RM_APPROVED_FLAG,
         CO_BORROWER_ID,
         DEAL_STEP_CCY_CODE,
         DEAL_STEP_CCY_AMT,
         TP_CUST_ID,
         TP_DEAL_ID,
         TP_STEP_ID,
         TP_SYSTEM_CODE,
         TP_REJECT_FLAG,
         TP_REJECT_REASON)
        (SELECT *
           FROM (SELECT dealHist.BANK_GROUP_CODE,
                        dealHist.CTY_CODE,
                        dealHist.BU_CODE,
                        dealHist.CUST_ID,
                        dealHist.DEAL_ID,
                        v_latest_deal_step_id AS DEAL_STEP_ID,
                        dealHist.BUSINESS_DATE,
                        dealHist.VALUE_DATE,
                        'CTL' AS STEP_CODE,
                        'MISC' AS SUB_STEP_CODE,
                        '03' AS STEP_STATUS_CODE,
                        'USRBATCH1' AS MAKER_ID,
                        sysdate AS MAKER_TIMESTAMP,
                        'USRBATCH1' AS CHECKER_ID,
                        sysdate AS CHECKER_TIMESTAMP,
                        NULL AS OFFERING_ID,
                        NULL AS OFFERING_TIMESTAMP,
                        NULL AS MANUAL_EXCEPTION_FLAG,
                        NULL AS MANUAL_EXCEPTION_REASON,
                        'N' AS EXCEPTION_PRE_APPROVED_FLAG,
                        'N' AS EXCEPTION_RM_APPROVED_FLAG,
                        dealHist.CO_BORROWER_ID,
                        dealHist.DEAL_STEP_CCY_CODE,
                        dealHist.DEAL_STEP_CCY_AMT,
                        dealHist.TP_CUST_ID,
                        dealHist.TP_DEAL_ID,
                        dealHist.TP_STEP_ID,
                        dealHist.TP_SYSTEM_CODE,
                        dealHist.TP_REJECT_FLAG,
                        dealHist.TP_REJECT_REASON
                   FROM scbt_t_deal_hist dealHist
                  WHERE dealHist.DEAL_ID = p_deal_id
                    AND dealHist.cty_code = p_cty_code
                    AND dealHist.bank_group_code = p_back_group_code
                    AND dealHist.bu_code = p_bu_code
                  ORDER BY dealHist.deal_step_id DESC)
          WHERE rownum = 1);
      dbms_output.put_line('scbt_t_deal_hist updated');
      UPDATE scbt_t_deal_mst
         SET latest_deal_step_id = v_latest_deal_step_id
       WHERE deal_id = p_deal_id
         AND cty_code = p_cty_code
         AND bank_group_code = p_back_group_code
         AND bu_code = p_bu_code;
      dbms_output.put_line('scbt_t_deal_mst updated');
      SELECT SCBS_C_RECID.NEXTVAL
        INTO v_txn_rec_id
        FROM dual2
       WHERE ROWNUM = 1;
      dbms_output.put_line('v_txn_rec_id ' || v_txn_rec_id);
      /* copy from master in to histor
      txn_status_code is 08 txn_step_code=MISC
      mst_txn_step_code not sure of the value , currently copying from master
      */
      INSERT INTO scbt_t_txn_hst
        (ACCEPTED_FLAG,
         ADDITIONAL_LIAB_AMT,
         ADDITIONAL_LIAB_AMT_CCY,
         AUTO_REVERSAL_FLAG,
         BANK_GROUP_CODE,
         BOOKING_BRANCH,
         CASH_MARGIN_ADJ,
         CASH_MARGIN_ADJ_AMT,
         CASH_MARGIN_CCY_AMT,
         CASH_MARGIN_CCY_CODE,
         CASH_MARGIN_ORIGN_AMT,
         CASH_MARGIN_PCT,
         CMT_REF_NO,
         CM_CCY_RELEASE_AMT,
         CONTACT_ID,
         CPTY_ID,
         CPTY_ROLE_CODE,
         CTY_CODE,
         CUST_ID,
         CUST_ROLE_CODE,
         DEAL_ID,
         DEAL_STEP_ID,
         DELIV_SCHEDULE_CODE,
         DELIV_SCHEDULE_DAYS,
         DELIV_SCHEDULE_YEAR,
         DOCUMENT_TYPE,
         DUE_DATE,
         EFFECTIVE_DATE,
         EFFECTIVE_DATE_IS_ZERO,
         EVERGREEN_LC_FLAG,
         EXCHG_CONTRACT,
         FINANCE_NO,
         HEDGE_DATE,
         INCOTERM,
         ISSUE_DATE,
         LATEST_TXN_REC_ID,
         LIMIT_TRANSFER,
         LINKED_TXN_REF_ID,
         MATURITY_DATE,
         MAX_SYNDICATED_TXN_AMT,
         MAX_SYNDICATED_TXN_AMT_CCY,
         MST_TXN_STEP_CODE,
         NEGATIVE_TOLERANCE_PCT,
         OD_COLLATERAL_REF,
         PARENT_TXN_REC_ID,
         PARENT_TXN_REF_ID,
         POSITIVE_TOLERANCE_PCT,
         PREV_DEAL_STEP_ID,
         PRODUCT_CODE,
         PRODUCT_SUB_TYPE,
         PROD_LIMIT_ID,
         REMARKS,
         REVOLVING_LC_FLAG,
         SCB_RISK_SHARING_PCT,
         SCB_ROLE,
         SECURITY_LEVEL,
         SHIP_DATE,
         SHIP_FROM,
         SHIP_TO,
         SHORTFALL_OFFSET_TYPE,
         SYNDICATED_TXN_AMT,
         SYNDICATED_TXN_AMT_CCY,
         SYNDICATED_UTIL_AMT,
         SYNDICATED_UTIL_AMT_CCY,
         SYNDICATION_ID,
         SYND_NEGATIVE_TOLERANCE_PCT,
         SYND_POSITIVE_TOLERANCE_PCT,
         TENOR,
         TOTAL_ENDORSED_CCY_AMT,
         TOTAL_ENDORSED_CCY_CODE,
         TOTAL_EXPIRY_DAYS,
         TP_REFER_STEP_CODE,
         TP_REF_ID,
         TP_STEP_CODE,
         TP_SYSTEM_CODE,
         TRANSACTION_TYPE,
         TXN_CCY_AMT,
         TXN_CCY_CODE,
         TXN_CCY_NET_AMT,
         TXN_CCY_ORIGN_AMT,
         TXN_CCY_UTIL_AMT,
         TXN_REC_ID,
         TXN_REFER_STEP_CODE,
         TXN_REFER_STEP_NO,
         TXN_REF_ID,
         TXN_STATUS_CODE,
         TXN_STEP_CODE)
        (SELECT txnMst.ACCEPTED_FLAG,
                txnMst.ADDITIONAL_LIAB_AMT,
                txnMst.ADDITIONAL_LIAB_AMT_CCY,
                txnMst.AUTO_REVERSAL_FLAG,
                txnMst.BANK_GROUP_CODE,
                txnMst.BOOKING_BRANCH,
                txnMst.CASH_MARGIN_ADJ,
                txnMst.CASH_MARGIN_ADJ_AMT,
                txnMst.CASH_MARGIN_CCY_AMT,
                txnMst.CASH_MARGIN_CCY_CODE,
                txnMst.CASH_MARGIN_ORIGN_AMT,
                txnMst.CASH_MARGIN_PCT,
                txnMst.CMT_REF_NO,
                txnMst.CM_CCY_RELEASE_AMT,
                txnMst.CONTACT_ID,
                txnMst.CPTY_ID,
                txnMst.CPTY_ROLE_CODE,
                txnMst.CTY_CODE,
                txnMst.CUST_ID,
                txnMst.CUST_ROLE_CODE,
                txnMst.DEAL_ID,
                v_latest_deal_step_id AS DEAL_STEP_ID,
                txnMst.DELIV_SCHEDULE_CODE,
                txnMst.DELIV_SCHEDULE_DAYS,
                txnMst.DELIV_SCHEDULE_YEAR,
                txnMst.DOCUMENT_TYPE,
                txnMst.DUE_DATE,
                txnMst.EFFECTIVE_DATE,
                txnMst.EFFECTIVE_DATE_IS_ZERO,
                txnMst.EVERGREEN_LC_FLAG,
                txnMst.EXCHG_CONTRACT,
                txnMst.FINANCE_NO,
                txnMst.HEDGE_DATE,
                txnMst.INCOTERM,
                txnMst.ISSUE_DATE,
                TXN_REC_ID AS LATEST_TXN_REC_ID,
                txnMst.LIMIT_TRANSFER,
                txnMst.LINKED_TXN_REF_ID,
                txnMst.MATURITY_DATE,
                txnMst.MAX_SYNDICATED_TXN_AMT,
                txnMst.MAX_SYNDICATED_TXN_AMT_CCY,
                'NEW' AS MST_TXN_STEP_CODE,
                txnMst.NEGATIVE_TOLERANCE_PCT,
                txnMst.OD_COLLATERAL_REF,
                TXN_REC_ID AS PARENT_TXN_REC_ID,
                txnMst.PARENT_TXN_REF_ID,
                txnMst.POSITIVE_TOLERANCE_PCT,
                txnMst.PREV_DEAL_STEP_ID,
                txnMst.PRODUCT_CODE,
                txnMst.PRODUCT_SUB_TYPE,
                txnMst.PROD_LIMIT_ID,
                txnMst.REMARKS,
                txnMst.REVOLVING_LC_FLAG,
                txnMst.SCB_RISK_SHARING_PCT,
                txnMst.SCB_ROLE,
                txnMst.SECURITY_LEVEL,
                txnMst.SHIP_DATE,
                txnMst.SHIP_FROM,
                txnMst.SHIP_TO,
                txnMst.SHORTFALL_OFFSET_TYPE,
                txnMst.SYNDICATED_TXN_AMT,
                txnMst.SYNDICATED_TXN_AMT_CCY,
                txnMst.SYNDICATED_UTIL_AMT,
                txnMst.SYNDICATED_UTIL_AMT_CCY,
                txnMst.SYNDICATION_ID,
                txnMst.SYND_NEGATIVE_TOLERANCE_PCT,
                txnMst.SYND_POSITIVE_TOLERANCE_PCT,
                txnMst.TENOR,
                txnMst.TOTAL_ENDORSED_CCY_AMT,
                txnMst.TOTAL_ENDORSED_CCY_CODE,
                txnMst.TOTAL_EXPIRY_DAYS,
                txnMst.TP_REFER_STEP_CODE,
                p_tp_ref_no AS TP_REF_ID,
                txnMst.TP_STEP_CODE,
                p_tp_sys_code AS TP_SYSTEM_CODE,
                txnMst.TRANSACTION_TYPE,
                txnMst.TXN_CCY_AMT,
                txnMst.TXN_CCY_CODE,
                txnMst.TXN_CCY_NET_AMT,
                txnMst.TXN_CCY_ORIGN_AMT,
                txnMst.TXN_CCY_UTIL_AMT,
                v_txn_rec_id AS TXN_REC_ID,
                txnMst.TXN_REFER_STEP_CODE,
                txnMst.TXN_REFER_STEP_NO,
                txnMst.TXN_REF_ID,
                NULL AS TXN_STATUS_CODE,
                'MISC' AS TXN_STEP_CODE
           FROM scbt_t_txn_mst txnMst
          WHERE txnmst.txn_ref_id = p_txn_ref_id
            AND txnmst.cty_code = p_cty_code
            AND txnmst.bank_group_code = p_back_group_code
            AND txnmst.txn_status_code <> '11');
      dbms_output.put_line('scbt_t_txn_hst updated');
      /* select *
      insert into scbt_t_txn_hst(BANK_GROUP_CODE,CTY_CODE,TXN_REC_ID,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,PARENT_TXN_REF_ID,DEAL_ID,CUST_ID,DEAL_STEP_ID,PROD_LIMIT_ID,TXN_STEP_CODE,TXN_STEP_NO,TXN_REFER_STEP_CODE,TXN_REFER_STEP_NO,TP_REF_ID,TP_STEP_CODE,TP_REFER_STEP_CODE,PRODUCT_CODE,PRODUCT_SUB_TYPE,SHORTFALL_OFFSET_TYPE,CPTY_ID,CPTY_ROLE_CODE,NEGATIVE_TOLERANCE_PCT,POSITIVE_TOLERANCE_PCT,TXN_CCY_CODE,TXN_CCY_ORIGN_AMT,TXN_CCY_AMT,TXN_CCY_NET_AMT,TXN_CCY_UTIL_AMT,TXN_STATUS_CODE,SHIP_FROM,SHIP_TO,INCOTERM,SHIP_DATE,ISSUE_DATE,EFFECTIVE_DATE,MATURITY_DATE,TENOR,DUE_DATE,REMARKS,DOCUMENT_TYPE,ACCEPTED_FLAG,SECURITY_LEVEL,DELIV_SCHEDULE_DAYS,DELIV_SCHEDULE_CODE,DELIV_SCHEDULE_YEAR,EXCHG_CONTRACT,HEDGE_DATE,CUST_ROLE_CODE,CASH_MARGIN_CCY_AMT,CASH_MARGIN_CCY_CODE,REVOLVING_LC_FLAG,EVERGREEN_LC_FLAG,AUTO_REVERSAL_FLAG,MST_TXN_STEP_CODE,FINANCE_NO,LINKED_TXN_REF_ID,CM_CCY_RELEASE_AMT,CASH_MARGIN_PCT,TP_SYSTEM_CODE,CASH_MARGIN_ADJ_AMT,CASH_MARGIN_ADJ,CASH_MARGIN_ORIGN_AMT,
      EFFECTIVE_DATE_IS_ZERO,OD_COLLATERAL_REF,CONTACT_ID,PREV_DEAL_STEP_ID,TRANSACTION_TYPE,SCB_ROLE,SCB_RISK_SHARING_PCT,SYNDICATED_TXN_AMT_CCY,SYNDICATED_TXN_AMT,SYND_POSITIVE_TOLERANCE_PCT,SYND_NEGATIVE_TOLERANCE_PCT,MAX_SYNDICATED_TXN_AMT_CCY,MAX_SYNDICATED_TXN_AMT,SYNDICATION_ID,ADDITIONAL_LIAB_AMT_CCY,ADDITIONAL_LIAB_AMT,CMT_REF_NO,SYNDICATED_UTIL_AMT_CCY,SYNDICATED_UTIL_AMT,BOOKING_BRANCH,TOTAL_EXPIRY_DAYS,TOTAL_ENDORSED_CCY_CODE,TOTAL_ENDORSED_CCY_AMT,LIMIT_TRANSFER)
      ( select * from (select txnHist.BANK_GROUP_CODE,txnHist.CTY_CODE,v_txn_rec_id as TXN_REC_ID,txnHist.PARENT_TXN_REC_ID,txnHist.LATEST_TXN_REC_ID,txnHist.TXN_REF_ID,txnHist.PARENT_TXN_REF_ID,txnHist.DEAL_ID,txnHist.CUST_ID,v_latest_deal_step_id as DEAL_STEP_ID,txnHist.PROD_LIMIT_ID,'MISC' as TXN_STEP_CODE,txnHist.TXN_STEP_NO,txnHist.TXN_REFER_STEP_CODE,txnHist.TXN_REFER_STEP_NO,p_tp_ref_no as TP_REF_ID,txnHist.TP_STEP_CODE,txnHist.TP_REFER_STEP_CODE,txnHist.PRODUCT_CODE,txnHist.PRODUCT_SUB_TYPE,txnHist.SHORTFALL_OFFSET_TYPE,txnHist.CPTY_ID,txnHist.CPTY_ROLE_CODE,txnHist.NEGATIVE_TOLERANCE_PCT,txnHist.POSITIVE_TOLERANCE_PCT,txnHist.TXN_CCY_CODE,txnHist.TXN_CCY_ORIGN_AMT,txnHist.TXN_CCY_AMT,txnHist.TXN_CCY_NET_AMT,txnHist.TXN_CCY_UTIL_AMT,txnHist.TXN_STATUS_CODE,txnHist.SHIP_FROM,txnHist.SHIP_TO,txnHist.INCOTERM,txnHist.SHIP_DATE,txnHist.ISSUE_DATE,txnHist.EFFECTIVE_DATE,txnHist.MATURITY_DATE,txnHist.TENOR,txnHist.DUE_DATE,txnHist.REMARKS,txnHist.DOCUMENT_TYPE,txnHist.ACCEPTED_FLAG,
      txnHist.SECURITY_LEVEL,txnHist.DELIV_SCHEDULE_DAYS,txnHist.DELIV_SCHEDULE_CODE,txnHist.DELIV_SCHEDULE_YEAR,txnHist.EXCHG_CONTRACT,txnHist.HEDGE_DATE,txnHist.CUST_ROLE_CODE,txnHist.CASH_MARGIN_CCY_AMT,txnHist.CASH_MARGIN_CCY_CODE,txnHist.REVOLVING_LC_FLAG,txnHist.EVERGREEN_LC_FLAG,txnHist.AUTO_REVERSAL_FLAG,txnHist.MST_TXN_STEP_CODE,txnHist.FINANCE_NO,txnHist.LINKED_TXN_REF_ID,txnHist.CM_CCY_RELEASE_AMT,txnHist.CASH_MARGIN_PCT,p_tp_sys_code as TP_SYSTEM_CODE,txnHist.CASH_MARGIN_ADJ_AMT,txnHist.CASH_MARGIN_ADJ,txnHist.CASH_MARGIN_ORIGN_AMT,txnHist.EFFECTIVE_DATE_IS_ZERO,txnHist.OD_COLLATERAL_REF,txnHist.CONTACT_ID,txnHist.PREV_DEAL_STEP_ID,txnHist.TRANSACTION_TYPE,txnHist.SCB_ROLE,txnHist.SCB_RISK_SHARING_PCT,txnHist.SYNDICATED_TXN_AMT_CCY,txnHist.SYNDICATED_TXN_AMT,txnHist.SYND_POSITIVE_TOLERANCE_PCT,txnHist.SYND_NEGATIVE_TOLERANCE_PCT,txnHist.MAX_SYNDICATED_TXN_AMT_CCY,txnHist.MAX_SYNDICATED_TXN_AMT,txnHist.SYNDICATION_ID,txnHist.ADDITIONAL_LIAB_AMT_CCY,
      txnHist.ADDITIONAL_LIAB_AMT,txnHist.CMT_REF_NO,txnHist.SYNDICATED_UTIL_AMT_CCY,txnHist.SYNDICATED_UTIL_AMT,txnHist.BOOKING_BRANCH,txnHist.TOTAL_EXPIRY_DAYS,txnHist.TOTAL_ENDORSED_CCY_CODE,txnHist.TOTAL_ENDORSED_CCY_AMT,txnHist.LIMIT_TRANSFER
      from scbt_t_txn_hst txnHist where txnHist.DEAL_ID=p_deal_id and txnhist.txn_ref_id= p_txn_ref_id and  txnHist.CTY_CODE=p_cty_code and  txnHist.BANK_GROUP_CODE=p_back_group_code  order by txnHist.deal_step_id desc) where rownum=1);
      */
      /*
      insert into scbt_t_txn_hst( select * from (select BANK_GROUP_CODE,CTY_CODE,v_txn_rec_id,PARENT_TXN_REC_ID,LATEST_TXN_REC_ID,TXN_REF_ID,PARENT_TXN_REF_ID,DEAL_ID,CUST_ID,DEAL_STEP_ID,PROD_LIMIT_ID,TXN_STEP_CODE,TXN_STEP_NO,TXN_REFER_STEP_CODE,TXN_REFER_STEP_NO,v_tp_ref_no,TP_STEP_CODE,TP_REFER_STEP_CODE,PRODUCT_CODE,PRODUCT_SUB_TYPE,SHORTFALL_OFFSET_TYPE,CPTY_ID,CPTY_ROLE_CODE,NEGATIVE_TOLERANCE_PCT,POSITIVE_TOLERANCE_PCT,TXN_CCY_CODE,TXN_CCY_ORIGN_AMT,TXN_CCY_AMT,TXN_CCY_NET_AMT,TXN_CCY_UTIL_AMT,TXN_STATUS_CODE,SHIP_FROM,SHIP_TO,INCOTERM,SHIP_DATE,ISSUE_DATE,EFFECTIVE_DATE,MATURITY_DATE,TENOR,DUE_DATE,REMARKS,DOCUMENT_TYPE,ACCEPTED_FLAG,SECURITY_LEVEL,DELIV_SCHEDULE_DAYS,DELIV_SCHEDULE_CODE,DELIV_SCHEDULE_YEAR,EXCHG_CONTRACT,HEDGE_DATE,CUST_ROLE_CODE,CASH_MARGIN_CCY_AMT,CASH_MARGIN_CCY_CODE,REVOLVING_LC_FLAG,EVERGREEN_LC_FLAG,AUTO_REVERSAL_FLAG,MST_TXN_STEP_CODE,FINANCE_NO,LINKED_TXN_REF_ID,CM_CCY_RELEASE_AMT,CASH_MARGIN_PCT,TP_SYSTEM_CODE,CASH_MARGIN_ADJ_AMT,CASH_MARGIN_ADJ,
      CASH_MARGIN_ORIGN_AMT,EFFECTIVE_DATE_IS_ZERO,OD_COLLATERAL_REF,CONTACT_ID,PREV_DEAL_STEP_ID,TRANSACTION_TYPE,SCB_ROLE,SCB_RISK_SHARING_PCT,SYNDICATED_TXN_AMT_CCY,SYNDICATED_TXN_AMT,SYND_POSITIVE_TOLERANCE_PCT,SYND_NEGATIVE_TOLERANCE_PCT,MAX_SYNDICATED_TXN_AMT_CCY,MAX_SYNDICATED_TXN_AMT,SYNDICATION_ID,ADDITIONAL_LIAB_AMT_CCY,ADDITIONAL_LIAB_AMT,CMT_REF_NO,SYNDICATED_UTIL_AMT_CCY,SYNDICATED_UTIL_AMT,BOOKING_BRANCH,TOTAL_EXPIRY_DAYS,TOTAL_ENDORSED_CCY_CODE,TOTAL_ENDORSED_CCY_AMT,LIMIT_TRANSFER
      from scbt_t_txn_hst where DEAL_ID=p_deal_id and CTY_CODE=p_cty_code and  BANK_GROUP_CODE=p_back_group_code  order by deal_step_id desc) where rownum=1);
      */
      FOR pendingDeal IN (SELECT deal_step_id
                            FROM scbt_t_deal_hist
                           WHERE deal_id = p_deal_id
                             AND bank_group_code = p_back_group_code
                             AND cty_code = p_cty_code
                             AND bu_code = p_bu_code
                             AND step_status_code <> '03') LOOP
        dbms_output.put_line('all the pending scbt_t_txn_hst updating');
        UPDATE scbt_t_txn_hst
           SET TP_REF_ID = p_tp_ref_no, TP_SYSTEM_CODE = p_tp_sys_code
         WHERE txn_ref_id = p_txn_ref_id
           AND cty_code = p_cty_code
           AND bank_group_code = p_back_group_code
           AND deal_step_id = pendingDeal.deal_step_id;
      END LOOP;
      UPDATE scbt_t_txn_mst
         SET TP_REF_ID = p_tp_ref_no, TP_SYSTEM_CODE = p_tp_sys_code
       WHERE txn_ref_id = p_txn_ref_id
         AND txn_status_code <> '11'
         AND cty_code = p_cty_code
         AND bank_group_code = p_back_group_code;
      dbms_output.put_line(' finally scbt_t_txn_mst updated');
      o_return := '1';
      commit;
    ELSE
      dbms_output.put_line('Step id return is null' ||
                           v_latest_deal_step_id);
      o_return := null;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      -- handles all other errors
      dbms_output.put_line('Exception occured in the procedure while running this file');
      rollback to SAVE_POINT_NEW_STEP;
      o_return := NULL;
  END SCBP_P_CREATE_NEW_STEP;

  PROCEDURE SCBP_P_ACBS_IPS_ACBS_LOG(ACBS_REC IN SCBT_T_IPS_ACBS_LOG%ROWTYPE,
                                     bizDate  IN DATE,
                                     debugMsg IN VARCHAR2)AS
    co NUMBER;
    /* this needs to be commited whatever happens     */
   PRAGMA AUTONOMOUS_TRANSACTION;
 msg varchar2(2000);
  BEGIN
  msg:=debugMsg;
    SELECT COUNT(*)
    INTO co
    FROM SCBT_T_IPS_ACBS_LOG
    WHERE filename = ACBS_REC.filename
    AND cty_code = ACBS_REC.cty_code
    AND bank_group_code = ACBS_REC.bank_group_code
    AND cocoa_txn_ref_number = ACBS_REC.cocoa_txn_ref_number
    AND CUSTOMER_LE_ID = ACBS_REC.CUSTOMER_LE_ID
    AND LOAN_ID = ACBS_REC.LOAN_ID
    AND business_date = bizDate;
    dbms_output.put_line('count=' || co || ', debugMsg=' || msg);
    dbms_output.put_line('count=' || co || ', debugMsg length =' ||
    LENGTH(msg));
    IF(co=1)THEN
      UPDATE SCBT_T_IPS_ACBS_LOG
      SET DEBUGMSG =  msg, PROCESSED_TIMESTAMP = sysdate
      WHERE filename = ACBS_REC.filename
      AND cty_code = ACBS_REC.cty_code
      AND bank_group_code = ACBS_REC.bank_group_code
      AND cocoa_txn_ref_number = ACBS_REC.cocoa_txn_ref_number
      AND CUSTOMER_LE_ID = ACBS_REC.CUSTOMER_LE_ID
      AND LOAN_ID = ACBS_REC.LOAN_ID
      AND business_date = bizDate;
       DBMS_OUTPUT.PUT_LINE('*** Updated ' || SQL%ROWCOUNT || ' rows. ***'||debugMsg);
    END IF;



    commit;

  END SCBP_P_ACBS_IPS_ACBS_LOG;

FUNCTION SCBP_F_TXNALLREADYEXISTS(txnRefId IN VARCHAR2,ERRORMSG IN VARCHAR2,CURRDATE DATE)RETURN NUMBER AS
 v_count NUMBER:=0;
 o_age NUMBER:=0;
BEGIN
SELECT count(*)into v_count from SCBT_T_IPS_ACBS_RECON_HIST where COCOA_TXN_REF_NUMBER=txnRefId and ERROR_MSG=ERRORMSG;
IF (v_count!=0) THEN
SELECT (CURRDATE - min(BUSINESS_DATE)) into o_age  from SCBT_T_IPS_ACBS_RECON_HIST where COCOA_TXN_REF_NUMBER=txnRefId and ERROR_MSG=ERRORMSG;
END IF;
 dbms_output.put_line('TXNALLREADYEXISTS');
 return o_age;
END SCBP_F_TXNALLREADYEXISTS;


END SCBP_P_ACBS_BATCH;
/
