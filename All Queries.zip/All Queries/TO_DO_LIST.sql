Select 
        '0' as temp,               
        hst.maker_id,
        Scbf_Get_Party_Name (mst.BANK_GROUP_CODE,mst.cust_id),
        Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE,'*', 'EN', 'DA001',Mst.Event_Type, 1),               
        --Mst.Event_Type,
        Mst.Event_Name,
        Mst.Txn_Ref_Id,
        Mst.Tp_Ref_Id,
        NVL2(Mst.Alert_Date,to_char(Mst.Alert_Date,'DD-MM-YYYY'),Mst.Alert_Date) AS ALERT_DATE,
        --Mst.Alert_Date,
        Mst.Reminder_Value||' '||Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE,'*', 'EN', 'DA002',Mst.Reminder_Period, 1),
        --Mst.Reminder_Value||Mst.Reminder_Period,
        Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE,'*', 'EN', 'DA004',Mst.Priority, 1),
        --Mst.Priority,
        Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE,'*', 'EN', 'DA003',Mst.Status, 1),
        --Mst.Status,
        ROUND(to_date(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code))-Mst.Alert_Date,0) AS OVERDue,
        NVL2(hst.maker_timestamp,to_char(hst.maker_timestamp,'DD-MM-YYYY'),hst.maker_timestamp) AS CREATED_DATE,
        Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE,'*', 'EN', 'CD003',mst.tbu_code, 1),
        mst.remarks,
        mst.followup_reason,
        mst.cust_id,
        --Scbf_Get_Party_Name (mst.BANK_GROUP_CODE,mst.cust_id),
        mst.party_id,
        Scbf_Get_Party_Name (mst.BANK_GROUP_CODE,mst.party_id),
        --hst.maker_timestamp,
        mst.step_id,
        mst.event_id,
        Mst.Latest_Deal_Step_Id,
        case when Mst.Txn_Ref_Id is not null then
        (select decode(Count(lock_key),'0','N' ,'Y')from scbt_t_soft_lock where lock_key like '%'||Mst.Txn_Ref_Id ||'%')
        else
        'N'
        END,
        usr.user_name
        From
        Scbt_T_Event_Mst Mst,
        scbt_t_event_hst hst,
        scbt_r_user_mst usr
        Where
        usr.user_id=to_char(hst.maker_id) and
        Mst.Event_id=Hst.Event_id And
        Mst.step_id=hst.step_id and
        Mst.Bank_Group_Code='SCB'
        AND MST.CTY_CODE='KE'
         And (Mst.Latest_Deal_Step_Id
    Not In (Select Deal_Step_Id From Scbt_T_Deleted_Deal_Step_Dtls ) or Mst.Latest_Deal_Step_Id is null) 
    and mst.status='O' and Hst.Maker_Id in('%', 'SYSTEM') and (mst.alert_date< to_DATE(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code))or 
    mst.alert_date between to_DATE(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code)) and 
    to_DATE(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code))+0  
    or (Scbf_Get_Event_Reminder_Date(Mst.Reminder_Value,Mst.Reminder_Period,Mst.Alert_Date)) between 
    to_DATE(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code)) and to_DATE(Scbf_Get_Business_Date(mst.bank_group_code,mst.cty_code))+0)