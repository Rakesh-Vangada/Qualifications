CREATE OR REPLACE PACKAGE body COCOOWNER.SCBP_P_SCI is

PROCEDURE SCBP_P_UPDATE_SCI_GBL_ATTR(P_RET_CODE IN OUT VARCHAR2,
                                     P_BANK_GROUP_CODE IN VARCHAR2,
                                     I_LE_ID IN VARCHAR2) IS

V_PARTY_ID                      VARCHAR2(100);
V_RECORD_LOCK_FLAG              VARCHAR2(1);

L_LMP_LONG_NAME                 VARCHAR2 (100);
L_LMP_SGMNT_CODE_VALUE          VARCHAR2(10);
L_LMP_SUB_SGMNT_CODE_VALUE      VARCHAR2(10);
L_LMP_INC_NUM_TEXT              VARCHAR2(100);
L_LMP_INC_CNTRY_ISO_CODE        VARCHAR2(2);
L_LMP_INC_DATE                  DATE;
L_LMP_LEGAL_CONST_VALUE         VARCHAR2(10);
L_LCG_CRDT_GRADE_CODE_VALUE     VARCHAR2(10);
L_LEM_EMP_CODE                  VARCHAR2 (10);
L_LID_ISIC_CODE_VALUE           VARCHAR2 (10);
L_ECDD_ID                       VARCHAR2 (30);
L_CRM_ID                        VARCHAR2 (30);
L_LRA_ADDR_LINE_1               VARCHAR2 (100);
L_LRA_ADDR_LINE_2               VARCHAR2 (100);
L_LRA_CITY_TEXT                 VARCHAR2 (100);
L_LRA_STATE                     VARCHAR2 (100);
L_LRA_CNTRY_ISO_CODE            VARCHAR2 (2);

L_MAKER_CHECKER_ID              VARCHAR2 (16);
L_SUB_STEP_CODE                 VARCHAR2 (16);
L_STEP_STATUS_CODE              VARCHAR2 (16);


L_LLP_BCA_REF_NUM               VARCHAR2 (30);
L_LLP_NEXT_ANNL_RVW_DATE        DATE;
L_LLP_NEXT_INTRM_RVW_DATE       DATE;
L_LLP_EXTD_NEXT_RVW_DATE        DATE;


    CURSOR PARTY_DET IS
      SELECT DISTINCT PM.PARTY_ID, PM.CTY_CODE
      FROM SCBT_R_PARTY_EXT_ID PE, SCBT_R_PARTY_MST PM
      WHERE EXT_SYSTEM_CODE = 'SC'
      AND PE.PARTY_ID = PM.PARTY_ID
      AND PE.BANK_GROUP_CODE = PM.BANK_GROUP_CODE
      --AND (PM.RECORD_LOCK_FLAG <> 'Y' OR PM.RECORD_LOCK_FLAG IS NULL)
      AND PE.EXT_SYSTEM_ID = I_LE_ID
      AND PE.PARTY_ID IS NOT NULL
      GROUP BY PM.PARTY_ID, PM.CTY_CODE;

BEGIN
       L_LMP_LONG_NAME             := NULL;
       L_LMP_SGMNT_CODE_VALUE      := NULL;
       L_LMP_SUB_SGMNT_CODE_VALUE  := NULL;
       L_LMP_INC_NUM_TEXT          := NULL;
       L_LMP_INC_CNTRY_ISO_CODE    := NULL;
       L_LMP_INC_DATE              := NULL;
       L_LMP_LEGAL_CONST_VALUE     := NULL;
       L_LCG_CRDT_GRADE_CODE_VALUE := NULL;
       L_LEM_EMP_CODE              := NULL;
       L_LID_ISIC_CODE_VALUE      := NULL;
       L_ECDD_ID                   := NULL;
       L_CRM_ID                    := NULL;
       L_LRA_ADDR_LINE_1           := NULL;
       L_LRA_ADDR_LINE_2           := NULL;
       L_LRA_CITY_TEXT             := NULL;
       L_LRA_STATE                 := NULL;
       L_LRA_CNTRY_ISO_CODE        := NULL;

       L_MAKER_CHECKER_ID          := 'SCI-UPDT';
       L_SUB_STEP_CODE             := '02';
       L_STEP_STATUS_CODE          := '03';

       L_LLP_BCA_REF_NUM           := NULL;
       L_LLP_NEXT_ANNL_RVW_DATE    := NULL;
       L_LLP_NEXT_INTRM_RVW_DATE   := NULL;
       L_LLP_EXTD_NEXT_RVW_DATE    := NULL;
       V_PARTY_ID                  := NULL;




    FOR CIN IN PARTY_DET LOOP

   V_RECORD_LOCK_FLAG:= NULL;

--  SCI details should be updated for all records suggested by Sunil on 26-NOV-2012
      BEGIN
           SELECT (CASE WHEN(COUNT(1) > 0) THEN 'Y' ELSE 'N' END)
           INTO V_RECORD_LOCK_FLAG
           FROM SCBT_R_PARTY_MST
           WHERE PARTY_ID = CIN.PARTY_ID
           AND CTY_CODE   = CIN.CTY_CODE
           AND  RECORD_LOCK_FLAG = 'Y';
      EXCEPTION
          WHEN OTHERS THEN V_RECORD_LOCK_FLAG  := 'N';
        END;


      V_PARTY_ID := 'Y';

    --SCI details should be updated for all records suggested by Sunil on 26-NOV-2012
      BEGIN
           select (CASE WHEN(COUNT(1) > 0) THEN 'N' ELSE 'Y' END) into V_PARTY_ID
           from SCBT_R_PARTY_HIST
           where PARTY_ID = CIN.PARTY_ID
           AND CTY_CODE   = CIN.CTY_CODE
           and  STEP_STATUS_CODE not in ('03');
           --COMMENTED BELOW LINE ON 26-NOV-2012 ON REQUEST BY SUNIL
           --and  STEP_STATUS_CODE in ('01','0','11');
      EXCEPTION
          WHEN OTHERS THEN V_PARTY_ID  := 'N';
        END;


       BEGIN
              -- check whether the party id  Hist table -- step_status_code 01,02,11
             -- IF ((V_RECORD_LOCK_FLAG IS NULL OR V_RECORD_LOCK_FLAG <> 'Y') and V_PARTY_ID = 'Y') THEN

                      -- Get the SCI Global values
                      BEGIN
                        SELECT
                        LMP_LONG_NAME,
                        LMP_SGMNT_CODE_VALUE,
                        LMP_SUB_SGMNT_CODE_VALUE,
                        LMP_INC_NUM_TEXT,
                        LMP_INC_CNTRY_ISO_CODE,
                        LMP_INC_DATE,
                        LMP_LEGAL_CONST_VALUE
                        INTO
                        L_LMP_LONG_NAME,
                        L_LMP_SGMNT_CODE_VALUE,
                        L_LMP_SUB_SGMNT_CODE_VALUE,
                        L_LMP_INC_NUM_TEXT,
                        L_LMP_INC_CNTRY_ISO_CODE,
                        L_LMP_INC_DATE,
                        L_LMP_LEGAL_CONST_VALUE
                        FROM SCBT_T_IPS_SCI_CUST_PROFILE
                        WHERE LE_ID = I_LE_ID;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;

                      BEGIN
                        SELECT LCG_CRDT_GRADE_CODE_VALUE
                        INTO L_LCG_CRDT_GRADE_CODE_VALUE
                        FROM (
                              SELECT LCG_LE_ID,LCG_CRDT_GRADE_CODE_VALUE
                              FROM SCBT_T_IPS_SCI_CUST_CRDGRD
                              WHERE LCG_LE_ID = I_LE_ID
                              ORDER BY UPDATE_DATE DESC
                              )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;


                      BEGIN
                        SELECT LEM_EMP_CODE
                        INTO L_LEM_EMP_CODE
                        FROM (
                              SELECT LEM_LE_ID, LEM_EMP_CODE
                              FROM SCBT_T_IPS_SCI_CUST_EMP_RELN
                              WHERE LEM_LE_ID = I_LE_ID
                              AND LEM_BKG_LOCTN_ID IN (SELECT BKL_LOCTN_ID FROM SCBT_T_IPS_SCI_STDC_BKGLOCTN
                                                        WHERE BKL_CNTRY_ISO_CODE   = CIN.CTY_CODE)
                              AND ACTIVE_FLAG = 'Y'
                              AND LEM_PRINCIPAL_FAM_IND = 'Y'
                              ORDER BY UPDATE_DATE DESC
                              )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;

                      BEGIN
                        SELECT LID_ISIC_CODE_VALUE
                        INTO L_LID_ISIC_CODE_VALUE
                        FROM (
                              SELECT LID_LE_ID, LID_ISIC_CODE_VALUE
                              FROM SCBT_T_IPS_SCI_CUST_ISIC_DTLS
                              WHERE LID_LE_ID = I_LE_ID
                              ORDER BY UPDATE_DATE DESC
                              )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;

                      BEGIN
                        SELECT  LSX_EXT_SYS_CUST_ID
                        INTO    L_ECDD_ID
                        FROM (
                             SELECT LSX_EXT_SYS_CODE_VALUE, LSX_EXT_SYS_CUST_ID, LSX_LE_ID
                             FROM SCBT_T_IPS_SCI_CUST_SYSXREF
                             WHERE LSX_LE_ID =  I_LE_ID
                             AND LSX_EXT_SYS_CODE_VALUE = 'eCDD'
                             AND ACTIVE_FLAG = 'Y'
                             ORDER BY UPDATE_DATE DESC
                             )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;


                      BEGIN
                        SELECT  LSX_EXT_SYS_CUST_ID
                        INTO    L_CRM_ID
                        FROM (
                             SELECT LSX_EXT_SYS_CODE_VALUE, LSX_EXT_SYS_CUST_ID, LSX_LE_ID
                             FROM SCBT_T_IPS_SCI_CUST_SYSXREF
                             WHERE LSX_LE_ID = I_LE_ID
                             AND LSX_EXT_SYS_CODE_VALUE = 'CRM'
                             AND ACTIVE_FLAG = 'Y'
                             ORDER BY UPDATE_DATE DESC
                             )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;


                      BEGIN
                        SELECT LRA_ADDR_LINE_1, LRA_ADDR_LINE_2, LRA_CITY_TEXT, LRA_STATE, LRA_CNTRY_ISO_CODE
                        INTO L_LRA_ADDR_LINE_1, L_LRA_ADDR_LINE_2, L_LRA_CITY_TEXT, L_LRA_STATE, L_LRA_CNTRY_ISO_CODE
                        FROM(
                            SELECT LRA_LE_ID, LRA_ADDR_LINE_1, LRA_ADDR_LINE_2, LRA_CITY_TEXT, LRA_STATE,  LRA_CNTRY_ISO_CODE
                            FROM SCBT_T_IPS_SCI_CUST_REG_ADDR B
                            WHERE LRA_LE_ID = I_LE_ID
                            ORDER BY UPDATE_DATE DESC
                            )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;

                    /*
                      BEGIN
                        SELECT LLP_BCA_REF_NUM, LLP_NEXT_ANNL_RVW_DATE, LLP_NEXT_INTRM_RVW_DATE, LLP_EXTD_NEXT_RVW_DATE
                        INTO   L_LLP_BCA_REF_NUM, L_LLP_NEXT_ANNL_RVW_DATE, L_LLP_NEXT_INTRM_RVW_DATE, L_LLP_EXTD_NEXT_RVW_DATE
                        FROM (
                             SELECT LLP_BCA_REF_NUM, LLP_NEXT_ANNL_RVW_DATE, LLP_NEXT_INTRM_RVW_DATE, LLP_EXTD_NEXT_RVW_DATE
                             FROM SCBT_T_IPS_SCI_APPR_LMTPROF
                             WHERE LLP_LE_ID = I_LE_ID AND NVL(ACTIVE_FLAG,'Y')='Y'
                             ORDER BY UPDATE_DATE DESC
                             )
                        WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;
                      */

                      BEGIN
                        SELECT LLP_BCA_REF_NUM, LLP_NEXT_ANNL_RVW_DATE, LLP_NEXT_INTRM_RVW_DATE, LLP_EXTD_NEXT_RVW_DATE
                          INTO   L_LLP_BCA_REF_NUM, L_LLP_NEXT_ANNL_RVW_DATE, L_LLP_NEXT_INTRM_RVW_DATE, L_LLP_EXTD_NEXT_RVW_DATE
                          FROM (
                                  SELECT DISTINCT LLP_BCA_REF_NUM, LLP_NEXT_ANNL_RVW_DATE, LLP_NEXT_INTRM_RVW_DATE, LLP_EXTD_NEXT_RVW_DATE,L.UPDATE_DATE
                                  FROM SCBT_T_IPS_SCI_APPR_LMTPROF L, SCBT_T_IPS_SCI_APPR_LIMITS A
                                  WHERE L.LLP_ID = A.LMT_LLP_ID AND L.LLP_LE_ID=A.LMT_LE_ID AND NVL(A.ACTIVE_FLAG,'Y')='Y'
                                      AND A.N_LMT_BKG_LOCTN_ID IN (SELECT B.BKL_LOCTN_ID FROM SCBT_T_IPS_SCI_STDC_BKGLOCTN B WHERE B.BKL_CNTRY_ISO_CODE = CIN.CTY_CODE)
                                      AND L.LLP_LE_ID = I_LE_ID AND NVL(L.ACTIVE_FLAG,'Y')='Y'
                                  ORDER BY L.UPDATE_DATE DESC
                           ) WHERE ROWNUM = 1;
                      EXCEPTION
                      WHEN OTHERS THEN
                      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
                      END;


                      UPDATE SCBT_R_PARTY_MST
                      SET
                        SEG_CODE = L_LMP_SGMNT_CODE_VALUE,
                        SUB_SEG_CODE = L_LMP_SUB_SGMNT_CODE_VALUE,
                        RESIDENCE_CTY_CODE = L_LMP_INC_CNTRY_ISO_CODE,
                        INDUSTRY_CODE = L_LID_ISIC_CODE_VALUE ,
                        LIMIT_SETUP_APPLN_REF = L_LLP_BCA_REF_NUM,
                        NEXT_INTERIM_REVIEW_DATE = L_LLP_NEXT_INTRM_RVW_DATE,
                        NEXT_REVIEW_DATE = L_LLP_NEXT_ANNL_RVW_DATE,
                        NEXT_EXT_REVIEW_DATE = L_LLP_EXTD_NEXT_RVW_DATE,
                        CURRENT_SCB_CG = L_LCG_CRDT_GRADE_CODE_VALUE,
                        GAM_CODE = (SELECT Scbf_Get_Gam_Id(P_BANK_GROUP_CODE, CIN.PARTY_ID) FROM DUAL),
                        RM_CODE = L_LEM_EMP_CODE
                      WHERE BANK_GROUP_CODE  = P_BANK_GROUP_CODE
                      AND CTY_CODE           = CIN.CTY_CODE
                      AND PARTY_ID = CIN.PARTY_ID;


                     IF ((V_RECORD_LOCK_FLAG IS NULL OR V_RECORD_LOCK_FLAG <> 'Y') and V_PARTY_ID = 'Y') THEN
                     INSERT INTO SCBT_R_PARTY_HIST(
                            BANK_GROUP_CODE,
                            CTY_CODE,
                            PARTY_ID,
                            STEP_ID,
                            PARTY_NAME,
                            ADD_1,
                            ADD_2,
                            ADD_3,
                            OPEN_DATE,
                            RESIDENCE_CTY_CODE,
                            INDUSTRY_CODE,
                            RM_CODE,
                            SPECIAL_REMARKS,
                            SEG_CODE,
                            SUB_SEG_CODE,
                            ADD_CTY_CODE,
                            BLACKLISTED_FLAG,
                            CUST_SLA_CLASS,
                            BUSINESS_DIVISION,
                            PROVINCE_CODE,
                            DUPLICATE_PARTY_FLAG,
                            BLACKLIST_REASON,
                            REMARKS,
                            LIMIT_SETUP_APPLN_REF,
                            CURRENT_SCB_CG,
                            NEXT_REVIEW_DATE,
                            NEXT_INTERIM_REVIEW_DATE,
                            NEXT_EXT_REVIEW_DATE,
                            GAM_CODE,
                            BU_LIST,
                            SUSPEND_FLAG,
                            SUSPEND_REASON,
                            OVERALL_EXP_CURRENCY,
                            CMT_MGR_PWID,
                            CMT_MGR_NAME,
                            BACKUP_CMT_MGR_PWID,
                            BACKUP_CMT_MGR_NAME,
                            SIP_MGR_PWID,
                            SIP_MGR_NAME,
                            BACKUP_SIP_MGR_PWID,
                            BACKUP_SIP_MGR_NAME,
                            PARTY_NAME_UPP,
                            FI_FLAG,
                            STEP_CODE, --Added on 13-FEB-2013
                            SUB_STEP_CODE,
                            STEP_STATUS_CODE,
                            MAKER_ID,
                            MAKER_TIMESTAMP,
                            CHECKER_ID,
                              CHECKER_TIMESTAMP,
                              --TO capture business date in SCBT_R_PARTY_HIST table while updaing SCI details
                              BUSINESS_DATE
                               )
                     SELECT
                            BANK_GROUP_CODE,
                            CTY_CODE,
                            PARTY_ID,
                            SUBSTR(sys_guid(),1,16),
                            PARTY_NAME,
                            ADD_1,
                            ADD_2,
                            ADD_3,
                            OPEN_DATE,
                            RESIDENCE_CTY_CODE,
                            INDUSTRY_CODE,
                            RM_CODE,
                            SPECIAL_REMARKS,
                            SEG_CODE,
                            SUB_SEG_CODE,
                            ADD_CTY_CODE,
                            BLACKLISTED_FLAG,
                            CUST_SLA_CLASS,
                            BUSINESS_DIVISION,
                            PROVINCE_CODE,
                            DUPLICATE_PARTY_FLAG,
                            BLACKLIST_REASON,
                            REMARKS,
                            LIMIT_SETUP_APPLN_REF,
                            CURRENT_SCB_CG,
                            NEXT_REVIEW_DATE,
                            NEXT_INTERIM_REVIEW_DATE,
                            NEXT_EXT_REVIEW_DATE,
                            GAM_CODE,
                            BU_LIST,
                            SUSPEND_FLAG,
                            SUSPEND_REASON,
                            OVERALL_EXP_CURRENCY,
                            CMT_MGR_PWID,
                            CMT_MGR_NAME,
                            BACKUP_CMT_MGR_PWID,
                            BACKUP_CMT_MGR_NAME,
                            SIP_MGR_PWID,
                            SIP_MGR_NAME,
                            BACKUP_SIP_MGR_PWID,
                            BACKUP_SIP_MGR_NAME,
                            PARTY_NAME_UPP,
                            FI_FLAG,
                            '02', --Added on 13-FEB-2013
                            '01', -- Changed on 13-Feb-2013  L_SUB_STEP_CODE,
                            L_STEP_STATUS_CODE,
                            L_MAKER_CHECKER_ID,
                            SYSDATE,
                            L_MAKER_CHECKER_ID,
                              SYSDATE,
                              --TO capture business date in SCBT_R_PARTY_HIST table while updaing SCI details
                              (SELECT BUSINESS_DATE FROM SCBT_S_DAILY_PARAM
                                  WHERE BANK_GROUP_CODE=P_BANK_GROUP_CODE AND CTY_CODE=CIN.CTY_CODE)
                     FROM SCBT_R_PARTY_MST
                     WHERE BANK_GROUP_CODE  = P_BANK_GROUP_CODE
                     AND PARTY_ID =  CIN.PARTY_ID
                     AND CTY_CODE = CIN.CTY_CODE;
                     ELSE
                       UPDATE SCBT_R_PARTY_HIST
                        SET SEG_CODE = L_LMP_SGMNT_CODE_VALUE,
                        SUB_SEG_CODE = L_LMP_SUB_SGMNT_CODE_VALUE,
                        RESIDENCE_CTY_CODE = L_LMP_INC_CNTRY_ISO_CODE,
                        INDUSTRY_CODE = L_LID_ISIC_CODE_VALUE ,
                        LIMIT_SETUP_APPLN_REF = L_LLP_BCA_REF_NUM,
                        NEXT_INTERIM_REVIEW_DATE = L_LLP_NEXT_INTRM_RVW_DATE,
                        NEXT_REVIEW_DATE = L_LLP_NEXT_ANNL_RVW_DATE,
                        NEXT_EXT_REVIEW_DATE = L_LLP_EXTD_NEXT_RVW_DATE,
                        CURRENT_SCB_CG = L_LCG_CRDT_GRADE_CODE_VALUE,
                        GAM_CODE = (SELECT Scbf_Get_Gam_Id(P_BANK_GROUP_CODE, CIN.PARTY_ID) FROM DUAL),
                        RM_CODE = L_LEM_EMP_CODE,
                        --TO capture business date in SCBT_R_PARTY_HIST table while updaing SCI details
                        BUSINESS_DATE = (SELECT BUSINESS_DATE FROM SCBT_S_DAILY_PARAM
                                  WHERE BANK_GROUP_CODE=P_BANK_GROUP_CODE AND CTY_CODE=CIN.CTY_CODE)
                       WHERE BANK_GROUP_CODE  = P_BANK_GROUP_CODE
                       AND PARTY_ID =  CIN.PARTY_ID
                       AND CTY_CODE = CIN.CTY_CODE
                       AND STEP_STATUS_CODE !='03';
                     END IF;

                     UPDATE SCBT_R_PARTY_SCI_MST SET
                    -- SCI_LE_ID =( SELECT LE_ID FROM (SELECT  LE_ID FROM SCBT_T_IPS_SCI_CUST_PROFILE WHERE LE_ID = I_LE_ID ORDER BY UPDATE_DATE DESC) WHERE ROWNUM=1),
                     CUSTOMER_LEGAL_NAME = L_LMP_LONG_NAME,
                     CUSTOMER_SEGMENT_CODE = L_LMP_SGMNT_CODE_VALUE,
                     CUSTOMER_SUB_SEGMENT_CODE = L_LMP_SUB_SGMNT_CODE_VALUE,
                     INCORPORATION_NO = L_LMP_INC_NUM_TEXT,
                     INCORPORATION_CTY_CODE = L_LMP_INC_CNTRY_ISO_CODE,
                     INCORPORATION_DATE = L_LMP_INC_DATE,
                     LEGAL_STATUS_CONSTITUTION = L_LMP_LEGAL_CONST_VALUE,
                     SCB_INTERNAL_CRG = L_LCG_CRDT_GRADE_CODE_VALUE,
                     ARM_CODE = L_LEM_EMP_CODE,
                     ISIC_CODE =L_LID_ISIC_CODE_VALUE,
                     ECDD_ID = L_ECDD_ID,
                     CRM_ID = L_CRM_ID
                     WHERE BANK_GROUP_CODE = P_BANK_GROUP_CODE
                     AND PARTY_ID = CIN.PARTY_ID;

                     INSERT INTO SCBT_R_PARTY_SCI_HIST (
                            BANK_GROUP_CODE,
                            CTY_CODE,
                            PARTY_ID,
                            STEP_ID,
                            BUSINESS_DATE,
                            SCI_LE_ID,
                            CUSTOMER_LEGAL_NAME,
                            CUSTOMER_SEGMENT_CODE,
                            CUSTOMER_SUB_SEGMENT_CODE,
                            INCORPORATION_NO,
                            INCORPORATION_CTY_CODE,
                            INCORPORATION_DATE,
                            LEGAL_STATUS_CONSTITUTION,
                            SCB_INTERNAL_CRG,
                            ARM_CODE,
                            ISIC_CODE,
                            ECDD_ID,
                            CRM_ID,
                            REGISTERED_ADD_1,
                            REGISTERED_ADD_2,
                            REGISTERED_ADD_3,
                            REGISTERED_ADD_4,
                            REGISTERED_ADD_CTY_CODE,
                            RECORD_LOCK_FLAG,
                            LEGAL_STATUS_CONSTITUTION_DESC,
                            STEP_CODE, --Added on 13-FEB-2013
                            SUB_STEP_CODE,
                            STEP_STATUS_CODE,
                            MAKER_ID,
                            MAKER_TIME_STAMP,
                            CHECKER_ID,
                            CHECKER_TIMESTAMP)
                     SELECT
                            BANK_GROUP_CODE,
                            CTY_CODE,
                            PARTY_ID,
                            SUBSTR(sys_guid(),1,16),
                            BUSINESS_DATE,
                            SCI_LE_ID,
                            CUSTOMER_LEGAL_NAME,
                            CUSTOMER_SEGMENT_CODE,
                            CUSTOMER_SUB_SEGMENT_CODE,
                            INCORPORATION_NO,
                            INCORPORATION_CTY_CODE,
                            INCORPORATION_DATE,
                            LEGAL_STATUS_CONSTITUTION,
                            SCB_INTERNAL_CRG,
                            ARM_CODE,
                            ISIC_CODE,
                            ECDD_ID,
                            CRM_ID,
                            REGISTERED_ADD_1,
                            REGISTERED_ADD_2,
                            REGISTERED_ADD_3,
                            REGISTERED_ADD_4,
                            REGISTERED_ADD_CTY_CODE,
                            RECORD_LOCK_FLAG,
                            LEGAL_STATUS_CONSTITUTION_DESC,
                            '02',  --Added on 13-FEB-2013
                            '01',  --Added on 13-FEB-2013 L_SUB_STEP_CODE,
                            L_SUB_STEP_CODE,
                            L_MAKER_CHECKER_ID,
                            SYSDATE,
                            L_MAKER_CHECKER_ID,
                            SYSDATE
                     FROM SCBT_R_PARTY_SCI_MST
                     WHERE BANK_GROUP_CODE  = P_BANK_GROUP_CODE
                     AND PARTY_ID = CIN.PARTY_ID ;

                     UPDATE SCBT_T_IPS_SCI_CUST_PROFILE SET PROC_FLAG = 'Y' WHERE LE_ID = I_LE_ID;
                -- END IF;
            end;

  COMMIT;

  DBMS_OUTPUT.PUT_LINE('Result ='||P_RET_CODE);
  P_RET_CODE := '0000';
  end loop;

  --To update RM_CODE in PARTY_MST and PARTY_HIST tables
  SCBP_P_UPDATE_SCI_RM_CODE_ATTR(P_BANK_GROUP_CODE,
                                 I_LE_ID);

END SCBP_P_UPDATE_SCI_GBL_ATTR;


PROCEDURE SCBP_P_UPDATE_SCI_RM_CODE_ATTR(P_BANK_GROUP_CODE IN VARCHAR2,
                                         I_LE_ID IN VARCHAR2) IS

    V_CTY_CODE  SCBT_T_IPS_SCI_STDC_BKGLOCTN.BKL_CNTRY_ISO_CODE%TYPE;
    V_BKG_LOCTN_ID SCBT_T_IPS_SCI_STDC_BKGLOCTN.BKL_LOCTN_ID%type;
    V_LEM_EMP_CODE SCBT_T_IPS_SCI_CUST_EMP_RELN.LEM_EMP_CODE%TYPE;
    V_BKL_CNTRY_ISO_CODE SCBT_T_IPS_SCI_STDC_BKGLOCTN.BKL_CNTRY_ISO_CODE%TYPE;
    V_COUNT              VARCHAR2(3);
    V_STAFF_VALUE        SCBT_T_IPS_SCI_STDC_EMPPROF.EMP_STAFF_ID_VALUE%TYPE;
    V_PWID               SCBT_T_IPS_SCI_STDC_EMPPROF.EMP_STAFF_ID_VALUE%TYPE;
    V_STEP_ID            SCBT_R_PARTY_HIST.STEP_ID%TYPE;

    --To retrieve PARTY_ID, CTY_CODE from SCBT_R_PARTY_MST, SCBT_R_PARTY_EXT_ID for given LE_ID
    CURSOR PARTY_DET IS
      SELECT PM.PARTY_ID, PM.CTY_CODE
      FROM SCBT_R_PARTY_EXT_ID PE, SCBT_R_PARTY_MST PM
      WHERE EXT_SYSTEM_CODE = 'SC'
      AND PE.BANK_GROUP_CODE = P_BANK_GROUP_CODE
      AND PE.PARTY_ID = PM.PARTY_ID
      AND PE.BANK_GROUP_CODE = PM.BANK_GROUP_CODE
      AND (PM.RECORD_LOCK_FLAG <> 'Y' OR PM.RECORD_LOCK_FLAG IS NULL)
      AND PE.EXT_SYSTEM_ID = I_LE_ID
      AND PE.PARTY_ID IS NOT NULL
      AND PM.CTY_CODE != '*'
      GROUP BY PM.PARTY_ID, PM.CTY_CODE;


BEGIN


    BEGIN
     SELECT
           STEP_ID
           into V_STEP_ID
            FROM
      (
           SELECT
            STEP_ID
           FROM SCBT_R_PARTY_HIST H
           WHERE H.BANK_GROUP_CODE = P_BANK_GROUP_CODE
           AND H.PARTY_ID = (SELECT PARTY_ID FROM SCBT_R_PARTY_EXT_ID E
             WHERE EXT_SYSTEM_CODE = 'SC'
               AND E.BANK_GROUP_CODE = P_BANK_GROUP_CODE
               AND E.EXT_SYSTEM_ID = I_LE_ID
               AND E.PARTY_ID IS NOT NULL
                )
                ORDER BY STEP_ID DESC NULLS LAST
       ) WHERE ROWNUM=1;

    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;


    FOR curPartyDet IN PARTY_DET LOOP

        BEGIN
             V_CTY_CODE := curPartyDet.Cty_Code;

             BEGIN
                  --To retrieve RM_CODE, BOOKING LOCATION ID from SCBT_R_PARTY_MST, SCBT_R_PARTY_EXT_ID for given LE_ID
                  SELECT TO_CHAR(ER.LEM_BKG_LOCTN_ID), ER.LEM_EMP_CODE, BL.BKL_CNTRY_ISO_CODE
                    INTO V_BKG_LOCTN_ID, V_LEM_EMP_CODE, V_BKL_CNTRY_ISO_CODE
                    FROM SCBT_T_IPS_SCI_CUST_EMP_RELN ER, SCBT_T_IPS_SCI_STDC_BKGLOCTN BL
                         WHERE ER.LEM_LE_ID = I_LE_ID
                         AND ER.LEM_PRINCIPAL_FAM_IND='Y'
                         AND ER.LEM_BKG_LOCTN_ID = BL.BKL_LOCTN_ID
                         AND BL.BKL_CNTRY_ISO_CODE = V_CTY_CODE
                         AND ER.ACTIVE_FLAG        = 'Y';

                  BEGIN
                     --To insert data in SCBT_R_PARTY_MST table
                     UPDATE SCBT_R_PARTY_MST
                        SET RM_CODE = V_LEM_EMP_CODE
                        WHERE PARTY_ID = curPartyDet.Party_Id
                        AND CTY_CODE = curPartyDet.Cty_Code;

                     --To insert data in SCBT_R_PARTY_MST table
                     UPDATE SCBT_R_PARTY_HIST
                        SET RM_CODE = V_LEM_EMP_CODE
                         , MAKER_TIMESTAMP = SYSDATE
                         , CHECKER_TIMESTAMP = SYSDATE
                         --TO capture business date in SCBT_R_PARTY_HIST table while updaing SCI details
                         , BUSINESS_DATE=(SELECT BUSINESS_DATE FROM SCBT_S_DAILY_PARAM
                                  WHERE BANK_GROUP_CODE=P_BANK_GROUP_CODE AND CTY_CODE=curPartyDet.CTY_CODE)
                         WHERE PARTY_ID = curPartyDet.Party_Id
                         AND CTY_CODE = curPartyDet.Cty_Code
                         AND STEP_ID=V_STEP_ID;
                  EXCEPTION
                      WHEN OTHERS THEN
                      NULL;
                  END;

            EXCEPTION
                 WHEN OTHERS THEN
                 NULL;
            END;


        EXCEPTION
            WHEN OTHERS THEN
            NULL;
        END;

        V_COUNT  := 0;

        SELECT COUNT(*) INTO V_COUNT FROM SCBT_R_RM_MST WHERE BANK_GROUP_CODE = P_BANK_GROUP_CODE AND CTY_CODE = V_CTY_CODE
           AND RM_CODE = V_LEM_EMP_CODE;

        IF V_COUNT = 0 THEN

           SELECT COUNT(*)
             INTO V_COUNT
             FROM SCBT_T_IPS_SCI_STDC_EMPCODE EC, SCBT_T_IPS_SCI_STDC_EMPPROF EP
            WHERE TO_CHAR(EC.EEC_BKG_LOCTN_ID) = V_BKG_LOCTN_ID
              AND TO_CHAR(EC.EEC_EMP_CODE)     = V_LEM_EMP_CODE
              AND EP.EMP_BASE_BKG_LOCTN_ID     = EC.EEC_BKG_LOCTN_ID
              AND EC.EEC_EMP_ID                = EP.EMP_ID;

           IF V_COUNT > 0 THEN

              SELECT EP.EMP_STAFF_ID_VALUE
                INTO V_STAFF_VALUE
                FROM SCBT_T_IPS_SCI_STDC_EMPCODE EC, SCBT_T_IPS_SCI_STDC_EMPPROF EP
               WHERE TO_CHAR(EC.EEC_BKG_LOCTN_ID) = V_BKG_LOCTN_ID
                 AND TO_CHAR(EC.EEC_EMP_CODE)     = V_LEM_EMP_CODE
                 AND EP.EMP_BASE_BKG_LOCTN_ID     = EC.EEC_BKG_LOCTN_ID
                 AND EC.EEC_EMP_ID                = EP.EMP_ID;

              INSERT INTO SCBT_R_RM_MST ( BANK_GROUP_CODE, RM_CODE, STEP_ID, RM_NAME, RECORD_LOCK_FLAG, CTY_CODE, PEOPLEWISE_ID, PEOPLEWISE_NAME, EMAIL_CC_LIST, TO_EMAIL_ID )
                                 VALUES ( P_BANK_GROUP_CODE, V_LEM_EMP_CODE, scbf_get_step_id, NULL, NULL, V_CTY_CODE, V_STAFF_VALUE, NULL, NULL,NULL);

           END IF;

        ELSE

           SELECT COUNT(*)
             INTO V_COUNT
             FROM SCBT_T_IPS_SCI_STDC_EMPCODE EC, SCBT_T_IPS_SCI_STDC_EMPPROF EP, SCBT_R_RM_MST RM
            WHERE TO_CHAR(EC.EEC_BKG_LOCTN_ID) = V_BKG_LOCTN_ID
              AND TO_CHAR(EC.EEC_EMP_CODE)     = V_LEM_EMP_CODE
              AND EP.EMP_BASE_BKG_LOCTN_ID     = EC.EEC_BKG_LOCTN_ID
              AND EC.EEC_EMP_ID                = EP.EMP_ID
              AND RM.CTY_CODE                   = V_BKL_CNTRY_ISO_CODE
              AND RM.RM_CODE                   = V_LEM_EMP_CODE;

           IF V_COUNT > 0 THEN

              SELECT RM.PEOPLEWISE_ID, EP.EMP_STAFF_ID_VALUE
                INTO V_PWID, V_STAFF_VALUE
                FROM SCBT_T_IPS_SCI_STDC_EMPCODE EC, SCBT_T_IPS_SCI_STDC_EMPPROF EP, SCBT_R_RM_MST RM
               WHERE TO_CHAR(EC.EEC_BKG_LOCTN_ID) = V_BKG_LOCTN_ID
                 AND TO_CHAR(EC.EEC_EMP_CODE)     = V_LEM_EMP_CODE
                 AND EP.EMP_BASE_BKG_LOCTN_ID     = EC.EEC_BKG_LOCTN_ID
                 AND EC.EEC_EMP_ID                = EP.EMP_ID
                 AND RM.CTY_CODE                  = V_BKL_CNTRY_ISO_CODE
                 AND RM.RM_CODE                    = V_LEM_EMP_CODE;

              IF V_PWID <> V_STAFF_VALUE THEN

                 UPDATE SCBT_R_RM_MST
                    SET PEOPLEWISE_ID   = V_STAFF_VALUE,
                        PEOPLEWISE_NAME = NULL
                  WHERE CTY_CODE        = V_CTY_CODE
                    AND BANK_GROUP_CODE = P_BANK_GROUP_CODE
                    AND RM_CODE         = V_LEM_EMP_CODE;

              END IF;

           END IF;

        END IF;

    END LOOP;

    COMMIT;

END SCBP_P_UPDATE_SCI_RM_CODE_ATTR;

function scbf_get_step_id
return varchar2 as
  o_step_id varchar2(16);
begin
  o_step_id := null;

  select to_char(systimestamp, 'yymmddhhmmssSSS')
  into o_step_id
  from dual;

return o_step_id;
end scbf_get_step_id;

end SCBP_P_SCI;
/

--
--SELECT PARTY_ID,GAM_CODE,RM_CODE,CMT_MGR_PWID,CMT_MGR_NAME,LIMIT_SETUP_APPLN_REF,NEXT_EXT_REVIEW_DATE,NEXT_INTERIM_REVIEW_DATE,NEXT_REVIEW_DATE
--FROM SCBT_R_PARTY_HIST WHERE PARTY_ID='800011623' AND STEP_ID='F73BA04C20610416' ORDER BY MAKER_TIMESTAMP DESC

--SELECT PARTY_ID,GAM_CODE,RM_CODE,CMT_MGR_PWID,CMT_MGR_NAME,LIMIT_SETUP_APPLN_REF,NEXT_EXT_REVIEW_DATE,NEXT_INTERIM_REVIEW_DATE,NEXT_REVIEW_DATE 
--FROM  SCBT_R_PARTY_MST WHERE PARTY_ID='800011623' AND CTY_CODE='US'

--SELECT * FROM  SCBT_R_PARTY_SCI_HIST WHERE PARTY_ID='800011623' AND STEP_ID='F73BA04C20620416' ORDER BY MAKER_TIME_STAMP DESC
 
--SELECT * FROM  SCBT_R_RM_MST WHERE RM_CODE='685'