/* START SIP DUPLICATE CHECK*/
PROCEDURE SCBP_P_GET_SIP_DUPLICATE_DTL(p_ret_code    IN OUT VARCHAR2,
                                   bankGroupCode IN VARCHAR2,
                                   ctyCode       IN VARCHAR2,
                                   custId        IN VARCHAR2,
                                   dealStepID    IN VARCHAR2) IS

 TYPE dealIdType IS TABLE OF SCBT_T_DEAL_HIST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;
 TYPE collIdType IS TABLE OF SCBT_T_INVENTORY_HST.COLLATERAL_ID%TYPE INDEX BY PLS_INTEGER;
 TYPE inventoryIdType IS TABLE OF SCBT_T_INVENTORY_HST.INVENTORY_ID%TYPE INDEX BY PLS_INTEGER;
 TYPE parInventoryIdType IS TABLE OF SCBT_T_INVENTORY_HST.PARENT_INVENTORY_ID%TYPE INDEX BY PLS_INTEGER;
 TYPE linkInventoryIdType IS TABLE OF SCBT_T_INVENTORY_HST.LINK_INVENTORY_ID%TYPE INDEX BY PLS_INTEGER;
 TYPE tmpDocRefIdType IS TABLE OF SCBT_T_INVENTORY_HST.TEMP_DOCUMENT_REF_NO%TYPE INDEX BY PLS_INTEGER;
 TYPE bankGrpCodeType IS TABLE OF SCBT_T_INVENTORY_HST.BANK_GROUP_CODE%TYPE INDEX BY PLS_INTEGER;
 TYPE ctyCodeType IS TABLE OF SCBT_T_INVENTORY_HST.CTY_CODE%TYPE INDEX BY PLS_INTEGER;
 dealIdList           dealIdType;
 collIdList           collIdType;
 tmpDocRefIdList      tmpDocRefIdType;
 inventoryIdList      inventoryIdType;
 parInventoryIdList   parInventoryIdType;
 linkInventoryIdList  linkInventoryIdType;
 bankGrpCodeList      bankGrpCodeType;
 ctyCodeList          ctyCodeType;
 orgDocRefNo          VARCHAR2(32);
 docRefNoList         tmpDocRefIdType;
 
 BEGIN
       p_ret_code := '0000';
       BEGIN
            SELECT DISTINCT BANK_GROUP_CODE, CTY_CODE, DEAL_ID,COLLATERAL_ID, TEMP_DOCUMENT_REF_NO , LINK_INVENTORY_ID, PARENT_INVENTORY_ID, INVENTORY_ID 
            BULK COLLECT INTO bankGrpCodeList,ctyCodeList,dealIdList,collIdList,tmpDocRefIdList,linkInventoryIdList,
            parInventoryIdList,inventoryIdList
            FROM (
            SELECT DISTINCT P1.BANK_GROUP_CODE, P1.CTY_CODE, P1.DEAL_ID,P1.COLLATERAL_ID,P1.TEMP_DOCUMENT_REF_NO,
            P1.LINK_INVENTORY_ID, P1.PARENT_INVENTORY_ID, P1.INVENTORY_ID
            FROM SCBT_T_INVENTORY_HST P1, SCBT_T_INVENTORY_HST P2 
            WHERE P1.BANK_GROUP_CODE = P2.BANK_GROUP_CODE 
            AND P1.CTY_CODE = P2.CTY_CODE 
            AND P1.DEAL_ID = P2.DEAL_ID 
            AND P1.DEAL_STEP_ID = P2.DEAL_STEP_ID    
            AND P1.BANK_GROUP_CODE=bankGroupCode
            AND P1.CTY_CODE=ctyCode
            AND P1.DEAL_STEP_ID = dealStepID 
            AND P1.COLLATERAL_ID <> P2.COLLATERAL_ID AND P1.TEMP_DOCUMENT_REF_NO  = P2.TEMP_DOCUMENT_REF_NO  
            AND (P1.LINK_INVENTORY_ID IS NULL OR P2.INVENTORY_ID <> P1.LINK_INVENTORY_ID)
            AND (P1.PARENT_INVENTORY_ID IS NULL OR P2.INVENTORY_ID <> P1.PARENT_INVENTORY_ID)
            AND P1.TEMP_DOCUMENT_REF_NO  IS NOT NULL
            AND (NVL(P1.NET_COMMODITY_QNTY,0) - NVL(P1.UTILISED_QNTY,0)) <> 0
            AND P1.INVENTORY_TYPE_CODE  <> 'REL' 
            AND P2.INVENTORY_TYPE_CODE  <> 'REL' ) HIST
            WHERE NOT exists -- HIST.COLLATERAL_ID 
            (
            SELECT INVENTORY_ID FROM SCBT_T_INVENTORY_MST M WHERE 
            M.BANK_GROUP_CODE=bankGroupCode AND M.CTY_CODE=ctyCode
            AND M.BANK_GROUP_CODE = HIST.BANK_GROUP_CODE AND M.CTY_CODE = HIST.CTY_CODE 
            AND M.DOCUMENT_REF_NO = (select DOCUMENT_REF_NO from SCBT_T_INVENTORY_HST where 
            bank_group_code = bankGroupCode and cty_code = ctyCode and deal_step_id = dealStepID and inventory_id =
            HIST.INVENTORY_ID) and  
            HIST.INVENTORY_ID = M.INVENTORY_ID)
            UNION
            SELECT DISTINCT BANK_GROUP_CODE, CTY_CODE, DEAL_ID,COLLATERAL_ID, TEMP_DOCUMENT_REF_NO , LINK_INVENTORY_ID, PARENT_INVENTORY_ID,INVENTORY_ID FROM (
            SELECT PH.BANK_GROUP_CODE, PH.CTY_CODE, PH.DEAL_ID,PH.COLLATERAL_ID,PH.TEMP_DOCUMENT_REF_NO ,PH.LINK_INVENTORY_ID, PH.PARENT_INVENTORY_ID,PH.INVENTORY_ID
            FROM SCBT_T_INVENTORY_HST PH, SCBT_T_INVENTORY_MST PM
            WHERE  PH.BANK_GROUP_CODE = PM.BANK_GROUP_CODE 
            AND PH.CTY_CODE = PM.CTY_CODE 
            AND PM.BANK_GROUP_CODE=bankGroupCode
            AND PM.CTY_CODE=ctyCode 
            AND PM.CUST_ID=custId
            and PH.deal_step_id = dealStepID
            AND PH.COLLATERAL_ID <> PM.COLLATERAL_ID
            AND PH.TEMP_DOCUMENT_REF_NO  = PM.TEMP_DOCUMENT_REF_NO  
            AND (PH.LINK_INVENTORY_ID IS NULL OR PM.INVENTORY_ID <> PH.LINK_INVENTORY_ID)
            AND (PH.PARENT_INVENTORY_ID IS NULL OR PM.INVENTORY_ID <> PH.PARENT_INVENTORY_ID)
            AND PH.TEMP_DOCUMENT_REF_NO  IS NOT NULL 
            AND PH.INVENTORY_TYPE_CODE  <> 'REL'  
            AND PM.INVENTORY_TYPE_CODE  <> 'REL'  
            AND (NVL(PM.NET_COMMODITY_QNTY,0) - NVL(PM.UTILISED_QNTY,0)) <> 0
            AND (NVL(PH.NET_COMMODITY_QNTY,0) - NVL(PH.UTILISED_QNTY,0)) <> 0
            ) HM
            WHERE NOT exists -- COLLATERAL_ID 
            (SELECT INVENTORY_ID FROM SCBT_T_INVENTORY_MST M WHERE
            M.BANK_GROUP_CODE=bankGroupCode AND M.CTY_CODE=ctyCode
            AND M.BANK_GROUP_CODE = HM.BANK_GROUP_CODE AND M.CTY_CODE = HM.CTY_CODE 
            AND M.DOCUMENT_REF_NO  = (select DOCUMENT_REF_NO from SCBT_T_INVENTORY_HST where 
            bank_group_code = bankGroupCode and cty_code = ctyCode and deal_step_id = dealStepID and inventory_id =
            HM.INVENTORY_ID)  AND 
            HM.INVENTORY_ID = M.INVENTORY_ID);
                
            /***Starting Deleting the Previous record for SIP***/
    
              BEGIN 
                  DELETE FROM  SCBT_T_DUPLICATE_CHK_DTLS
                  WHERE BANK_GROUP_CODE = bankGroupCode
                  AND CTY_CODE = ctyCode
                  AND CUST_ID = custId
                  AND DEAL_STEP_ID = dealStepID
                  AND BUSINESS_TYPE ='SIP';
              EXCEPTION
                   WHEN OTHERS THEN
                   NULL;
              END;      
              /***End Deleting the Previous record for SIP***/
              
           FOR i IN 1..collIdList.COUNT LOOP

              /***Starting inserting the orginal document no for SIP***/
    
              BEGIN 
                  SELECT DOCUMENT_REF_NO 
                  INTO  orgDocRefNo
                  FROM  SCBT_T_INVENTORY_HST
                  WHERE BANK_GROUP_CODE = bankGroupCode
                  AND CTY_CODE = ctyCode
                  AND DEAL_STEP_ID = dealStepID
                  AND COLLATERAL_ID = collIdList(i);
              EXCEPTION
                   WHEN OTHERS THEN
                   NULL;
              END;      
              /***End inserting the orginal document no for SIP***/  
            
                 
           /*****STARTING INSERTING TO THE SCBT_T_DUPLICATE_CHK_DTLS TABLE************/     
              INSERT INTO SCBT_T_DUPLICATE_CHK_DTLS
                (BANK_GROUP_CODE,
                 CTY_CODE,
                 CUST_ID,
                 DEAL_ID,
                 PARCEL_ID,
                 DEAL_STEP_ID,
                 DOCUMENT_REF,
                 ORGINAL_DOCUMENT_REF,
                 BUSINESS_TYPE)
              VALUES
                (bankGroupCode,
                 ctyCode,
                 custId,
                 dealIdList(i),
                 collIdList(i),
                 dealStepID,
                 tmpDocRefIdList(i),
                 orgDocRefNo,
                 'SIP');
           /*****END INSERTING TO THE TABLE************/ 
            
            END LOOP;           
       END;
        p_ret_code := '0000';
      COMMIT;
      
      BEGIN
      
      SELECT DISTINCT DOCUMENT_REF 
      BULK COLLECT INTO docRefNoList 
      FROM SCBT_T_DUPLICATE_CHK_DTLS
      WHERE DEAL_STEP_ID = dealStepID;
      
      FOR j IN 1..docRefNoList.COUNT LOOP
      /*HISTORY Record **/ 
          BEGIN      
                 INSERT INTO SCBT_T_DUPLICATE_CHK_DTLS
                      (BANK_GROUP_CODE,
                       CTY_CODE,
                       CUST_ID,
                       DEAL_ID,
                       PARCEL_ID,
                       DEAL_STEP_ID,
                       DOCUMENT_REF,
                       ORGINAL_DOCUMENT_REF,
                       BUSINESS_TYPE)
                SELECT bankGroupCode,ctyCode,
                custId,
                DEAL_ID,
                COLLATERAL_ID,
                DEAL_STEP_ID,
                TEMP_DOCUMENT_REF_NO,
                document_ref_no,
                'SIP'
                 FROM SCBT_T_INVENTORY_HST h WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND TEMP_DOCUMENT_REF_NO = docRefNoList(j)
                AND DEAL_STEP_ID = dealStepID 
                AND INVENTORY_TYPE_CODE  <> 'REL'
                AND NOT EXISTS 
                (SELECT PARCEL_ID FROM SCBT_T_DUPLICATE_CHK_DTLS d
                WHERE h.bank_group_code = d.bank_group_code and h.cty_code = d.cty_code and
                d.parcel_id = h.collateral_id and DEAL_STEP_ID = dealStepID);
           EXCEPTION
                WHEN OTHERS THEN
                NULL;
           END;  

           /*Master Record **/ 

          BEGIN      
                 INSERT INTO SCBT_T_DUPLICATE_CHK_DTLS
                      (BANK_GROUP_CODE,
                       CTY_CODE,
                       CUST_ID,
                       DEAL_ID,
                       PARCEL_ID,
                       DEAL_STEP_ID,
                       DOCUMENT_REF,
                       ORGINAL_DOCUMENT_REF,
                       BUSINESS_TYPE)
                SELECT bankGroupCode,ctyCode,
                custId,
                IM.DEAL_ID,
                IM.COLLATERAL_ID,
                dealStepID,  
                IM.TEMP_DOCUMENT_REF_NO,
                IM.document_ref_no,
                'SIP'
                 FROM SCBT_T_INVENTORY_MST IM  
                 WHERE IM.BANK_GROUP_CODE = bankGroupCode
                AND IM.CTY_CODE = ctyCode
                AND IM.CUST_ID = custId
                AND IM.TEMP_DOCUMENT_REF_NO = docRefNoList(j)
                AND IM.INVENTORY_TYPE_CODE  <> 'REL'
                AND (NVL(IM.NET_COMMODITY_QNTY,0) - NVL(IM.UTILISED_QNTY,0)) <> 0
                AND NOT EXISTS 
                (SELECT PARCEL_ID FROM SCBT_T_DUPLICATE_CHK_DTLS d
                WHERE d.bank_group_code = IM.bank_group_code and d.cty_code = IM.cty_code and 
                d.parcel_id = IM.collateral_id and DEAL_STEP_ID = dealStepID)
                and NOT EXISTS 
                (SELECT collateral_ID FROM scbt_t_inventory_hst d
                WHERE d.bank_group_code = IM.bank_group_code and d.cty_code = IM.cty_code and 
                d.collateral_id = IM.collateral_id and DEAL_STEP_ID = dealStepID);
           EXCEPTION
                WHEN OTHERS THEN
                NULL;
           END;  
     
      END LOOP;
      
      
      END;      
 END SCBP_P_GET_SIP_DUPLICATE_DTL;
/*END SIP DUPLICATE CHECK*/

END SCBK_P_DUPLICATE_DOC_CHK;
/
