SELECT (
            CASE WHEN ((SELECT NVL(SUM(Scbf_Tls_Exch_Rate(BANK_GROUP_CODE, CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(cash_margin_ccy_amt,0), 'USD', 'N')
                 - Scbf_Tls_Exch_Rate(BANK_GROUP_CODE, CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(CM_CCY_RELEASE_AMT,0), 'USD', 'N')),0) TOTAL_MST_CM_AMT FROM SCBT_T_TXN_MST WHERE cust_id = '800006010' AND txn_step_code = 'NEW'
                 AND txn_rec_id NOT IN (SELECT parent_txn_rec_id FROM SCBT_T_TXN_HST th,SCBT_T_DEAL_HIST dh
                 WHERE th.cty_code = dh.cty_code AND th.bank_group_code = dh.bank_group_code AND dh.deal_id = th.deal_id AND th.cust_id = dh.cust_id
                 AND dh.deal_step_id = th.deal_step_id AND dh.step_status_code <> '03' AND dh.cust_id = '800006010') AND txn_step_code NOT IN ('DRAW','MISC'))
            +
            (SELECT NVL(SUM(Scbf_Tls_Exch_Rate(th.BANK_GROUP_CODE, th.CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(cash_margin_ccy_amt,0), 'USD', 'N')
              -Scbf_Tls_Exch_Rate(th.BANK_GROUP_CODE, th.CTY_CODE, CASH_MARGIN_CCY_CODE, NVL(CM_CCY_RELEASE_AMT,0), 'USD', 'N')),0) TOTAL_HST_CM_AMT FROM SCBT_T_TXN_HST th,SCBT_T_DEAL_HIST dh
            WHERE th.cty_code = dh.cty_code AND th.bank_group_code = dh.bank_group_code AND dh.deal_id = th.deal_id AND th.cust_id = dh.cust_id
            AND dh.step_status_code <> '03' AND dh.cust_id = '800006010' AND txn_step_code NOT IN ('DRAW','MISC'))
            )<= (SELECT  NVL(SUM(Scbf_Tls_Exch_Rate(ASM.BANK_GROUP_CODE, ASM.CTY_CODE, ASM.ACC_CCY_CODE, NVL(ASM.ACC_CCY_ANTICIPATED_AMT,0), 'USD', 'N')),0)  FROM SCBT_R_CUST_ACCT_MAINTENANCE CAM, SCBT_T_CUST_ACC_SMRY_MST ASM WHERE 
            CAM.CUST_ID = ASM.CUST_ID AND CAM.BANK_GROUP_CODE = ASM.BANK_GROUP_CODE AND CAM.ACC_NO = ASM.ACC_NO
            AND CAM.cust_id = '800006010' AND CAM.INCLUDE_FOR_CASH_COLLATERAL = 'Y' 
            AND CAM.ACC_NO NOT IN (SELECT NVL(PRODL.OVERDRAFT_FACILITY_ACCNO,'NA') FROM SCBT_R_CUST_PRODUCT_LIMIT PRODL
            WHERE PRODL.SHORTFALL_OFFSET = 'HO' AND PRODL.CUST_ID = '800006010'))
            THEN 'SUCCESS' ELSE 'FAIL'
        END) AS CTL_CHECK_02  FROM dual