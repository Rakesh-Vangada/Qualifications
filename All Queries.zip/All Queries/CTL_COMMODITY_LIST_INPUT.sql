CTL_COMMODITY_LIST_INPUT

select step_status_code,  Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1),COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
			COMMODITY_CODE
			from
			SCBT_R_COMMODITY_HIST where step_status_code in ('01', '11','02')  and BANK_GROUP_CODE='SCB'   and NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper(?)
			and upper(COMMODITY_TYPE_CODE) like upper(?) and upper(COMMODITY_CAT_CODE) like upper(?) and upper(EXCH_CODE) like upper(?) and upper(COMMODITY_OWNER) like (?)
			and upper(HUB_BU_CODE) like (?)  and upper(BU_CODE) like (?) and upper(COMMODITY_ID) like upper(?)
			UNION ALL
			select '03', Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1), COMMODITY_TYPE_CODE, COMMODITY_ID, COMMODITY_CAT_CODE, COMMODITY_OWNER, EXCH_CODE,HUB_BU_CODE,BU_CODE,
			COMMODITY_CODE
			from
			SCBT_R_COMMODITY_MST mst where BANK_GROUP_CODE=?   AND  NVL(upper(Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, CTY_CODE, '*', 'EN', 'CD066', COMMODITY_CODE, 1)),'%') like upper(?)
			and upper(COMMODITY_TYPE_CODE) like upper(?) and upper(COMMODITY_CAT_CODE) like upper(?) and upper(EXCH_CODE) like upper(?) and upper(COMMODITY_OWNER) like (?)
			 and upper(HUB_BU_CODE) like (?)  and upper(BU_CODE) like (?)
			and mst.BANK_GROUP_CODE=? AND upper(COMMODITY_ID) like upper(?) and mst.COMMODITY_ID  NOT IN (select COMMODITY_ID from SCBT_R_COMMODITY_HIST 
						where step_status_code in ('01', '11','02') and COMMODITY_ID = mst.COMMODITY_ID  
						AND BANK_GROUP_CODE=mst.BANK_GROUP_CODE)
INFO  - Tue Aug 27 12:36:36 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> 
Param [0]--> SCB
Param [1]--> %
Param [2]--> %
Param [3]--> %
Param [4]--> %
Param [5]--> %
Param [6]--> %SG957%
Param [7]--> %SG*%
Param [8]--> %CM10000328%
Param [9]--> SCB
Param [10]--> %
Param [11]--> %
Param [12]--> %
Param [13]--> %
Param [14]--> %
Param [15]--> %SG957%
Param [16]--> %SG*%
Param [17]--> SCB
Param [18]--> %CM10000328%
Result Size --> 0
Execution time (ms)  --> 15



APPROVED_COMMODITY_DETAILS_QUERY
================================

SELECT app.commodity_id, app.commodity_name, app.price_feed_id, app.deliv_schedule_days,
       app.deliv_schedule_code, app.deliv_schedule_year, app.market_price_ccy,
       app.market_price_amt, app.market_price_uom, app.commodity_type_code,
       app.commodity_cat_code, app.exch_code, app.commodity_owner, app.last_update_date,
       app.vendor_feed_id, app.commodity_price_id, app.adjustment_id,
       scbf_c_get_code_desc (app.bank_group_code,
                             '*',
                             '*',
                             'EN',
                             'CD016',
                             app.market_price_uom,
                             1
                            ) AS market_uom,
       app.commodity, adj.adj_formula, adj.ADJUSTMENT_NAME, price.FEED_PRICE_CCY, price.FEED_PRICE_AMT, price.FEED_PRICE_UOM
  	   FROM scbt_t_appr_commodity_lookup app,  scbt_r_commodity_price_mst price,  scbt_r_commodity_adj_dtls adj
       WHERE app.bank_group_code = ? AND app.cty_code = ?  AND app.user_id = ? AND app.session_id = ?
             AND app.COMMODITY_ID = adj.COMMODITY_ID(+)
             AND app.ADJUSTMENT_ID = adj.ADJUSTMENT_ID(+)
             AND app.bank_group_code = adj.bank_group_code(+)
             AND app.CTY_CODE = adj.CTY_CODE(+)
             AND app.bank_group_code = price.bank_group_code
             AND app.PRICE_FEED_ID = price.FEED_ID
INFO  - Fri Sep 20 15:49:15 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> APPROVED_COMMODITY_DETAILS_QUERY
Param [0]--> SCB
Param [1]--> HK
Param [2]--> 1433068
Param [3]--> 20130920154526555
Result Size --> 0
Execution time (ms)  --> 0