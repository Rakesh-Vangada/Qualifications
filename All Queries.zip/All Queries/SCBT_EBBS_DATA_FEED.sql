CREATE OR REPLACE PACKAGE BODY COCOA_OWNER_DEV_01.SCBT_EBBS_DATA_FEED IS


--Master Procedure ---------
     PROCEDURE SCBT_EBBS_ACCT_MAST_PROC(bankGroupCode IN VARCHAR2, country_code IN VARCHAR2, source_fileName IN VARCHAR2) IS
       BEGIN
       DECLARE
       balanceCount number;
       depositCount number;
       tranCount number;
     BEGIN

       select count(*) into balanceCount from SCBT_T_IPS_CB_ACCT_BALANCE where processed_flag='N';
       select count(*) into depositCount from SCBT_T_IPS_CB_ACCT_DEP_DTLS where processed_flag='N';
       select count(*) into tranCount from SCBT_T_IPS_CB_ACCT_TXN_DTLS where processed_flag='N';

       if(balanceCount > 0) THEN
       --To delete old account details from SCBT_T_CUST_EXT_ACCOUNTS_MST and SCBT_T_CUST_RECONCIL_SMRY_MST
       --if account is not available in latest file. --28-FEB-2013-- START
         BEGIN
            DELETE FROM SCBT_T_CUST_EXT_ACCOUNTS_MST
              where BANK_GROUP_CODE=bankGroupCode
              AND CTY_CODE = country_code
              AND ACCOUNT_NUMBER in (
               select accountno from SCBT_T_IPS_CB_ACCT_BALANCE WHERE SOURCE_FILE_NAME=source_fileName
              );
         EXCEPTION WHEN OTHERS THEN
           NULL;
         END; 
       --To delete old account details from SCBT_T_CUST_EXT_ACCOUNTS_MST and SCBT_T_CUST_RECONCIL_SMRY_MST
       --if account is not available in latest file. --28-FEB-2013-- END   
         
         SCBT_EBBS_ACCT_BAL_UPDATE(bankGroupCode, source_fileName, upper(country_code));
                                                  
        END IF;
          if(depositCount > 0) THEN
         --To delete old account details from SCBT_T_CUST_EXT_ACCOUNTS_MST and SCBT_T_CUST_RECONCIL_SMRY_MST
         --if account is not available in latest file. --28-FEB-2013-- START
    
             BEGIN
                DELETE FROM SCBT_T_CUST_EXT_ACCOUNTS_MST
                  where BANK_GROUP_CODE=bankGroupCode
                  AND CTY_CODE = country_code
                  AND ACCOUNT_NUMBER in (
                   select accountno from SCBT_T_IPS_CB_ACCT_DEP_DTLS WHERE SOURCE_FILE_NAME=source_fileName
                  );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;           
    
         --To delete old account details from SCBT_T_CUST_EXT_ACCOUNTS_MST and SCBT_T_CUST_RECONCIL_SMRY_MST
         --if account is not available in latest file. --28-FEB-2013-- END   
             SCBT_EBBS_ACCT_DEP_UPDATE(bankGroupCode, source_fileName, upper(country_code));
        END IF;
          if(tranCount > 0) THEN
             SCBT_EBBS_ACCT_TRAN_MST(bankGroupCode, upper(country_code),source_fileName);
        END IF;
       SCBT_EBBS_ACCT_RECONSILE(bankGroupCode, upper(country_code), source_fileName);

     COMMIT;
     END;
     END SCBT_EBBS_ACCT_MAST_PROC;
     -- Procedure for Deposit tablle --
     PROCEDURE SCBT_EBBS_ACCT_DEP_UPDATE(bankGroupCode IN VARCHAR2, source_fileName IN VARCHAR2, country_code IN VARCHAR2) IS
     BEGIN
       DECLARE
     ips_relationshipNo SCBT_T_IPS_CB_ACCT_DEP_DTLS.RELATIONSHIPNO%TYPE;
     ips_accountNo SCBT_T_IPS_CB_ACCT_DEP_DTLS.ACCOUNTNO%TYPE;
     ips_currencyCode SCBT_T_IPS_CB_ACCT_DEP_DTLS.CURRENCY_CODE%TYPE;
     ips_principalAmount SCBT_T_IPS_CB_ACCT_DEP_DTLS.PRINICIPAL_AMT%TYPE;
     ips_processedFlag SCBT_T_IPS_CB_ACCT_DEP_DTLS.PROCESSED_FLAG%TYPE;
     ips_inputSource SCBT_T_IPS_CB_ACCT_DEP_DTLS.INPUT_SOURCE%TYPE;
     ips_ctyCode SCBT_T_IPS_CB_ACCT_DEP_DTLS.COUNTRY_CODE%TYPE;
     exist_data_count NUMBER;

     CURSOR ipsDepositCur IS
     SELECT RELATIONSHIPNO, ACCOUNTNO, CURRENCY_CODE, PRINICIPAL_AMT, INPUT_SOURCE, PROCESSED_FLAG, COUNTRY_CODE
     FROM SCBT_T_IPS_CB_ACCT_DEP_DTLS
     WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;
     BEGIN
      for ips_cursor_rec in ipsDepositCur
      LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCY_CODE ;
          ips_principalAmount  := ips_cursor_rec.PRINICIPAL_AMT;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          ips_ctyCode := ips_cursor_rec.COUNTRY_CODE;
       BEGIN

        --insert into HISTORY table
        INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
         ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
          VALUES (bankGroupCode, ips_ctyCode, ips_relationshipNo, ips_accountNo,
          ips_currencyCode, ips_principalAmount, ips_inputSource, 'Deposit Account');
       END;

       BEGIN

        SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
         WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
          cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
           cocoaMst.ACCOUNT_CCY = ips_currencyCode;

        IF (exist_data_count > 0)    THEN
            UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
              SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount WHERE
              cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
              cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
              cocoaMst.ACCOUNT_CCY = ips_currencyCode;

        ELSE
          INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
              EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
              VALUES (bankGroupCode, ips_ctyCode, ips_relationshipNo, ips_accountNo, ips_currencyCode,
              ips_principalAmount, ips_inputSource, 'Deposit Account');
        END IF;
       EXCEPTION WHEN OTHERS THEN
        NULL;
    END;
  END LOOP;
   BEGIN
        UPDATE SCBT_T_IPS_CB_ACCT_DEP_DTLS
          SET PROCESSED_FLAG = 'Y', processed_timestamp = SYSDATE
          WHERE NVL(PROCESSED_FLAG, 'N') = 'N' and SOURCE_FILE_NAME = source_fileName;
     END;
   END;
   COMMIT;
  END SCBT_EBBS_ACCT_DEP_UPDATE;

     -- Procedure for Balance tablle --

     PROCEDURE SCBT_EBBS_ACCT_BAL_UPDATE(bankGroupCode IN VARCHAR2, source_fileName IN VARCHAR2, country_code IN VARCHAR2) IS
     BEGIN
      DECLARE
     ips_relationshipNo SCBT_T_IPS_CB_ACCT_BALANCE.RELATIONSHIPNO%TYPE;
     ips_accountNo SCBT_T_IPS_CB_ACCT_BALANCE.ACCOUNTNO%TYPE;
     ips_currencyCode SCBT_T_IPS_CB_ACCT_BALANCE.CURRENCYCODE%TYPE;
     ips_principalAmount SCBT_T_IPS_CB_ACCT_BALANCE.CLOSING_AVAIL_BALANCE%TYPE;
     ips_processedFlag SCBT_T_IPS_CB_ACCT_BALANCE.PROCESSED_FLAG%TYPE;
     ips_inputSource SCBT_T_IPS_CB_ACCT_BALANCE.INPUT_SOURCE%TYPE;
     exist_data_count NUMBER;

/*Changes has been made as india user is requested... on 14-SEP-2012'
CLOSING_AVAIL_BALANCE to OPENING_LEDGER_BALANCE
*Changes has been made as india user is requested... on 24-SEP-2012'
OPENING_LEDGER_BALANCE to CLOSING_LEDGER_BALANCE
*Changes has been made as india user is requested... on 08-OCT-2012'
CLOSING_LEDGER_BALANCE to CLOSING_AVAIL_BALANCE
*/
     --Account number alone (LB, ZA, GH, NG, CM, CI, SL, GM, KE, BW, TZ, UG, ZM, ZW, IN, UK, MO, ID, CN, US)
     CURSOR ipsBalanceCurOne IS
     SELECT RELATIONSHIPNO, ACCOUNTNO, CURRENCYCODE, CLOSING_AVAIL_BALANCE, INPUT_SOURCE, PROCESSED_FLAG
     FROM SCBT_T_IPS_CB_ACCT_BALANCE
     WHERE PROCESSED_FLAG = 'N' and SOURCE_FILE_NAME = source_fileName
     AND ACCOUNTNO IS NOT NULL;

     --Account number + currency code (BH, JO, JP, NP, OM, QA, LK, AE, BD, PK)
     CURSOR ipsBalanceCurTwo IS
     SELECT RELATIONSHIPNO
     , SUBSTR(ACCOUNTNO, 0, length(ACCOUNTNO)-3) AS accountno--ACCOUNTNO
     , CURRENCYCODE, CLOSING_AVAIL_BALANCE, INPUT_SOURCE, PROCESSED_FLAG
     FROM SCBT_T_IPS_CB_ACCT_BALANCE
     WHERE PROCESSED_FLAG = 'N' and SOURCE_FILE_NAME = source_fileName
     AND ACCOUNTNO IS NOT NULL;

     --Currency code + account number (VN)
     CURSOR ipsBalanceCurThree IS
     SELECT RELATIONSHIPNO
     , SUBSTR(ACCOUNTNO, 4, length(ACCOUNTNO)) as accountno --ACCOUNTNO
     , CURRENCYCODE, CLOSING_AVAIL_BALANCE, INPUT_SOURCE, PROCESSED_FLAG
     FROM SCBT_T_IPS_CB_ACCT_BALANCE
     WHERE PROCESSED_FLAG = 'N' and SOURCE_FILE_NAME = source_fileName
     AND ACCOUNTNO IS NOT NULL;

     --Currency number + account number (MU)
     CURSOR ipsBalanceCurFour IS
     SELECT RELATIONSHIPNO
     , SUBSTR(ACCOUNTNO, 3, length(ACCOUNTNO)) as accountno --ACCOUNTNO
     , CURRENCYCODE, CLOSING_AVAIL_BALANCE, INPUT_SOURCE, PROCESSED_FLAG
     FROM SCBT_T_IPS_CB_ACCT_BALANCE
     WHERE PROCESSED_FLAG = 'N' and SOURCE_FILE_NAME = source_fileName
     AND ACCOUNTNO IS NOT NULL;
     
     --Default
     CURSOR ipsBalanceCur IS
     SELECT RELATIONSHIPNO, ACCOUNTNO, CURRENCYCODE, CLOSING_AVAIL_BALANCE, INPUT_SOURCE, PROCESSED_FLAG
     FROM SCBT_T_IPS_CB_ACCT_BALANCE
     WHERE PROCESSED_FLAG = 'N' and SOURCE_FILE_NAME = source_fileName
     AND ACCOUNTNO IS NOT NULL;
     
     
BEGIN

   IF country_code in ('LB','ZA','GH','NG','CM','CI','SL','GM','KE','BW','TZ','UG','ZM','ZW','IN','UK','MO','ID','CN','US') THEN
       FOR ips_cursor_rec IN ipsBalanceCurOne
        LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCYCODE ;
          ips_principalAmount  := ips_cursor_rec.CLOSING_AVAIL_BALANCE;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          
          BEGIN
            --insert into HISTORY table
            INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
             ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
            VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo,
                 ips_currencyCode, ips_principalAmount, ips_inputSource, 'Current Account');
          END;
    
          BEGIN
            SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
                  WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            
            IF (exist_data_count > 0) THEN
              UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
               SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount 
               WHERE cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            ELSE
               INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
                      EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
                      VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo, ips_currencyCode
                      , ips_principalAmount, ips_inputSource, 'Current Account');
            
            END IF;
            
          END;
         END LOOP;
     ELSIF country_code in ('BH','JO','JP','NP','OM','QA','LK','AE','BD','PK') THEN
       FOR ips_cursor_rec IN ipsBalanceCurTwo
        LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCYCODE ;
          ips_principalAmount  := ips_cursor_rec.CLOSING_AVAIL_BALANCE;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          
          BEGIN
            --insert into HISTORY table
            INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
             ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
            VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo,
                 ips_currencyCode, ips_principalAmount, ips_inputSource, 'Current Account');
          END;
    
          BEGIN
            SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
                  WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            
            IF (exist_data_count > 0) THEN
              UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
               SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount 
               WHERE cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            ELSE
               INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
                      EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
                      VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo, ips_currencyCode
                      , ips_principalAmount, ips_inputSource, 'Current Account');
            
            END IF;
            
          END;
         END LOOP;
     ELSIF country_code in ('VN') THEN
       FOR ips_cursor_rec IN ipsBalanceCurThree
        LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCYCODE ;
          ips_principalAmount  := ips_cursor_rec.CLOSING_AVAIL_BALANCE;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          
          BEGIN
            --insert into HISTORY table
            INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
             ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
            VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo,
                 ips_currencyCode, ips_principalAmount, ips_inputSource, 'Current Account');
          END;
    
          BEGIN
            SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
                  WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            
            IF (exist_data_count > 0) THEN
              UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
               SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount 
               WHERE cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            ELSE
               INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
                      EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
                      VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo, ips_currencyCode
                      , ips_principalAmount, ips_inputSource, 'Current Account');
            
            END IF;
            
          END;
         END LOOP;
     ELSIF country_code in ('MU') THEN
       FOR ips_cursor_rec IN ipsBalanceCurFour
        LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCYCODE ;
          ips_principalAmount  := ips_cursor_rec.CLOSING_AVAIL_BALANCE;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          
          BEGIN
            --insert into HISTORY table
            INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
             ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
            VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo,
                 ips_currencyCode, ips_principalAmount, ips_inputSource, 'Current Account');
          END;
    
          BEGIN
            SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
                  WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            
            IF (exist_data_count > 0) THEN
              UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
               SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount 
               WHERE cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            ELSE
               INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
                      EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
                      VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo, ips_currencyCode
                      , ips_principalAmount, ips_inputSource, 'Current Account');
            
            END IF;
            
          END;
         END LOOP;
     ELSE
       FOR ips_cursor_rec IN ipsBalanceCur
        LOOP
          ips_relationshipNo := ips_cursor_rec.RELATIONSHIPNO;
          ips_accountNo  := ips_cursor_rec.ACCOUNTNO;
          ips_currencyCode  := ips_cursor_rec.CURRENCYCODE ;
          ips_principalAmount  := ips_cursor_rec.CLOSING_AVAIL_BALANCE;
          ips_inputSource  := ips_cursor_rec.INPUT_SOURCE ;
          ips_processedFlag  := ips_cursor_rec.PROCESSED_FLAG;
          
          BEGIN
            --insert into HISTORY table
            INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_HST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER ,
             ACCOUNT_CCY, EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
            VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo,
                 ips_currencyCode, ips_principalAmount, ips_inputSource, 'Current Account');
          END;
    
          BEGIN
            SELECT COUNT(1) INTO  exist_data_count FROM SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
                  WHERE  cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            
            IF (exist_data_count > 0) THEN
              UPDATE SCBT_T_CUST_EXT_ACCOUNTS_MST cocoaMst
               SET cocoaMst.EBBS_AMOUNT_BALANCE = ips_principalAmount 
               WHERE cocoaMst.CUSTOMER_ID = ips_relationshipNo AND
                  cocoaMst.ACCOUNT_NUMBER = ips_accountNo AND
                  cocoaMst.ACCOUNT_CCY = ips_currencyCode;
            ELSE
               INSERT INTO SCBT_T_CUST_EXT_ACCOUNTS_MST (BANK_GROUP_CODE, CTY_CODE, CUSTOMER_ID, ACCOUNT_NUMBER , ACCOUNT_CCY,
                      EBBS_AMOUNT_BALANCE, INPUT_SOURCE, ACCOUNT_TYPE)
                      VALUES (bankGroupCode, country_code, ips_relationshipNo, ips_accountNo, ips_currencyCode
                      , ips_principalAmount, ips_inputSource, 'Current Account');
            
            END IF;
            
          END;
         END LOOP;
     END IF;                 
     
  --CLOSE ipsDepositCur;
     BEGIN
        UPDATE SCBT_T_IPS_CB_ACCT_BALANCE
          SET PROCESSED_FLAG = 'Y', processed_timestamp = SYSDATE
          WHERE NVL(PROCESSED_FLAG, 'N') = 'N' and SOURCE_FILE_NAME = source_fileName;
       END;
     END;
     COMMIT;
     END SCBT_EBBS_ACCT_BAL_UPDATE;


     -- Procedure for DEP Reconsile--

     PROCEDURE SCBT_EBBS_ACCT_RECONSILE(bankGroupCode IN VARCHAR2, country_code IN VARCHAR2, source_fileName IN VARCHAR2) IS

     BEGIN
       DECLARE
     c_customerId SCBT_T_CUST_ACC_SMRY_MST.CUST_ID%TYPE;
     c_accNo SCBT_T_CUST_ACC_SMRY_MST.ACC_NO%TYPE;
     c_accCcyCode SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_CODE%TYPE;
     c_accTypeCode SCBT_T_CUST_ACC_SMRY_MST.ACC_TYPE_CODE%TYPE;
     c_accTypeDesc  Scbt_r_Code_Data.DESC_1%TYPE;
     c_accCcyBalAmt SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_BALANCE_AMT%TYPE;
     m_inc_ccy  SCBT_R_CUST_ACCT_MAINTENANCE.INCLUDE_FOR_CASH_COLLATERAL%TYPE;
     i_relationId SCBT_T_CUST_EXT_ACCOUNTS_MST.CUSTOMER_ID%TYPE;
     i_ebbsBalance SCBT_T_CUST_EXT_ACCOUNTS_MST.EBBS_AMOUNT_BALANCE%TYPE;
     r_cocoaBalance SCBT_T_CUST_RECONCIL_SMRY_MST.COCOA_AMOUNT_BALANCE%TYPE;
     r_mismatchDate SCBT_T_CUST_RECONCIL_SMRY_MST.MISMATCH_DATE%TYPE;
     r_reason SCBT_T_CUST_RECONCIL_SMRY_MST.REASON%TYPE;
     p_bussinessDate SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
     p_invalidAccount NUMBER;

     -- Cursor Creation --

     CURSOR summary_cur IS

     SELECT DISTINCT custmst.CUST_ID, custmst.ACC_NO, custmst.ACC_CCY_ANTICIPATED_CCY, custmst.ACC_TYPE_CODE,custmst.ACC_CCY_ANTICIPATED_AMT
     ,maint.INCLUDE_FOR_CASH_COLLATERAL,codeData.DESC_1  FROM SCBT_T_CUST_ACC_SMRY_MST custmst, SCBT_R_CUST_ACCT_MAINTENANCE maint,Scbt_r_Code_Data codeData
     WHERE custmst.CTY_CODE = country_code and custmst.BANK_GROUP_CODE = bankGroupCode and  custmst.CUST_ID=maint.cust_id and custmst.acc_no=maint.acc_no
     and custmst.acc_ccy_code=maint.acc_ccy_code and  custmst.ACC_TYPE_CODE=codeData.code_value
     and custmst.ACC_TYPE_CODE in (select account_type_code from reconcile_account_type);


BEGIN
   OPEN summary_cur;
   SELECT BUSINESS_DATE INTO p_bussinessDate FROM SCBT_S_DAILY_PARAM WHERE bank_group_code = bankGroupCode AND cty_code = country_code;
   LOOP
   FETCH summary_cur INTO c_customerId, c_accNo, c_accCcyCode, c_accTypeCode, c_accCcyBalAmt,m_inc_ccy,c_accTypeDesc;

   -- Checking whether customerid present in ebbs table --
   BEGIN
   --Default
   

     SELECT DISTINCT SCBT_T_CUST_EXT_ACCOUNTS_MST.CUSTOMER_ID,SCBT_T_CUST_EXT_ACCOUNTS_MST.EBBS_AMOUNT_BALANCE  INTO i_relationId, i_ebbsBalance
     FROM SCBT_T_CUST_EXT_ACCOUNTS_MST, SCBT_R_PARTY_EXT_ID, SCBT_T_IPS_SCI_CUST_SYSXREF
     WHERE SCBT_R_PARTY_EXT_ID.PARTY_ID = c_customerId
     AND UPPER(SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_ext_sys_code_value) in ('EBBS','HOGAN')
     AND SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_ext_sys_cust_id = SCBT_T_CUST_EXT_ACCOUNTS_MST.CUSTOMER_ID
     AND SCBT_R_PARTY_EXT_ID.EXT_SYSTEM_ID =  to_char(SCBT_T_IPS_SCI_CUST_SYSXREF.lsx_le_id)
     AND SCBT_T_CUST_EXT_ACCOUNTS_MST.ACCOUNT_NUMBER = c_accNo
     AND SCBT_T_CUST_EXT_ACCOUNTS_MST.Account_Ccy =c_accCcyCode;

     -- Checking whether customerid present in reconsile table --
     BEGIN

        SELECT DISTINCT COCOA_AMOUNT_BALANCE, MISMATCH_DATE, REASON INTO r_cocoaBalance, r_mismatchDate, r_reason
        FROM SCBT_T_CUST_RECONCIL_SMRY_MST
        WHERE customer_id = c_customerId AND ACCOUNT_NUMBER = c_accNo AND ACCOUNT_CCY = c_accCcyCode;


         IF (c_accCcyBalAmt != i_ebbsBalance) THEN
          --update the mismatch date and Reason--
            UPDATE SCBT_T_CUST_RECONCIL_SMRY_MST
               SET MISMATCH_DATE = p_bussinessDate, --MISMATCH_DATE = NVL(MISMATCH_DATE,p_bussinessDate),
                   REASON = 'Account Balance mismatch',
               COCOA_AMOUNT_BALANCE=c_accCcyBalAmt,
               EBBS_AMOUNT_BALANCE=i_ebbsBalance,
               DIFFERENCE=(c_accCcyBalAmt-i_ebbsBalance),
               INCLUDE_FOR_CASH_COLLATERAL=m_inc_ccy,
               RECONSILE_FLAG='N',
               PASS_ADJ_FLAG='N',justification='',
               RECONCILED_USER='',
               RECONCILED_TIMESTAMP=null,
               RECONCILED_STEP_ID=''
                WHERE customer_id = c_customerId AND ACCOUNT_NUMBER = c_accNo AND ACCOUNT_CCY = c_accCcyCode;
        ELSE
        -- update both data and reasosn to null--
         UPDATE SCBT_T_CUST_RECONCIL_SMRY_MST
                SET MISMATCH_DATE = NULL, REASON = NULL,DIFFERENCE=0,
                COCOA_AMOUNT_BALANCE=c_accCcyBalAmt,EBBS_AMOUNT_BALANCE=i_ebbsBalance,
                INCLUDE_FOR_CASH_COLLATERAL=m_inc_ccy,
                RECONCILED_USER='',
                RECONCILED_TIMESTAMP=null,
                RECONCILED_STEP_ID='',
                RECONSILE_FLAG='Y',
                PASS_ADJ_FLAG='N',
                justification=''
                WHERE customer_id = c_customerId AND ACCOUNT_NUMBER = c_accNo AND ACCOUNT_CCY = c_accCcyCode;
        END IF;
        -- not present in the reconsile table --
     EXCEPTION
         WHEN NO_DATA_FOUND THEN

        IF (c_accCcyBalAmt != i_ebbsBalance ) THEN
           --INSERT INTO SCBT_T_CUST_RECONCIL_SMRY_MST VALUES and insert the reason also;
         INSERT INTO SCBT_T_CUST_RECONCIL_SMRY_MST(BANK_GROUP_CODE, CUSTOMER_ID, ACCOUNT_NUMBER, ACCOUNT_TYPE,
         ACCOUNT_TYPE_DESC,ACCOUNT_CCY,CTY_CODE, COCOA_AMOUNT_BALANCE, EBBS_AMOUNT_BALANCE,
         DIFFERENCE, REASON, MISMATCH_DATE, RECONSILE_FLAG, PASS_ADJ_FLAG,INCLUDE_FOR_CASH_COLLATERAL)
         VALUES (bankGroupCode, c_customerId, c_accNo,c_accTypeCode,c_accTypeDesc,c_accCcyCode,country_code,c_accCcyBalAmt,i_ebbsBalance,(c_accCcyBalAmt-i_ebbsBalance),
         'Account Balance mismatch',p_bussinessDate,'N','N',m_inc_ccy);
         ELSE
           INSERT INTO SCBT_T_CUST_RECONCIL_SMRY_MST(BANK_GROUP_CODE, CUSTOMER_ID,  ACCOUNT_NUMBER, ACCOUNT_TYPE,
           ACCOUNT_TYPE_DESC,ACCOUNT_CCY,CTY_CODE, COCOA_AMOUNT_BALANCE, EBBS_AMOUNT_BALANCE,
           DIFFERENCE, REASON, MISMATCH_DATE, RECONSILE_FLAG, PASS_ADJ_FLAG,INCLUDE_FOR_CASH_COLLATERAL)
           VALUES (bankGroupCode, c_customerId, c_accNo,c_accTypeCode,c_accTypeDesc,c_accCcyCode,country_code,c_accCcyBalAmt,i_ebbsBalance,(c_accCcyBalAmt-i_ebbsBalance),
           '',p_bussinessDate,'Y','N',m_inc_ccy);
        END IF;
     END;
   -- not present in the ebbs table --
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
    -- Checking data present in reconsile table--
    BEGIN


       SELECT COCOA_AMOUNT_BALANCE, MISMATCH_DATE, REASON
       INTO r_cocoaBalance, r_mismatchDate, r_reason FROM SCBT_T_CUST_RECONCIL_SMRY_MST
        WHERE customer_id = c_customerId AND ACCOUNT_NUMBER = c_accNo AND ACCOUNT_CCY = c_accCcyCode;

       -- update the amount field --
       UPDATE SCBT_T_CUST_RECONCIL_SMRY_MST SET COCOA_AMOUNT_BALANCE = c_accCcyBalAmt,INCLUDE_FOR_CASH_COLLATERAL=m_inc_ccy,
       difference=(c_accCcyBalAmt-EBBS_AMOUNT_BALANCE),REASON ='Account Number not found in HOGAN/EBBS',ACCOUNT_TYPE=c_accTypeCode,
       ACCOUNT_TYPE_DESC=c_accTypeDesc,MISMATCH_DATE = NVL(MISMATCH_DATE,p_bussinessDate),RECONSILE_FLAG='N',PASS_ADJ_FLAG='N',
       justification='',  RECONCILED_USER='',RECONCILED_TIMESTAMP=null,RECONCILED_STEP_ID=''
       WHERE customer_id = c_customerId AND ACCOUNT_NUMBER = c_accNo AND ACCOUNT_CCY = c_accCcyCode;
        -- not present in the reconsile table --
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- insert the values in to the reconsile with reason and date as null--
      BEGIN
        INSERT INTO SCBT_T_CUST_RECONCIL_SMRY_MST(BANK_GROUP_CODE, CUSTOMER_ID, ACCOUNT_NUMBER, ACCOUNT_TYPE,ACCOUNT_TYPE_DESC,
        ACCOUNT_CCY,CTY_CODE, COCOA_AMOUNT_BALANCE, EBBS_AMOUNT_BALANCE,
        DIFFERENCE, REASON, MISMATCH_DATE, RECONSILE_FLAG, PASS_ADJ_FLAG,INCLUDE_FOR_CASH_COLLATERAL)
        VALUES (bankGroupCode, c_customerId,  c_accNo,c_accTypeCode,c_accTypeDesc,c_accCcyCode,country_code,c_accCcyBalAmt,0,c_accCcyBalAmt,
        'Account Number not found in HOGAN/EBBS',p_bussinessDate,'N','N',m_inc_ccy);
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;

    END;
    WHEN OTHERS THEN
      NULL;
   END;
   EXIT WHEN summary_cur%NOTFOUND;
   END LOOP;
   CLOSE summary_cur;
END;
    delete from SCBT_T_CUST_RECONCIL_SMRY_MST where customer_id is null;
     COMMIT;
     END SCBT_EBBS_ACCT_RECONSILE;


     --Procedure for Updating tranaction table--

 PROCEDURE SCBT_EBBS_ACCT_TRAN_MST(bankGroupCode IN VARCHAR2, country_code IN VARCHAR2, source_fileName IN VARCHAR2) IS
  BEGIN
                -- Insering values to SCBT_T_CB_ACCT_TRAN_SMRY_MST from SCBT_T_IPS_CB_ACCT_TXN_DTLS --

  DECLARE
     recordCount NUMBER DEFAULT 0;

     CURSOR cursor_ipsAcctTxnDtlsOne IS
       SELECT RELATIONSHIPNO
         , ACCOUNTNO
         , SWIFT_CURRENCYCODE, PROCESSED_FLAG, NARRATION1, TRANSACTIONAMOUNT, batchentrydate, CREDITDEBIT, source_file_name
       FROM SCBT_T_IPS_CB_ACCT_TXN_DTLS
            WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;

     CURSOR cursor_ipsAcctTxnDtlsTwo IS
       SELECT RELATIONSHIPNO
         , SUBSTR(ACCOUNTNO, 0, length(ACCOUNTNO)-3) AS accountno--ACCOUNTNO
         , SWIFT_CURRENCYCODE, PROCESSED_FLAG, NARRATION1, TRANSACTIONAMOUNT, batchentrydate, CREDITDEBIT, source_file_name
       FROM SCBT_T_IPS_CB_ACCT_TXN_DTLS
            WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;

     CURSOR cursor_ipsAcctTxnDtlsThree IS
       SELECT RELATIONSHIPNO
         , SUBSTR(ACCOUNTNO, 4, length(ACCOUNTNO)) as accountno --ACCOUNTNO
         , SWIFT_CURRENCYCODE, PROCESSED_FLAG, NARRATION1, TRANSACTIONAMOUNT, batchentrydate, CREDITDEBIT, source_file_name
       FROM SCBT_T_IPS_CB_ACCT_TXN_DTLS
            WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;

     CURSOR cursor_ipsAcctTxnDtlsFour IS
       SELECT RELATIONSHIPNO
         , SUBSTR(ACCOUNTNO, 3, length(ACCOUNTNO)) as accountno --ACCOUNTNO
         , SWIFT_CURRENCYCODE, PROCESSED_FLAG, NARRATION1, TRANSACTIONAMOUNT, batchentrydate, CREDITDEBIT, source_file_name
       FROM SCBT_T_IPS_CB_ACCT_TXN_DTLS
            WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;
            
     CURSOR cursor_ipsAcctTxnDtls IS
       SELECT RELATIONSHIPNO
         , ACCOUNTNO
         , SWIFT_CURRENCYCODE, PROCESSED_FLAG, NARRATION1, TRANSACTIONAMOUNT, batchentrydate, CREDITDEBIT, source_file_name
       FROM SCBT_T_IPS_CB_ACCT_TXN_DTLS
            WHERE PROCESSED_FLAG = 'N'and SOURCE_FILE_NAME = source_fileName;


    BEGIN
      
      IF country_code in ('LB','ZA','GH','NG','CM','CI','SL','GM','KE','BW','TZ','UG','ZM','ZW','IN','UK','MO','ID','CN','US') THEN
         FOR ipsAcctTxnDtls IN cursor_ipsAcctTxnDtlsOne LOOP
           BEGIN
               INSERT INTO SCBT_T_CB_ACCT_TRAN_SMRY_MST (
                   BANK_GROUP_CODE
                   , CTY_CODE
                   , CUSTOMER_ID
                   , ACCOUNT_NUMBER
                   , ACCOUNT_TYPE
                   , ACCOUNT_CCY
                   , NARRATION
                   , TRANACTION_AMT
                   , TRANSACTIONDATE
                   , CREDITDEBIT)
                SELECT
                    custSumm.BANK_GROUP_CODE
                   , custSumm.CTY_CODE
                   , custSumm.CUST_ID
                   , ipsAcctTxnDtls.ACCOUNTNO
                   , custSumm.ACC_TYPE_CODE
                   , ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                   , ipsAcctTxnDtls.NARRATION1
                   , ipsAcctTxnDtls.TRANSACTIONAMOUNT
                   , ipsAcctTxnDtls.batchentrydate
                   , ipsAcctTxnDtls.CREDITDEBIT
                FROM SCBT_T_CUST_ACC_SMRY_MST custSumm, SCBT_R_PARTY_EXT_ID partExt,
                 SCBT_T_IPS_SCI_CUST_SYSXREF xref
                 WHERE xref.lsx_ext_sys_cust_id= ipsAcctTxnDtls.RELATIONSHIPNO
                 AND partExt.PARTY_ID = custSumm.CUST_ID
                 AND custSumm.ACC_NO = ipsAcctTxnDtls.ACCOUNTNO
                 AND custSumm.ACC_CCY_CODE = ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                -- AND ipsAcctTxnDtls.PROCESSED_FLAG = 'N'
                -- AND ipsAcctTxnDtls.source_file_name = source_fileName
                 AND custSumm.Bank_Group_Code=bankGroupCode
                 AND custSumm.Cty_Code=country_code;
  
                 -- Updating the processed flag to Y for the table SCBT_T_IPS_CB_ACCT_TXN_DTLS --
                 UPDATE SCBT_T_IPS_CB_ACCT_TXN_DTLS
                    SET processed_flag = 'Y'
                    , PROCESSED_TIMESTAMP = SYSDATE
                 WHERE  source_file_name = source_fileName
                    AND PROCESSED_FLAG='N'
                    AND RELATIONSHIPNO = ipsAcctTxnDtls.RELATIONSHIPNO
                    AND ACCOUNTNO = ipsAcctTxnDtls.ACCOUNTNO
                    AND TRANSACTIONAMOUNT = ipsAcctTxnDtls.TRANSACTIONAMOUNT
                    AND BATCHENTRYDATE = ipsAcctTxnDtls.batchentrydate;
  
               EXCEPTION WHEN OTHERS THEN
                 NULL;
               END;
  
               recordCount := recordCount + 1;
  
               IF ( recordCount = 500 ) THEN
                  COMMIT;
                  recordCount := 0;
               END IF;
         END LOOP;
      ELSIF country_code in ('BH','JO','JP','NP','OM','QA','LK','AE','BD','PK') THEN
         FOR ipsAcctTxnDtls IN cursor_ipsAcctTxnDtlsTwo LOOP
           BEGIN
               INSERT INTO SCBT_T_CB_ACCT_TRAN_SMRY_MST (
                   BANK_GROUP_CODE
                   , CTY_CODE
                   , CUSTOMER_ID
                   , ACCOUNT_NUMBER
                   , ACCOUNT_TYPE
                   , ACCOUNT_CCY
                   , NARRATION
                   , TRANACTION_AMT
                   , TRANSACTIONDATE
                   , CREDITDEBIT)
                SELECT
                    custSumm.BANK_GROUP_CODE
                   , custSumm.CTY_CODE
                   , custSumm.CUST_ID
                   , ipsAcctTxnDtls.ACCOUNTNO
                   , custSumm.ACC_TYPE_CODE
                   , ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                   , ipsAcctTxnDtls.NARRATION1
                   , ipsAcctTxnDtls.TRANSACTIONAMOUNT
                   , ipsAcctTxnDtls.batchentrydate
                   , ipsAcctTxnDtls.CREDITDEBIT
                FROM SCBT_T_CUST_ACC_SMRY_MST custSumm, SCBT_R_PARTY_EXT_ID partExt,
                 SCBT_T_IPS_SCI_CUST_SYSXREF xref
                 WHERE xref.lsx_ext_sys_cust_id= ipsAcctTxnDtls.RELATIONSHIPNO
                 AND partExt.PARTY_ID = custSumm.CUST_ID
                 AND custSumm.ACC_NO = ipsAcctTxnDtls.ACCOUNTNO
                 AND custSumm.ACC_CCY_CODE = ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                -- AND ipsAcctTxnDtls.PROCESSED_FLAG = 'N'
                -- AND ipsAcctTxnDtls.source_file_name = source_fileName
                 AND custSumm.Bank_Group_Code=bankGroupCode
                 AND custSumm.Cty_Code=country_code;
  
                 -- Updating the processed flag to Y for the table SCBT_T_IPS_CB_ACCT_TXN_DTLS --
                 UPDATE SCBT_T_IPS_CB_ACCT_TXN_DTLS
                    SET processed_flag = 'Y'
                    , PROCESSED_TIMESTAMP = SYSDATE
                 WHERE  source_file_name = source_fileName
                    AND PROCESSED_FLAG='N'
                    AND RELATIONSHIPNO = ipsAcctTxnDtls.RELATIONSHIPNO
                    AND ACCOUNTNO = ipsAcctTxnDtls.ACCOUNTNO
                    AND TRANSACTIONAMOUNT = ipsAcctTxnDtls.TRANSACTIONAMOUNT
                    AND BATCHENTRYDATE = ipsAcctTxnDtls.batchentrydate;
  
               EXCEPTION WHEN OTHERS THEN
                 NULL;
               END;
  
               recordCount := recordCount + 1;
  
               IF ( recordCount = 500 ) THEN
                  COMMIT;
                  recordCount := 0;
               END IF;
         END LOOP;
      ELSIF country_code in ('VN') THEN
         FOR ipsAcctTxnDtls IN cursor_ipsAcctTxnDtlsThree LOOP
           BEGIN
               INSERT INTO SCBT_T_CB_ACCT_TRAN_SMRY_MST (
                   BANK_GROUP_CODE
                   , CTY_CODE
                   , CUSTOMER_ID
                   , ACCOUNT_NUMBER
                   , ACCOUNT_TYPE
                   , ACCOUNT_CCY
                   , NARRATION
                   , TRANACTION_AMT
                   , TRANSACTIONDATE
                   , CREDITDEBIT)
                SELECT
                    custSumm.BANK_GROUP_CODE
                   , custSumm.CTY_CODE
                   , custSumm.CUST_ID
                   , ipsAcctTxnDtls.ACCOUNTNO
                   , custSumm.ACC_TYPE_CODE
                   , ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                   , ipsAcctTxnDtls.NARRATION1
                   , ipsAcctTxnDtls.TRANSACTIONAMOUNT
                   , ipsAcctTxnDtls.batchentrydate
                   , ipsAcctTxnDtls.CREDITDEBIT
                FROM SCBT_T_CUST_ACC_SMRY_MST custSumm, SCBT_R_PARTY_EXT_ID partExt,
                 SCBT_T_IPS_SCI_CUST_SYSXREF xref
                 WHERE xref.lsx_ext_sys_cust_id= ipsAcctTxnDtls.RELATIONSHIPNO
                 AND partExt.PARTY_ID = custSumm.CUST_ID
                 AND custSumm.ACC_NO = ipsAcctTxnDtls.ACCOUNTNO
                 AND custSumm.ACC_CCY_CODE = ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                -- AND ipsAcctTxnDtls.PROCESSED_FLAG = 'N'
                -- AND ipsAcctTxnDtls.source_file_name = source_fileName
                 AND custSumm.Bank_Group_Code=bankGroupCode
                 AND custSumm.Cty_Code=country_code;
  
                 -- Updating the processed flag to Y for the table SCBT_T_IPS_CB_ACCT_TXN_DTLS --
                 UPDATE SCBT_T_IPS_CB_ACCT_TXN_DTLS
                    SET processed_flag = 'Y'
                    , PROCESSED_TIMESTAMP = SYSDATE
                 WHERE  source_file_name = source_fileName
                    AND PROCESSED_FLAG='N'
                    AND RELATIONSHIPNO = ipsAcctTxnDtls.RELATIONSHIPNO
                    AND ACCOUNTNO = ipsAcctTxnDtls.ACCOUNTNO
                    AND TRANSACTIONAMOUNT = ipsAcctTxnDtls.TRANSACTIONAMOUNT
                    AND BATCHENTRYDATE = ipsAcctTxnDtls.batchentrydate;
  
               EXCEPTION WHEN OTHERS THEN
                 NULL;
               END;
  
               recordCount := recordCount + 1;
  
               IF ( recordCount = 500 ) THEN
                  COMMIT;
                  recordCount := 0;
               END IF;
         END LOOP;
      ELSIF country_code in ('MU') THEN
         FOR ipsAcctTxnDtls IN cursor_ipsAcctTxnDtlsFour LOOP
           BEGIN
               INSERT INTO SCBT_T_CB_ACCT_TRAN_SMRY_MST (
                   BANK_GROUP_CODE
                   , CTY_CODE
                   , CUSTOMER_ID
                   , ACCOUNT_NUMBER
                   , ACCOUNT_TYPE
                   , ACCOUNT_CCY
                   , NARRATION
                   , TRANACTION_AMT
                   , TRANSACTIONDATE
                   , CREDITDEBIT)
                SELECT
                    custSumm.BANK_GROUP_CODE
                   , custSumm.CTY_CODE
                   , custSumm.CUST_ID
                   , ipsAcctTxnDtls.ACCOUNTNO
                   , custSumm.ACC_TYPE_CODE
                   , ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                   , ipsAcctTxnDtls.NARRATION1
                   , ipsAcctTxnDtls.TRANSACTIONAMOUNT
                   , ipsAcctTxnDtls.batchentrydate
                   , ipsAcctTxnDtls.CREDITDEBIT
                FROM SCBT_T_CUST_ACC_SMRY_MST custSumm, SCBT_R_PARTY_EXT_ID partExt,
                 SCBT_T_IPS_SCI_CUST_SYSXREF xref
                 WHERE xref.lsx_ext_sys_cust_id= ipsAcctTxnDtls.RELATIONSHIPNO
                 AND partExt.PARTY_ID = custSumm.CUST_ID
                 AND custSumm.ACC_NO = ipsAcctTxnDtls.ACCOUNTNO
                 AND custSumm.ACC_CCY_CODE = ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                -- AND ipsAcctTxnDtls.PROCESSED_FLAG = 'N'
                -- AND ipsAcctTxnDtls.source_file_name = source_fileName
                 AND custSumm.Bank_Group_Code=bankGroupCode
                 AND custSumm.Cty_Code=country_code;
  
                 -- Updating the processed flag to Y for the table SCBT_T_IPS_CB_ACCT_TXN_DTLS --
                 UPDATE SCBT_T_IPS_CB_ACCT_TXN_DTLS
                    SET processed_flag = 'Y'
                    , PROCESSED_TIMESTAMP = SYSDATE
                 WHERE  source_file_name = source_fileName
                    AND PROCESSED_FLAG='N'
                    AND RELATIONSHIPNO = ipsAcctTxnDtls.RELATIONSHIPNO
                    AND ACCOUNTNO = ipsAcctTxnDtls.ACCOUNTNO
                    AND TRANSACTIONAMOUNT = ipsAcctTxnDtls.TRANSACTIONAMOUNT
                    AND BATCHENTRYDATE = ipsAcctTxnDtls.batchentrydate;
  
               EXCEPTION WHEN OTHERS THEN
                 NULL;
               END;
  
               recordCount := recordCount + 1;
  
               IF ( recordCount = 500 ) THEN
                  COMMIT;
                  recordCount := 0;
               END IF;
         END LOOP;
      ELSE
         FOR ipsAcctTxnDtls IN cursor_ipsAcctTxnDtls LOOP
           BEGIN
               INSERT INTO SCBT_T_CB_ACCT_TRAN_SMRY_MST (
                   BANK_GROUP_CODE
                   , CTY_CODE
                   , CUSTOMER_ID
                   , ACCOUNT_NUMBER
                   , ACCOUNT_TYPE
                   , ACCOUNT_CCY
                   , NARRATION
                   , TRANACTION_AMT
                   , TRANSACTIONDATE
                   , CREDITDEBIT)
                SELECT
                    custSumm.BANK_GROUP_CODE
                   , custSumm.CTY_CODE
                   , custSumm.CUST_ID
                   , ipsAcctTxnDtls.ACCOUNTNO
                   , custSumm.ACC_TYPE_CODE
                   , ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                   , ipsAcctTxnDtls.NARRATION1
                   , ipsAcctTxnDtls.TRANSACTIONAMOUNT
                   , ipsAcctTxnDtls.batchentrydate
                   , ipsAcctTxnDtls.CREDITDEBIT
                FROM SCBT_T_CUST_ACC_SMRY_MST custSumm, SCBT_R_PARTY_EXT_ID partExt,
                 SCBT_T_IPS_SCI_CUST_SYSXREF xref
                 WHERE xref.lsx_ext_sys_cust_id= ipsAcctTxnDtls.RELATIONSHIPNO
                 AND partExt.PARTY_ID = custSumm.CUST_ID
                 AND custSumm.ACC_NO = ipsAcctTxnDtls.ACCOUNTNO
                 AND custSumm.ACC_CCY_CODE = ipsAcctTxnDtls.SWIFT_CURRENCYCODE
                -- AND ipsAcctTxnDtls.PROCESSED_FLAG = 'N'
                -- AND ipsAcctTxnDtls.source_file_name = source_fileName
                 AND custSumm.Bank_Group_Code=bankGroupCode
                 AND custSumm.Cty_Code=country_code;
  
                 -- Updating the processed flag to Y for the table SCBT_T_IPS_CB_ACCT_TXN_DTLS --
                 UPDATE SCBT_T_IPS_CB_ACCT_TXN_DTLS
                    SET processed_flag = 'Y'
                    , PROCESSED_TIMESTAMP = SYSDATE
                 WHERE  source_file_name = source_fileName
                    AND PROCESSED_FLAG='N'
                    AND RELATIONSHIPNO = ipsAcctTxnDtls.RELATIONSHIPNO
                    AND ACCOUNTNO = ipsAcctTxnDtls.ACCOUNTNO
                    AND TRANSACTIONAMOUNT = ipsAcctTxnDtls.TRANSACTIONAMOUNT
                    AND BATCHENTRYDATE = ipsAcctTxnDtls.batchentrydate;
  
               EXCEPTION WHEN OTHERS THEN
                 NULL;
               END;
  
               recordCount := recordCount + 1;
  
               IF ( recordCount = 500 ) THEN
                  COMMIT;
                  recordCount := 0;
               END IF;
         END LOOP;

      END IF;
    
      COMMIT;
    END;

  END SCBT_EBBS_ACCT_TRAN_MST;
END SCBT_EBBS_DATA_FEED;
/
