CREATE OR REPLACE PACKAGE BODY COCOOWNER.Scbk_P_Get_Coll_Position_Sfall IS

/*-----------------------------------------------------
/* REFNO: REF_25SEP_2012 :- Added for US Enhancement
/* SCBP_P_GET_GBB_UK_SFALL_DTL_US, SCBP_P_GET_DTL_EXP_AMT_COB 
/*---------------------------------------------------------------------------------------------------------------------------*/

  FUNCTION SCBF_RET_PROD_WISE_EXPOSURE(bankGroupCode IN VARCHAR2,
                                       ctyCode       IN VARCHAR2,
                                       custExpCcy    IN VARCHAR2,
                                       facilityId    IN VARCHAR2) RETURN NUMBER IS
    v_prod_exp_amt   SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;

    TYPE EXPCcyType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE EXPAmtType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;

    expCcyTypeList              EXPCcyType;
    expAmtTypeList              EXPAmtType;

    BEGIN

      v_prod_exp_amt := 0;

      BEGIN
        SELECT SUM(D.TXN_CCY_AMT), D.TXN_CCY_CODE BULK COLLECT
              INTO expAmtTypeList, expCcyTypeList
              FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL D,
                   SCBT_T_PROD_LIMIT_REQ_LOG R
             WHERE D.BANK_GROUP_CODE = bankGroupCode
               AND D.CTY_CODE        = ctyCode
               AND D.PROD_LIMIT_ID   = facilityId
               AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
               AND R.CTY_CODE        = D.CTY_CODE
               AND D.limit_tree_type_code = 'PROD'
               AND D.INIT_REQ_ID     = R.INIT_REQ_ID
               AND R.REQ_TYPE_CODE   = 'NEW'
               AND R.REQ_STATUS_CODE IN ('PEND','CON')
               GROUP BY D.INIT_REQ_ID HAVING SUM(D.TXN_CCY_AMT) > 0;
      EXCEPTION
        WHEN OTHERS THEN
        NULL;
      END;

      IF expCcyTypeList.COUNT > 0 THEN

         FOR i IN 1 ..expCcyTypeList.COUNT LOOP

             IF expCcyTypeList(i) <> custExpCcy THEN

                v_prod_exp_amt := v_prod_exp_amt + NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                                   ctyCode,           -- COUNTRY CODE
                                                                                expCcyTypeList(i), -- FROM CURR CODE
                                                                              expAmtTypeList(i), -- FROM AMOUNT
                                                                                custExpCcy,        -- TO CURR CODE
                                                                              'Y'),0);           -- ROUNG FLAG

             ELSE

                v_prod_exp_amt := v_prod_exp_amt + expAmtTypeList(i);

             END IF;

         END LOOP;

      END IF;

      RETURN v_prod_exp_amt;

  END SCBF_RET_PROD_WISE_EXPOSURE;

/*---------------------------------------------------------------------------------------------------------------------------*/

  FUNCTION SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode IN VARCHAR2,
                                        ctyCode       IN VARCHAR2,
                                        custExpCcy    IN VARCHAR2,
                                        custId        IN VARCHAR2) RETURN NUMBER IS
    v_clt_lnk_bal   SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;

    TYPE LNKCcyType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE LNKAmtType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;

    lnkCcyTypeList              LNKCcyType;
    lnkAmtTypeList              LNKAmtType;

    BEGIN

      v_clt_lnk_bal := 0;

      BEGIN           
           SELECT SUM(ACC_BAL),ACC_CCY BULK COLLECT INTO lnkAmtTypeList, lnkCcyTypeList 
           FROM(
            SELECT SUM(A.ACC_CCY_ANTICIPATED_AMT) AS ACC_BAL, A.ACC_CCY_CODE  AS ACC_CCY
            FROM SCBT_T_CUST_ACC_SMRY_MST A,SCBT_R_CUST_ACCT_MAINTENANCE M
            WHERE A.BANK_GROUP_CODE = bankGroupCode
            AND A.CTY_CODE        = ctyCode
            AND A.CUST_ID         = custId
            AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
            AND M.CTY_CODE        = A.CTY_CODE
            AND M.CUST_ID         = A.CUST_ID
            AND M.ACC_NO          = A.ACC_NO
            AND M.ACC_CCY_CODE    = A.ACC_CCY_ANTICIPATED_CCY
            AND NVL(M.ACCOUNT_LINKED, 'N')  = 'N'
            AND M.INCLUDE_FOR_CASH_COLLATERAL = 'Y'
            AND A.ACC_NO NOT IN (SELECT SUBSTR(T.COLUMN_VALUE,5) FROM SCBT_R_CUST_PRODUCT_LIMIT PL,TABLE(SPLIT(PL.OVERDRAFT_FACILITY_ACCNO)) T
                     WHERE PL.BANK_GROUP_CODE = bankGroupCode AND PL.CTY_CODE = ctyCode AND PL.CUST_ID = custId
                     AND T.COLUMN_VALUE IS NOT NULL AND ((NVL(PL.FIN_HEDGE_MARGIN,'N')) = 'Y' OR
                     PL.LIMIT_PRODUCT_CODE IN (SELECT PRODUCT_CODE FROM SCBT_R_PRODUCT_MST WHERE BANK_GROUP_CODE = bankGroupCode AND PROD_REF_CODE ='OD')))            
            GROUP BY A.ACC_CCY_CODE
            /*
            UNION ALL
            SELECT SUM(A.TXN_CCY_AMT) AS ACC_BAL,A.TXN_CCY_CODE AS ACC_CCY
            FROM SCBT_T_CUST_ACC_ACTIVITY_HST A,SCBT_R_CUST_ACCT_MAINTENANCE M
            WHERE A.BANK_GROUP_CODE = bankGroupCode
            AND A.CTY_CODE        = ctyCode
            AND A.CUST_ID         = custId            
            AND A.TXN_CCY_CODE    = M.ACC_CCY_CODE
            AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
            AND M.CTY_CODE        = A.CTY_CODE
            AND M.CUST_ID         = A.CUST_ID
            AND M.ACC_NO          = A.ACC_NO
            AND A.STEP_STATUS_CODE IN ( '02','10','14')
            AND A.ACC_NO NOT IN (SELECT SUBSTR(T.COLUMN_VALUE,5) FROM SCBT_R_CUST_PRODUCT_LIMIT PL,TABLE(SPLIT(PL.OVERDRAFT_FACILITY_ACCNO)) T
                     WHERE PL.BANK_GROUP_CODE = bankGroupCode AND PL.CTY_CODE = ctyCode AND PL.CUST_ID = custId
                     AND T.COLUMN_VALUE IS NOT NULL AND NVL(PL.FIN_HEDGE_MARGIN,'N') = 'Y')
            GROUP BY A.TXN_CCY_CODE */
          )GROUP BY ACC_CCY;

       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;

      IF lnkCcyTypeList.COUNT > 0 THEN

         FOR i IN 1 ..lnkCcyTypeList.COUNT LOOP

             IF lnkCcyTypeList(i) <> custExpCcy THEN

                v_clt_lnk_bal := v_clt_lnk_bal + NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                               ctyCode,           -- COUNTRY CODE
                                                                              lnkCcyTypeList(i), -- FROM CURR CODE
                                                                            lnkAmtTypeList(i), -- FROM AMOUNT
                                                                              custExpCcy,        -- TO CURR CODE
                                                                            'Y'),0);           -- ROUNG FLAG

             ELSE

                v_clt_lnk_bal := v_clt_lnk_bal + lnkAmtTypeList(i);

             END IF;

         END LOOP;

      END IF;

      RETURN v_clt_lnk_bal;

  END SCBF_RET_CLIENT_LINK_ACC_BAL;

/*---------------------------------------------------------------------------------------------------------------------------*/

  FUNCTION SCBF_RET_GROUP_LINK_ACC_BAL(bankGroupCode IN VARCHAR2,
                                       ctyCode       IN VARCHAR2,
                                       lmtCcy        IN VARCHAR2,
                                       custId        IN VARCHAR2,
                                       acc_no        IN VARCHAR2) RETURN NUMBER IS

    v_grp_lnk_bal   SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
    TYPE LNKCcyType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE LNKAmtType IS TABLE OF SCBT_T_COLL_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
    lnkCcyTypeList              LNKCcyType;
    lnkAmtTypeList              LNKAmtType;
    v_acc_no        SCBT_T_CUST_ACC_SMRY_MST.ACC_NO%TYPE;
    v_acc_ccy       SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_CODE%TYPE;

    BEGIN

      v_grp_lnk_bal := 0;

      v_acc_ccy     := SUBSTR(acc_no, 1, 3);
      v_acc_no      := SUBSTR(acc_no,5);

      BEGIN

          SELECT SUM(A.ACC_CCY_ANTICIPATED_AMT), A.ACC_CCY_CODE BULK COLLECT INTO lnkAmtTypeList, lnkCcyTypeList
          FROM SCBT_T_CUST_ACC_SMRY_MST A
          WHERE A.BANK_GROUP_CODE = bankGroupCode
          AND A.CTY_CODE        = ctyCode
          AND A.CUST_ID         = custId
          AND A.ACC_NO          = v_acc_no
          AND A.Acc_Ccy_Code    = v_acc_ccy
          AND A.ACC_NO NOT IN (SELECT SUBSTR(T.COLUMN_VALUE,5) FROM SCBT_R_CUST_PRODUCT_LIMIT PL,TABLE(SPLIT(PL.OVERDRAFT_FACILITY_ACCNO)) T
                   WHERE PL.BANK_GROUP_CODE = bankGroupCode AND PL.CTY_CODE = ctyCode AND PL.CUST_ID = custId
                   AND SUBSTR(T.COLUMN_VALUE,5) = v_acc_no
                   AND T.COLUMN_VALUE IS NOT NULL AND NVL(PL.FIN_HEDGE_MARGIN,'N') = 'Y')
          GROUP BY A.ACC_CCY_CODE;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
      END;

      IF lnkCcyTypeList.COUNT > 0 THEN
         FOR i IN 1 ..lnkCcyTypeList.COUNT LOOP
             IF lnkCcyTypeList(i) <> lmtCcy THEN
                v_grp_lnk_bal := v_grp_lnk_bal + NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                               ctyCode,           -- COUNTRY CODE
                                                                              lnkCcyTypeList(i), -- FROM CURR CODE
                                                                            lnkAmtTypeList(i), -- FROM AMOUNT
                                                                              lmtCcy,        -- TO CURR CODE
                                                                            'Y'),0);           -- ROUNG FLAG
             ELSE
                v_grp_lnk_bal := v_grp_lnk_bal + lnkAmtTypeList(i);
             END IF;
         END LOOP;
      END IF;

      RETURN v_grp_lnk_bal;

  END SCBF_RET_GROUP_LINK_ACC_BAL;
  /*------------------------------------------------
  /*------------ --REF_25SEP_2012  
   /*---------------------------------------------------------------------------------------------------------------------------*/
               PROCEDURE SCBP_ISRT_SFALL_OFFSET_MST_COB(bankGroupCode  IN VARCHAR2,
                                                      ctyCode        IN VARCHAR2,
                                                      custId         IN VARCHAR2,
                                                      v_limit_id     IN VARCHAR2,
                                                      v_ovl_ccy      IN VARCHAR2,
                                                      v_deal_stepid  IN VARCHAR2,
                                                      v_fac_grp_name IN VARCHAR2,
                                                      v_group_id     IN VARCHAR2,
                                                      v_co_borr_id   IN VARCHAR2,
                                                      pageSource     IN VARCHAR2) IS
               
                 v_lmt_ccy_code              SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;
                 v_lmt_class                 SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
                 v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
                 v_prod_Code                 SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE;
                 v_prog_grp_ncv              SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
                 v_prog_grp_cmr              SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
                 v_prod_grp_exp              SCBT_T_CUST_ACC_ACTIVITY_MST.TXN_CCY_AMT%TYPE := 0;
                 v_prod_grp_acc_bal          SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
                 v_is_syndicate_coll         NUMBER;
                 v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
                 v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
                 v_max_syndicated_amt_ccy    SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT_CCY%TYPE;
                 v_max_syndicated_amt        SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT%TYPE;
                 v_od_or_hedge_account       number;
                 v_deal_step_id              SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE;
                 v_co_borrower_id            SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE;
               
                   TYPE odCcyType IS TABLE OF SCBT_T_COLLATERAL_REGISTER_HST.total_ncv_ccy_code%TYPE INDEX BY PLS_INTEGER;
                   TYPE odAmtType IS TABLE OF SCBT_T_COLLATERAL_REGISTER_HST.total_ncv_ccy_amt%TYPE INDEX BY PLS_INTEGER;
                   odCcyTypeList              odCcyType;
                   odAmtTypeList              odAmtType;
               
                   BEGIN
               
                       BEGIN
                         SELECT LIMIT_CCY_CODE
                                , LIMIT_CLASSIFICATION
                                , shortfall_offset
                                , LIMIT_PRODUCT_CODE
                            INTO v_lmt_ccy_code
                                , v_lmt_class
                                , v_sfall_off
                                , v_prod_Code
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                             WHERE BANK_GROUP_CODE = bankGroupCode
                               AND CTY_CODE = ctycode
                               AND CUST_ID = custId
                               AND LIMIT_ID = v_limit_id;
                          EXCEPTION
                            WHEN OTHERS THEN
                              v_lmt_ccy_code := '';
                              v_lmt_class := '';
                              v_sfall_off := '';
                              v_prod_Code := '';
                        END;
               
               
                       --Exposure value for Syndication Collateralization START
                       BEGIN
                         SELECT COUNT(1) into v_is_syndicate_coll
                             FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                                WHERE map_id = 'TXNISSUVAL'
                                AND code_value_1 = 'CONT_PROD'
                                AND m.code_value_2 = p.limit_product_code
                                AND p.cust_id = custId
                                AND p.limit_id = v_limit_id
                                AND p.bank_group_code = bankGroupCode
                                AND p.cty_code = ctyCode;
                       EXCEPTION
                           WHEN OTHERS THEN
                           v_is_syndicate_coll := 0;
                       END;
               
                       IF v_is_syndicate_coll > 0 THEN
                         v_product_type := 'CON';
                       ELSE
                         v_product_type := 'ASS';
                       END IF;
               
               
                       BEGIN
                         select PARAM_DATA_04 INTO v_syndicate_data
                            FROM SCBT_R_PARAM_DATA
                            WHERE param_id = 'TP10'
                             AND PARAM_KEY_01 = (
                              select SCB_ROLE
                                FROM SCBT_T_TXN_MST
                                WHERE BANK_GROUP_CODE=bankGroupCode
                                  AND CTY_CODE=ctyCode
                                  AND CUST_ID=custId
                                  AND LATEST_DEAL_STEP_ID=v_deal_stepid
                                  AND PROD_LIMIT_ID=v_limit_id
                            ) and PARAM_KEY_02 = v_product_type;
                       EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                       END;
               
               
                       IF v_syndicate_data IS NOT NULL AND v_syndicate_data = 'USYA' THEN
                          --SELECT MAX_SYNDICATED_TXN_AMT_CCY, MAX_SYNDICATED_TXN_AMT
                          BEGIN

/*
                            SELECT MAX_SYNDICATED_TXN_AMT_CCY
                                   , MAX_SYNDICATED_TXN_AMT
                              INTO v_max_syndicated_amt_ccy
                                   , v_max_syndicated_amt --v_prod_grp_exp
                              FROM SCBT_T_TXN_MST
                                WHERE BANK_GROUP_CODE=bankGroupCode
                                  AND CTY_CODE=ctyCode
                                  AND CUST_ID=custId
                                  AND LATEST_DEAL_STEP_ID=v_deal_stepid
                                  AND PROD_LIMIT_ID=v_limit_id;
*/
                              SELECT SUM(D.TXN_CCY_AMT), D.TXN_CCY_CODE 
                                    INTO v_max_syndicated_amt_ccy,v_max_syndicated_amt 
                                    FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL D,
                                         SCBT_T_PROD_LIMIT_REQ_LOG R
                                   WHERE D.BANK_GROUP_CODE = bankGroupCode
                                     AND D.CTY_CODE        = ctyCode
                                     AND D.PROD_LIMIT_ID   = v_limit_id
                                     AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
                                     AND R.CTY_CODE        = D.CTY_CODE
                                     AND D.limit_tree_type_code = 'PROD'
                                     AND D.INIT_REQ_ID     = R.INIT_REQ_ID
                                     AND R.REQ_TYPE_CODE   = 'NEW'
                                     AND R.REQ_STATUS_CODE IN ('PEND','CON')
                                     GROUP BY D.TXN_CCY_CODE HAVING SUM(D.TXN_CCY_AMT) > 0;
  
                            EXCEPTION
                              WHEN OTHERS THEN
                                v_max_syndicated_amt_ccy := '';
                                v_max_syndicated_amt := 0;
                          END;
               
                          --If LIMIT CURRENCY and SYNDICATED AMT CURRENCY is different
               
                          IF (v_max_syndicated_amt_ccy <> v_ovl_ccy) THEN
                             v_prod_grp_exp := NVL( Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                                 ctyCode,           -- COUNTRY CODE
                                                                                   v_max_syndicated_amt_ccy, -- FROM CURR CODE
                                                                                 v_max_syndicated_amt, -- FROM AMOUNT
                                                                                   v_ovl_ccy,        -- TO CURR CODE
                                                                                 'Y'),0 );
                          ELSE
                            v_prod_grp_exp := v_max_syndicated_amt;
                          END IF;
               
                       ELSE
                          BEGIN
               
               
                          SELECT sum(Scbf_Tls_Exch_Rate(r.bank_group_code,
                                                                    r.cty_code,           -- COUNTRY CODE
                                                                      d.txn_ccy_code,         -- FROM CURR CODE
                                                               --27-SEP-2012 
                                                                    --d.txn_ccy_amt, 
                                                               d.syn_txn_ccy_amt,            -- FROM AMOUNT
                                                              v_ovl_ccy,            -- TO CURR CODE
                                                                    'Y'))
                            INTO v_prod_grp_exp
                          FROM SCBT_T_PROD_LIMIT_REQ_LOG R,
                                 SCBT_T_PROD_LIMIT_REQ_LOG_DTL D
                         WHERE R.BANK_GROUP_CODE  = bankGroupCode
                           AND R.CTY_CODE             = ctycode
                           AND D.BANK_GROUP_CODE  = R.BANK_GROUP_CODE
                           AND D.CTY_CODE             = R.CTY_CODE
                           --AND R.BUS_EVENT_REF_NO = v_deal_stepid
                           AND R.REQ_TYPE_CODE    = 'NEW'
                           AND D.LIMIT_TREE_TYPE_CODE = 'PROD'
                           AND R.REQ_STATUS_CODE  in ('PEND','CON')
                           AND R.INIT_REQ_ID         = D.INIT_REQ_ID
                           AND D.prod_LIMIT_ID             = v_limit_id;
                          EXCEPTION
                            WHEN OTHERS THEN
                              v_prod_grp_exp := 0;
                          END;
                       END IF;
               
                       --Exposure value for Syndication Collateralization END
                       v_prod_grp_acc_bal := Scbf_Get_Acc_Balance(bankGroupCode,ctyCode,custId,v_limit_id,v_ovl_ccy,'O');
               
                       BEGIN
                          v_od_or_hedge_account :=0;
                          SELECT COUNT(*) INTO v_od_or_hedge_account FROM SCBT_R_CUST_PRODUCT_LIMIT
                           WHERE (LIMIT_PRODUCT_CODE IN (SELECT PRODUCT_CODE FROM SCBT_R_PRODUCT_MST WHERE BANK_GROUP_CODE = 'SCB' AND PROD_REF_CODE ='OD')
                             OR NVL(FIN_HEDGE_MARGIN,'N') = 'Y')
                              AND LIMIT_ID=v_limit_id;
                       EXCEPTION
                           WHEN OTHERS THEN
                             NULL;
                       END;
               
                        IF (v_od_or_hedge_account > 0) THEN
                          
                            SELECT TOTAL_NCV_CCY_CODE, SUM(TOTAL_NCV_CCY_AMT) BULK COLLECT  INTO ODCCYTYPELIST, ODAMTTYPELIST
                            FROM SCBT_T_COLLATERAL_REGISTER_HST C, SCBT_T_DEAL_REGISTER_HDR_MST R,SCBT_T_DEAL_HIST H
                            WHERE C.BANK_GROUP_CODE = R.BANK_GROUP_CODE AND C.CTY_CODE = R.CTY_CODE
                            AND C.BANK_GROUP_CODE = H.BANK_GROUP_CODE AND C.CTY_CODE = H.CTY_CODE 
                            AND C.CUST_ID = R.CUST_ID AND C.DEAL_ID = R.DEAL_ID AND C.CUST_ID = H.CUST_ID AND C.DEAL_ID = H.DEAL_ID
                            AND C.DEAL_STEP_ID = H.DEAL_STEP_ID AND H.STEP_STATUS_CODE IN ('02','10','14')
                            AND COLLATERAL_CATEGORY<>'REL'
                            AND C.BANK_GROUP_CODE = bankGroupCode AND C.CTY_CODE = ctyCode AND C.CUST_ID = custId AND R.PROD_LIMIT_ID = V_LIMIT_ID
                            GROUP BY TOTAL_NCV_CCY_CODE
                            UNION ALL
                            SELECT TOTAL_NCV_CCY_CODE, SUM(TOTAL_NCV_CCY_AMT)
                            FROM SCBT_T_COLLATERAL_REGISTER_MST C, SCBT_T_DEAL_REGISTER_HDR_MST R
                            WHERE C.BANK_GROUP_CODE = R.BANK_GROUP_CODE AND C.CTY_CODE = R.CTY_CODE AND C.CUST_ID = R.CUST_ID AND C.DEAL_ID = R.DEAL_ID 
                            AND COLLATERAL_CATEGORY<>'REL'
                            AND C.BANK_GROUP_CODE = bankGroupCode AND C.CTY_CODE = ctyCode AND C.CUST_ID = custId AND R.PROD_LIMIT_ID = v_limit_id
                            AND C.COLLATERAL_ID NOT IN (SELECT C.COLLATERAL_ID
                            FROM SCBT_T_COLLATERAL_REGISTER_HST C, SCBT_T_DEAL_REGISTER_HDR_MST R,SCBT_T_DEAL_HIST H
                            WHERE C.BANK_GROUP_CODE = R.BANK_GROUP_CODE AND C.CTY_CODE = R.CTY_CODE
                            AND C.BANK_GROUP_CODE = H.BANK_GROUP_CODE AND C.CTY_CODE = H.CTY_CODE 
                            AND C.CUST_ID = R.CUST_ID AND C.DEAL_ID = R.DEAL_ID AND C.CUST_ID = H.CUST_ID AND C.DEAL_ID = H.DEAL_ID
                            AND C.DEAL_STEP_ID = H.DEAL_STEP_ID AND H.STEP_STATUS_CODE IN ('02','10','14')
                            AND COLLATERAL_CATEGORY<>'REL'
                            AND C.BANK_GROUP_CODE = bankGroupCode AND C.CTY_CODE = ctyCode AND C.CUST_ID = custId AND R.PROD_LIMIT_ID = v_limit_id)
                            GROUP BY TOTAL_NCV_CCY_CODE;
              
                          IF odCcyTypeList.COUNT > 0 THEN
                            v_prog_grp_ncv := 0;
                            FOR i IN 1 ..odCcyTypeList.COUNT LOOP
                                IF odCcyTypeList(i) <> v_ovl_ccy THEN
                                   v_prog_grp_ncv := v_prog_grp_ncv + NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                                                  ctyCode,           -- COUNTRY CODE
                                                                                                 odCcyTypeList(i), -- FROM CURR CODE
                                                                                               odAmtTypeList(i), -- FROM AMOUNT
                                                                                                 v_ovl_ccy,        -- TO CURR CODE
                                                                                               'Y'),0);           -- ROUNG FLAG
               
                                ELSE
                                   v_prog_grp_ncv := v_prog_grp_ncv + odAmtTypeList(i);
                                END IF;
               
                            END LOOP;
               
                         END IF;
               
                        ELSE
                       -- v_prog_grp_ncv     :=0;
                             v_prog_grp_ncv     := NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_TOT_NCV_AMT(v_limit_id,v_ovl_ccy,bankGroupCode,ctyCode,'A'),0);
                        END IF;
               
               
                          v_prog_grp_cmr     := NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_OVERALL_CM_AMT(v_prod_Code,custId,v_limit_id,v_ovl_ccy,bankGroupCode,ctyCode,'S'),0);
                         -- v_prog_grp_cmr :=0;
                         
                        
     
                                      
                        DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                               WHERE BANK_GROUP_CODE = bankGroupCode
                        AND CTY_CODE = ctyCode
                        AND CUST_ID = custId
                        AND LIMIT_ID = v_limit_id
                        AND DEAL_STEP_ID = v_deal_stepid
                        AND CUST_CO_BORROWER_ID = v_co_borr_id
                        AND PAGE_SOURCE = pageSource
                        AND SHORTFALL_OFFSET  IN ('GBB', 'CBB');
                        
                        
                       BEGIN
                         INSERT INTO SCBT_T_CUST_SFALL_OFFSET_MST (
                                BANK_GROUP_CODE
                                , CTY_CODE
                                , CUST_ID
                                , OVERALL_EXP_CCY_CODE
                                , FACILITY_GROUP_NAME
                                , LIMIT_CLASSIFICATION
                                , SHORTFALL_OFFSET
                                , LIMIT_ID
                                , FACILITY_EXPOSURE_CCY
                                , FACILITY_EXPOSURE_AMT
                                , FACILITY_NCV_CCY
                                , FACILITY_NCV_AMT
                                , FACILITY_CMR_CCY
                                , FACILITY_CMR_AMT
                                , CASH_FOR_EXP_OFFSET_CCY
                                , CASH_FOR_EXP_OFFSET_AMT
                                , DEAL_STEP_ID
                                , CUST_CO_BORROWER_ID --, FACILITY_GROUP_ID
                                , PAGE_SOURCE )
                                         VALUES (
                                bankGroupCode
                                , ctycode
                                , custId
                                , v_ovl_ccy
                                , v_fac_grp_name
                                , v_lmt_class
                                , v_sfall_off
                                , v_limit_id
                                , v_ovl_ccy --v_lmt_ccy_code
                                , v_prod_grp_exp
                                , v_ovl_ccy  --v_lmt_ccy_code
                                , nvl(v_prog_grp_ncv, 0)
                                , v_ovl_ccy  --v_lmt_ccy_code
                                , v_prog_grp_cmr
                                , v_ovl_ccy --v_lmt_ccy_code
                                , v_prod_grp_acc_bal
                                , nvl(v_deal_step_id,v_deal_stepid) --, v_deal_step_id
                                , v_co_borr_id --NVL(v_group_id,'CLIENT')
                                , pageSource
                                );
                       EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                        dbms_output.put_line('SQLERRM:'|| SQLERRM);
                       END;
                      -- COMMIT;---
               
                 END SCBP_ISRT_SFALL_OFFSET_MST_COB;
               
               /*---------------------------------------------------------------------------------------------------------------------------*/
               
               --REF_25SEP_2012  
               /*---------------------------------------------------------------------------------------------------------------------------*/
               
               
                 PROCEDURE SCBP_P_GET_DTL_EXP_AMT_COB(p_ret_code    IN OUT VARCHAR2,
                                                  bankGroupCode IN VARCHAR2,
                                                  ctyCode       IN VARCHAR2,
                                                  custId        IN VARCHAR2,
                                                  dealStepID    IN VARCHAR2,
                                                  limitId       IN VARCHAR2,
                                                  coBorrowerId  IN VARCHAR2,
                                                  pageSource    IN VARCHAR2) IS
               
                 v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
                 v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
                 v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
                 v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
                 v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
                 v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
                 v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
                 v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
                 v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
                 v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
                 v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
                 v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
                 v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
                 v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
                 v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
                 v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
                 v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
                 v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
                 v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
                 v_temp_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
                 v_coll_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
                 v_hf_facility                        SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE;
                 v_hf_acc_no                          SCBT_R_CUST_PRODUCT_LIMIT.OVERDRAFT_FACILITY_ACCNO%TYPE;
                 v_hf_acc_bal                SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
                 v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
                 v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
                 v_coll_limit_req_ncv_amt    SCBT_T_Coll_LIMIT_REQ_LOG_DTL.Txn_Ccy_Amt%TYPE;
                 v_group_facility_ncv_amt    SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
                 v_client_limit_class        SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
                 v_over_curr_lmt_ccy_active_amt SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
                 v_coll_limit_id             SCBT_R_CUST_COLLAT_LIMIT.Collateral_Limit_Id%TYPE;
                 v_ci_limit_cat_code         SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CAT_CODE%TYPE;
                 TYPE ci_limit_id_type IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
                 ci_limit_id_list ci_limit_id_type;
                 v_local_limit_id            SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
                 v_co_borrower_id            SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE;
                 v_is_syndicate_coll         NUMBER;
                 v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
                 v_tot_dp_app_amt            NUMBER;
                 v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
                 v_appl_dp_ccy_code          SCBT_R_BBC_DTLS_MST.Appl_Dp_Ccy_Code%type;
                 v_deal_step_id              SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE;
                 v_temp_co_borrower_id       SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE;
                 v_expiry_date               SCBT_R_BBC_DTLS_MST.EXPIRY_DATE%type; 
                 sep_bb_cert_flag   VARCHAR2(2);
                
               
                 CURSOR group_coll IS
                 SELECT FACILITY_GRP_ID, PROD_LIMIT_IDS, LINKED_ACC_NOS, LIMIT_AMT_CCY
                   FROM SCBT_R_CUST_FACILITY_GRP
                  WHERE bank_group_code = bankGroupCode
                    AND cty_code            = ctyCode
                      AND cust_id             = custId
                      AND group_type        = v_grp_type;
               
                 CURSOR mbb_client_coll IS
                 SELECT distinct cpl.LIMIT_ID as LIMIT_ID,
                        cpl.LIMIT_CLASSIFICATION as LIMIT_CLASSIFICATION,
                        nvl(cpl.CO_BORROWER_ID,cpl.cust_id) as CO_BORROWER_ID
                   FROM SCBT_R_CUST_PRODUCT_LIMIT cpl
                 WHERE cpl.bank_group_code = bankGroupCode
                       AND cpl.cty_code = ctyCode
                          --AND cpl.cust_id    = custId
                       AND nvl(cpl.CO_BORROWER_ID,cpl.cust_id) = custId
                       AND cpl.shortfall_offset = 'CBB';     
                       
                        
                 CURSOR cbb_client_coll IS
                 SELECT distinct cpl.LIMIT_ID as LIMIT_ID,
                        cpl.LIMIT_CLASSIFICATION as LIMIT_CLASSIFICATION,
                        nvl(cpl.CO_BORROWER_ID,cpl.cust_id) as CO_BORROWER_ID
                   FROM SCBT_R_CUST_PRODUCT_LIMIT cpl
                 WHERE cpl.bank_group_code = bankGroupCode
                       AND cpl.cty_code = ctyCode
                          --AND cpl.cust_id    = custId
                       --AND nvl(cpl.CO_BORROWER_ID,cpl.cust_id) = custId
                       AND cpl.CO_BORROWER_ID = v_co_borrower_id
                       AND cpl.shortfall_offset = 'CBB';                   
               
               
                 CURSOR group_cap_coll IS
                 SELECT FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION
                   FROM SCBT_T_CUST_SFALL_OFFSET_MST c
                  WHERE bank_group_code      = bankGroupCode
                    AND cty_code                 = ctyCode
                      AND cust_id                  = custId
                    AND deal_step_id         = dealStepID
                      AND shortfall_offset     = 'GFL'
                    GROUP BY FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION;
               
               
                 CURSOR coll_limit IS
                 SELECT COLLATERAL_LIMIT_ID, PRODUCT_LIMIT_ID, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT
                    , COLLATERAL_TYPE_CODE
                    , COLLATERAL_LIMIT_NAME
                   FROM SCBT_R_CUST_COLLAT_LIMIT
                  WHERE bank_group_code = bankGroupCode
                    AND cty_code            = ctyCode
                      AND cust_id             = custId;
               
 BEGIN
               
                        p_ret_code := '0000';
                      v_grp_id   := '0';
                      

                 BEGIN  
                   SELECT CO_BORROWER_ID INTO v_co_borrower_id
                    FROM SCBT_R_CUST_PRODUCT_LIMIT
                   WHERE bank_group_code  = bankGroupCode
                     AND cty_code         = ctyCode
                     AND cust_id          = custId
                     AND limit_id = limitId
                     AND CO_BORROWER_ID is not null;  
                 EXCEPTION WHEN OTHERS THEN
                    NULL;
                 END;                        

                      
                      
                 BEGIN  
                   SELECT NVL(SEP_BB_CERT_FLAG,'N') into sep_bb_cert_flag
                    FROM SCBT_R_CUST_LIMIT_MST
                   WHERE bank_group_code  = bankGroupCode
                     AND cty_code         = ctyCode
                     AND cust_id          = custId;  
                 END;                        
               
                      v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);
               
                      v_local_limit_id := limitId;
               
                      BEGIN
                          SELECT SHORTFALL_OFFSET, LIMIT_CLASSIFICATION, LIMIT_CCY_CODE
                            INTO v_shortfall_offset, v_limit_class, v_lmt_ccy_code
                            FROM SCBT_R_CUST_PRODUCT_LIMIT
                             WHERE bank_group_code = bankGroupCode
                               AND cty_code            = ctyCode
                               AND cust_id             = custId
                               AND limit_id        = v_local_limit_id;
                              EXCEPTION
                           WHEN OTHERS THEN
                             v_shortfall_offset := '';
                             v_limit_class := '';
                             v_lmt_ccy_code := '';
                       END;
               
               
                        /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE GROUP FACILITY */
               
                      BEGIN
                         IF pageSource = 'CDB' THEN
                           DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                             WHERE BANK_GROUP_CODE = bankGroupCode
                                   AND CTY_CODE = ctyCode
                                   AND CUST_ID = custId
                                   --AND DEAL_STEP_ID = dealStepID
                                   AND CUST_CO_BORROWER_ID=v_grp_id
                                   AND PAGE_SOURCE = pageSource
                                   AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                         ELSE
                           DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                             WHERE BANK_GROUP_CODE = bankGroupCode
                                   AND CTY_CODE = ctyCode
                                   AND CUST_ID = custId
                                   AND DEAL_STEP_ID = dealStepID
                                   AND PAGE_SOURCE = pageSource
                                   AND SHORTFALL_OFFSET ='CBB';
                         END IF;
               
               
                       EXCEPTION
                         WHEN OTHERS THEN
                           NULL;
                       END;
               
               
               
               
                        /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */
               
                      IF v_shortfall_offset = 'CBB' THEN
               
                        SELECT  LIMIT_CLASSIFICATION
                           INTO v_client_limit_class
                           FROM SCBT_R_CUST_PRODUCT_LIMIT c
                           WHERE bank_group_code      = bankGroupCode
                            AND cty_code                 = ctyCode
                              AND cust_id                  = custId
                            AND shortfall_offset = 'CBB'
                            AND LIMIT_ID = v_local_limit_id;
               
               
              
                         v_grp_id          := NULL;
                         
                         IF v_co_borrower_id is not null THEN
                            FOR clt IN cbb_client_coll LOOP
                                v_grp_id := 'CS';
                                v_fac_grp_name := 'Client Borrowing Base';
                 
                               SCBP_ISRT_SFALL_OFFSET_MST_COB(bankGroupCode,
                                                          ctyCode,
                                                          custId,
                                                          clt.limit_id,
                                                          v_exp_curr_code,
                                                          dealStepID,
                                                          v_fac_grp_name,
                                                          v_grp_id,
                                                          clt.co_borrower_id,
                                                          pageSource);
                           END LOOP;                         
                         ELSE
                          FOR clt IN mbb_client_coll LOOP
                              v_grp_id := 'CS';
                              v_fac_grp_name := 'Client Borrowing Base';
               
                             SCBP_ISRT_SFALL_OFFSET_MST_COB(bankGroupCode,
                                                        ctyCode,
                                                        custId,
                                                        clt.limit_id,
                                                        v_exp_curr_code,
                                                        dealStepID,
                                                        v_fac_grp_name,
                                                        v_grp_id,
                                                        clt.co_borrower_id,
                                                        pageSource);
                         END LOOP;
                                       
                         END IF;
                         

                      END IF;
               
                      /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */
               
                        IF v_shortfall_offset = 'CBB' THEN
               
                         v_grp_lnk_bal := NULL;
                         v_grp_id      := NULL;
               
                         v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode
                                                                           , ctyCode
                                                                           , v_exp_curr_code --v_lmt_ccy_code,
                                                                           , custId)
                                                                           , 0);
               
                      END IF;
               
                      IF v_shortfall_offset = 'GFL' THEN
               
                         v_clt_grp_indicator := 'GROUP';
               
                      ELSE
               
                         v_clt_grp_indicator    := 'CLIENT';
               
                      END IF;
                   v_clt_grp_indicator := 'CBB';
                  
               
                      BEGIN
                        IF pageSource = 'CDB' THEN
                          SELECT SUM(FACILITY_EXPOSURE_AMT)
                                , SUM(FACILITY_NCV_AMT)
                                , SUM(FACILITY_CMR_AMT)
                                , SUM(CASH_FOR_EXP_OFFSET_AMT)
                             INTO v_facility_exposure_amt
                                , v_facility_ncv_amt
                                , v_facility_cmr_amt
                                , v_cash_for_exp_offset_amt
                            FROM SCBT_T_CUST_SFALL_OFFSET_MST
                           WHERE BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE        = ctyCode
                             AND CUST_ID         = custId
                             AND DEAL_STEP_ID    = dealStepID
                             AND PAGE_SOURCE     = pageSource
                             AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                        ELSE
                          IF v_co_borrower_id is not null then
                          SELECT sum(FACILITY_EXPOSURE_AMT)
                                ,sum(FACILITY_NCV_AMT)
                                , sum(FACILITY_CMR_AMT)
                                , sum(CASH_FOR_EXP_OFFSET_AMT)
                             INTO v_facility_exposure_amt
                                , v_facility_ncv_amt
                                , v_facility_cmr_amt
                                , v_cash_for_exp_offset_amt
                            FROM SCBT_T_CUST_SFALL_OFFSET_MST
                           WHERE BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE        = ctyCode
                             AND CUST_ID         = custId
                              AND cust_co_borrower_id=v_co_borrower_id
                             AND DEAL_STEP_ID    = dealStepID
                             AND PAGE_SOURCE     = pageSource
                            -- AND LIMIT_ID        = limitId
                             AND SHORTFALL_OFFSET = 'CBB';
                          else
                          SELECT sum(FACILITY_EXPOSURE_AMT)
                                ,sum(FACILITY_NCV_AMT)
                                , sum(FACILITY_CMR_AMT)
                                , sum(CASH_FOR_EXP_OFFSET_AMT)
                             INTO v_facility_exposure_amt
                                , v_facility_ncv_amt
                                , v_facility_cmr_amt
                                , v_cash_for_exp_offset_amt
                            FROM SCBT_T_CUST_SFALL_OFFSET_MST
                           WHERE BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE        = ctyCode
                             AND CUST_ID         = custId
                             AND cust_co_borrower_id=custId
                             AND DEAL_STEP_ID    = dealStepID
                             AND PAGE_SOURCE     = pageSource
                            -- AND LIMIT_ID        = limitId
                             AND SHORTFALL_OFFSET = 'CBB';                          
                          end if;   
                        END IF;
                      EXCEPTION
                          WHEN OTHERS THEN
                          v_facility_exposure_amt := 0;
                          v_facility_ncv_amt := 0;
                          v_facility_cmr_amt := 0;
                          v_cash_for_exp_offset_amt := 0;
                      END;
               
                      BEGIN
                        IF pageSource = 'CDB' THEN
                          SELECT SUM(FACILITY_CMR_AMT)
                            INTO v_secured_cmr_amt
                            FROM SCBT_T_CUST_SFALL_OFFSET_MST
                           WHERE BANK_GROUP_CODE      = bankgroupcode
                             AND CTY_CODE               = ctycode
                             AND CUST_ID                 = custid
                             AND DEAL_STEP_ID            = dealstepid
                             --AND LIMIT_CLASSIFICATION = 'SEC';
                             AND CUST_CO_BORROWER_ID = 'CS'
                             AND PAGE_SOURCE     = pageSource
                             AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                        ELSE
                          SELECT FACILITY_CMR_AMT
                            INTO v_secured_cmr_amt
                            FROM SCBT_T_CUST_SFALL_OFFSET_MST
                           WHERE BANK_GROUP_CODE      = bankgroupcode
                             AND CTY_CODE               = ctycode
                             AND CUST_ID                 = custid
                             --AND DEAL_STEP_ID            = dealstepid
                             AND LIMIT_ID             = limitId
                             AND PAGE_SOURCE          = pageSource
                             AND SHORTFALL_OFFSET ='CBB';
                        END IF;
               
                      EXCEPTION
                         WHEN OTHERS THEN
                                 v_secured_cmr_amt:=0;
                      END;
               
               
               
                      v_temp_ncv_amt            := 0;
                        v_coll_ncv_amt            := 0;
               
                       
                       --START
                       BEGIN
                            SELECT COUNT(1) into v_is_syndicate_coll
                                FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                            WHERE map_id = 'TXNISSUVAL'
                                AND code_value_1 = 'CONT_PROD'
                                AND m.code_value_2 = p.limit_product_code
                                AND p.cust_id = custId
                                AND p.limit_id = limitId
                                AND p.bank_group_code = bankGroupCode
                                AND p.cty_code = ctyCode;
                         EXCEPTION
                         WHEN OTHERS THEN
                            v_is_syndicate_coll := 0;
                       END;
                       
                       IF v_is_syndicate_coll > 0 THEN
                             v_product_type := 'CON';
                       ELSE
                             v_product_type := 'ASS';
                       END IF;
                       
                       
                       BEGIN
                          select PARAM_DATA_07 INTO v_syndicate_data
                            FROM SCBT_R_PARAM_DATA
                             WHERE param_id = 'TP10'
                             AND PARAM_KEY_01 = (
                            select DISTINCT SCB_ROLE
                                FROM SCBT_T_TXN_HST
                            WHERE BANK_GROUP_CODE=bankGroupCode
                                  AND CTY_CODE=ctyCode
                                  AND CUST_ID=custId
                                  --AND DEAL_STEP_ID= dealStepID
                                  AND PROD_LIMIT_ID=limitId
                                  ) and PARAM_KEY_02 = v_product_type;
                         EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                       END;
                       
                       BEGIN
                         SELECT distinct TH.DEAL_STEP_ID
                            INTO v_deal_step_id
                           FROM SCBT_T_TXN_HST TH
                             WHERE TH.BANK_GROUP_CODE= bankGroupCode
                               AND TH.CTY_CODE = ctycode
                               AND TH.CUST_ID = custId
                               AND TH.PROD_LIMIT_ID = limitId;
                          EXCEPTION
                          WHEN OTHERS THEN
                              v_deal_step_id := '';
                              dbms_output.put_line('SQLERRM:'|| SQLERRM);
                        END;
                        
                  BEGIN
                      SELECT distinct PL.CO_BORROWER_ID
                            INTO v_temp_co_borrower_id
                      FROM SCBT_R_CUST_PRODUCT_LIMIT PL
                      WHERE PL.BANK_GROUP_CODE = bankGroupCode
                               AND PL.CTY_CODE = ctycode
                               AND PL.CUST_ID = custId
                               AND PL.LIMIT_ID = limitId;
                 EXCEPTION
                 WHEN OTHERS THEN
                      v_temp_co_borrower_id := '';
                      dbms_output.put_line('SQLERRM:'|| SQLERRM);
                 END; 
                        

                   IF v_temp_co_borrower_id =custId or sep_bb_cert_flag = 'N' THEN
                    v_temp_co_borrower_id := null;
                   ELSE
                    v_temp_co_borrower_id := v_temp_co_borrower_id;
                   END IF;
                                              
                        BEGIN
                       
                            select      decode(nvl(v_syndicate_data, 'NCV'),
                                                    'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                                                    , Scbf_Tls_Exch_Rate(
                                                              bbcMst.BANK_GROUP_CODE
                                                                  , bbcMst.CTY_CODE           -- COUNTRY CODE
                                                                    , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                                                  , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                                                    , v_exp_curr_code            -- TO CURR CODE
                                                                  , 'Y')
                                                            ,bbcMst.expiry_date 
                                                    INTO v_appl_dp_ccy_code
                                                    , v_tot_dp_app_amt
                                                    , v_expiry_date
                                                   FROM SCBT_R_BBC_DTLS_MST bbcMst,
                                                   SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                                                   where bbcMst.BANK_GROUP_CODE=bankgroupcode
                                                   AND bbcMst.CTY_CODE=ctycode
                                                   AND bbcMst.Active_Bbc_Flag= 'Y'
                                                   AND bbcGen.Bank_Group_Code = bankgroupcode
                                                   AND bbcGen.Cty_Code = ctycode
                                                   AND bbcGen.Cust_Id = custid
                                                   AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                                                   AND bbcGen.Co_Borrower_Id = nvl(v_temp_co_borrower_id, '*');
                            EXCEPTION
                            WHEN OTHERS THEN
                                 v_appl_dp_ccy_code := '';
                                 v_tot_dp_app_amt := 0;
                         END;
               
               
                 BEGIN
                      SELECT distinct NVL(PL.CO_BORROWER_ID,PL.CUST_ID)
                            INTO v_temp_co_borrower_id
                      FROM SCBT_R_CUST_PRODUCT_LIMIT PL
                      WHERE PL.BANK_GROUP_CODE = bankGroupCode
                               AND PL.CTY_CODE = ctycode
                               AND PL.CUST_ID = custId
                               AND PL.LIMIT_ID = limitId;
                 EXCEPTION
                 WHEN OTHERS THEN
                      v_temp_co_borrower_id := '';
                      dbms_output.put_line('SQLERRM:'|| SQLERRM);
                 END;       
               
               
                         BEGIN
                                delete from SCBT_T_CUST_GRP_CLT_OFFSET_MST
                                   where BANK_GROUP_CODE = bankGroupCode
                                     AND CTY_CODE = ctyCode
                                     AND CUST_ID = custId
                                     --AND LIMIT_ID = limitId   --26Sep2012 120PM
                                     AND CUST_CO_BORROWER_ID = v_temp_co_borrower_id
                                     AND DEAL_STEP_ID = nvl(v_deal_step_id,dealStepID)
                                     AND PAGE_SOURCE = pageSource
                                     AND CLIENT_GROUP_INDICATOR ='CBB';
               
                           EXCEPTION
                               WHEN OTHERS THEN
                                 NULL;
                         END;
                         
                         
                         
                         
                   BEGIN
                          INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                                 BANK_GROUP_CODE
                                 , CTY_CODE
                                 , CUST_ID
                                 , OVERALL_EXP_CCY_CODE
                                 , FACILITY_GROUP_NAME
                                 , CLIENT_GROUP_INDICATOR
                                 , LIMIT_CLASSIFICATION
                                 , LIMIT_ID
                                 , CUST_CO_BORROWER_ID
                                 , FACILITY_EXPOSURE_CCY
                                 , FACILITY_EXPOSURE_AMT
                                 , FACILITY_NCV_CCY
                                 , FACILITY_NCV_AMT
                                 , FACILITY_CMR_CCY
                                 , FACILITY_CMR_AMT
                                 , CASH_FOR_EXP_OFFSET_CCY
                                 , CASH_FOR_EXP_OFFSET_AMT
                                 , LINKED_ACCOUNT_CCY
                                 , LINKED_ACCOUNT_BALANCE
                                 , SECURED_CMR_CCY
                                 , SECURED_CMR_AMT
                                 , UNSECURED_CMR_CCY
                                 , UNSECURED_CMR_AMT
                                 , DEAL_STEP_ID
                                 , EFF_NCV_COLL_CAP
                                 , EFF_NCV_COLL_GRP_CAP
                                 , APPLICABLE_DP_CCY
                                 , APPLICABLE_DP_AMT
                                 , HF_ACC_BALANCE
                                 , PAGE_SOURCE
                                 , EXPIRY_DATE )
                             VALUES ( bankGroupCode
                                 , ctyCode
                                 , custId
                                 , v_exp_curr_code
                                 , v_fac_grp_name
                                 , v_clt_grp_indicator
                                 , v_limit_class
                                 , NVL(limitId,'CSCU')
                                 , nvl(v_temp_co_borrower_id,custId)    --NVL(v_grp_id,'CSCU')
                                 , v_exp_curr_code --v_lmt_ccy_code
                                 , v_facility_exposure_amt
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , v_facility_ncv_amt
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , v_facility_cmr_amt
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , v_cash_for_exp_offset_amt
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , NVL(v_grp_lnk_bal , v_clt_lnk_bal)
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , NVL(v_secured_cmr_amt, 0)
                                 , v_exp_curr_code  --v_lmt_ccy_code
                                 , NVL(v_unsecured_cmr_amt, 0)
                                 , nvl(dealStepID,v_deal_step_id)
                                 , least(v_eff_ncv_coll_cap, v_coll_ncv_amt) -- v_eff_ncv_coll_cap
                                 , least(nvl(v_eff_ncv_coll_grp_cap, v_group_facility_ncv_amt), v_group_facility_ncv_amt) -- v_eff_ncv_coll_grp_cap
                                 , v_appl_dp_ccy_code
                                 , v_tot_dp_app_amt
                                 , v_hf_acc_bal
                                 , pageSource
                                 , v_expiry_date
                               );
               
                        EXCEPTION
                            WHEN OTHERS THEN
                            dbms_output.put_line('SQLERRM:'|| SQLERRM);
                               NULL;
                        END; 
               
               END SCBP_P_GET_DTL_EXP_AMT_COB;
                 
               
               
/*---------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------------------------*/
  PROCEDURE SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode  IN VARCHAR2,
                                       ctyCode        IN VARCHAR2,
                                       custId         IN VARCHAR2,
                                       v_limit_id     IN VARCHAR2,
                                       v_ovl_ccy      IN VARCHAR2,
                                       v_deal_stepid  IN VARCHAR2,
                                       v_fac_grp_name IN VARCHAR2,
                                       v_group_id     IN VARCHAR2,
                                       pageSource     IN VARCHAR2) IS

  v_lmt_ccy_code              SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;
  v_lmt_class                 SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_prod_Code                 SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE;
  v_prog_grp_ncv              SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_prog_grp_cmr              SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_prod_grp_exp              SCBT_T_CUST_ACC_ACTIVITY_MST.TXN_CCY_AMT%TYPE := 0;
  v_prod_grp_acc_bal          SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
  v_is_syndicate_coll         NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  v_max_syndicated_amt_ccy    SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT_CCY%TYPE;
  v_max_syndicated_amt        SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT%TYPE;
--  v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  v_od_or_hedge_account       number;
        v_deal_step_id              SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE;
        v_co_borrower_id            SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE;

    TYPE odCcyType IS TABLE OF SCBT_T_COLLATERAL_REGISTER_HST.total_ncv_ccy_code%TYPE INDEX BY PLS_INTEGER;
    TYPE odAmtType IS TABLE OF SCBT_T_COLLATERAL_REGISTER_HST.total_ncv_ccy_amt%TYPE INDEX BY PLS_INTEGER;
    odCcyTypeList              odCcyType;
    odAmtTypeList              odAmtType;

    BEGIN

        BEGIN
          SELECT LIMIT_CCY_CODE
                 , LIMIT_CLASSIFICATION
                 , shortfall_offset
                 , LIMIT_PRODUCT_CODE
             INTO v_lmt_ccy_code
                 , v_lmt_class
                 , v_sfall_off
                 , v_prod_Code
            FROM SCBT_R_CUST_PRODUCT_LIMIT
              WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctycode
                AND CUST_ID = custId
                AND LIMIT_ID = v_limit_id;
           EXCEPTION
             WHEN OTHERS THEN
               v_lmt_ccy_code := '';
               v_lmt_class := '';
               v_sfall_off := '';
               v_prod_Code := '';
         END;


        --Exposure value for Syndication Collateralization START
        BEGIN
          SELECT COUNT(1) into v_is_syndicate_coll
              FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                 WHERE map_id = 'TXNISSUVAL'
                 AND code_value_1 = 'CONT_PROD'
                 AND m.code_value_2 = p.limit_product_code
                 AND p.cust_id = custId
                 AND p.limit_id = v_limit_id
                 AND p.bank_group_code = bankGroupCode
                 AND p.cty_code = ctyCode;
        EXCEPTION
            WHEN OTHERS THEN
            v_is_syndicate_coll := 0;
        END;

        IF v_is_syndicate_coll > 0 THEN
          v_product_type := 'CON';
        ELSE
          v_product_type := 'ASS';
        END IF;


        BEGIN
          SELECT PARAM_DATA_04 INTO v_syndicate_data
          FROM SCBT_R_PARAM_DATA WHERE param_id = 'TP10'
          AND PARAM_KEY_01 = (SELECT DISTINCT SCB_ROLE FROM SCBT_T_TXN_HST
                   WHERE BANK_GROUP_CODE=bankGroupCode
                   AND CTY_CODE=ctyCode
                   AND CUST_ID=custId
                   AND DEAL_STEP_ID=v_deal_stepid
                   AND PROD_LIMIT_ID=v_group_id
             ) AND PARAM_KEY_02 = v_product_type;
        EXCEPTION
           WHEN NO_DATA_FOUND THEN
            BEGIN
                SELECT PARAM_DATA_04 INTO v_syndicate_data
                FROM SCBT_R_PARAM_DATA WHERE param_id = 'TP10'
                AND PARAM_KEY_01 = (SELECT DISTINCT SCB_ROLE FROM SCBT_T_TXN_MST
                         WHERE BANK_GROUP_CODE=bankGroupCode
                         AND CTY_CODE=ctyCode
                         AND CUST_ID=custId
                         AND LATEST_DEAL_STEP_ID=v_deal_stepid
                         AND PROD_LIMIT_ID=v_group_id
                   ) AND PARAM_KEY_02 = v_product_type;
              EXCEPTION
                WHEN OTHERS THEN
                 NULL;
              END;   
        END;


        IF v_syndicate_data IS NOT NULL AND v_syndicate_data = 'USYA' THEN
           BEGIN
           
               SELECT TM.MAX_SYNDICATED_TXN_AMT_CCY, (TM.MAX_SYNDICATED_TXN_AMT-NVL(TM.SYNDICATED_UTIL_AMT,0))
               INTO v_max_syndicated_amt_ccy,v_max_syndicated_amt 
               FROM SCBT_T_TXN_MST TM WHERE TM.BANK_GROUP_CODE=bankGroupCode
               AND TM.CTY_CODE=ctyCode AND TM.CUST_ID=custId               
               AND TM.PROD_LIMIT_ID=v_group_id
               AND TM.TXN_REC_ID NOT IN (
                  SELECT TH.TXN_REC_ID FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                  WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND TH.CTY_CODE = DH.CTY_CODE
                  AND TH.DEAL_ID = DH.DEAL_ID AND TH.CUST_ID = DH.CUST_ID                  
                  AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE IN ('10','02','14')
                  AND TH.CTY_CODE=ctyCode AND TH.CUST_ID=custId
                  AND TH.DEAL_STEP_ID=v_deal_stepid
                  AND TH.PROD_LIMIT_ID=v_group_id)
               AND (TM.MAX_SYNDICATED_TXN_AMT-NVL(TM.SYNDICATED_UTIL_AMT,0))>0
               UNION ALL
               SELECT TH.MAX_SYNDICATED_TXN_AMT_CCY, (TH.MAX_SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0)) FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
               WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND TH.CTY_CODE = DH.CTY_CODE
               AND TH.DEAL_ID = DH.DEAL_ID AND TH.CUST_ID = DH.CUST_ID                  
               AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE IN ('10','02','14')
               AND TH.CTY_CODE=ctyCode AND TH.CUST_ID=custId
               AND TH.DEAL_STEP_ID=v_deal_stepid
               AND TH.PROD_LIMIT_ID=v_group_id
               AND (TH.MAX_SYNDICATED_TXN_AMT-NVL(TH.SYNDICATED_UTIL_AMT,0))>0;


/*                SELECT SUM(D.TXN_CCY_AMT), D.TXN_CCY_CODE 
                      INTO v_max_syndicated_amt_ccy,v_max_syndicated_amt 
                      FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL D,
                           SCBT_T_PROD_LIMIT_REQ_LOG R
                     WHERE D.BANK_GROUP_CODE = bankGroupCode
                       AND D.CTY_CODE        = ctyCode
                       AND D.PROD_LIMIT_ID   = v_group_id
                       AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
                       AND R.CTY_CODE        = D.CTY_CODE
                       AND D.limit_tree_type_code = 'PROD'
                       AND D.INIT_REQ_ID     = R.INIT_REQ_ID
                       AND R.REQ_TYPE_CODE   = 'NEW'
                       AND R.REQ_STATUS_CODE IN ('PEND','CON')
                       GROUP BY D.TXN_CCY_CODE HAVING SUM(D.TXN_CCY_AMT) > 0;*/ --ANBU 

  
               
             EXCEPTION
               WHEN OTHERS THEN
                 v_max_syndicated_amt_ccy := '';
                 v_max_syndicated_amt := 0;
           END;

           --If LIMIT CURRENCY and SYNDICATED AMT CURRENCY is different

           IF (v_max_syndicated_amt_ccy <> v_ovl_ccy) THEN
              v_prod_grp_exp := NVL( Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                  ctyCode,           -- COUNTRY CODE
                                                                    v_max_syndicated_amt_ccy, -- FROM CURR CODE
                                                                  v_max_syndicated_amt, -- FROM AMOUNT
                                                                    v_ovl_ccy,        -- TO CURR CODE
                                                                  'Y'),0 );
           ELSE
             v_prod_grp_exp := v_max_syndicated_amt;
           END IF;

        ELSE
           BEGIN           
               SELECT SUM(Scbf_Tls_Exch_Rate(r.bank_group_code,r.cty_code,d.txn_ccy_code
                                            --27-SEP-2012 
                                            ,d.syn_txn_ccy_amt --d.txn_ccy_amt 
                                            ,v_ovl_ccy,'Y')) INTO v_prod_grp_exp
               FROM SCBT_T_PROD_LIMIT_REQ_LOG R,SCBT_T_PROD_LIMIT_REQ_LOG_DTL D
               WHERE R.BANK_GROUP_CODE  = bankGroupCode
               AND R.CTY_CODE                = ctycode
               AND D.BANK_GROUP_CODE    = R.BANK_GROUP_CODE
               AND D.CTY_CODE                = R.CTY_CODE
               AND R.REQ_TYPE_CODE      = 'NEW'
                    AND D.LIMIT_TREE_TYPE_CODE = 'PROD'
                    AND R.REQ_STATUS_CODE  in ('PEND','CON')
                    AND R.INIT_REQ_ID         = D.INIT_REQ_ID
                    AND D.prod_LIMIT_ID             = v_limit_id;
                   EXCEPTION
                     WHEN OTHERS THEN
                       v_prod_grp_exp := 0;
                   END;
    
        END IF;

        --Exposure value for Syndication Collateralization END
        v_prod_grp_acc_bal := Scbf_Get_Acc_Balance(bankGroupCode,ctyCode,custId,v_limit_id,v_ovl_ccy,'O');

        BEGIN
           v_od_or_hedge_account :=0;
           SELECT COUNT(*) INTO v_od_or_hedge_account FROM SCBT_R_CUST_PRODUCT_LIMIT
           WHERE (LIMIT_PRODUCT_CODE IN (SELECT PRODUCT_CODE FROM SCBT_R_PRODUCT_MST 
                                         WHERE BANK_GROUP_CODE = bankGroupCode AND PROD_REF_CODE ='OD')
                  OR NVL(FIN_HEDGE_MARGIN,'N') = 'Y')
            AND BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND CUST_ID = custId AND LIMIT_ID=v_limit_id;
        EXCEPTION
            WHEN OTHERS THEN
              NULL;
        END;

         IF (v_od_or_hedge_account > 0) THEN
             SELECT total_ncv_ccy_code, SUM(total_ncv_ccy_amt) BULK COLLECT  INTO odCcyTypeList, odAmtTypeList
             FROM SCBT_T_COLLATERAL_REGISTER_HST CR,SCBT_T_DEAL_REGISTER_HDR_MST DR,SCBT_T_DEAL_HIST DH
             WHERE CR.BANK_GROUP_CODE = DR.BANK_GROUP_CODE  AND CR.CTY_CODE = DR.CTY_CODE
             AND CR.CUST_ID = DR.CUST_ID AND CR.DEAL_ID = DR.DEAL_ID 
             AND CR.BANK_GROUP_CODE = DH.BANK_GROUP_CODE  AND CR.CTY_CODE = DH.CTY_CODE
             AND CR.CUST_ID = DH.CUST_ID AND CR.DEAL_ID = DH.DEAL_ID AND CR.DEAL_STEP_ID = DH.DEAL_STEP_ID 
             AND CR.BANK_GROUP_CODE = bankGroupCode AND CR.CTY_CODE = ctyCode AND CR.CUST_ID = custId
             AND DR.PROD_LIMIT_ID =v_limit_id AND CR.DEAL_STEP_ID = DH.DEAL_STEP_ID
             AND DH.STEP_STATUS_CODE IN ('02','10','14') AND CR.COLLATERAL_CATEGORY<>'REL'
             GROUP BY total_ncv_ccy_code
             UNION
             SELECT total_ncv_ccy_code, SUM(total_ncv_ccy_amt) 
             FROM SCBT_T_COLLATERAL_REGISTER_MST CM,SCBT_T_DEAL_REGISTER_HDR_MST DR
             WHERE CM.BANK_GROUP_CODE = DR.BANK_GROUP_CODE  AND CM.CTY_CODE = DR.CTY_CODE
             AND CM.CUST_ID = DR.CUST_ID AND CM.DEAL_ID = DR.DEAL_ID AND CM.COLLATERAL_CATEGORY<>'REL'            
             AND CM.BANK_GROUP_CODE = bankGroupCode AND CM.CTY_CODE = ctyCode AND CM.CUST_ID = custId
             AND DR.PROD_LIMIT_ID =v_limit_id 
             AND CM.COLLATERAL_ID NOT IN (SELECT CR.COLLATERAL_ID
                 FROM SCBT_T_COLLATERAL_REGISTER_HST CR,SCBT_T_DEAL_REGISTER_HDR_MST DR,SCBT_T_DEAL_HIST DH
                 WHERE CR.BANK_GROUP_CODE = DR.BANK_GROUP_CODE  AND CR.CTY_CODE = DR.CTY_CODE
                 AND CR.CUST_ID = DR.CUST_ID AND CR.DEAL_ID = DR.DEAL_ID 
                 AND CR.BANK_GROUP_CODE = DH.BANK_GROUP_CODE  AND CR.CTY_CODE = DH.CTY_CODE
                 AND CR.CUST_ID = DH.CUST_ID AND CR.DEAL_ID = DH.DEAL_ID AND CR.DEAL_STEP_ID = DH.DEAL_STEP_ID 
                 AND CR.BANK_GROUP_CODE = bankGroupCode AND CR.CTY_CODE = ctyCode AND CR.CUST_ID = custId
                 AND DR.PROD_LIMIT_ID =v_limit_id AND CR.DEAL_STEP_ID = DH.DEAL_STEP_ID
                 AND DH.STEP_STATUS_CODE IN ('02','10','14') AND CR.COLLATERAL_CATEGORY<>'REL'   
             )
             GROUP BY total_ncv_ccy_code;

           IF odCcyTypeList.COUNT > 0 THEN
             v_prog_grp_ncv := 0;
             FOR i IN 1 ..odCcyTypeList.COUNT LOOP
                 IF odCcyTypeList(i) <> v_ovl_ccy THEN
                    v_prog_grp_ncv := v_prog_grp_ncv + NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                                   ctyCode,           -- COUNTRY CODE
                                                                                  odCcyTypeList(i), -- FROM CURR CODE
                                                                                odAmtTypeList(i), -- FROM AMOUNT
                                                                                  v_ovl_ccy,        -- TO CURR CODE
                                                                                'Y'),0);           -- ROUNG FLAG

                 ELSE
                    v_prog_grp_ncv := v_prog_grp_ncv + odAmtTypeList(i);
                 END IF;

             END LOOP;

          END IF;

         ELSE
              v_prog_grp_ncv     := NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_TOT_NCV_AMT(v_limit_id,v_ovl_ccy,bankGroupCode,ctyCode,'A'),0);
         END IF;


           v_prog_grp_cmr     := NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_OVERALL_CM_AMT(v_prod_Code,custId,v_limit_id,v_ovl_ccy,bankGroupCode,ctyCode,'S'),0);
               
             BEGIN
                SELECT distinct PL.CO_BORROWER_ID
                   INTO v_co_borrower_id
                  FROM SCBT_R_CUST_PRODUCT_LIMIT PL
                    WHERE PL.BANK_GROUP_CODE = bankGroupCode
                      AND PL.CTY_CODE = ctycode
                      AND PL.CUST_ID = custId
                      AND PL.LIMIT_ID = v_limit_id;
                 EXCEPTION
                 WHEN OTHERS THEN
                     v_co_borrower_id := '';
                     dbms_output.put_line('SQLERRM:'|| SQLERRM);
               END;
                 
              BEGIN
          INSERT INTO SCBT_T_CUST_SFALL_OFFSET_MST (
                 BANK_GROUP_CODE
                 , CTY_CODE
                 , CUST_ID
                 , OVERALL_EXP_CCY_CODE
                 , FACILITY_GROUP_NAME
                 , LIMIT_CLASSIFICATION
                 , SHORTFALL_OFFSET
                 , LIMIT_ID
                 , FACILITY_EXPOSURE_CCY
                 , FACILITY_EXPOSURE_AMT
                 , FACILITY_NCV_CCY
                 , FACILITY_NCV_AMT
                 , FACILITY_CMR_CCY
                 , FACILITY_CMR_AMT
                 , CASH_FOR_EXP_OFFSET_CCY
                 , CASH_FOR_EXP_OFFSET_AMT
                 , DEAL_STEP_ID
                 , FACILITY_GROUP_ID
                       , CUST_CO_BORROWER_ID
                 , PAGE_SOURCE )
                          VALUES (
                 bankGroupCode
                 , ctycode
                 , custId
                 , v_ovl_ccy
                 , v_fac_grp_name
                 , v_lmt_class
                 , v_sfall_off
                 , v_limit_id
                 , v_ovl_ccy --v_lmt_ccy_code
                 , v_prod_grp_exp
                 , v_ovl_ccy  --v_lmt_ccy_code
                 , nvl(v_prog_grp_ncv, 0)
                 , v_ovl_ccy  --v_lmt_ccy_code
                 , v_prog_grp_cmr
                 , v_ovl_ccy --v_lmt_ccy_code
                 , v_prod_grp_acc_bal
                 , decode(ctycode, 'US', nvl(v_deal_stepid,0), v_deal_stepid)
                 , NVL(v_group_id,decode(v_lmt_class, 'SC', 'CS', 'USC', 'CU')) --NVL(v_group_id,'CLIENT')
                       , nvl(v_co_borrower_id,custId)
                 , pageSource
                 );
        EXCEPTION
          WHEN OTHERS THEN
          NULL;
          dbms_output.put_line('SQLERRM:'||'ISRT'|| SQLERRM);
        END;
       -- COMMIT;

  END SCBP_ISRT_SFALL_OFFSET_MST;

/*---------------------------------------------------------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------------------------------------------------------*/


  PROCEDURE SCBP_P_GET_DTL_EXP_AMT(p_ret_code    IN OUT VARCHAR2,
                                   bankGroupCode IN VARCHAR2,
                                   ctyCode       IN VARCHAR2,
                                   custId        IN VARCHAR2,
                                   dealStepID    IN VARCHAR2,
                                   limitId       IN VARCHAR2,
                                   pageSource    IN VARCHAR2) IS

  v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
  v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
  v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
  v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
  v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
  v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
  v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
  v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
  v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
  v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
  v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
  v_temp_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_coll_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_hf_facility                        SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE;
  v_hf_acc_no                          SCBT_R_CUST_PRODUCT_LIMIT.OVERDRAFT_FACILITY_ACCNO%TYPE;
  v_hf_acc_bal                SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
  v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
  v_coll_limit_req_ncv_amt    SCBT_T_Coll_LIMIT_REQ_LOG_DTL.Txn_Ccy_Amt%TYPE;
  v_group_facility_ncv_amt    SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_client_limit_class        SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_over_curr_lmt_ccy_active_amt SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
  v_coll_limit_id             SCBT_R_CUST_COLLAT_LIMIT.Collateral_Limit_Id%TYPE;
  v_ci_limit_cat_code         SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CAT_CODE%TYPE;
  TYPE ci_limit_id_type IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  ci_limit_id_list ci_limit_id_type;
  v_local_limit_id            SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
  vCollGrpCount number(10);
  TYPE vHfLimitType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE vHFFlagType  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE INDEX BY PLS_INTEGER;
  v_deal_step_id              SCBT_T_TXN_HST.DEAL_STEP_ID%TYPE;
  v_temp_co_borrower_id       SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE;
  v_is_syndicate_coll         SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  v_tot_dp_app_amt            NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_appl_dp_ccy_code          SCBT_R_BBC_DTLS_MST.Appl_Dp_Ccy_Code%type;
  v_expiry_date               SCBT_R_BBC_DTLS_MST.EXPIRY_DATE%type; 
  v_cbb_limit_id              SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
  v_cbb_limit_class           SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_co_borr_cnt               number(10);
  sep_bb_cert_flag            SCBT_R_CUST_LIMIT_MST.SEP_BB_CERT_FLAG%TYPE;
 
  
  vHfLimitId         vHfLimitType;
  vHFFlag            vHFFlagType; 
  vClientBalGetCount number(2);
  CURSOR group_coll IS
  SELECT FACILITY_GRP_ID, PROD_LIMIT_IDS, LINKED_ACC_NOS, LIMIT_AMT_CCY
    FROM SCBT_R_CUST_FACILITY_GRP
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId
       AND group_type        = v_grp_type;

  CURSOR client_coll IS
  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
       AND shortfall_offset     = 'CUL';
     --AND LIMIT_CLASSIFICATION = v_client_limit_class;
     --AND LIMIT_ID = limitId;
--GROUP BY LIMIT_CLASSIFICATION, LIMIT_ID;


  CURSOR cbb_coll IS
  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
       AND shortfall_offset     = 'CBB';

  CURSOR group_cap_coll IS
  SELECT FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION
    FROM SCBT_T_CUST_SFALL_OFFSET_MST c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
     AND deal_step_id         = dealStepID
       AND shortfall_offset     = 'GFL'
     GROUP BY FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION;


  CURSOR coll_limit IS
  SELECT COLLATERAL_LIMIT_ID, PRODUCT_LIMIT_ID, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT
     , COLLATERAL_TYPE_CODE
     , COLLATERAL_LIMIT_NAME
    FROM SCBT_R_CUST_COLLAT_LIMIT
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId;

  BEGIN

         p_ret_code := '0000';
       v_grp_id   := '0';
       vClientBalGetCount := 0;
       v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);

       v_local_limit_id := limitId;

       BEGIN
           SELECT SHORTFALL_OFFSET, LIMIT_CLASSIFICATION, LIMIT_CCY_CODE
             INTO v_shortfall_offset, v_limit_class, v_lmt_ccy_code
             FROM SCBT_R_CUST_PRODUCT_LIMIT
              WHERE bank_group_code = bankGroupCode
                AND cty_code            = ctyCode
                AND cust_id             = custId
                AND limit_id        = v_local_limit_id;
               EXCEPTION
            WHEN OTHERS THEN
              v_shortfall_offset := '';
              v_limit_class := '';
              v_lmt_ccy_code := '';
        END;


         /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS GROUP FACILITY START */

         IF v_shortfall_offset = 'GFL' THEN

              v_grp_type         := 'COL';

          -- if limit is co-borrower limit
          select limit_cat_code into v_ci_limit_cat_code from scbt_r_cust_product_limit
          where limit_id = v_local_limit_id;

          IF v_ci_limit_cat_code = 'CI' THEN
             select limit_id into v_local_limit_id from scbt_r_cust_product_limit
                where ext_limit_id = (
                select inner_to_id from scbt_r_cust_product_limit
                  where limit_id = limitId
             );

          END IF;
          -- get the mainborrower limit id

          FOR grp IN group_coll LOOP

                  FOR c1 IN (SELECT * FROM TABLE(SPLIT(grp.prod_limit_ids))) LOOP

                        IF c1.COLUMN_VALUE IS NOT NULL AND c1.COLUMN_VALUE = v_local_limit_id THEN

                             v_grp_id := grp.facility_grp_id;

                   EXIT;

                END IF;

            END LOOP;

            IF v_grp_id != '0' THEN
               EXIT;
            END IF;

          END LOOP;



       END IF;

         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE GROUP FACILITY */

       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    --AND DEAL_STEP_ID = dealStepID
                    AND FACILITY_GROUP_ID=v_grp_id
                    AND PAGE_SOURCE = pageSource
                    AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND DEAL_STEP_ID = dealStepID
                    AND PAGE_SOURCE = pageSource
                    AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          END IF;


        EXCEPTION
          WHEN OTHERS THEN
            NULL;
        END;


       IF v_shortfall_offset = 'GFL' AND v_grp_id IS NOT NULL THEN

          v_grp_lnk_bal := 0;
          v_hf_acc_bal    := 0;

          BEGIN
            SELECT PROD_LIMIT_IDS, FACLIITY_GRP_NAME, LINKED_ACC_NOS
              INTO v_prod_limit_id, v_fac_grp_name, v_linked_acc_nos
              FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctycode
                AND CUST_ID = custId
                AND FACILITY_GRP_ID = v_grp_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_prod_limit_id := '';
                v_fac_grp_name := '';
                v_linked_acc_nos := '';
          END;
          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_prod_limit_id))) LOOP

              IF c1.COLUMN_VALUE IS NOT NULL THEN


                 SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                            ctyCode,
                                            custId,
                                            c1.column_value,
                                            v_exp_curr_code,
                                            dealStepID,
                                            v_fac_grp_name,
                                            v_grp_id,
                                            pageSource);

                 BEGIN
                   SELECT FIN_HEDGE_MARGIN, OVERDRAFT_FACILITY_ACCNO INTO v_hf_facility, v_hf_acc_no
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                           WHERE bank_group_code = bankGroupCode
                           AND cty_code           = ctyCode
                   AND CUST_ID        = custId
                             AND limit_id            = c1.COLUMN_VALUE;
                           EXCEPTION
                   WHEN OTHERS THEN
                     v_hf_facility := '';
                     v_hf_acc_no := '';
                 END;
                 -- Get +ve Net Balance for Hedge Facility
                         IF v_hf_facility = 'Y' AND v_hf_acc_no IS NOT NULL THEN
                   v_hf_acc_bal := v_hf_acc_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, c1.COLUMN_VALUE, v_exp_curr_code, 'S'),0);
                         ELSE 
                    IF v_hf_acc_no IS NOT NULL THEN -- Get +ve Net Balance for OD Facility
                        v_grp_lnk_bal := v_grp_lnk_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, c1.COLUMN_VALUE, v_exp_curr_code, 'S'),0);
                    END IF;    
                         END IF;

                 -- if limit is co-borrower limit START
                 select limit_id BULK COLLECT INTO ci_limit_id_list from scbt_r_cust_product_limit
                 where inner_to_id = ( select ext_limit_id from scbt_r_cust_product_limit
                    where Limit_id = c1.COLUMN_VALUE) and limit_cat_code = 'CI';

                 FOR i IN 1..ci_limit_id_list.COUNT LOOP

                    SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                              ctyCode,
                                              custId,
                                              ci_limit_id_list(i),
                                              v_exp_curr_code,
                                              dealStepID,
                                              v_fac_grp_name,
                                              v_grp_id,
                                              pageSource);

                   BEGIN
                   SELECT FIN_HEDGE_MARGIN, OVERDRAFT_FACILITY_ACCNO
                             INTO v_hf_facility, v_hf_acc_no
                             FROM SCBT_R_CUST_PRODUCT_LIMIT
                            WHERE bank_group_code = bankGroupCode
                              AND cty_code             = ctyCode
                     AND CUST_ID        = custId
                                AND limit_id            = ci_limit_id_list(i);
                             EXCEPTION
                     WHEN OTHERS THEN
                       v_hf_facility := '';
                       v_hf_acc_no := '';
                   END;
                   -- Get +ve Net Balance for Hedge Facility
                           IF v_hf_facility = 'Y' AND v_hf_acc_no IS NOT NULL THEN
                     v_hf_acc_bal := v_hf_acc_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, ci_limit_id_list(i), v_exp_curr_code, 'S'),0);
                           ELSE
                      IF v_hf_acc_no IS NOT NULL THEN -- Get +ve Net Balance for OD Facility
                         v_grp_lnk_bal := v_grp_lnk_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, ci_limit_id_list(i), v_exp_curr_code, 'S'),0);                   
                      END IF;   
                   END IF;
                   -- if limit is co-borrower limit END
                 END LOOP;
                 
              END IF;

          END LOOP;
          
          -- Get +ve Net Balance of All Linked Accounts at group level.
          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_linked_acc_nos))) LOOP

              IF c1.column_value IS NOT NULL THEN

                 v_clt_lnk_bal := NULL;

                 v_grp_lnk_bal := v_grp_lnk_bal + SCBF_RET_GROUP_LINK_ACC_BAL(bankGroupCode,
                                                                              ctyCode,
                                                                              v_exp_curr_code,
                                                                              custId,
                                                                              c1.column_value);

              END IF;

          END LOOP;

       END IF;

         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */

       IF v_shortfall_offset = 'CUL' THEN

         SELECT  LIMIT_CLASSIFICATION
            INTO v_client_limit_class
            FROM SCBT_R_CUST_PRODUCT_LIMIT c
            WHERE bank_group_code      = bankGroupCode
             AND cty_code                 = ctyCode
               AND cust_id                  = custId
             AND shortfall_offset = 'CUL'
             AND LIMIT_ID = v_local_limit_id;

          v_grp_id          := NULL;
                -- v_sfall_off := 'SC';
                -- v_sfall_off := 'USC';

          FOR clt IN client_coll LOOP
              IF clt.limit_classification = 'SC' THEN
                 v_fac_grp_name := 'Secured Client';
                 v_grp_id := 'CS';
              ELSE
                 v_fac_grp_name := 'UnSecured Client';
                 v_grp_id := 'CU';
              END IF;

              SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                         ctyCode,
                                         custId,
                                         clt.limit_id,
                                         v_exp_curr_code,
                                         dealStepID,
                                         v_fac_grp_name,
                                         v_grp_id,
                                         pageSource);
          END LOOP;

       END IF;
       
       
       IF v_shortfall_offset = 'CBB' and ctyCode ='US' THEN

         SELECT  LIMIT_CLASSIFICATION
            INTO v_client_limit_class
            FROM SCBT_R_CUST_PRODUCT_LIMIT c
            WHERE bank_group_code      = bankGroupCode
             AND cty_code                 = ctyCode
               AND cust_id                  = custId
             AND shortfall_offset = 'CBB'
             AND LIMIT_ID = v_local_limit_id;

          v_grp_id          := NULL;
                -- v_sfall_off := 'SC';
                -- v_sfall_off := 'USC';

          FOR clt IN cbb_coll LOOP
            
                 v_fac_grp_name := 'Client Borrowing Base';
           

              SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                         ctyCode,
                                         custId,
                                         clt.limit_id,
                                         v_exp_curr_code,
                                         dealStepID,
                                         v_fac_grp_name,
                                         v_grp_id,
                                         pageSource);
          END LOOP;

       END IF;


       /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */
       v_clt_lnk_bal := 0; 
         IF v_shortfall_offset = 'CUL' THEN

          v_grp_lnk_bal := NULL;
          v_grp_id      := NULL;
          
          IF vClientBalGetCount = 0 THEN 
            v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode
                                                              , ctyCode
                                                              , v_exp_curr_code --v_lmt_ccy_code,
                                                              , custId)
                                                              , 0);
            vClientBalGetCount := 1;                                                                
          END IF;                                                    
       END IF;

       IF v_shortfall_offset = 'GFL' THEN

          v_clt_grp_indicator := 'GROUP';

       ELSE

          v_clt_grp_indicator    := 'CLIENT';

       END IF;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_EXPOSURE_AMT)
                 , SUM(FACILITY_NCV_AMT)
                 , SUM(FACILITY_CMR_AMT)
                 , SUM(CASH_FOR_EXP_OFFSET_AMT)
              INTO v_facility_exposure_amt
                 , v_facility_ncv_amt
                 , v_facility_cmr_amt
                 , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND DEAL_STEP_ID    = dealStepID
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_EXPOSURE_AMT)
                 , SUM(FACILITY_NCV_AMT)
                 , SUM(FACILITY_CMR_AMT)
                 , SUM(CASH_FOR_EXP_OFFSET_AMT)
              INTO v_facility_exposure_amt
                 , v_facility_ncv_amt
                 , v_facility_cmr_amt
                 , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND DEAL_STEP_ID    = dealStepID
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;
       EXCEPTION
           WHEN OTHERS THEN
           v_facility_exposure_amt := 0;
           v_facility_ncv_amt := 0;
           v_facility_cmr_amt := 0;
           v_cash_for_exp_offset_amt := 0;
       END;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'SEC';
              AND FACILITY_GROUP_ID = 'CS'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'SEC';
              AND FACILITY_GROUP_ID = 'CS'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;

       EXCEPTION
          WHEN OTHERS THEN
                  v_secured_cmr_amt:=0;
       END;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'UNS';
              AND FACILITY_GROUP_ID = 'CU'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'UNS';
              AND FACILITY_GROUP_ID = 'CU'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;

       EXCEPTION
         WHEN OTHERS THEN
                    v_unsecured_cmr_amt := 0;
       END;


       v_temp_ncv_amt            := 0;
         v_coll_ncv_amt            := 0;


          BEGIN
                 delete from SCBT_T_COLL_SFALL_DETAIL_MST
                    where BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID = dealstepid
                      AND PAGE_SOURCE = pageSource;
                   -- AND FACILITY_NAME = v_fac_grp_name
                   -- AND COLLATERAL_TYPE = lmt.Collateral_Type_Code;

            EXCEPTION
                WHEN OTHERS THEN
                  NULL;
          END;


         FOR lmt IN coll_limit LOOP

               FOR c1 IN (SELECT * FROM TABLE(SPLIT(lmt.product_limit_id))) LOOP

                     IF (c1.COLUMN_VALUE = NVL(v_grp_id, limitid)) OR (v_shortfall_offset ='CUL' AND c1.COLUMN_VALUE in ('CS', 'CU')) THEN

                          IF c1.COLUMN_VALUE = 'CS' THEN
                     v_fac_grp_name := 'Secured Client';
                    -- v_grp_id := 'CS';
                  ELSIF c1.COLUMN_VALUE = 'CU' THEN
                     v_fac_grp_name := 'UnSecured Client';
                    -- v_grp_id := 'CU';
                  END IF;
                  --To calculate NCV amount at group level
                      BEGIN
                         SELECT NVL(sum(Scbf_Tls_Exch_Rate(r.bank_group_code,
                                      r.cty_code,           -- COUNTRY CODE
                                        d.ncv_txn_ccy_code, --d.txn_ccy_code,         -- FROM CURR CODE
                                      d.ncv_txn_ccy_amt, --d.txn_ccy_amt,            -- FROM AMOUNT
                                        v_exp_curr_code, --'USD',            -- TO CURR CODE
                                      'Y')), 0)
                                INTO v_coll_limit_req_ncv_amt
                           FROM SCBT_T_coll_LIMIT_REQ_LOG R,
                                  SCBT_T_Coll_LIMIT_REQ_LOG_DTL D
                          WHERE R.BANK_GROUP_CODE  = bankGroupCode
                            AND R.CTY_CODE         = ctyCode
                            AND R.REQ_TYPE_CODE    = 'NEW'
                            AND R.REQ_STATUS_CODE  in ('PEND','CON')
                            AND R.INIT_REQ_ID      = D.INIT_REQ_ID
                            AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
                            AND R.CTY_CODE        = D.CTY_CODE
                            AND D.COLLATERAL_LIMIT_ID =  lmt.collateral_limit_id;
                      EXCEPTION
                          WHEN OTHERS THEN
                            v_coll_limit_req_ncv_amt := 0;
                      END;




                  IF lmt.limit_ccy_code <> v_exp_curr_code THEN

                     v_temp_ncv_amt := NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                  ctyCode,           -- COUNTRY CODE
                                                                    lmt.limit_ccy_code, -- FROM CURR CODE
                                                                  lmt.limit_ccy_active_amt, -- FROM AMOUNT
                                                                     v_exp_curr_code,        -- TO CURR CODE
                                                                  'Y'),0);           -- ROUNG FLAG

                     IF v_temp_ncv_amt > v_coll_limit_req_ncv_amt THEN
                                     v_coll_ncv_amt     := v_coll_ncv_amt + v_coll_limit_req_ncv_amt;
                             ELSE
                        v_coll_ncv_amt     := v_coll_ncv_amt + v_temp_ncv_amt;
                               END IF;

                          ELSE
                     IF lmt.limit_ccy_active_amt > v_coll_limit_req_ncv_amt THEN
                                     v_coll_ncv_amt     := v_coll_ncv_amt + v_coll_limit_req_ncv_amt;
                             ELSE
                        v_coll_ncv_amt     := v_coll_ncv_amt + lmt.limit_ccy_active_amt;
                               END IF;

                          END IF;

                   --Insert data in SCBT_T_COLL_SFALL_DETAIL_MST START
                  -- IF v_sfall_off IS NOT NULL AND v_sfall_off != 'GBB' THEN

                      --To delete existing data from SCBT_T_COLL_SFALL_DETAIL_MST table

                      BEGIN

                        IF pageSource = 'CDB' THEN
                          SELECT SUM(FACILITY_NCV_AMT)
                             INTO v_group_facility_ncv_amt
                             FROM SCBT_T_CUST_SFALL_OFFSET_MST
                            WHERE BANK_GROUP_CODE = bankGroupCode
                              AND CTY_CODE        = ctyCode
                              AND CUST_ID         = custId
                              AND DEAL_STEP_ID    = dealStepID
                              AND FACILITY_GROUP_ID = v_grp_id
                              AND PAGE_SOURCE     = pageSource
                              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                        ELSE
                          SELECT SUM(FACILITY_NCV_AMT)
                             INTO v_group_facility_ncv_amt
                             FROM SCBT_T_CUST_SFALL_OFFSET_MST
                            WHERE BANK_GROUP_CODE = bankGroupCode
                              AND CTY_CODE        = ctyCode
                              AND CUST_ID         = custId
                              AND DEAL_STEP_ID    = dealStepID
                              AND FACILITY_GROUP_ID = v_grp_id
                              AND PAGE_SOURCE     = pageSource
                              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                        END IF;
                      EXCEPTION
                          WHEN OTHERS THEN
                            v_group_facility_ncv_amt := 0;
                      END;

                      BEGIN
                              v_over_curr_lmt_ccy_active_amt := NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                  ctyCode,           -- COUNTRY CODE
                                                                    lmt.limit_ccy_code, -- FROM CURR CODE
                                                                  lmt.limit_ccy_active_amt, -- FROM AMOUNT
                                                                     v_exp_curr_code,        -- TO CURR CODE
                                                                  'Y'),0);           -- ROUNG FLAG
                      EXCEPTION
                         WHEN OTHERS THEN
                            v_over_curr_lmt_ccy_active_amt :=0;
                      END;


                      BEGIN
                           --To insert shortfall details from SCBT_T_COLL_SFALL_DETAIL_MST table
                           INSERT INTO SCBT_T_COLL_SFALL_DETAIL_MST (
                                  BANK_GROUP_CODE
                                , CTY_CODE
                                , CUST_ID
                                , FACILITY_NAME
                                , COLLATERAL_TYPE
                                , FACILITY_NCV_CCY
                                , FACILITY_NCV_AMT
                                , FACILITY_COLL_CAP_AMT
                                , EFFECTIVE_NCV_AMT
                                , DEAL_STEP_ID
                                , COLLATERAL_LIMIT_ID
                                , COLLATERAL_LIMIT_NAME
                                , PAGE_SOURCE )
                           VALUES (
                                  bankGroupCode
                                , ctyCode
                                , custId
                                , v_fac_grp_name
                                , lmt.Collateral_Type_Code
                                ,  v_exp_curr_code  --v_lmt_ccy_code
                                , NVL(v_coll_limit_req_ncv_amt, 0)
                                , nvl( v_over_curr_lmt_ccy_active_amt, 0)
                                , least(nvl(v_coll_limit_req_ncv_amt, 0), nvl( v_over_curr_lmt_ccy_active_amt, 0))
                                , dealstepid
                                , lmt.collateral_limit_id
                                , lmt.collateral_limit_name
                                , pageSource
                           );

                      EXCEPTION
                          WHEN OTHERS THEN
                            NULL;
                          END;
                         -- COMMIT;

                  -- END IF;
                   --Insert data in SCBT_T_COLL_SFALL_DETAIL_MST END

                     END IF;

               END LOOP;

         END LOOP;


       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    --AND DEAL_STEP_ID = dealStepID
                    AND LIMIT_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                    AND PAGE_SOURCE = pageSource
                    AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE bank_group_code = bankGroupCode
                AND cty_code        = ctyCode
                AND cust_id         = custId
                AND deal_step_id    = dealStepID
                AND PAGE_SOURCE     = pageSource
                AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          END IF;

       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;

       FOR gcl IN group_cap_coll LOOP
        v_hf_acc_bal := 0;
         --To calculate HF ACCOUNT BALANCE
         BEGIN         
            SELECT SF.LIMIT_ID,NVL(PL.FIN_HEDGE_MARGIN,'N') BULK COLLECT INTO vHfLimitId,vHFFlag
            FROM SCBT_T_CUST_SFALL_OFFSET_MST SF,SCBT_R_CUST_PRODUCT_LIMIT PL
            WHERE PL.bank_group_code = bankGroupCode AND PL.cty_code = ctyCode
                      AND PL.CUST_ID  = custId AND SF.deal_step_id  = dealStepID
            AND SF.PAGE_SOURCE  = pageSource
            AND PL.OVERDRAFT_FACILITY_ACCNO IS NOT NULL AND SF.LIMIT_ID = PL.LIMIT_ID
            AND SF.FACILITY_GROUP_ID=v_grp_id;            
               EXCEPTION
               WHEN OTHERS THEN
                  v_hf_acc_bal := 0;                  
         END;
       IF vHfLimitId.COUNT > 0 THEN
           FOR i IN 1 ..vHfLimitId.COUNT LOOP      
               IF(vHFFlag(i) = 'Y') THEN -- Get +ve Net Balance for A/C Linked to Hedge Facility
                  v_hf_acc_bal := v_hf_acc_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, vHfLimitId(i), v_exp_curr_code, 'S'),0);
               ELSE -- Get +ve Net Balance for A/C Linked to OD Facility
                  v_clt_lnk_bal := v_clt_lnk_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, vHfLimitId(i), v_exp_curr_code, 'S'),0);
               END IF;   
           END LOOP;
        END IF;

       --For EFF_NCV_COLL_CAP
      -- SELECT SUM(EFFECTIVE_NCV_AMT)
       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT
               SUM(FACILITY_COLL_CAP_AMT)
             INTO v_eff_ncv_coll_cap
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              AND PAGE_SOURCE          = pageSource;
         ELSE
           SELECT
               SUM(FACILITY_COLL_CAP_AMT)
             INTO v_eff_ncv_coll_cap
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              AND PAGE_SOURCE          = pageSource;
         END IF;

       EXCEPTION
         WHEN OTHERS THEN
                   v_eff_ncv_coll_cap := 0;
       END;



      --For EFF_NCV_COLL_GRP_CAP
       BEGIN
         SELECT COLLATERAL_LIMIT_ID
           INTO  v_coll_limit_id
         FROM (
           SELECT COLLATERAL_LIMIT_ID
              FROM SCBT_R_CUST_COLLAT_LIMIT
            WHERE BANK_GROUP_CODE = bankgroupcode
              AND CTY_CODE     = ctycode
              AND CUST_ID      = custid
              AND PRODUCT_LIMIT_ID = v_grp_id
          ) WHERE ROWNUM=1;
       EXCEPTION
         WHEN OTHERS THEN
            NULL;
            v_coll_limit_id := null;
       END;
       vCollGrpCount := 0;
       IF (v_coll_limit_id IS NOT NULL) THEN
         BEGIN 
         
         SELECT count(1) INTO vCollGrpCount
                    FROM SCBT_R_CUST_COL_GRP_LIMIT g
                    WHERE BANK_GROUP_CODE = bankgroupcode
                    AND CTY_CODE     = ctycode
                    AND CUST_ID      = custid
                    AND v_coll_limit_id IN (SELECT * FROM TABLE(SPLIT(COLLATERAL_LIMIT_ID)));
                    
        IF (vCollGrpCount>0) THEN
                  SELECT
                      Scbf_Tls_Exch_Rate(bank_group_code,
                                 cty_code,           -- COUNTRY CODE
                                   limit_ccy_code,         -- FROM CURR CODE
                                 LIMIT_CCY_ACTIVE_AMT,            -- FROM AMOUNT
                                   v_exp_curr_code,            -- TO CURR CODE
                                 'Y')

                      INTO v_eff_ncv_coll_grp_cap
                    FROM SCBT_R_CUST_COL_GRP_LIMIT g
                  WHERE BANK_GROUP_CODE = bankgroupcode
                    AND CTY_CODE     = ctycode
                    AND CUST_ID      = custid
                    AND v_coll_limit_id IN (SELECT * FROM TABLE(SPLIT(COLLATERAL_LIMIT_ID)));
        ELSE
          v_eff_ncv_coll_grp_cap := null;
        END IF;        
        Exception
           WHEN OTHERS THEN
             NULL;
             v_eff_ncv_coll_grp_cap := null;
         END;
       ELSE
          v_eff_ncv_coll_grp_cap := null;
       END IF;

        BEGIN
           INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                  BANK_GROUP_CODE
                  , CTY_CODE
                  , CUST_ID
                  , OVERALL_EXP_CCY_CODE
                  , FACILITY_GROUP_NAME
                  , CLIENT_GROUP_INDICATOR
                  , LIMIT_CLASSIFICATION
                  , LIMIT_ID
                  , FACILITY_EXPOSURE_CCY
                  , FACILITY_EXPOSURE_AMT
                  , FACILITY_NCV_CCY
                  , FACILITY_NCV_AMT
                  , FACILITY_CMR_CCY
                  , FACILITY_CMR_AMT
                  , CASH_FOR_EXP_OFFSET_CCY
                  , CASH_FOR_EXP_OFFSET_AMT
                  , LINKED_ACCOUNT_CCY
                  , LINKED_ACCOUNT_BALANCE
                  , SECURED_CMR_CCY
                  , SECURED_CMR_AMT
                  , UNSECURED_CMR_CCY
                  , UNSECURED_CMR_AMT
                  , DEAL_STEP_ID
                  , EFF_NCV_COLL_CAP
                  , EFF_NCV_COLL_GRP_CAP
                  , HF_ACC_BALANCE
                  , PAGE_SOURCE
                  , EXPIRY_DATE )
              VALUES ( bankGroupCode
                  , ctyCode
                  , custId
                  , v_exp_curr_code
                  , v_fac_grp_name
                  , v_clt_grp_indicator
                  , v_limit_class
                  , NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))    --NVL(v_grp_id,'CSCU')
                  , v_exp_curr_code --v_lmt_ccy_code
                  , v_facility_exposure_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_ncv_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_cmr_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_cash_for_exp_offset_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_grp_lnk_bal , v_clt_lnk_bal)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_secured_cmr_amt, 0)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_unsecured_cmr_amt, 0)
                  , dealStepID
                  , least(v_eff_ncv_coll_cap, v_coll_ncv_amt) -- v_eff_ncv_coll_cap
                  , least(nvl(v_eff_ncv_coll_grp_cap, v_group_facility_ncv_amt), v_group_facility_ncv_amt) -- v_eff_ncv_coll_grp_cap
                  , v_hf_acc_bal
                  , pageSource
                  , v_expiry_date
                );

         EXCEPTION
             WHEN OTHERS THEN
                NULL;
            dbms_output.put_line('SQLERRM:'||'DTL'|| SQLERRM);    
         END;
       END LOOP;
       
       
       
   IF(ctycode='US' and pageSource='DDB') THEN    
   
   
   BEGIN
   
     BEGIN
     
     SELECT DISTINCT PROD_LIMIT_ID INTO v_cbb_limit_id 
     FROM SCBT_T_TXN_HST 
     WHERE BANK_GROUP_CODE = bankGroupCode
           AND CTY_CODE        = ctyCode
           AND CUST_ID         = custId
           AND SHORTFALL_OFFSET_TYPE ='CBB'
           AND DEAL_STEP_ID    = dealStepID; 
     
     END;
   
     SELECT COUNT(*) INTO v_co_borr_cnt
     FROM SCBT_R_CUST_PRODUCT_LIMIT 
     WHERE  BANK_GROUP_CODE = bankGroupCode
            AND CTY_CODE        = ctyCode
            AND CUST_ID         = custId
            AND LIMIT_ID        = v_cbb_limit_id
            AND CO_BORROWER_ID IS NOT NULL;
     
     EXCEPTION
      WHEN OTHERS THEN
      NULL;
       
     END;   
   
 --  IF(v_co_borr_cnt > 0) THEN
   
     BEGIN
          v_grp_id := 'SC';
          v_clt_grp_indicator :='CBB';
   
          SELECT SUM(FACILITY_EXPOSURE_AMT)
                 , SUM(FACILITY_NCV_AMT)
                 , SUM(FACILITY_CMR_AMT)
                 , SUM(CASH_FOR_EXP_OFFSET_AMT)
              INTO v_facility_exposure_amt
                 , v_facility_ncv_amt
                 , v_facility_cmr_amt
                 , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND DEAL_STEP_ID    = dealStepID
              AND FACILITY_GROUP_NAME    = 'Client Borrowing Base'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
       
       EXCEPTION
           WHEN OTHERS THEN
           v_facility_exposure_amt := 0;
           v_facility_ncv_amt := 0;
           v_facility_cmr_amt := 0;
           v_cash_for_exp_offset_amt := 0;
       END;
   
                         BEGIN
                            SELECT COUNT(1) into v_is_syndicate_coll
                                FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                            WHERE map_id = 'TXNISSUVAL'
                                AND code_value_1 = 'CONT_PROD'
                                AND m.code_value_2 = p.limit_product_code
                                AND p.cust_id = custId
                                AND p.limit_id = v_cbb_limit_id
                                AND p.bank_group_code = bankGroupCode
                                AND p.cty_code = ctyCode;
                         EXCEPTION
                         WHEN OTHERS THEN
                            v_is_syndicate_coll := 0;
                       END;
                       
                       IF v_is_syndicate_coll > 0 THEN
                             v_product_type := 'CON';
                       ELSE
                             v_product_type := 'ASS';
                       END IF;
   
                    
                       BEGIN
                          select PARAM_DATA_07 INTO v_syndicate_data
                            FROM SCBT_R_PARAM_DATA
                             WHERE param_id = 'TP10'
                             AND PARAM_KEY_01 = (
                            select DISTINCT SCB_ROLE
                                FROM SCBT_T_TXN_HST
                            WHERE BANK_GROUP_CODE=bankGroupCode
                                  AND CTY_CODE=ctyCode
                                  AND CUST_ID=custId
                                  --AND DEAL_STEP_ID= dealStepID
                                  AND PROD_LIMIT_ID=v_cbb_limit_id
                                  ) and PARAM_KEY_02 = v_product_type;
                         EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                       END;
                       
                       
                  BEGIN
                      SELECT distinct PL.CO_BORROWER_ID
                            INTO v_temp_co_borrower_id
                      FROM SCBT_R_CUST_PRODUCT_LIMIT PL
                      WHERE PL.BANK_GROUP_CODE = bankGroupCode
                               AND PL.CTY_CODE = ctycode
                               AND PL.CUST_ID = custId
                               AND PL.LIMIT_ID = v_cbb_limit_id;
                 EXCEPTION
                 WHEN OTHERS THEN
                      v_temp_co_borrower_id := '';
                      dbms_output.put_line('SQLERRM:'|| SQLERRM);
                 END; 
                        
                 BEGIN  
                   SELECT NVL(SEP_BB_CERT_FLAG,'N') into sep_bb_cert_flag
                    FROM SCBT_R_CUST_LIMIT_MST
                   WHERE bank_group_code  = bankGroupCode
                     AND cty_code         = ctyCode
                     AND cust_id          = custId;  
                 END;                        
     
        
                   IF v_temp_co_borrower_id =custId OR sep_bb_cert_flag='N' THEN
                    v_temp_co_borrower_id := null;
                   ELSE
                    v_temp_co_borrower_id := v_temp_co_borrower_id;
                   END IF;
                                              
                        BEGIN
                       
                            select      decode(nvl(v_syndicate_data, 'NCV'),
                                                    'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                                                    , Scbf_Tls_Exch_Rate(
                                                              bbcMst.BANK_GROUP_CODE
                                                                  , bbcMst.CTY_CODE           -- COUNTRY CODE
                                                                    , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                                                  , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                                                    , v_exp_curr_code            -- TO CURR CODE
                                                                  , 'Y')
                                                             ,bbcMst.expiry_date
                                                    INTO v_appl_dp_ccy_code
                                                    , v_tot_dp_app_amt
                                                    ,v_expiry_date 
                                                   FROM SCBT_R_BBC_DTLS_MST bbcMst,
                                                   SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                                                   where bbcMst.BANK_GROUP_CODE=bbcGen.Bank_Group_Code
                                                   AND bbcMst.CTY_CODE=bbcGen.Cty_Code
                                                   AND bbcMst.Active_Bbc_Flag= 'Y'
                                                   AND bbcGen.Bank_Group_Code = bankgroupcode
                                                   AND bbcGen.Cty_Code = ctycode
                                                   AND bbcGen.Cust_Id = custid
                                                   AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                                                   AND bbcGen.Co_Borrower_Id = nvl(v_temp_co_borrower_id, '*');
                            EXCEPTION
                            WHEN OTHERS THEN
                                 v_appl_dp_ccy_code := '';
                                 v_tot_dp_app_amt := 0;
                         END;
               
   
   
               v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode
                                                              , ctyCode
                                                              , v_exp_curr_code --v_lmt_ccy_code,
                                                              , custId)
                                                              , 0);
   
   
                 BEGIN
                      SELECT distinct PL.CO_BORROWER_ID
                            INTO v_temp_co_borrower_id
                      FROM SCBT_R_CUST_PRODUCT_LIMIT PL
                      WHERE PL.BANK_GROUP_CODE = bankGroupCode
                               AND PL.CTY_CODE = ctycode
                               AND PL.CUST_ID = custId
                               AND PL.LIMIT_ID = v_cbb_limit_id;
                 EXCEPTION
                 WHEN OTHERS THEN
                      v_temp_co_borrower_id := '';
                      dbms_output.put_line('SQLERRM:'|| SQLERRM);
                 END; 
   
       
     BEGIN
           INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                  BANK_GROUP_CODE
                  , CTY_CODE
                  , CUST_ID
                  , OVERALL_EXP_CCY_CODE
                  , FACILITY_GROUP_NAME
                  , CLIENT_GROUP_INDICATOR
                  , LIMIT_CLASSIFICATION
                  , LIMIT_ID
                  , FACILITY_EXPOSURE_CCY
                  , FACILITY_EXPOSURE_AMT
                  , FACILITY_NCV_CCY
                  , FACILITY_NCV_AMT
                  , FACILITY_CMR_CCY
                  , FACILITY_CMR_AMT
                  , CASH_FOR_EXP_OFFSET_CCY
                  , CASH_FOR_EXP_OFFSET_AMT
                  , LINKED_ACCOUNT_CCY
                  , LINKED_ACCOUNT_BALANCE
                  , SECURED_CMR_CCY
                  , SECURED_CMR_AMT
                  , UNSECURED_CMR_CCY
                  , UNSECURED_CMR_AMT
                  , DEAL_STEP_ID
                  , EFF_NCV_COLL_CAP
                  , EFF_NCV_COLL_GRP_CAP
                  , HF_ACC_BALANCE
                  , APPLICABLE_DP_CCY
                  , APPLICABLE_DP_AMT
                  , CUST_CO_BORROWER_ID
                  , PAGE_SOURCE
                  , EXPIRY_DATE )
              VALUES ( bankGroupCode
                  , ctyCode
                  , custId
                  , v_exp_curr_code
                  , v_fac_grp_name
                  , v_clt_grp_indicator
                  , v_limit_class
                  , NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))    --NVL(v_grp_id,'CSCU')
                  , v_exp_curr_code --v_lmt_ccy_code
                  , v_facility_exposure_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_ncv_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_cmr_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_cash_for_exp_offset_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_grp_lnk_bal , v_clt_lnk_bal)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_secured_cmr_amt, 0)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_unsecured_cmr_amt, 0)
                  , dealStepID
                  , least(v_eff_ncv_coll_cap, v_coll_ncv_amt) -- v_eff_ncv_coll_cap
                  , least(nvl(v_eff_ncv_coll_grp_cap, v_group_facility_ncv_amt), v_group_facility_ncv_amt) -- v_eff_ncv_coll_grp_cap
                  , v_hf_acc_bal
                  , v_appl_dp_ccy_code
                  , v_tot_dp_app_amt
                  , nvl(v_temp_co_borrower_id,custId)
                  , pageSource
                  , v_expiry_date
                );

         EXCEPTION
             WHEN OTHERS THEN
                NULL;
            dbms_output.put_line('SQLERRM:'||'DTL'|| SQLERRM);    
         END;
   --   END IF;  
    END IF;
      -- TODO:TEMP CODE : Need to Remove in Next Release      
     -- UPDATE SCBT_T_CUST_GRP_CLT_OFFSET_MST SET LINKED_ACCOUNT_BALANCE = (SELECT SUM(LINKED_ACCOUNT_BALANCE) FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
       -- WHERE cust_id = custId AND page_source = pageSource AND limit_id IN ('CS','CU')  and deal_step_id = dealStepID)
     -- WHERE cust_id = custId AND page_source = pageSource AND limit_id IN ('CS','CU')  and deal_step_id = dealStepID;

  
      COMMIT;
  END SCBP_P_GET_DTL_EXP_AMT;

/*---------------------------------------------------------------------------------------------------------------------------*/
PROCEDURE SCBP_P_GET_CLIENT_DTL_EXP_AMT(p_ret_code    IN OUT VARCHAR2,
                                   bankGroupCode IN VARCHAR2,
                                   ctyCode       IN VARCHAR2,
                                   custId        IN VARCHAR2,
                                   dealStepID    IN VARCHAR2,
                                   limitId       IN VARCHAR2,
                                   pageSource    IN VARCHAR2) IS

  v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
  v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
  v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
  v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
  v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
  v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
  v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
  v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
  v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
  v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
  v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
  v_temp_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_coll_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_hf_facility                        SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE;
  v_hf_acc_no                          SCBT_R_CUST_PRODUCT_LIMIT.OVERDRAFT_FACILITY_ACCNO%TYPE;
  v_hf_acc_bal                SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
  v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
  v_coll_limit_req_ncv_amt    SCBT_T_Coll_LIMIT_REQ_LOG_DTL.Txn_Ccy_Amt%TYPE;
  v_group_facility_ncv_amt    SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_client_limit_class        SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_over_curr_lmt_ccy_active_amt SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
  v_effective_ncv_amt         SCBT_T_COLL_SFALL_DETAIL_MST.Effective_Ncv_Amt%TYPE;
  v_coll_limit_id             SCBT_R_CUST_COLLAT_LIMIT.Collateral_Limit_Id%TYPE;
 -- v_hf_facility                        SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE;
 -- v_hf_acc_no                          SCBT_R_CUST_PRODUCT_LIMIT.OVERDRAFT_FACILITY_ACCNO%TYPE;
 -- v_hf_acc_bal                SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  vCollGrpCount number(10);
  vClientBalGetCount number(2);
  
  TYPE vHfLimitType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE vHFFlagType  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE INDEX BY PLS_INTEGER;
  
  vHfLimitId         vHfLimitType;
  vHFFlag            vHFFlagType; 

  CURSOR client_coll IS
  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
       AND shortfall_offset     = 'CUL';
     --AND LIMIT_CLASSIFICATION = v_client_limit_class;
     --AND LIMIT_ID = limitId;
--GROUP BY LIMIT_CLASSIFICATION, LIMIT_ID;

  CURSOR coll_limit IS
  SELECT COLLATERAL_LIMIT_ID, PRODUCT_LIMIT_ID, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT
     , COLLATERAL_TYPE_CODE
     , COLLATERAL_LIMIT_NAME
    FROM SCBT_R_CUST_COLLAT_LIMIT
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId
     AND PRODUCT_LIMIT_ID in ('CS', 'CU');


  CURSOR group_client_coll IS
  SELECT DISTINCT FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION
    FROM SCBT_T_CUST_SFALL_OFFSET_MST c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
     AND deal_step_id         = NVL(dealStepID,deal_step_id)
     AND PAGE_SOURCE          = pageSource
       AND shortfall_offset     = 'CUL'
     GROUP BY FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION;


  BEGIN

         p_ret_code := '0000';
       v_grp_id   := 0;

       v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);


          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    --AND DEAL_STEP_ID = dealStepID
                    --AND FACILITY_GROUP_ID=v_grp_id
                    AND PAGE_SOURCE = pageSource
                    AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND DEAL_STEP_ID = dealStepID
                    AND PAGE_SOURCE = pageSource
                    AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          END IF;


         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */

       v_grp_id          := NULL;

       FOR clt IN client_coll LOOP
           IF clt.limit_classification = 'SC' THEN
              v_fac_grp_name := 'Secured Client';
              v_grp_id := 'CS';
           ELSE
              v_fac_grp_name := 'UnSecured Client';
              v_grp_id := 'CU';
           END IF;

           SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                  ctyCode,
                  custId,
                  clt.limit_id,
                  v_exp_curr_code,
                  dealStepID,
                  v_fac_grp_name,
                  v_grp_id,
                  pageSource);
       END LOOP;


       /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */

       v_grp_lnk_bal := NULL;
       v_grp_id      := NULL;

/*       v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(
                                         bankGroupCode,
                                         ctyCode,
                                         v_exp_curr_code,
                                         custId)
                                         ,0);*/

       v_clt_grp_indicator    := 'CLIENT';




       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              --AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'SEC';
              AND FACILITY_GROUP_ID = 'CS'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'SEC';
              AND FACILITY_GROUP_ID = 'CS'
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;
       EXCEPTION
          WHEN OTHERS THEN
                  v_secured_cmr_amt:=0;
       END;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              --AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'UNS';
              AND FACILITY_GROUP_ID    = 'CU'
              AND PAGE_SOURCE          = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              --AND LIMIT_CLASSIFICATION = 'UNS';
              AND FACILITY_GROUP_ID    = 'CU'
              AND PAGE_SOURCE          = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;

       EXCEPTION
         WHEN OTHERS THEN
                    v_unsecured_cmr_amt := 0;
       END;


       v_temp_ncv_amt            := 0;
         v_coll_ncv_amt            := 0;


          BEGIN
              IF pageSource = 'CDB' THEN
                 delete from SCBT_T_COLL_SFALL_DETAIL_MST
                    where BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                     -- AND DEAL_STEP_ID = dealstepid
                      AND PAGE_SOURCE = pageSource;
                   -- AND FACILITY_NAME = v_fac_grp_name
                   -- AND COLLATERAL_TYPE = lmt.Collateral_Type_Code;
              ELSE
                 delete from SCBT_T_COLL_SFALL_DETAIL_MST
                    where BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID = dealstepid
                      AND PAGE_SOURCE = pageSource;
                   -- AND FACILITY_NAME = v_fac_grp_name
                   -- AND COLLATERAL_TYPE = lmt.Collateral_Type_Code;

              END IF;



            EXCEPTION
                WHEN OTHERS THEN
                  NULL;
          END;


         FOR lmt IN coll_limit LOOP

               FOR c1 IN (SELECT * FROM TABLE(SPLIT(lmt.product_limit_id))) LOOP

                     IF (c1.COLUMN_VALUE in ('CS', 'CU')) THEN

                          IF c1.COLUMN_VALUE = 'CS' THEN
                     v_fac_grp_name := 'Secured Client';
                      v_grp_id := 'CS';
                  ELSIF c1.COLUMN_VALUE = 'CU' THEN
                     v_fac_grp_name := 'UnSecured Client';
                      v_grp_id := 'CU';
                  END IF;
                  --To calculate NCV amount at group level
                      BEGIN
                         SELECT NVL(sum(Scbf_Tls_Exch_Rate(r.bank_group_code,
                                      r.cty_code,           -- COUNTRY CODE
                                        d.ncv_txn_ccy_code, --d.txn_ccy_code,         -- FROM CURR CODE
                                      d.ncv_txn_ccy_amt, --d.txn_ccy_amt,            -- FROM AMOUNT
                                        v_exp_curr_code, --'USD',            -- TO CURR CODE
                                      'Y')), 0)
                                INTO v_coll_limit_req_ncv_amt
                           FROM SCBT_T_coll_LIMIT_REQ_LOG R,
                                  SCBT_T_Coll_LIMIT_REQ_LOG_DTL D
                          WHERE R.BANK_GROUP_CODE  = bankGroupCode
                            AND R.CTY_CODE         = ctyCode
                            AND R.REQ_TYPE_CODE    = 'NEW'
                            AND R.REQ_STATUS_CODE  in ('PEND','CON')
                            AND R.INIT_REQ_ID     = D.INIT_REQ_ID
                            AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
                            AND R.CTY_CODE        = D.CTY_CODE
                            AND D.COLLATERAL_LIMIT_ID =  lmt.collateral_limit_id;
                      EXCEPTION
                          WHEN OTHERS THEN
                            v_coll_limit_req_ncv_amt := 0;
                      END;




                  IF lmt.limit_ccy_code <> v_exp_curr_code THEN

                     v_temp_ncv_amt := NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                  ctyCode,           -- COUNTRY CODE
                                                                    lmt.limit_ccy_code, -- FROM CURR CODE
                                                                  lmt.limit_ccy_active_amt, -- FROM AMOUNT
                                                                     v_exp_curr_code,        -- TO CURR CODE
                                                                  'Y'),0);           -- ROUNG FLAG

                     IF v_temp_ncv_amt > v_coll_limit_req_ncv_amt THEN
                                     v_coll_ncv_amt     := v_coll_ncv_amt + v_coll_limit_req_ncv_amt;
                             ELSE
                        v_coll_ncv_amt     := v_coll_ncv_amt + v_temp_ncv_amt;
                               END IF;

                          ELSE
                     IF lmt.limit_ccy_active_amt > v_coll_limit_req_ncv_amt THEN
                                     v_coll_ncv_amt     := v_coll_ncv_amt + v_coll_limit_req_ncv_amt;
                             ELSE
                        v_coll_ncv_amt     := v_coll_ncv_amt + lmt.limit_ccy_active_amt;
                               END IF;
                          END IF;

                   --Insert data in SCBT_T_COLL_SFALL_DETAIL_MST START
                  -- IF v_sfall_off IS NOT NULL AND v_sfall_off != 'GBB' THEN

                      --To delete existing data from SCBT_T_COLL_SFALL_DETAIL_MST table



                      BEGIN
                              v_over_curr_lmt_ccy_active_amt := NVL(Scbf_Tls_Exch_Rate(bankGroupCode,     -- BANK GROUP CODE
                                                                  ctyCode,           -- COUNTRY CODE
                                                                    lmt.limit_ccy_code, -- FROM CURR CODE
                                                                  lmt.limit_ccy_active_amt, -- FROM AMOUNT
                                                                     v_exp_curr_code,        -- TO CURR CODE
                                                                  'Y'),0);           -- ROUNG FLAG
                      EXCEPTION
                         WHEN OTHERS THEN
                            v_over_curr_lmt_ccy_active_amt :=0;
                      END;


                      BEGIN
                           --To insert shortfall details from SCBT_T_COLL_SFALL_DETAIL_MST table
                           INSERT INTO SCBT_T_COLL_SFALL_DETAIL_MST (
                                  BANK_GROUP_CODE
                                , CTY_CODE
                                , CUST_ID
                                , FACILITY_NAME
                                , COLLATERAL_TYPE
                                , FACILITY_NCV_CCY
                                , FACILITY_NCV_AMT
                                , FACILITY_COLL_CAP_AMT
                                , EFFECTIVE_NCV_AMT
                                , DEAL_STEP_ID
                                , COLLATERAL_LIMIT_ID
                                , COLLATERAL_LIMIT_NAME
                                , PAGE_SOURCE )
                           VALUES (
                                  bankGroupCode
                                , ctyCode
                                , custId
                                , v_fac_grp_name
                                , lmt.Collateral_Type_Code
                                ,  v_exp_curr_code  --v_lmt_ccy_code
                                , NVL(v_coll_limit_req_ncv_amt, 0)
                                , nvl( v_over_curr_lmt_ccy_active_amt, 0)
                                , least(nvl(v_coll_limit_req_ncv_amt, 0), nvl( v_over_curr_lmt_ccy_active_amt, 0))
                                , dealstepid
                                , lmt.collateral_limit_id
                                , lmt.collateral_limit_name
                                , pageSource
                           );

                      EXCEPTION
                          WHEN OTHERS THEN
                            NULL;
                          END;
                          -- v_coll_ncv_amt :=0;
                         -- COMMIT;

                     END IF;

               END LOOP;

         END LOOP;

/*
      BEGIN
          IF pageSource = 'DDB' THEN
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE bank_group_code = bankGroupCode
                AND cty_code        = ctyCode
                AND cust_id         = custId
                AND deal_step_id    = dealStepID
                AND PAGE_SOURCE  = pageSource;
          END IF;
       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;
*/

       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    --AND DEAL_STEP_ID = dealStepID
                    AND LIMIT_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                    AND PAGE_SOURCE = pageSource
                    AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE bank_group_code = bankGroupCode
                AND cty_code        = ctyCode
                AND cust_id         = custId
                AND deal_step_id    = dealStepID
                AND PAGE_SOURCE     = pageSource
                AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          END IF;

       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;

      vClientBalGetCount := 0;
      FOR group_coll IN group_client_coll LOOP
         v_clt_lnk_bal   := 0;
         v_hf_acc_bal := 0;      
         select decode(group_coll.limit_classification, 'SC', 'CS', 'USC', 'CU', group_coll.limit_classification)
         INTO v_grp_id from dual;

        -- To get the Client Level Cash Balance only once at Secured Group, in Client Page, it will total of SC 
        IF vClientBalGetCount = 0 THEN 
           v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(
                                             bankGroupCode,
                                             ctyCode,
                                             v_exp_curr_code,
                                             custId)
                                             ,0);
           vClientBalGetCount := 1;                                  
        END IF;

       --To calculate HF ACCOUNT BALANCE
       BEGIN         
            SELECT SF.LIMIT_ID,NVL(PL.FIN_HEDGE_MARGIN,'N') BULK COLLECT INTO vHfLimitId,vHFFlag
            FROM SCBT_T_CUST_SFALL_OFFSET_MST SF,SCBT_R_CUST_PRODUCT_LIMIT PL
            WHERE PL.bank_group_code = bankGroupCode AND PL.cty_code = ctyCode
                      AND PL.CUST_ID  = custId AND SF.deal_step_id  = dealStepID
            AND SF.PAGE_SOURCE  = pageSource
            AND PL.OVERDRAFT_FACILITY_ACCNO IS NOT NULL AND SF.LIMIT_ID = PL.LIMIT_ID
            AND SF.FACILITY_GROUP_ID=v_grp_id;            
               EXCEPTION
               WHEN OTHERS THEN
                  v_hf_acc_bal := 0;                  
         END;

        IF vHfLimitId.COUNT > 0 THEN
           FOR i IN 1 ..vHfLimitId.COUNT LOOP      
               IF(vHFFlag(i) = 'Y') THEN -- Get +ve Net Balance for A/C Linked to Hedge Facility
                  v_hf_acc_bal := v_hf_acc_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, vHfLimitId(i), v_exp_curr_code, 'S'),0);
               ELSE -- Get +ve Net Balance for A/C Linked to OD Facility
                  v_clt_lnk_bal := v_clt_lnk_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, vHfLimitId(i), v_exp_curr_code, 'S'),0);
               END IF;   
           END LOOP;
        END IF; 


       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_EXPOSURE_AMT)
                 , SUM(FACILITY_NCV_AMT)
                 , SUM(FACILITY_CMR_AMT)
                 , SUM(CASH_FOR_EXP_OFFSET_AMT)
              INTO v_facility_exposure_amt
                 , v_facility_ncv_amt
                 , v_facility_cmr_amt
                 , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              --AND DEAL_STEP_ID    = dealStepID
              AND FACILITY_GROUP_NAME = group_coll.facility_group_name
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_EXPOSURE_AMT)
                 , SUM(FACILITY_NCV_AMT)
                 , SUM(FACILITY_CMR_AMT)
                 , SUM(CASH_FOR_EXP_OFFSET_AMT)
              INTO v_facility_exposure_amt
                 , v_facility_ncv_amt
                 , v_facility_cmr_amt
                 , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND DEAL_STEP_ID    = dealStepID
              AND FACILITY_GROUP_NAME = group_coll.facility_group_name
              AND PAGE_SOURCE     = pageSource
              AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
         END IF;
           EXCEPTION
               WHEN OTHERS THEN
               v_facility_exposure_amt := 0;
               v_facility_ncv_amt := 0;
               v_facility_cmr_amt := 0;
               v_cash_for_exp_offset_amt := 0;
           END;



      --For EFF_NCV_COLL_CAP
      -- SELECT SUM(EFFECTIVE_NCV_AMT)
       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_COLL_CAP_AMT)
                  , SUM(EFFECTIVE_NCV_AMT)
             INTO v_eff_ncv_coll_cap
                , v_effective_ncv_amt
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              --AND DEAL_STEP_ID            = dealstepid
              AND FACILITY_NAME        = group_coll.facility_group_name
              AND PAGE_SOURCE     = pageSource;
         ELSE
           SELECT SUM(FACILITY_COLL_CAP_AMT)
                  , SUM(EFFECTIVE_NCV_AMT)
             INTO v_eff_ncv_coll_cap
                , v_effective_ncv_amt
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              AND FACILITY_NAME        = group_coll.facility_group_name
              AND PAGE_SOURCE     = pageSource;
         END IF;


       EXCEPTION
         WHEN OTHERS THEN
                   v_eff_ncv_coll_cap := 0;
       END;

       BEGIN
          IF pageSource = 'CDB' THEN
            SELECT SUM(FACILITY_NCV_AMT)
               INTO v_group_facility_ncv_amt
               FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE        = ctyCode
               AND CUST_ID         = custId
               --AND DEAL_STEP_ID    = dealStepID
               AND FACILITY_GROUP_ID = v_grp_id
               AND PAGE_SOURCE     = pageSource
               AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          ELSE
            SELECT SUM(FACILITY_NCV_AMT)
               INTO v_group_facility_ncv_amt
               FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE        = ctyCode
               AND CUST_ID         = custId
               AND DEAL_STEP_ID    = dealStepID
               AND FACILITY_GROUP_ID = v_grp_id
               AND PAGE_SOURCE     = pageSource
               AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          END IF;

       EXCEPTION
          WHEN OTHERS THEN
              v_group_facility_ncv_amt := 0;
       END;

       --For EFF_NCV_COLL_GRP_CAP
       BEGIN
         SELECT COLLATERAL_LIMIT_ID
           INTO  v_coll_limit_id
         FROM (
           SELECT COLLATERAL_LIMIT_ID
              FROM SCBT_R_CUST_COLLAT_LIMIT
            WHERE BANK_GROUP_CODE = bankgroupcode
              AND CTY_CODE     = ctycode
              AND CUST_ID      = custid
              AND PRODUCT_LIMIT_ID = v_grp_id
          ) WHERE ROWNUM=1;
       EXCEPTION
         WHEN OTHERS THEN
            NULL;
            v_coll_limit_id := null;
       END;
       vCollGrpCount := 0;
       IF (v_coll_limit_id IS NOT NULL) THEN
         BEGIN         
              SELECT  count(1) INTO vCollGrpCount
                    FROM SCBT_R_CUST_COL_GRP_LIMIT g
                    WHERE BANK_GROUP_CODE = bankgroupcode
                    AND CTY_CODE     = ctycode
                    AND CUST_ID      = custid
                    AND v_coll_limit_id IN (SELECT * FROM TABLE(SPLIT(COLLATERAL_LIMIT_ID)));
                    
           IF (vCollGrpCount>0) THEN         
                  SELECT
                      Scbf_Tls_Exch_Rate(bank_group_code,
                                 cty_code,           -- COUNTRY CODE
                                   limit_ccy_code,         -- FROM CURR CODE
                                 LIMIT_CCY_ACTIVE_AMT,            -- FROM AMOUNT
                                   v_exp_curr_code,            -- TO CURR CODE
                                 'Y')

                      INTO v_eff_ncv_coll_grp_cap
                    FROM SCBT_R_CUST_COL_GRP_LIMIT g
                  WHERE BANK_GROUP_CODE = bankgroupcode
                    AND CTY_CODE     = ctycode
                    AND CUST_ID      = custid
                    AND v_coll_limit_id IN (SELECT * FROM TABLE(SPLIT(COLLATERAL_LIMIT_ID)));
           ELSE
              v_eff_ncv_coll_grp_cap := null;
           END IF;  
        Exception
           WHEN OTHERS THEN
             NULL;
             v_eff_ncv_coll_grp_cap := null;
         END;
       ELSE
          v_eff_ncv_coll_grp_cap := null;
       END IF;


      BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE bank_group_code = bankGroupCode
                AND cty_code        = ctyCode
                AND cust_id         = custId
                AND limit_id    = v_grp_id
                AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                AND PAGE_SOURCE  = pageSource
                AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
              WHERE bank_group_code = bankGroupCode
                AND cty_code        = ctyCode
                AND cust_id         = custId
                AND limit_id    = v_grp_id
                AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                AND PAGE_SOURCE  = pageSource
                AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
          END IF;
       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;

       BEGIN
           INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                  BANK_GROUP_CODE
                  , CTY_CODE
                  , CUST_ID
                  , OVERALL_EXP_CCY_CODE
                  , FACILITY_GROUP_NAME
                  , CLIENT_GROUP_INDICATOR
                  , LIMIT_CLASSIFICATION
                  , LIMIT_ID
                  , FACILITY_EXPOSURE_CCY
                  , FACILITY_EXPOSURE_AMT
                  , FACILITY_NCV_CCY
                  , FACILITY_NCV_AMT
                  , FACILITY_CMR_CCY
                  , FACILITY_CMR_AMT
                  , CASH_FOR_EXP_OFFSET_CCY
                  , CASH_FOR_EXP_OFFSET_AMT
                  , LINKED_ACCOUNT_CCY
                  , LINKED_ACCOUNT_BALANCE
                  , SECURED_CMR_CCY
                  , SECURED_CMR_AMT
                  , UNSECURED_CMR_CCY
                  , UNSECURED_CMR_AMT
                  , DEAL_STEP_ID
                  , EFF_NCV_COLL_CAP
                  , EFF_NCV_COLL_GRP_CAP
                  , HF_ACC_BALANCE
                  , PAGE_SOURCE )
              VALUES ( bankGroupCode
                  , ctyCode
                  , custId
                  , v_exp_curr_code
                  , group_coll.facility_group_name
                  , v_clt_grp_indicator
                  , group_coll.limit_classification
                  , v_grp_id --NVL(v_grp_id,decode(group_coll.limit_classification, 'SC', 'CS', 'USC', 'CU'))    --NVL(v_grp_id,'CSCU')
                  , v_exp_curr_code --v_lmt_ccy_code
                  , v_facility_exposure_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_ncv_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_facility_cmr_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , v_cash_for_exp_offset_amt
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_clt_lnk_bal, 0)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_secured_cmr_amt, 0)
                  , v_exp_curr_code  --v_lmt_ccy_code
                  , NVL(v_unsecured_cmr_amt, 0)
                  , dealStepID
                  , least(v_eff_ncv_coll_cap, v_effective_ncv_amt) -- v_eff_ncv_coll_cap
                  , least(nvl(v_eff_ncv_coll_grp_cap, v_group_facility_ncv_amt), v_group_facility_ncv_amt) -- v_eff_ncv_coll_grp_cap
                  , v_hf_acc_bal
                  , pageSource
                );

           EXCEPTION
               WHEN OTHERS THEN
                  NULL;
           END;

      END LOOP;

      --TODO : Need to Remove in next release
     -- UPDATE SCBT_T_CUST_GRP_CLT_OFFSET_MST SET LINKED_ACCOUNT_BALANCE = (SELECT SUM(LINKED_ACCOUNT_BALANCE) FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
       -- WHERE cust_id = custId AND page_source = pageSource AND limit_id IN ('CS','CU') and deal_step_id = dealStepID)
     -- WHERE cust_id = custId AND page_source = pageSource AND limit_id IN ('CS','CU')  and deal_step_id = dealStepID;

      COMMIT;
  END SCBP_P_GET_CLIENT_DTL_EXP_AMT;

PROCEDURE SCBP_P_GET_MISCLNS_DTL_EXP_AMT(p_ret_code    IN OUT VARCHAR2,
                                   bankGroupCode IN VARCHAR2,
                                   ctyCode       IN VARCHAR2,
                                   custId        IN VARCHAR2,
                                   dealStepID    IN VARCHAR2,
                                   limitId       IN VARCHAR2,
                                   pageSource    IN VARCHAR2) IS

  v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
  v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
  v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
  v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
  v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
  v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
  v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
  v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
  v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
  v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
  v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
  v_temp_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_coll_ncv_amt                    SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_hf_facility                        SCBT_R_CUST_PRODUCT_LIMIT.FIN_HEDGE_MARGIN%TYPE;
  v_hf_acc_no                          SCBT_R_CUST_PRODUCT_LIMIT.OVERDRAFT_FACILITY_ACCNO%TYPE;
  v_hf_acc_bal                SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CAP_CCY_ACTIVE_AMT%TYPE;
  v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
  v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
  v_coll_limit_req_ncv_amt    SCBT_T_Coll_LIMIT_REQ_LOG_DTL.Txn_Ccy_Amt%TYPE;
  v_group_facility_ncv_amt    SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_client_limit_class        SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_over_curr_lmt_ccy_active_amt SCBT_R_CUST_COLLAT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
  v_coll_limit_id             SCBT_R_CUST_COLLAT_LIMIT.Collateral_Limit_Id%TYPE;
  vClientBalGetCount number(2);

  CURSOR group_coll IS
  SELECT FACILITY_GRP_ID, PROD_LIMIT_IDS, LINKED_ACC_NOS, LIMIT_AMT_CCY
    FROM SCBT_R_CUST_FACILITY_GRP
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId
       AND group_type        = v_grp_type;

  CURSOR client_coll IS
  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
       AND shortfall_offset     = 'CUL';

  CURSOR group_cap_coll IS
  SELECT FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION
    FROM SCBT_T_CUST_SFALL_OFFSET_MST c
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
     AND deal_step_id         = dealStepID
       AND shortfall_offset     = 'GFL'
     GROUP BY FACILITY_GROUP_NAME, LIMIT_CLASSIFICATION;


  CURSOR coll_limit IS
  SELECT COLLATERAL_LIMIT_ID, PRODUCT_LIMIT_ID, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT
     , COLLATERAL_TYPE_CODE
     , COLLATERAL_LIMIT_NAME
    FROM SCBT_R_CUST_COLLAT_LIMIT
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId;

  BEGIN

         p_ret_code := '0000';
       v_grp_id   := 0;
       vClientBalGetCount := 0;     

       v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);

       BEGIN
           SELECT SHORTFALL_OFFSET, LIMIT_CLASSIFICATION, LIMIT_CCY_CODE
             INTO v_shortfall_offset, v_limit_class, v_lmt_ccy_code
             FROM SCBT_R_CUST_PRODUCT_LIMIT
              WHERE bank_group_code = bankGroupCode
                AND cty_code            = ctyCode
                AND cust_id             = custId
                AND limit_id        = limitId;
               EXCEPTION
            WHEN OTHERS THEN
              v_shortfall_offset := '';
              v_limit_class := '';
              v_lmt_ccy_code := '';
        END;

         /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS GROUP FACILITY START */
         IF v_shortfall_offset = 'GFL' THEN

              v_grp_type         := 'COL';

          FOR grp IN group_coll LOOP

                  FOR c1 IN (SELECT * FROM TABLE(SPLIT(grp.prod_limit_ids))) LOOP

                        IF c1.COLUMN_VALUE IS NOT NULL AND c1.COLUMN_VALUE = limitId THEN

                             v_grp_id := grp.facility_grp_id;

                   EXIT;

                END IF;

            END LOOP;

          END LOOP;

       END IF;

         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE GROUP FACILITY */
       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND PAGE_SOURCE = pageSource
                      AND DEAL_STEP_ID IS NULL
                      AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND PAGE_SOURCE = pageSource
                      AND DEAL_STEP_ID = dealStepID
                      AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
       END;


       IF v_shortfall_offset = 'GFL' AND v_grp_id IS NOT NULL THEN
          v_grp_lnk_bal := 0;
          v_hf_acc_bal    := 0;

          BEGIN
            SELECT PROD_LIMIT_IDS, FACLIITY_GRP_NAME, LINKED_ACC_NOS
              INTO v_prod_limit_id, v_fac_grp_name, v_linked_acc_nos
              FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctycode
                AND CUST_ID = custId
                AND FACILITY_GRP_ID = v_grp_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_prod_limit_id := '';
                v_fac_grp_name := '';
                v_linked_acc_nos := '';
          END;
          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_prod_limit_id))) LOOP

              IF c1.COLUMN_VALUE IS NOT NULL THEN

                 SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                            ctyCode,
                                            custId,
                                            c1.column_value,
                                            v_exp_curr_code,
                                            dealStepID,
                                            v_fac_grp_name,
                                            v_grp_id,
                                            pageSource);

                 BEGIN
                   SELECT FIN_HEDGE_MARGIN, OVERDRAFT_FACILITY_ACCNO INTO v_hf_facility, v_hf_acc_no
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                           WHERE bank_group_code = bankGroupCode
                           AND cty_code             = ctyCode
                   AND CUST_ID         = custId
                   AND limit_id            = c1.COLUMN_VALUE;
                           EXCEPTION
                   WHEN OTHERS THEN
                     v_hf_facility := '';
                     v_hf_acc_no := '';
                 END;
                 -- Get +ve Net Balance for A/C Linked to Hedge Facility                 
                         IF v_hf_facility = 'Y' AND v_hf_acc_no IS NOT NULL THEN
                   v_hf_acc_bal := v_hf_acc_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, c1.COLUMN_VALUE, v_exp_curr_code, 'S'),0);
                         ELSE 
                    IF v_hf_acc_no IS NOT NULL THEN -- Get +ve Net Balance for A/C Linked to OD Facility
                        v_grp_lnk_bal := v_grp_lnk_bal + NVL(Scbf_Get_Acc_Balance(bankGroupCode, ctyCode, custId, c1.COLUMN_VALUE, v_exp_curr_code, 'S'),0);
                    END IF;    
                 END IF;

              END IF;

          END LOOP;

          -- Get +ve Net Balance of All Linked Accounts at group level.
          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_linked_acc_nos))) LOOP

              IF c1.column_value IS NOT NULL THEN

                 v_clt_lnk_bal := NULL;

                 v_grp_lnk_bal := v_grp_lnk_bal + SCBF_RET_GROUP_LINK_ACC_BAL(bankGroupCode,
                                                                              ctyCode,
                                                                              v_exp_curr_code,
                                                                              custId,
                                                                              c1.column_value);

              END IF;

          END LOOP;

       END IF;

         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */
       IF v_shortfall_offset = 'CUL' THEN

         SELECT  LIMIT_CLASSIFICATION
            INTO v_client_limit_class
            FROM SCBT_R_CUST_PRODUCT_LIMIT c
            WHERE bank_group_code      = bankGroupCode
             AND cty_code                 = ctyCode
               AND cust_id                  = custId
             AND shortfall_offset = 'CUL'
             AND LIMIT_ID = limitId;
             v_grp_id          := NULL;

          FOR clt IN client_coll LOOP
              IF clt.limit_classification = 'SC' THEN
                 v_fac_grp_name := 'Secured Client';
                 v_grp_id := 'CS';
              ELSE
                 v_fac_grp_name := 'UnSecured Client';
                 v_grp_id := 'CU';
              END IF;

              SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                         ctyCode,
                                         custId,
                                         clt.limit_id,
                                         v_exp_curr_code,
                                         dealStepID,
                                         v_fac_grp_name,
                                         v_grp_id,
                                         pageSource);
          END LOOP;

       END IF;

       /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */
         IF v_shortfall_offset = 'CUL' THEN

          v_grp_lnk_bal := NULL;
          v_grp_id      := NULL;
          IF vClientBalGetCount = 0 THEN 
            v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode
                                                              , ctyCode
                                                              , v_exp_curr_code
                                                              , custId)
                                                              , 0);
            vClientBalGetCount := 1;                                                                   
          END IF;
       END IF;

       IF v_shortfall_offset = 'GFL' THEN
          v_clt_grp_indicator := 'GROUP';
       ELSE
          v_clt_grp_indicator    := 'CLIENT';
       END IF;

       v_facility_exposure_amt := 0;
       v_facility_ncv_amt := 0;
       v_facility_cmr_amt := 0;
       v_cash_for_exp_offset_amt := 0;
       v_secured_cmr_amt:=0;
       v_unsecured_cmr_amt := 0;
       v_temp_ncv_amt            := 0;
         v_coll_ncv_amt            := 0;


          BEGIN
               IF pageSource = 'CDB' THEN
                 delete from SCBT_T_COLL_SFALL_DETAIL_MST
                    where BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID IS NULL
                      AND PAGE_SOURCE = pageSource;
               ELSE
                 delete from SCBT_T_COLL_SFALL_DETAIL_MST
                    where BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID = dealstepid
                      AND PAGE_SOURCE = pageSource;
               END IF;

            EXCEPTION
                WHEN OTHERS THEN
                  NULL;
          END;


         FOR lmt IN coll_limit LOOP

               FOR c1 IN (SELECT * FROM TABLE(SPLIT(lmt.product_limit_id))) LOOP

                     IF (c1.COLUMN_VALUE = NVL(v_grp_id, limitid)) OR (v_shortfall_offset ='CUL' AND c1.COLUMN_VALUE in ('CS', 'CU')) THEN

                          IF c1.COLUMN_VALUE = 'CS' THEN
                     v_fac_grp_name := 'Secured Client';
                    -- v_grp_id := 'CS';
                  ELSIF c1.COLUMN_VALUE = 'CU' THEN
                     v_fac_grp_name := 'UnSecured Client';
                    -- v_grp_id := 'CU';
                  END IF;

                  v_coll_ncv_amt := 0;
                  v_temp_ncv_amt := 0;
                  v_coll_limit_req_ncv_amt := 0;
                  v_group_facility_ncv_amt := 0;
                  v_over_curr_lmt_ccy_active_amt :=0;

                      BEGIN
                           --To insert shortfall details from SCBT_T_COLL_SFALL_DETAIL_MST table
                           INSERT INTO SCBT_T_COLL_SFALL_DETAIL_MST (
                                  BANK_GROUP_CODE
                                , CTY_CODE
                                , CUST_ID
                                , FACILITY_NAME
                                , COLLATERAL_TYPE
                                , FACILITY_NCV_CCY
                                , FACILITY_NCV_AMT
                                , FACILITY_COLL_CAP_AMT
                                , EFFECTIVE_NCV_AMT
                                , DEAL_STEP_ID
                                , COLLATERAL_LIMIT_ID
                                , COLLATERAL_LIMIT_NAME
                                , PAGE_SOURCE )
                           VALUES (
                                  bankGroupCode
                                , ctyCode
                                , custId
                                , v_fac_grp_name
                                , lmt.Collateral_Type_Code
                                ,  v_exp_curr_code
                                , NVL(v_coll_limit_req_ncv_amt, 0)
                                , nvl( v_over_curr_lmt_ccy_active_amt, 0)
                                , least(nvl(v_coll_limit_req_ncv_amt, 0), nvl( v_over_curr_lmt_ccy_active_amt, 0))
                                , dealstepid
                                , lmt.collateral_limit_id
                                , lmt.collateral_limit_name
                                , pageSource
                           );

                      EXCEPTION
                          WHEN OTHERS THEN
                            NULL;
                      END;

                     END IF;
               END LOOP;
         END LOOP;


       BEGIN

         IF pageSource = 'CDB' THEN
           DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
            WHERE bank_group_code = bankGroupCode
              AND cty_code        = ctyCode
              AND cust_id         = custId
              AND deal_step_id    IS NULL
              AND PAGE_SOURCE = pageSource
              AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
         ELSE
           DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
            WHERE bank_group_code = bankGroupCode
              AND cty_code        = ctyCode
              AND cust_id         = custId
              AND deal_step_id    = dealStepID
              AND PAGE_SOURCE = pageSource
              AND CLIENT_GROUP_INDICATOR NOT IN ('GBB', 'CBB');
         END IF;
       EXCEPTION
         WHEN OTHERS THEN
           NULL;
       END;

       FOR gcl IN group_cap_coll LOOP

         --To calculate HF ACCOUNT BALANCE
         BEGIN
            SELECT FIN_HEDGE_MARGIN, OVERDRAFT_FACILITY_ACCNO INTO v_hf_facility, v_hf_acc_no
                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                         WHERE bank_group_code = bankGroupCode
                           AND cty_code             = ctyCode
            AND CUST_ID         = custid
                             AND limit_id            = v_grp_id;
               EXCEPTION
               WHEN OTHERS THEN
                  v_hf_facility := '';
                  v_hf_acc_no := '';
         END;

         v_hf_acc_bal := 0;
         v_eff_ncv_coll_cap := 0;

       BEGIN
         SELECT COLLATERAL_LIMIT_ID
           INTO  v_coll_limit_id
         FROM (
           SELECT COLLATERAL_LIMIT_ID
              FROM SCBT_R_CUST_COLLAT_LIMIT
            WHERE BANK_GROUP_CODE = bankgroupcode
              AND CTY_CODE     = ctycode
              AND CUST_ID      = custid
              AND PRODUCT_LIMIT_ID = v_grp_id
          ) WHERE ROWNUM=1;
       EXCEPTION
         WHEN OTHERS THEN
            NULL;
            v_coll_limit_id := null;
       END;

       IF (v_coll_limit_id IS NOT NULL) THEN
         BEGIN
                  SELECT
                      Scbf_Tls_Exch_Rate(bank_group_code,
                                 cty_code,
                                   limit_ccy_code,
                                 LIMIT_CCY_ACTIVE_AMT,
                                   v_exp_curr_code,
                                 'Y')

                      INTO v_eff_ncv_coll_grp_cap
                    FROM SCBT_R_CUST_COL_GRP_LIMIT g
                  WHERE BANK_GROUP_CODE = bankgroupcode
                    AND CTY_CODE     = ctycode
                    AND CUST_ID      = custid
                    AND v_coll_limit_id IN (SELECT * FROM TABLE(SPLIT(COLLATERAL_LIMIT_ID)));
        Exception
           WHEN OTHERS THEN
             NULL;
             v_eff_ncv_coll_grp_cap := null;
         END;
       ELSE
          v_eff_ncv_coll_grp_cap := null;
       END IF;

       BEGIN
           INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                  BANK_GROUP_CODE
                  , CTY_CODE
                  , CUST_ID
                  , OVERALL_EXP_CCY_CODE
                  , FACILITY_GROUP_NAME
                  , CLIENT_GROUP_INDICATOR
                  , LIMIT_CLASSIFICATION
                  , LIMIT_ID
                  , FACILITY_EXPOSURE_CCY
                  , FACILITY_EXPOSURE_AMT
                  , FACILITY_NCV_CCY
                  , FACILITY_NCV_AMT
                  , FACILITY_CMR_CCY
                  , FACILITY_CMR_AMT
                  , CASH_FOR_EXP_OFFSET_CCY
                  , CASH_FOR_EXP_OFFSET_AMT
                  , LINKED_ACCOUNT_CCY
                  , LINKED_ACCOUNT_BALANCE
                  , SECURED_CMR_CCY
                  , SECURED_CMR_AMT
                  , UNSECURED_CMR_CCY
                  , UNSECURED_CMR_AMT
                  , DEAL_STEP_ID
                  , EFF_NCV_COLL_CAP
                  , EFF_NCV_COLL_GRP_CAP
                  , HF_ACC_BALANCE
                  , PAGE_SOURCE )
              VALUES ( bankGroupCode
                  , ctyCode
                  , custId
                  , v_exp_curr_code
                  , v_fac_grp_name
                  , v_clt_grp_indicator
                  , v_limit_class
                  , NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                  , v_exp_curr_code
                  , v_facility_exposure_amt
                  , v_exp_curr_code
                  , v_facility_ncv_amt
                  , v_exp_curr_code
                  , v_facility_cmr_amt
                  , v_exp_curr_code
                  , v_cash_for_exp_offset_amt
                  , v_exp_curr_code
                  , NVL(v_grp_lnk_bal , v_clt_lnk_bal)
                  , v_exp_curr_code
                  , NVL(v_secured_cmr_amt, 0)
                  , v_exp_curr_code
                  , NVL(v_unsecured_cmr_amt, 0)
                  , dealStepID
                  , least(v_eff_ncv_coll_cap, v_coll_ncv_amt)
                  , least(nvl(v_eff_ncv_coll_grp_cap, v_group_facility_ncv_amt), v_group_facility_ncv_amt)
                  , v_hf_acc_bal
                  , pageSource
                );
         EXCEPTION
             WHEN OTHERS THEN
                NULL;
                     -- dbms_output.put_line('SQLERRM:'|| SQLERRM);
               END;
             END LOOP;
             
      COMMIT;
  END SCBP_P_GET_MISCLNS_DTL_EXP_AMT;

/*---------------------------------------------------------------------------------------------------------------------------*/
    PROCEDURE SCBP_P_GET_EXPOSURE_AMT(p_ret_code    IN OUT VARCHAR2,
                                    bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    dealStepID    IN VARCHAR2) IS
   v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
   v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
   v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
   TYPE v_processed_limit_type IS VARRAY(100) OF VARCHAR2(20);
   v_prev_group_id             SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
   v_deal_step_id              SCBT_T_TXN_HST.Deal_Step_Id%TYPE;
   v_client_executed           NUMBER;
         sep_bb_cert_flag            SCBT_R_CUST_LIMIT_MST.SEP_BB_CERT_FLAG%TYPE;

  CURSOR txn_hist IS
        SELECT distinct PROD_LIMIT_ID 
    FROM SCBT_T_TXN_HST
   WHERE bank_group_code  = bankGroupCode
     AND cty_code         = ctyCode
     AND cust_id          = custId
     --AND deal_step_id     = dealStepID;
     AND deal_step_id = v_deal_step_id;

 CURSOR cust_txn_hist IS
  SELECT PROD_LIMIT_ID
    FROM SCBT_T_TXN_HST
   WHERE bank_group_code  = bankGroupCode
     AND cty_code         = ctyCode
     AND cust_id          = custId;
     --AND ;
     --AND deal_step_id     = dealStepID;

  CURSOR cust_txn IS
   SELECT A.GROUP_ID
      , A.LIMIT_ID
      , T.PROD_LIMIT_ID
      , T.LATEST_DEAL_STEP_ID  FROM
    (
    SELECT DISTINCT G.FACILITY_GRP_ID AS GROUP_ID
         , L.LIMIT_ID
         , L.BANK_GROUP_CODE
         , L.CTY_CODE
         , L.CUST_ID
      FROM SCBT_R_CUST_FACILITY_GRP G,SCBT_R_CUST_PRODUCT_LIMIT L
        WHERE L.BANK_GROUP_CODE =  G.BANK_GROUP_CODE
          AND L.CTY_CODE = G.CTY_CODE
          AND L.CUST_ID = G.CUST_ID
          AND L.BANK_GROUP_CODE = bankGroupCode
          AND L.CTY_CODE = ctyCode
          AND L.CUST_ID = custId
          AND G.GROUP_TYPE IN ('BBG','COL')
          AND REGEXP_SUBSTR ( ',' || G.PROD_LIMIT_IDS|| ',' , ',' || L.LIMIT_ID || ',', 1, 1 ) =( ',' || L.LIMIT_ID || ',')          
      UNION ALL
    SELECT
      decode(LIMIT_CLASSIFICATION, 'SC', 'CS', 'USC', 'CU', LIMIT_CLASSIFICATION)  AS GROUP_ID
         , LIMIT_ID
         , BANK_GROUP_CODE
         , CTY_CODE
         , CUST_ID
       FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE BANK_GROUP_CODE =  bankGroupCode
           AND CTY_CODE = ctyCode
           AND CUST_ID = custId
           AND SHORTFALL_OFFSET = 'CUL'
           AND LIMIT_CLASSIFICATION in ('SC', 'USC')
        UNION ALL
      SELECT 'Client BB' AS GROUP_ID
             , LIMIT_ID
         , BANK_GROUP_CODE
         , CTY_CODE
         , CUST_ID
       FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE BANK_GROUP_CODE = bankGroupCode
           AND CTY_CODE = ctyCode
           AND CUST_ID = custId
           AND SHORTFALL_OFFSET = 'CBB'
        -- ORDER BY GROUP_ID DESC
   )   A
     , SCBT_T_TXN_MST T
    WHERE --T.BANK_GROUP_CODE = 'SCB'
           --    AND T.CTY_CODE = 'GB'
            --   AND T.CUST_ID = '800000566'
               A.BANK_GROUP_CODE = T.BANK_GROUP_CODE(+)
               AND A.CTY_CODE = T.CTY_CODE(+)
               AND A.CUST_ID = T.CUST_ID(+)
               AND A.LIMIT_ID = T.PROD_LIMIT_ID(+)
               ORDER BY GROUP_ID DESC, LATEST_DEAL_STEP_ID NULLS LAST;

  BEGIN

         p_ret_code := '0000';

       IF dealStepID is null or dealStepID = '' THEN

          v_client_executed := 0;

          FOR custTxnList IN cust_txn LOOP
            IF v_prev_group_id is null OR  v_prev_group_id != custTxnList.GROUP_ID THEN
              v_prev_group_id := custTxnList.GROUP_ID;

              IF custTxnList.Latest_Deal_Step_Id IS NULL THEN

                 BEGIN
                    DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE = ctyCode
                             AND CUST_ID = custId
                             AND DEAL_STEP_ID IS NULL
                             AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');
                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
                        IF ctyCode ='US' THEN 
                               SCBP_P_GET_GBB_UK_SFALL_DTL_US(p_ret_code,
                                            bankGroupCode,
                                            ctyCode,
                                            custId,
                                            custTxnList.Latest_Deal_Step_Id,
                                            custTxnList.limit_id,
                                            'CDB');
                         ELSE
                           SCBP_P_GET_MISCLNS_DTL_EXP_AMT(p_ret_code,
                                              bankGroupCode,
                                              ctyCode,
                                              custId,
                                              custTxnList.Latest_Deal_Step_Id,
                                              custTxnList.Limit_Id,
                                              'CDB');                   
                        END IF;                                 

              ELSE
               SELECT SHORTFALL_OFFSET, LIMIT_CLASSIFICATION, LIMIT_CCY_CODE
                     INTO v_shortfall_offset, v_limit_class, v_lmt_ccy_code
                     FROM SCBT_R_CUST_PRODUCT_LIMIT
                      WHERE bank_group_code = bankGroupCode
                        AND cty_code            = ctyCode
                        AND cust_id             = custId
                        AND limit_id        = custTxnList.prod_limit_id;
                    

                    
                IF v_shortfall_offset IS NOT NULL AND v_shortfall_offset in ('GBB', 'CBB') THEN
                         IF ctyCode ='US' THEN 
                           SCBP_P_GET_GBB_UK_SFALL_DTL_US(p_ret_code,
                                              bankGroupCode,
                                              ctyCode,
                                              custId,
                                              custTxnList.Latest_Deal_Step_Id,
                                              custTxnList.limit_id,
                                              'CDB');
                         ELSE
                           SCBP_P_GET_GBB_UK_SFALL_DTL(p_ret_code,
                                          bankGroupCode,
                                          ctyCode,
                                          custId,
                                          custTxnList.Latest_Deal_Step_Id,
                                          custTxnList.prod_limit_id,
                                          'CDB');
                                        
                         END IF;               

                ELSIF v_prev_group_id not in ('CS', 'CU') THEN

                  SCBP_P_GET_DTL_EXP_AMT(p_ret_code,
                                        bankGroupCode,
                                        ctyCode,
                                        custId,
                                        custTxnList.Latest_Deal_Step_Id, --dealStepID,
                                        custTxnList.Limit_Id,
                                        'CDB');
                ELSE
                  IF (v_prev_group_id in ('CU', 'CS') AND v_client_executed = 0) THEN
                      v_client_executed := 1;
                      SCBP_P_GET_CLIENT_DTL_EXP_AMT(p_ret_code,
                                        bankGroupCode,
                                        ctyCode,
                                        custId,
                                        custTxnList.Latest_Deal_Step_Id, --dealStepID,
                                        custTxnList.Limit_Id,
                                        'CDB');
                        END IF;
                      END IF;
                    END IF;
                  END IF;
                END LOOP;

       ELSE
         v_deal_step_id := dealStepID;
         
           BEGIN
                                delete from SCBT_T_CUST_GRP_CLT_OFFSET_MST
                                   where BANK_GROUP_CODE = bankGroupCode
                                     AND CTY_CODE = ctyCode
                                     AND CUST_ID = custId
                                     --AND LIMIT_ID = limitId
                                    -- AND CUST_CO_BORROWER_ID = v_temp_co_borrower_id
                                     AND DEAL_STEP_ID = nvl(v_deal_step_id,dealStepID)
                                     AND PAGE_SOURCE = 'DDB'
                                     AND CLIENT_GROUP_INDICATOR ='CBB';
               
          EXCEPTION
             WHEN OTHERS THEN
                NULL;
          END; -- SRK
         
         FOR txn IN txn_hist LOOP
           BEGIN
                SELECT SHORTFALL_OFFSET, LIMIT_CLASSIFICATION, LIMIT_CCY_CODE
                 INTO v_shortfall_offset, v_limit_class, v_lmt_ccy_code
                 FROM SCBT_R_CUST_PRODUCT_LIMIT
                  WHERE bank_group_code = bankGroupCode
                    AND cty_code            = ctyCode
                    AND cust_id             = custId
                    AND limit_id        = txn.prod_limit_id;
                 EXCEPTION
              WHEN OTHERS THEN
                v_shortfall_offset := '';
                v_limit_class := '';
                v_lmt_ccy_code := '';
          END;
                 BEGIN  
                   SELECT NVL(SEP_BB_CERT_FLAG,'N') into sep_bb_cert_flag
                    FROM SCBT_R_CUST_LIMIT_MST
                   WHERE bank_group_code  = bankGroupCode
                     AND cty_code         = ctyCode
                     AND cust_id          = custId;  
                 END;  

             IF v_shortfall_offset = 'CUL' THEN
               SCBP_P_GET_CLIENT_DTL_EXP_AMT(p_ret_code,
                                      bankGroupCode,
                                      ctyCode,
                                      custId,
                                      dealStepID,
                                      txn.prod_limit_id,
                                      'DDB');
            ELSE
                        IF ctyCode ='US' and sep_bb_cert_flag = 'Y' THEN
                     SCBP_P_GET_DTL_EXP_AMT_COB(p_ret_code,
                                            bankGroupCode,
                                            ctyCode,
                                            custId,
                                            dealStepID,
                                            txn.prod_limit_id,
                                            null,
                                            'DDB');    
                       ELSE
                     SCBP_P_GET_DTL_EXP_AMT(p_ret_code,
                                            bankGroupCode,
                                            ctyCode,
                                            custId,
                                            dealStepID,
                                            txn.prod_limit_id,
                                            'DDB');
                       END IF;                       
            END IF;
       END LOOP;

       END IF;


  END SCBP_P_GET_EXPOSURE_AMT;

/******************************************************************************************************/

/*
   Procedure to populate Applicable DP Amount for UK Group Borrowing Base.
*/
--SCBP_P_GET_GBB_UK_SHORTFALL START
 PROCEDURE SCBP_P_GET_GBB_UK_SHORTFALL(p_ret_code    IN OUT VARCHAR2,
                                    bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    dealStepID    IN VARCHAR2) IS

  v_page_source SCBT_T_CUST_SFALL_OFFSET_MST.PAGE_SOURCE%TYPE;
  v_temp_deal_step_id    SCBT_T_CUST_SFALL_OFFSET_MST.deal_step_id%type;

  CURSOR txn_hist IS
  SELECT PROD_LIMIT_ID, deal_step_id
    FROM SCBT_T_TXN_HST
   WHERE bank_group_code  = bankGroupCode
     AND cty_code         = ctyCode
     AND cust_id          = custId
     AND deal_step_id     = nvl(v_temp_deal_step_id, deal_step_id)
     AND SHORTFALL_OFFSET_TYPE in ('CBB', 'GBB');

 CURSOR cust_txn_hist IS
  SELECT PROD_LIMIT_ID, DEAL_STEP_ID
    FROM SCBT_T_TXN_HST
   WHERE bank_group_code  = bankGroupCode
     AND cty_code         = ctyCode
     AND cust_id          = custId;

  BEGIN

         p_ret_code := '0000';

       IF dealStepID IS NULL  or length(dealStepID) <= 0 THEN
        v_page_source := 'CDB';
        v_temp_deal_step_id := NULL;
       ELSE
        v_page_source := 'DDB';
       END IF;

      -- IF dealStepID IS NULL THEN
       --   FOR txn IN cust_txn_hist LOOP
/*
             SCBP_P_GET_GBB_UK_SFALL_DTL(p_ret_code,
                                  bankGroupCode,
                                  ctyCode,
                                  custId,
                                  txn.Deal_Step_Id,
                                  txn.prod_limit_id,
                                  'CDB');
*/
      --    END LOOP;
      -- ELSE
           FOR txn IN txn_hist LOOP

               SCBP_P_GET_GBB_UK_SFALL_DTL(p_ret_code,
                                      bankGroupCode,
                                      ctyCode,
                                      custId,
                                      txn.deal_step_id, --dealStepID,
                                      txn.prod_limit_id,
                                      v_page_source
                                      );

           END LOOP;
    --   END IF;

       COMMIT;

  END SCBP_P_GET_GBB_UK_SHORTFALL;

/******************************************************************************************************/
PROCEDURE SCBP_P_GET_GBB_UK_SFALL_DTL(p_ret_code    IN OUT VARCHAR2,
                                   bankGroupCode IN VARCHAR2,
                                   ctyCode       IN VARCHAR2,
                                   custId        IN VARCHAR2,
                                   dealStepID    IN VARCHAR2,
                                   limitId       IN VARCHAR2,
                                   pageSource    IN VARCHAR2) IS

  v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
  v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
  v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
  v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
  v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
  v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
  v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
  v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
  v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
  v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
  v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
  v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
  v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
  v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
  v_appl_dp_ccy_code          SCBT_R_BBC_DTLS_MST.Appl_Dp_Ccy_Code%type;
  v_appl_dp_ccy_amt           SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_AMT%type;
  v_expiry_date               SCBT_R_BBC_DTLS_MST.EXPIRY_DATE%type; 
  v_co_borrower_id            SCBT_T_DEAL_HIST.CO_BORROWER_ID%TYPE;
  v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
  v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
  v_scb_role                  SCBT_T_TXN_HST.SCB_ROLE%TYPE;
  v_is_syndicate_coll         NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  v_max_syndicated_amt_ccy    SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT_CCY%TYPE;
  v_max_syndicated_amt        SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT%TYPE;
  v_bbc_count                 NUMBER;

  CURSOR group_coll IS
  SELECT FACILITY_GRP_ID, PROD_LIMIT_IDS, LINKED_ACC_NOS, LIMIT_AMT_CCY
    FROM SCBT_R_CUST_FACILITY_GRP
   WHERE bank_group_code = bankGroupCode
     AND cty_code            = ctyCode
       AND cust_id             = custId
       AND group_type        = v_grp_type;

  CURSOR client_coll IS
  SELECT LIMIT_ID, LIMIT_CLASSIFICATION
    FROM SCBT_R_CUST_PRODUCT_LIMIT
   WHERE bank_group_code      = bankGroupCode
     AND cty_code                 = ctyCode
       AND cust_id                  = custId
       AND shortfall_offset     = 'CBB' --v_sfall_off
GROUP BY LIMIT_CLASSIFICATION, LIMIT_ID;

  BEGIN

         p_ret_code := '0000';
       v_grp_id   := 0;

       v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);

       BEGIN
           SELECT SHORTFALL_OFFSET
           , LIMIT_CLASSIFICATION
           , LIMIT_CCY_CODE
           INTO v_shortfall_offset
           , v_limit_class
           , v_lmt_ccy_code
             FROM SCBT_R_CUST_PRODUCT_LIMIT
              WHERE bank_group_code = bankGroupCode
                AND cty_code            = ctyCode
                AND cust_id             = custId
                AND limit_id        = limitId;
               EXCEPTION
            WHEN OTHERS THEN
              v_shortfall_offset := '';
              v_limit_class := '';
              v_lmt_ccy_code := '';
        END;

       /* v_shortfall_offset = 'C' --> CLIENT LEVEL FACILITY
               v_shortfall_offset = 'G' --> GROUP LEVEL FACILITY
              v_limit_class           = 'S' --> SECURED FACILITY
              v_limit_class           = 'U' --> SECURED FACILITY */

         /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS GROUP FACILITY START */


         IF v_shortfall_offset = 'GBB' THEN

              v_grp_type         := 'BBG';

          FOR grp IN group_coll LOOP

                  FOR c1 IN (SELECT * FROM TABLE(SPLIT(grp.prod_limit_ids))) LOOP

                        IF c1.COLUMN_VALUE IS NOT NULL AND c1.COLUMN_VALUE = limitId THEN

                             v_grp_id := grp.facility_grp_id;

                   EXIT;

                END IF;

            END LOOP;
               IF v_grp_id != 0 THEN
                  EXIT;
               END IF;
          END LOOP;

       END IF;


       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND FACILITY_GROUP_ID = v_grp_id
                      --AND DEAL_STEP_ID = dealStepID
                      AND PAGE_SOURCE = pageSource
                      AND SHORTFALL_OFFSET  IN ('GBB', 'CBB');
          ELSE
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID = dealStepID
                      AND PAGE_SOURCE = pageSource
                      AND SHORTFALL_OFFSET  IN ('GBB', 'CBB');
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
       END;


         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE GROUP FACILITY */

       IF v_shortfall_offset = 'GBB' AND v_grp_id IS NOT NULL THEN

          v_grp_lnk_bal := 0;

          BEGIN
            SELECT PROD_LIMIT_IDS, FACLIITY_GRP_NAME, LINKED_ACC_NOS
              INTO v_prod_limit_id, v_fac_grp_name, v_linked_acc_nos
              FROM SCBT_R_CUST_FACILITY_GRP
             WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctycode
                AND CUST_ID = custId
                AND FACILITY_GRP_ID = v_grp_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_prod_limit_id :='';
                v_fac_grp_name := '';
                v_linked_acc_nos := '';
          END;

          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_prod_limit_id))) LOOP

              IF c1.COLUMN_VALUE IS NOT NULL THEN

                 SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                            ctyCode,
                                            custId,
                                            c1.column_value,
                                            v_exp_curr_code,
                                            dealStepID,
                                            v_fac_grp_name,
                                            v_grp_id,
                                            pageSource);

              END IF;

          END LOOP;

          -- Get +ve Net Balance of All Linked Accounts at group level.
          v_clt_lnk_bal := NULL;
          FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_linked_acc_nos))) LOOP

              IF c1.column_value IS NOT NULL THEN

                 v_grp_lnk_bal := v_grp_lnk_bal + SCBF_RET_GROUP_LINK_ACC_BAL(bankGroupCode,
                                                                              ctyCode,
                                                                              v_exp_curr_code,
                                                                              custId,
                                                                              c1.column_value);

              END IF;

          END LOOP;

       END IF;

         /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */

       IF v_shortfall_offset = 'CBB' THEN

          v_grp_id          := NULL;

       BEGIN
          IF pageSource = 'CDB' THEN
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      --AND FACILITY_GROUP_ID = v_grp_id
                      AND FACILITY_GROUP_NAME = 'Client Borrowing Base'
                      --AND DEAL_STEP_ID = dealStepID
                      AND PAGE_SOURCE = pageSource;
                     -- AND SHORTFALL_OFFSET NOT IN ('GBB', 'CBB');;
          ELSE
            DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND DEAL_STEP_ID = dealStepID
                      AND FACILITY_GROUP_NAME = 'Client Borrowing Base'
                      AND PAGE_SOURCE = pageSource;
          END IF;

        EXCEPTION
          WHEN OTHERS THEN
            NULL;
       END;


          FOR clt IN client_coll LOOP

              v_fac_grp_name := 'Client Borrowing Base';

              SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                         ctyCode,
                                         custId,
                                         clt.limit_id,
                                         v_exp_curr_code,
                                         dealStepID,
                                         v_fac_grp_name,
                                         NULL,
                                         pageSource);
          END LOOP;

       END IF;

       /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */

         IF v_shortfall_offset = 'CBB' THEN

          v_grp_lnk_bal := NULL;
          v_grp_id      := NULL;

          v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode,
                                                            ctyCode,
                                                            v_lmt_ccy_code,
                                                            custId),0);

       END IF;

       --To set SHORTFALL_OFFSET as GBB if CTY CODE is 'GB' and v_sfall_off is GFL
       IF v_shortfall_offset = 'GBB' THEN
          --For group borrowing base
          v_clt_grp_indicator := 'GBB';

       ELSE
          --For client borrowing base
          v_clt_grp_indicator    := 'CBB';

       END IF;

       BEGIN
         IF pageSource ='CDB' THEN
           SELECT SUM(FACILITY_EXPOSURE_AMT)
              , SUM(FACILITY_NCV_AMT)
              , SUM(FACILITY_CMR_AMT)
              ,    SUM(CASH_FOR_EXP_OFFSET_AMT)
             INTO v_facility_exposure_amt
              , v_facility_ncv_amt
              , v_facility_cmr_amt
              , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND FACILITY_GROUP_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_EXPOSURE_AMT)
              , SUM(FACILITY_NCV_AMT)
              , SUM(FACILITY_CMR_AMT)
              ,    SUM(CASH_FOR_EXP_OFFSET_AMT)
             INTO v_facility_exposure_amt
              , v_facility_ncv_amt
              , v_facility_cmr_amt
              , v_cash_for_exp_offset_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE = bankGroupCode
              AND CTY_CODE        = ctyCode
              AND CUST_ID         = custId
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND DEAL_STEP_ID    = dealStepID
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         END IF;

       EXCEPTION
         WHEN OTHERS THEN
         v_facility_exposure_amt := 0;
         v_facility_ncv_amt := 0;
         v_facility_cmr_amt := 0;
         v_cash_for_exp_offset_amt := 0;
       END;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND FACILITY_GROUP_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND LIMIT_CLASSIFICATION = 'SC'
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_secured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND DEAL_STEP_ID            = dealstepid
              AND LIMIT_CLASSIFICATION = 'SC'
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         END IF;
       EXCEPTION
          WHEN OTHERS THEN
            v_secured_cmr_amt := 0;
       END;

       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND FACILITY_GROUP_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND LIMIT_CLASSIFICATION = 'USC'
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         ELSE
           SELECT SUM(FACILITY_CMR_AMT)
             INTO v_unsecured_cmr_amt
             FROM SCBT_T_CUST_SFALL_OFFSET_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND SHORTFALL_OFFSET = v_shortfall_offset
              AND DEAL_STEP_ID            = dealstepid
              AND LIMIT_CLASSIFICATION = 'USC'
              AND PAGE_SOURCE = pageSource
              AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
         END IF;
       EXCEPTION
          WHEN OTHERS THEN
            v_unsecured_cmr_amt := 0;
       END;



       --To get CO_BORROWER_ID from SCBT_T_DEAL_HIST table
       BEGIN
         select CO_BORROWER_ID INTO v_co_borrower_id from SCBT_T_DEAL_HIST
            WHERE BANK_GROUP_CODE = bankgroupcode
            AND CTY_CODE = ctycode
            AND CUST_ID = custid
            AND DEAL_STEP_ID = dealStepid;
         EXCEPTION
           WHEN OTHERS THEN
             v_co_borrower_id := '';
       END;

--START
        BEGIN
          SELECT COUNT(1) into v_is_syndicate_coll
              FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                 WHERE map_id = 'TXNISSUVAL'
                 AND code_value_1 = 'CONT_PROD'
                 AND m.code_value_2 = p.limit_product_code
                 AND p.cust_id = custId
                 AND p.limit_id = limitId
                 AND p.bank_group_code = bankGroupCode
                 AND p.cty_code = ctyCode;
        EXCEPTION
            WHEN OTHERS THEN
            v_is_syndicate_coll := 0;
        END;

        IF v_is_syndicate_coll > 0 THEN
          v_product_type := 'CON';
        ELSE
          v_product_type := 'ASS';
        END IF;


        BEGIN
          select PARAM_DATA_07 INTO v_syndicate_data
             FROM SCBT_R_PARAM_DATA
             WHERE param_id = 'TP10'
              AND PARAM_KEY_01 IN (
               select DISTINCT SCB_ROLE
                 FROM SCBT_T_TXN_HST
                 WHERE BANK_GROUP_CODE=bankGroupCode
                   AND CTY_CODE=ctyCode
                   AND CUST_ID=custId
                   AND DEAL_STEP_ID= dealStepID
                   AND PROD_LIMIT_ID=limitId
                   AND SCB_ROLE IS NOT NULL
             ) and PARAM_KEY_02 = v_product_type;
        EXCEPTION
           WHEN OTHERS THEN
           NULL;
        END;




--END




       --Query to calculate APPL DP CCY and APPL DP AMT
--       BEGIN
--           IF (v_scb_role = 'AG') THEN
       IF (ctyCode='US') THEN
                     IF v_grp_id ='0' THEN
                      v_fac_grp_name := 'Client Borrowing Base';
                      v_grp_id := null;
                      END IF;
                     BEGIN
                       select
                                    decode(nvl(v_syndicate_data, 'NCV'),
                                    'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                                 --, TOTAL_NCV_CCY_AMT
                                 , Scbf_Tls_Exch_Rate(
                                           bbcMst.BANK_GROUP_CODE
                                               , bbcMst.CTY_CODE           -- COUNTRY CODE
                                                 , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                               , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                                 , v_exp_curr_code            -- TO CURR CODE
                                               , 'Y')
                                           ,bbcMst.expiry_date
                                 INTO v_appl_dp_ccy_code
                                 , v_appl_dp_ccy_AMT
                                 , v_expiry_date
                                FROM SCBT_R_BBC_DTLS_MST bbcMst,
                                SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                                where bbcMst.BANK_GROUP_CODE=bbcGen.Bank_Group_Code
                                AND bbcMst.CTY_CODE=bbcGen.Cty_Code
                                AND bbcMst.Active_Bbc_Flag= 'Y'
                                AND bbcGen.Bank_Group_Code = bankgroupcode
                                AND bbcGen.Cty_Code = ctycode
                                AND bbcGen.Cust_Id = custid
                                AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                                --AND bbcGen.Facility_Group_Id = nvl(v_grp_id, '*')
                                --AND bbcGen.Co_Borrower_Id = nvl(v_co_borrower_id, '*');
                                AND bbcGen.Co_Borrower_Id = nvl(v_grp_id, '*');
                       EXCEPTION
                         WHEN OTHERS THEN
                           v_appl_dp_ccy_code := '';
                           v_appl_dp_ccy_AMT := 0;
                     END;
          ELSE
             
            BEGIN 
              SELECT COUNT(1) INTO v_bbc_count FROM SCBT_R_BBC_DTLS_MST BBCMST,SCBT_R_BBC_GENERAL_DTLS_MST BBCGEN
              WHERE BBCMST.BANK_GROUP_CODE=BBCGEN.BANK_GROUP_CODE AND BBCMST.CTY_CODE = BBCGEN.CTY_CODE
              AND BBCMST.ACTIVE_BBC_FLAG= 'Y' AND BBCGEN.BBC_ID = BBCMST.BBC_ID 
              AND BBCGEN.BANK_GROUP_CODE = BANKGROUPCODE AND BBCGEN.CTY_CODE= CTYCODE AND BBCGEN.CUST_ID = CUSTID
              AND BBCGEN.FACILITY_GROUP_ID = NVL(V_GRP_ID, '*') AND BBCGEN.CO_BORROWER_ID = V_CO_BORROWER_ID;
            EXCEPTION
                    WHEN OTHERS THEN
                    v_bbc_count :=0;
            END;
            
             IF v_bbc_count > 0 THEN
                 BEGIN
                   select
                          decode(nvl(v_syndicate_data, 'BCA'),
                          'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                       --, TOTAL_NCV_CCY_AMT
                       , Scbf_Tls_Exch_Rate(
                                 bbcMst.BANK_GROUP_CODE
                                     , bbcMst.CTY_CODE           -- COUNTRY CODE
                                       , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                     , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                       , v_exp_curr_code            -- TO CURR CODE
                                     , 'Y')
                             ,bbcMst.Expiry_Date
                       INTO v_appl_dp_ccy_code
                       , v_appl_dp_ccy_AMT
                       , v_expiry_date
                      FROM SCBT_R_BBC_DTLS_MST bbcMst,
                      SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                      where bbcMst.BANK_GROUP_CODE=bankgroupcode
                      AND bbcMst.CTY_CODE=ctycode
                      AND bbcMst.Active_Bbc_Flag= 'Y'
                      AND bbcGen.Bank_Group_Code = bankgroupcode
                      AND bbcGen.Cty_Code = ctycode
                      AND bbcGen.Cust_Id = custid
                      AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                      AND bbcGen.Facility_Group_Id = nvl(v_grp_id, '*')
                      AND bbcGen.Co_Borrower_Id = v_co_borrower_id;
                   EXCEPTION
                     WHEN OTHERS THEN
                       v_appl_dp_ccy_code := '';
                       v_appl_dp_ccy_AMT := 0;
                 END;             
             ELSE
                 BEGIN
                   select
                          decode(nvl(v_syndicate_data, 'BCA'),
                          'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                       --, TOTAL_NCV_CCY_AMT
                       , Scbf_Tls_Exch_Rate(
                                 bbcMst.BANK_GROUP_CODE
                                     , bbcMst.CTY_CODE           -- COUNTRY CODE
                                       , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                     , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                       , v_exp_curr_code            -- TO CURR CODE
                                     , 'Y')
                                     , bbcMst.Expiry_Date
                       INTO v_appl_dp_ccy_code
                       , v_appl_dp_ccy_AMT
                       , v_expiry_date
                      FROM SCBT_R_BBC_DTLS_MST bbcMst,
                      SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                      where bbcMst.BANK_GROUP_CODE=bankgroupcode
                      AND bbcMst.CTY_CODE=ctycode
                      AND bbcMst.Active_Bbc_Flag= 'Y'
                      AND bbcGen.Bank_Group_Code = bankgroupcode
                      AND bbcGen.Cty_Code = ctycode
                      AND bbcGen.Cust_Id = custid
                      AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                      AND bbcGen.Facility_Group_Id = nvl(v_grp_id, '*')
                      AND bbcGen.Co_Borrower_Id = '*';
                   EXCEPTION
                     WHEN OTHERS THEN
                       v_appl_dp_ccy_code := '';
                       v_appl_dp_ccy_AMT := 0;
                 END;             
             END IF; 
          

                 
           END IF;
           
          BEGIN
            IF pageSource = 'CDB' THEN
               DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
                 WHERE bank_group_code = bankGroupCode
                  AND cty_code        = ctyCode
                  AND cust_id         = custId
                  --AND deal_step_id    = dealStepID
                  AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                  AND LIMIT_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                  AND PAGE_SOURCE = pageSource;
            ELSE
              DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
                WHERE bank_group_code = bankGroupCode
                  AND cty_code        = ctyCode
                  AND cust_id         = custId
                  AND deal_step_id    = dealStepID
                  AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                  AND PAGE_SOURCE = pageSource;
            END IF;

          EXCEPTION
            WHEN OTHERS THEN
            NULL;
          END;


       --For EFF_NCV_COLL_CAP
       BEGIN
         IF pageSource = 'CDB' THEN
           SELECT SUM(EFFECTIVE_NCV_AMT)
             INTO v_eff_ncv_coll_cap
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND PAGE_SOURCE = pageSource;
         ELSE
           SELECT SUM(EFFECTIVE_NCV_AMT)
             INTO v_eff_ncv_coll_cap
             FROM SCBT_T_COLL_SFALL_DETAIL_MST
            WHERE BANK_GROUP_CODE      = bankgroupcode
              AND CTY_CODE               = ctycode
              AND CUST_ID                 = custid
              AND DEAL_STEP_ID            = dealstepid
              AND PAGE_SOURCE = pageSource;
         END IF;

       EXCEPTION
          WHEN OTHERS THEN
            v_eff_ncv_coll_cap := 0;
       END;

       --For EFF_NCV_COLL_GRP_CAP
       BEGIN
         SELECT
         --LIMIT_CCY_ACTIVE_AMT
           Scbf_Tls_Exch_Rate(
                             BANK_GROUP_CODE
                                 , CTY_CODE           -- COUNTRY CODE
                                   , LIMIT_CCY_CODE         -- FROM CURR CODE
                                 , LIMIT_CCY_ACTIVE_AMT            -- FROM AMOUNT
                                   , v_exp_curr_code            -- TO CURR CODE
                                 , 'Y')
           INTO v_eff_ncv_coll_grp_cap
           FROM SCBT_R_CUST_COL_GRP_LIMIT
         WHERE BANK_GROUP_CODE = bankgroupcode
            AND CTY_CODE     = ctycode
            AND CUST_ID      = custid;
       EXCEPTION
         WHEN OTHERS THEN
           v_eff_ncv_coll_grp_cap := 0;
       END;

       IF (ctyCode='US') THEN
             IF v_grp_id ='0' OR  v_grp_id is null THEN
              v_fac_grp_name := 'Client Borrowing Base';
              v_grp_id := 'CS';
              END IF;
             
              IF v_limit_class is NULL THEN
              v_limit_class := 'SC';
              END IF;
       END IF;       

       BEGIN
         INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                BANK_GROUP_CODE
                , CTY_CODE
                , CUST_ID
                , OVERALL_EXP_CCY_CODE
                , FACILITY_GROUP_NAME
                , CLIENT_GROUP_INDICATOR
                , LIMIT_CLASSIFICATION
                , LIMIT_ID
                , FACILITY_EXPOSURE_CCY
                , FACILITY_EXPOSURE_AMT
                , FACILITY_NCV_CCY
                , FACILITY_NCV_AMT
                , FACILITY_CMR_CCY
                , FACILITY_CMR_AMT
                , CASH_FOR_EXP_OFFSET_CCY
                , CASH_FOR_EXP_OFFSET_AMT
                , LINKED_ACCOUNT_CCY
                , LINKED_ACCOUNT_BALANCE
                , SECURED_CMR_CCY
                , SECURED_CMR_AMT
                , UNSECURED_CMR_CCY
                , UNSECURED_CMR_AMT
                , DEAL_STEP_ID
                , APPLICABLE_DP_CCY
                , APPLICABLE_DP_AMT
                , EFF_NCV_COLL_CAP
                , EFF_NCV_COLL_GRP_CAP
                , PAGE_SOURCE
                , EXPIRY_DATE )
             VALUES (
                bankGroupCode
                , ctyCode
                , custId
                , v_exp_curr_code
                , v_fac_grp_name
                , v_clt_grp_indicator
                , v_limit_class
                , NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))    --NVL(v_grp_id,'CSCU')
                , v_exp_curr_code  --v_lmt_ccy_code
                , v_facility_exposure_amt
                , v_exp_curr_code  --v_lmt_ccy_code
                , v_facility_ncv_amt
                , v_exp_curr_code  --v_lmt_ccy_code
                , v_facility_cmr_amt
                , v_exp_curr_code  --v_lmt_ccy_code
                , v_cash_for_exp_offset_amt
                , v_exp_curr_code  --v_lmt_ccy_code
                , NVL(v_grp_lnk_bal,v_clt_lnk_bal)
                , v_exp_curr_code  --v_lmt_ccy_code
                , NVL(v_secured_cmr_amt, 0)
                , v_exp_curr_code  --v_lmt_ccy_code
                , NVL(v_unsecured_cmr_amt, 0)
                , dealStepID
                , v_exp_curr_code  --v_appl_dp_ccy_code
                , v_appl_dp_ccy_amt
                , v_eff_ncv_coll_cap
                , v_eff_ncv_coll_grp_cap
                , pageSource
                , v_expiry_date);
                COMMIT;
             EXCEPTION
                WHEN OTHERS THEN
                NULL;
                 dbms_output.put_line('SQLERRM:'||'SFALLDTL'|| SQLERRM);
             END;

          --temp patch start
          BEGIN
            IF v_clt_grp_indicator = 'CBB' and pageSource='CDB' and v_grp_id = 0 THEN
                DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
                  WHERE bank_group_code = bankGroupCode
                    AND cty_code        = ctyCode
                    AND cust_id         = custId
                    AND LIMIT_ID        = '0'
                    AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                    AND PAGE_SOURCE = pageSource;
            END IF;
            --temp patch end
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;



       EXCEPTION

       WHEN OTHERS THEN
            NULL;


  END SCBP_P_GET_GBB_UK_SFALL_DTL;


/*---------------------------------------------------------------------------------------------------------------------------*/
 --REF_25SEP_2012  
/*---------------------------------------------------------------------------------------------------------------------------*/

PROCEDURE SCBP_P_GET_GBB_UK_SFALL_DTL_US(p_ret_code    IN OUT VARCHAR2,
                                               bankGroupCode IN VARCHAR2,
                                               ctyCode       IN VARCHAR2,
                                               custId        IN VARCHAR2,
                                               dealStepID    IN VARCHAR2,
                                               limitId       IN VARCHAR2,
                                               pageSource    IN VARCHAR2) IS
            
              v_exp_curr_code                     SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
              v_grp_id                    SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
              v_clt_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
              v_grp_lnk_bal               SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
              v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
              v_fac_grp_name              SCBT_R_CUST_FACILITY_GRP.FACLIITY_GRP_NAME%TYPE;
              v_sfall_off                 SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
              v_linked_acc_nos            SCBT_R_CUST_FACILITY_GRP.LINKED_ACC_NOS%TYPE;
              v_clt_grp_indicator         SCBT_T_CUST_GRP_CLT_OFFSET_MST.CLIENT_GROUP_INDICATOR%TYPE;
              v_lmt_ccy_code              SCBT_T_PROD_LIMIT_MVMT.TXN_CCY_CODE%TYPE;
              v_facility_exposure_amt        SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_EXPOSURE_AMT%TYPE;
              v_facility_ncv_amt          SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_NCV_AMT%TYPE;
              v_facility_cmr_amt            SCBT_T_CUST_SFALL_OFFSET_MST.FACILITY_CMR_AMT%TYPE;
              v_cash_for_exp_offset_amt   SCBT_T_CUST_SFALL_OFFSET_MST.CASH_FOR_EXP_OFFSET_AMT%TYPE;
              v_secured_cmr_amt              SCBT_T_CUST_GRP_CLT_OFFSET_MST.SECURED_CMR_AMT%TYPE;
              v_unsecured_cmr_amt         SCBT_T_CUST_GRP_CLT_OFFSET_MST.UNSECURED_CMR_AMT%TYPE;
              v_shortfall_offset          SCBT_R_CUST_PRODUCT_LIMIT.SHORTFALL_OFFSET%TYPE;
              v_limit_class               SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CLASSIFICATION%TYPE;
              v_grp_type                  SCBT_R_CUST_FACILITY_GRP.GROUP_TYPE%TYPE;
              v_appl_dp_ccy_code          SCBT_R_BBC_DTLS_MST.Appl_Dp_Ccy_Code%type;
              v_appl_dp_ccy_amt           SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_AMT%type;
              v_co_borrower_id            SCBT_T_DEAL_HIST.CO_BORROWER_ID%TYPE;
              v_eff_ncv_coll_cap          SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_CAP%TYPE;
              v_eff_ncv_coll_grp_cap      SCBT_T_CUST_GRP_CLT_OFFSET_MST.EFF_NCV_COLL_GRP_CAP%TYPE;
              v_scb_role                  SCBT_T_TXN_HST.SCB_ROLE%TYPE;
              v_is_syndicate_coll         NUMBER;
              v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
              v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
              v_max_syndicated_amt_ccy    SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT_CCY%TYPE;
              v_max_syndicated_amt        SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT%TYPE;
              v_temp_appl_dp_ccy_amt      SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_AMT%type;
              v_expiry_date               SCBT_R_BBC_DTLS_MST.EXPIRY_DATE%type; 
              v_deal_step_id              SCBT_T_TXN_HST.Deal_Step_Id%TYPE;
              sep_bb_cert_flag            varchar2(2);
            
              CURSOR group_coll IS
              SELECT FACILITY_GRP_ID, PROD_LIMIT_IDS, LINKED_ACC_NOS, LIMIT_AMT_CCY
                FROM SCBT_R_CUST_FACILITY_GRP
               WHERE bank_group_code = bankGroupCode
                 AND cty_code            = ctyCode
                   AND cust_id             = custId
                   AND group_type        = v_grp_type;
            
             
            
             CURSOR client_coll IS 
            SELECT  distinct cpl.LIMIT_ID as LIMIT_ID,
                     cpl.LIMIT_CLASSIFICATION as LIMIT_CLASSIFICATION,
                     cpl.CO_BORROWER_ID as CO_BORROWER_ID
                FROM SCBT_R_CUST_PRODUCT_LIMIT cpl
              WHERE cpl.bank_group_code = bankGroupCode
                 AND cpl.cty_code = ctyCode
                   AND cpl.cust_id    = custId
                   AND cpl.shortfall_offset     = 'CBB';

         
              BEGIN
            

                     p_ret_code := '0000';
                   v_grp_id   := 0;
                  
            
                 BEGIN  
                   SELECT NVL(SEP_BB_CERT_FLAG,'N') into sep_bb_cert_flag
                    FROM SCBT_R_CUST_LIMIT_MST
                   WHERE bank_group_code  = bankGroupCode
                     AND cty_code         = ctyCode
                     AND cust_id          = custId;  
                 END;  
            
            
                   v_exp_curr_code := Scbf_Get_Exp_Ccy(bankGroupCode, ctyCode, custId);
            
                   BEGIN
                       SELECT SHORTFALL_OFFSET
                       , LIMIT_CLASSIFICATION
                       , LIMIT_CCY_CODE
                       INTO v_shortfall_offset
                       , v_limit_class
                       , v_lmt_ccy_code
                         FROM SCBT_R_CUST_PRODUCT_LIMIT
                          WHERE bank_group_code = bankGroupCode
                            AND cty_code            = ctyCode
                            AND cust_id             = custId
                            AND limit_id        = limitId;
                           EXCEPTION
                        WHEN OTHERS THEN
                          v_shortfall_offset := '';
                          v_limit_class := '';
                          v_lmt_ccy_code := '';
                    END;
            
            
            
                   BEGIN
                       SELECT distinct deal_step_id
                       INTO v_deal_step_id
                         FROM SCBT_T_TXN_HST
                          WHERE bank_group_code = bankGroupCode
                            AND cty_code            = ctyCode
                            AND cust_id             = custId
                            AND prod_limit_id   = limitId;
                        
                    EXCEPTION
                        WHEN OTHERS THEN
                          v_deal_step_id := '';
                     END;
                    
         
            
                     IF v_shortfall_offset = 'GBB' THEN
            
                          v_grp_type         := 'BBG';
            
                      FOR grp IN group_coll LOOP
            
                              FOR c1 IN (SELECT * FROM TABLE(SPLIT(grp.prod_limit_ids))) LOOP
            
                                    IF c1.COLUMN_VALUE IS NOT NULL AND c1.COLUMN_VALUE = limitId THEN
            
                                         v_grp_id := grp.facility_grp_id;
            
                               EXIT;
            
                            END IF;
            
                        END LOOP;
                           IF v_grp_id != 0 THEN
                              EXIT;
                           END IF;
                      END LOOP;
            
                   END IF;
            
                     /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE GROUP FACILITY */
            
                   IF v_shortfall_offset = 'GBB' AND v_grp_id IS NOT NULL THEN
            
                      v_grp_lnk_bal := 0;
            
                      BEGIN
                        SELECT PROD_LIMIT_IDS, FACLIITY_GRP_NAME, LINKED_ACC_NOS
                          INTO v_prod_limit_id, v_fac_grp_name, v_linked_acc_nos
                          FROM SCBT_R_CUST_FACILITY_GRP
                         WHERE BANK_GROUP_CODE = bankGroupCode
                            AND CTY_CODE = ctycode
                            AND CUST_ID = custId
                            AND FACILITY_GRP_ID = v_grp_id;
                        EXCEPTION
                          WHEN OTHERS THEN
                            v_prod_limit_id :='';
                            v_fac_grp_name := '';
                            v_linked_acc_nos := '';
                      END;
            
                      FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_prod_limit_id))) LOOP
            
                          IF c1.COLUMN_VALUE IS NOT NULL THEN
            
                             SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                                        ctyCode,
                                                        custId,
                                                        c1.column_value,
                                                        v_exp_curr_code,
                                                        dealStepID,
                                                        v_fac_grp_name,
                                                        v_grp_id,
                                                        pageSource);
            
                          END IF;
            
                      END LOOP;
            
                      v_clt_lnk_bal := NULL;
                      FOR c1 IN (SELECT * FROM TABLE(SPLIT(v_linked_acc_nos))) LOOP
            
                          IF c1.column_value IS NOT NULL THEN
            
                             v_grp_lnk_bal := v_grp_lnk_bal + SCBF_RET_GROUP_LINK_ACC_BAL(bankGroupCode,
                                                                                          ctyCode,
                                                                                          v_exp_curr_code,
                                                                                          custId,
                                                                                          c1.column_value);
            
                          END IF;
            
                      END LOOP;
            
                   END IF;
            
                     /* PRODUCT WISE EXPOSURE / NCV / CMR / CASH FOR EXP OFFSET FOR THE CLIENT FACILITY */
            
             IF v_shortfall_offset = 'CBB' THEN
            
                      v_grp_id          := NULL;
                      
                     BEGIN
                      IF pageSource = 'CDB' THEN
                        DELETE FROM SCBT_T_CUST_SFALL_OFFSET_MST
                            WHERE BANK_GROUP_CODE = bankGroupCode
                                  AND CTY_CODE = ctyCode
                                  AND CUST_ID = custId
                                  AND PAGE_SOURCE = pageSource
                                  AND SHORTFALL_OFFSET  IN ('GBB', 'CBB');
                      END IF;            
                      END;
                      
                      
               FOR clt IN client_coll LOOP                                  
            
                          v_fac_grp_name := 'Client Borrowing Base';
            
                          SCBP_ISRT_SFALL_OFFSET_MST(bankGroupCode,
                                                     ctyCode,
                                                     custId,
                                                     clt.limit_id,
                                                     v_exp_curr_code,
                                                     v_deal_step_id,
                                                     v_fac_grp_name,
                                                     NULL,
                                                     pageSource);
                      END LOOP;
            
             END IF;
            
                   /* LOAD THE ACCOUNT BALANCE FOR ALL THE ACCOUNT NUMBERS LINKED TO THIS CLIENT FACILITY START */
            
                     IF v_shortfall_offset = 'CBB' THEN
            
                      v_grp_lnk_bal := NULL;
                      v_grp_id      := NULL;
            
                      v_clt_lnk_bal := NVL(SCBF_RET_CLIENT_LINK_ACC_BAL(bankGroupCode,
                                                                        ctyCode,
                                                                        v_lmt_ccy_code,
                                                                        custId),0);
                   END IF;
            
                   --To set SHORTFALL_OFFSET as GBB if CTY CODE is 'GB' and v_sfall_off is GFL
                   IF v_shortfall_offset = 'GBB' THEN
                      --For group borrowing base
                      v_clt_grp_indicator := 'GBB';
            
                   ELSE
                      --For client borrowing base
                      v_clt_grp_indicator    := 'CBB';
            
                   END IF;
         FOR clt IN client_coll LOOP   
                   BEGIN
                     IF pageSource ='CDB' THEN
                       SELECT sum(FACILITY_EXPOSURE_AMT)
                          , sum(FACILITY_NCV_AMT)
                          , sum(FACILITY_CMR_AMT)
                          ,    sum(CASH_FOR_EXP_OFFSET_AMT)
                         INTO v_facility_exposure_amt
                          , v_facility_ncv_amt
                          , v_facility_cmr_amt
                          , v_cash_for_exp_offset_amt
                         FROM SCBT_T_CUST_SFALL_OFFSET_MST
                        WHERE BANK_GROUP_CODE = bankGroupCode
                          AND CTY_CODE        = ctyCode
                          AND CUST_ID         = custId
                          AND CUST_CO_BORROWER_ID = nvl(clt.co_borrower_id,custId)
                          --AND LIMIT_ID         = clt.limit_id
                          --AND SHORTFALL_OFFSET = v_shortfall_offset
                         -- AND FACILITY_GROUP_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                          AND PAGE_SOURCE = pageSource
                          AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
                     ELSE
                       SELECT FACILITY_EXPOSURE_AMT
                          , FACILITY_NCV_AMT
                          , FACILITY_CMR_AMT
                          ,    CASH_FOR_EXP_OFFSET_AMT
                         INTO v_facility_exposure_amt
                          , v_facility_ncv_amt
                          , v_facility_cmr_amt
                          , v_cash_for_exp_offset_amt
                         FROM SCBT_T_CUST_SFALL_OFFSET_MST
                        WHERE BANK_GROUP_CODE = bankGroupCode
                          AND CTY_CODE        = ctyCode
                          AND CUST_ID         = custId
                          --AND SHORTFALL_OFFSET = v_shortfall_offset
                          --AND DEAL_STEP_ID    = dealStepID  
                          AND PAGE_SOURCE = pageSource
                          AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
                     END IF;
            
                   EXCEPTION
                     WHEN OTHERS THEN
                     v_facility_exposure_amt := 0;
                     v_facility_ncv_amt := 0;
                     v_facility_cmr_amt := 0;
                     v_cash_for_exp_offset_amt := 0;
                      dbms_output.put_line('SQLERRM:'|| SQLERRM);
                   END;
            
                   BEGIN
                     IF pageSource = 'CDB' THEN
                       SELECT FACILITY_CMR_AMT
                         INTO v_secured_cmr_amt
                         FROM SCBT_T_CUST_SFALL_OFFSET_MST
                        WHERE BANK_GROUP_CODE      = bankgroupcode
                          AND CTY_CODE               = ctycode
                          AND CUST_ID                 = custid
                          AND LIMIT_ID         = clt.limit_id
                          --AND FACILITY_GROUP_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                          --AND SHORTFALL_OFFSET = v_shortfall_offset
                          --AND LIMIT_CLASSIFICATION = 'SC'
                          AND PAGE_SOURCE = pageSource
                          AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
                     ELSE
                       SELECT FACILITY_CMR_AMT
                         INTO v_secured_cmr_amt
                         FROM SCBT_T_CUST_SFALL_OFFSET_MST
                        WHERE BANK_GROUP_CODE      = bankgroupcode
                          AND CTY_CODE               = ctycode
                          AND CUST_ID                 = custid
                          --AND SHORTFALL_OFFSET = v_shortfall_offset
                          --AND DEAL_STEP_ID            = dealstepid
                          --AND LIMIT_CLASSIFICATION = 'SC'
                          AND PAGE_SOURCE = pageSource
                          AND SHORTFALL_OFFSET IN ('GBB', 'CBB');
                     END IF;
                   EXCEPTION
                      WHEN OTHERS THEN
                        v_secured_cmr_amt := 0;
                   END;
            
            
                   --To get CO_BORROWER_ID from SCBT_T_DEAL_HIST table
                   BEGIN
                     select CO_BORROWER_ID INTO v_co_borrower_id from SCBT_R_CUST_PRODUCT_LIMIT
                        WHERE BANK_GROUP_CODE = bankgroupcode
                        AND CTY_CODE = ctycode
                        AND CUST_ID = custid
                        AND LIMIT_ID = clt.limit_id;
                     EXCEPTION
                       WHEN OTHERS THEN
                         v_co_borrower_id := '';
                   END;
            
            --START
                    BEGIN
                      SELECT COUNT(1) into v_is_syndicate_coll
                          FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                             WHERE map_id = 'TXNISSUVAL'
                             AND code_value_1 = 'CONT_PROD'
                             AND m.code_value_2 = p.limit_product_code
                             AND p.cust_id = custId
                             AND p.limit_id = clt.limit_id
                             AND p.bank_group_code = bankGroupCode
                             AND p.cty_code = ctyCode;
                    EXCEPTION
                        WHEN OTHERS THEN
                        v_is_syndicate_coll := 0;
                    END;
            
                    IF v_is_syndicate_coll > 0 THEN
                      v_product_type := 'CON';
                    ELSE
                      v_product_type := 'ASS';
                    END IF;
            
            
                    BEGIN
                      select PARAM_DATA_07 INTO v_syndicate_data
                         FROM SCBT_R_PARAM_DATA
                         WHERE param_id = 'TP10'
                          AND PARAM_KEY_01 = (
                           select DISTINCT SCB_ROLE
                             FROM SCBT_T_TXN_HST
                             WHERE BANK_GROUP_CODE=bankGroupCode
                               AND CTY_CODE=ctyCode
                               AND CUST_ID=custId
                               AND DEAL_STEP_ID= nvl(dealStepID,v_deal_step_id)
                               AND PROD_LIMIT_ID=clt.limit_id
                         ) and PARAM_KEY_02 = v_product_type;
                    EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                    END;
            
                    BEGIN
                      SELECT TH.DEAL_STEP_ID,NVL(PL.CO_BORROWER_ID,PL.CUST_ID)
                         INTO v_deal_step_id,v_co_borrower_id
                        FROM SCBT_T_TXN_HST TH,SCBT_R_CUST_PRODUCT_LIMIT PL
                          WHERE TH.BANK_GROUP_CODE=PL.BANK_GROUP_CODE
                          AND TH.CTY_CODE=PL.CTY_CODE
                          AND TH.CUST_ID=PL.CUST_ID
                          AND TH.PROD_LIMIT_ID=PL.LIMIT_ID
                          AND TH.BANK_GROUP_CODE = bankGroupCode
                            AND TH.CTY_CODE = ctycode
                            AND TH.CUST_ID = custId
                            AND PL.LIMIT_ID = clt.limit_id;
                       EXCEPTION
                       WHEN OTHERS THEN
                           v_deal_step_id := '';
                           dbms_output.put_line('SQLERRM:'|| SQLERRM);
                     END;
           
                   IF v_grp_id ='0' THEN
                    v_fac_grp_name := 'Client Borrowing Base';
                    v_grp_id := null;
                    END IF;
                    
                   IF v_co_borrower_id =custId or sep_bb_cert_flag = 'N' THEN
                    v_co_borrower_id := null;
                   ELSE
                    v_co_borrower_id := v_co_borrower_id;
                   END IF;
                     
                         BEGIN
                           select
                                  decode(nvl(v_syndicate_data, 'NCV'),
                                  'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)
                               --, TOTAL_NCV_CCY_AMT
                               , Scbf_Tls_Exch_Rate(
                                         bbcMst.BANK_GROUP_CODE
                                             , bbcMst.CTY_CODE           -- COUNTRY CODE
                                               , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_CODE, TOTAL_NCV_CCY_CODE)         -- FROM CURR CODE
                                             , decode(nvl(v_syndicate_data, 'NCV'), 'BCA',APPL_DP_CCY_AMT, TOTAL_NCV_CCY_AMT)            -- FROM AMOUNT
                                               , v_exp_curr_code            -- TO CURR CODE
                                             , 'Y')
                                         ,bbcMst.expiry_date
                               INTO v_appl_dp_ccy_code
                               , v_appl_dp_ccy_AMT
                               ,v_expiry_date
                              FROM SCBT_R_BBC_DTLS_MST bbcMst,
                              SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                              where bbcMst.BANK_GROUP_CODE=bbcGen.Bank_Group_Code
                              AND bbcMst.CTY_CODE=bbcGen.Cty_Code
                              AND bbcMst.Active_Bbc_Flag= 'Y'
                              AND bbcGen.Bank_Group_Code = bankgroupcode
                              AND bbcGen.Cty_Code = ctycode
                              AND bbcGen.Cust_Id = custid
                              AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                              --AND bbcGen.Facility_Group_Id = nvl(v_grp_id, '*')
                              --AND bbcGen.Co_Borrower_Id = nvl(v_co_borrower_id, '*');
                              AND bbcGen.Co_Borrower_Id = nvl(v_co_borrower_id, '*');
                              
                         EXCEPTION
                             WHEN OTHERS THEN
                               v_appl_dp_ccy_code := '';
                               v_appl_dp_ccy_AMT := 0;
                                 
                         END;
                         
               
                      BEGIN
                        IF pageSource = 'CDB' THEN
                           DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
                             WHERE bank_group_code = bankGroupCode
                              AND cty_code        = ctyCode
                              AND cust_id         = custId
                              AND CUST_CO_BORROWER_ID = nvl(clt.co_borrower_id,custId)
                              --AND LIMIT_ID =clt.limit_id
                              --AND deal_step_id    = dealStepID
                              --AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                              --AND LIMIT_ID = NVL(v_grp_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))
                              AND PAGE_SOURCE = pageSource;
                        ELSE
                          DELETE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST
                            WHERE bank_group_code = bankGroupCode
                              AND cty_code        = ctyCode
                              AND cust_id         = custId
                              AND LIMIT_ID =clt.limit_id
                              --AND deal_step_id    = nvl(dealStepID,v_deal_step_id)
                              --AND CLIENT_GROUP_INDICATOR = v_clt_grp_indicator
                              AND PAGE_SOURCE = pageSource;
                        END IF;
            
                      EXCEPTION
                        WHEN OTHERS THEN
                        NULL;
                      END;
            
            
                   --For EFF_NCV_COLL_CAP
                   BEGIN
                     IF pageSource = 'CDB' THEN
                       SELECT EFFECTIVE_NCV_AMT
                         INTO v_eff_ncv_coll_cap
                         FROM SCBT_T_COLL_SFALL_DETAIL_MST
                        WHERE BANK_GROUP_CODE      = bankgroupcode
                          AND CTY_CODE               = ctycode
                          AND CUST_ID                 = custid
                          AND PAGE_SOURCE = pageSource;
                     ELSE
                       SELECT EFFECTIVE_NCV_AMT
                         INTO v_eff_ncv_coll_cap
                         FROM SCBT_T_COLL_SFALL_DETAIL_MST
                        WHERE BANK_GROUP_CODE      = bankgroupcode
                          AND CTY_CODE               = ctycode
                          AND CUST_ID                 = custid
                          --AND DEAL_STEP_ID            = dealstepid
                          AND PAGE_SOURCE = pageSource;
                     END IF;
            
                   EXCEPTION
                      WHEN OTHERS THEN
                        v_eff_ncv_coll_cap := 0;
                   END;
            
                   --For EFF_NCV_COLL_GRP_CAP
                   BEGIN
                     SELECT
                     --LIMIT_CCY_ACTIVE_AMT
                       Scbf_Tls_Exch_Rate(
                                         BANK_GROUP_CODE
                                             , CTY_CODE           -- COUNTRY CODE
                                               , LIMIT_CCY_CODE         -- FROM CURR CODE
                                             , LIMIT_CCY_ACTIVE_AMT            -- FROM AMOUNT
                                               , v_exp_curr_code            -- TO CURR CODE
                                             , 'Y')
                       INTO v_eff_ncv_coll_grp_cap
                       FROM SCBT_R_CUST_COL_GRP_LIMIT
                     WHERE BANK_GROUP_CODE = bankgroupcode
                        AND CTY_CODE     = ctycode
                        AND CUST_ID      = custid;
                   EXCEPTION
                     WHEN OTHERS THEN
                       v_eff_ncv_coll_grp_cap := 0;
                   END;
            
                   IF v_grp_id ='0' OR  v_grp_id is null THEN
                    v_fac_grp_name := 'Client Borrowing Base';
                    v_grp_id := 'CS';
                    END IF;
                   
                    IF v_limit_class is NULL THEN
                    v_limit_class := 'SC';
                    END IF;
                    
                    BEGIN
                       SELECT distinct deal_step_id
                       INTO v_deal_step_id
                         FROM SCBT_T_TXN_HST
                          WHERE bank_group_code = bankGroupCode
                            AND cty_code            = ctyCode
                            AND cust_id             = custId
                            AND prod_limit_id   = clt.limit_id;
                        
                    EXCEPTION
                        WHEN OTHERS THEN
                          v_deal_step_id := '';
                     END;
                     
                     
                    IF v_deal_step_id is null then
                                   BEGIN
                      SELECT TH.LATEST_DEAL_STEP_ID AS DEAL_STEP_ID
                         INTO v_deal_step_id
                        FROM SCBT_T_TXN_MST TH
                          WHERE TH.BANK_GROUP_CODE = bankGroupCode
                            AND TH.CTY_CODE = ctycode
                            AND TH.CUST_ID = custId
                            AND TH.PROD_LIMIT_ID = clt.limit_id;
                       EXCEPTION
                       WHEN OTHERS THEN
                           v_deal_step_id := '';
                           dbms_output.put_line('SQLERRM:'|| SQLERRM);
                     END;
                     END IF;
                       
                     IF v_clt_lnk_bal IS NOT NULL and v_clt_lnk_bal > 0 THEN
                        UPDATE SCBT_T_CUST_GRP_CLT_OFFSET_MST
                           SET LINKED_ACCOUNT_BALANCE = 0
                        WHERE BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE        = ctyCode
                           AND CUST_ID         = custId
                           AND PAGE_SOURCE = pageSource;
--                           AND CUST_CO_BORROWER_ID = nvl(clt.co_borrower_id,custId);                           
                     END IF;
                   
            
                   BEGIN
                     INSERT INTO SCBT_T_CUST_GRP_CLT_OFFSET_MST (
                            BANK_GROUP_CODE
                            , CTY_CODE
                            , CUST_ID
                            , OVERALL_EXP_CCY_CODE
                            , FACILITY_GROUP_NAME
                            , CLIENT_GROUP_INDICATOR
                            , LIMIT_CLASSIFICATION
                            , LIMIT_ID
                            , FACILITY_EXPOSURE_CCY
                            , FACILITY_EXPOSURE_AMT
                            , FACILITY_NCV_CCY
                            , FACILITY_NCV_AMT
                            , FACILITY_CMR_CCY
                            , FACILITY_CMR_AMT
                            , CASH_FOR_EXP_OFFSET_CCY
                            , CASH_FOR_EXP_OFFSET_AMT
                            , LINKED_ACCOUNT_CCY
                            , LINKED_ACCOUNT_BALANCE
                            , SECURED_CMR_CCY
                            , SECURED_CMR_AMT
                            , UNSECURED_CMR_CCY
                            , UNSECURED_CMR_AMT
                            , DEAL_STEP_ID
                            , APPLICABLE_DP_CCY
                            , APPLICABLE_DP_AMT
                            , EFF_NCV_COLL_CAP
                            , EFF_NCV_COLL_GRP_CAP
                            , CUST_CO_BORROWER_ID
                            , PAGE_SOURCE
                            , EXPIRY_DATE )
                         VALUES (
                            bankGroupCode
                            , ctyCode
                            , custId
                            , v_exp_curr_code
                            , v_fac_grp_name
                            , v_clt_grp_indicator
                            , v_limit_class
                            , NVL(clt.limit_id,decode(v_limit_class, 'SC', 'CS', 'USC', 'CU'))    --NVL(v_grp_id,'CSCU')
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , v_facility_exposure_amt
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , v_facility_ncv_amt
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , v_facility_cmr_amt
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , v_cash_for_exp_offset_amt
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , NVL(v_grp_lnk_bal,v_clt_lnk_bal)
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , NVL(v_secured_cmr_amt, 0)
                            , v_exp_curr_code  --v_lmt_ccy_code
                            , NVL(v_unsecured_cmr_amt, 0)
                            , nvl(dealStepID,v_deal_step_id)
                            , v_exp_curr_code  --v_appl_dp_ccy_code
                            , v_appl_dp_ccy_amt
                            , v_eff_ncv_coll_cap
                            , v_eff_ncv_coll_grp_cap
                            , nvl(clt.co_borrower_id,custId)
                            , pageSource
                            , v_expiry_date);
                            COMMIT;
                         EXCEPTION
                            WHEN OTHERS THEN
                            NULL;
                            dbms_output.put_line('SQLERRM:'|| SQLERRM);
                         END;
            END LOOP;
            
            
            
END SCBP_P_GET_GBB_UK_SFALL_DTL_US;
      
      
/*---------------------------------------------------------------------------------------------------------------------------*/

END Scbk_P_Get_Coll_Position_Sfall;
/
