SELECT
		      COBORROWERID,COBORROWERNAME,LIMITID,SCILIMITID,INNERTOID,NVL(LIMITNAME,' '),PRODUCTCODE,LIMITCCY,
		      ACTIVELIMIT,PRODWISE_UTIL,UTILISATION,PENDINGINCREASEAMOUNT,AVAILABLITY,PENDINGDECREASEAMOUNT,
		      NCV,PI_NCV,CSH_MARGIN,PI_CSH_MARGIN,PD_CSH_MARGIN,SHORTFALLOFFSET,LINKED_GCV,PI_LINKED_GCV,UNLINKED_GCV,PI_UNLINKED_GCV,TOTAL_NCV_WT_PI,TOTAL_NCV,NVL(SCBF_C_GET_CODE_DESC('SCB','*','*','EN','CI124',PRODUCTCODE,1),' ')
			  FROM (
			  	    SELECT 
			  				   L.LIMIT_SEQ_NO "SEQNO",
				               L.CUST_ID "CUSTOMERID",
				               L.LIMIT_CAT_CODE "LIMITCATEGORYCODE",
			  			       L.CO_BORROWER_ID "COBORROWERID",
			  			       SCBF_GET_PARTY_NAME (L.BANK_GROUP_CODE, L.CO_BORROWER_ID) "COBORROWERNAME",
			  			       SCBF_C_GET_CODE_DESC(L.BANK_GROUP_CODE,L.CTY_CODE,'*','EN','CD032',L.SHORTFALL_OFFSET,1) "SHORTFALLOFFSET",
			  			       L.LIMIT_NAME "LIMITNAME",      
			  			       DECODE(L.LIMIT_PRODUCT_CODE,'*','OVERALL LIMIT',L.LIMIT_PRODUCT_CODE) "PRODUCTCODE",
			  			       NVL(SCBF_C_GET_CODE_DESC(L.BANK_GROUP_CODE,'*','*','EN','CI124',L.LIMIT_PRODUCT_CODE,1),' ') "PRODUCTDESCRIPTION",
			  			       L.LIMIT_ID "LIMITID",
			  			       L.EXT_LIMIT_ID "SCILIMITID",
			  			       L.INNER_TO_ID "INNERTOID",
			  			       L.LIMIT_CCY_CODE "LIMITCCY",
			  			       NVL(L.LIMIT_CCY_ACTIVE_AMT,0) "ACTIVELIMIT",
			  			       NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,L.LIMIT_PRODUCT_CODE),0) "PRODWISE_UTIL",
			  			       NVL(U.LIMIT_CCY_UTILISED_AMT,0) "UTILISATION",
			  			       NVL(U.LIMIT_CCY_PEND_INC_AMT,0) "PENDINGINCREASEAMOUNT",
			  			       NVL(U.LIMIT_CCY_PEND_DEC_AMT,0) "PENDINGDECREASEAMOUNT",      
			  			      NVL(L.LIMIT_CCY_ACTIVE_AMT,0) - (NVL(U.LIMIT_CCY_UTILISED_AMT,0) + NVL(U.LIMIT_CCY_PEND_INC_AMT,0)) "AVAILABLITY",
			  			       NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0) "CSH_MARGIN",
			  			       NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'Y'),0) "PI_CSH_MARGIN",
			  			       NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'D'),0) "PD_CSH_MARGIN",
			  			         
								  (CASE							  
							     	   WHEN L.SHORTFALL_OFFSET <> 'CBB' AND L.SHORTFALL_OFFSET <> 'GBB' THEN 
								 	   NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_NCV_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0)||'' 
									 ELSE   
								     'NA'
									 END )AS NCV,
									 
								  (CASE							  
							     	   WHEN L.SHORTFALL_OFFSET <> 'CBB' AND L.SHORTFALL_OFFSET <> 'GBB' THEN 
								 	  NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_NCV_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'Y'),0)||''
									 ELSE   
								      'NA'
									 END )AS PI_NCV, 
									 
								 (CASE							  
							     	   WHEN L.SHORTFALL_OFFSET <> 'CBB' AND L.SHORTFALL_OFFSET <> 'GBB' THEN 
								 	   NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_NCV_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0)||'' +
			  			      		   NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0) ||''
									 ELSE   
								      'NA'
									 END )AS TOTAL_NCV_WT_PI,
									 
								 (CASE							  
							     	 	 WHEN L.SHORTFALL_OFFSET <> 'CBB' AND L.SHORTFALL_OFFSET <> 'GBB' THEN										 
										  NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_NCV_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0)||'' +
			  			       			  NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_NCV_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'Y'),0)||'' +
			  			       			  NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'N'),0) ||''+ 
			  			      			  NVL(SCBK_P_COCOA_CDB.SCBF_C_GET_OVERALL_CM_AMT(L.LIMIT_PRODUCT_CODE,CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,?,?, 'Y'),0) ||''
									  ELSE   
								      'NA'
									  END )AS TOTAL_NCV,
								 (CASE
								    WHEN L.SHORTFALL_OFFSET = 'CBB' AND L.SHORTFALL_OFFSET= 'GBB' THEN 
								       0 
			  				        WHEN L.LIMIT_PRODUCT_CODE = '*' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_CUST_LEVEL_LTV(L.BANK_GROUP_CODE,
					                                                           L.CTY_CODE,
					                                                           L.CUST_ID,
					                                                           'N',
					                                                           'GCV')
        			  				WHEN STOP_LOSS_APPL_FLAG ='F' THEN
        					  		     SCBK_P_COCOA_CDB.SCBF_GET_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'N','GCV')
			                        WHEN STOP_LOSS_APPL_FLAG ='G' THEN 	
			                             SCBK_P_COCOA_CDB.SCBF_GET_GROUP_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'N','GCV')
			                        ELSE
			                        	 SCBK_P_COCOA_CDB.SCBF_GET_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'N','GCV')			                           	
			                      END) AS LINKED_GCV,	
									
			                  (CASE 
								  WHEN L.SHORTFALL_OFFSET = 'CBB' AND L.SHORTFALL_OFFSET= 'GBB' THEN 
								       0
			                       WHEN L.LIMIT_PRODUCT_CODE = '*' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_CUST_LEVEL_LTV(L.BANK_GROUP_CODE,
					                                                           L.CTY_CODE,
					                                                           L.CUST_ID,
					                                                           'Y',
					                                                           'GCV')
			  				   		WHEN STOP_LOSS_APPL_FLAG ='F' THEN
					  					SCBK_P_COCOA_CDB. SCBF_GET_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'Y','GCV')
			                        WHEN STOP_LOSS_APPL_FLAG ='G' THEN 	
			                             SCBK_P_COCOA_CDB.SCBF_GET_GROUP_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'Y','GCV')
			                        ELSE
			                        	SCBK_P_COCOA_CDB. SCBF_GET_LIMIT_LEVEL_LTV(L.BANK_GROUP_CODE,L.CTY_CODE,L.CUST_ID,L.LIMIT_ID,L.LIMIT_CCY_CODE,'Y','GCV')			                           	
			                    END) AS PI_LINKED_GCV,	
			                    (CASE
					                 WHEN L.LIMIT_PRODUCT_CODE = '*' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                           L.CTY_CODE,
					                                                           L.CUST_ID,
					                                                           'N',
					                                                           'N')
					                 WHEN STOP_LOSS_APPL_FLAG = 'F' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                            L.CTY_CODE,
					                                                            L.CUST_ID,
					                                                            L.LIMIT_ID,
					                                                            L.LIMIT_CCY_CODE,
					                                                            'N',
					                                                            'N')
					                 WHEN STOP_LOSS_APPL_FLAG = 'G' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_GROUP_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                                  L.CTY_CODE,
					                                                                  L.CUST_ID,
					                                                                  L.LIMIT_ID,
					                                                                  L.LIMIT_CCY_CODE,
					                                                                  'N',
					                                                                  'N')
					                 ELSE
					                  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                            L.CTY_CODE,
					                                                            L.CUST_ID,
					                                                            L.LIMIT_ID,
					                                                            L.LIMIT_CCY_CODE,
					                                                            'N',
					                                                            'N')
					               END) AS UNLINKED_GCV,
					               (CASE
					                 WHEN L.LIMIT_PRODUCT_CODE = '*' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_CUST_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                           L.CTY_CODE,
					                                                           L.CUST_ID,
					                                                           'Y',
					                                                           'N')
					                 WHEN STOP_LOSS_APPL_FLAG = 'F' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                            L.CTY_CODE,
					                                                            L.CUST_ID,
					                                                            L.LIMIT_ID,
					                                                            L.LIMIT_CCY_CODE,
					                                                            'Y',
					                                                            'N')
					                 WHEN STOP_LOSS_APPL_FLAG = 'G' THEN
					                  SCBK_P_COCOA_CDB.SCBF_GET_GROUP_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                                  L.CTY_CODE,
					                                                                  L.CUST_ID,
					                                                                  L.LIMIT_ID,
					                                                                  L.LIMIT_CCY_CODE,
					                                                                  'Y',
					                                                                  'N')
					                 ELSE
					                  SCBK_P_COCOA_CDB.SCBF_GET_FACILITY_UNLINKED_GCV(L.BANK_GROUP_CODE,
					                                                            L.CTY_CODE,
					                                                            L.CUST_ID,
					                                                            L.LIMIT_ID,
					                                                            L.LIMIT_CCY_CODE,
					                                                            'Y',
					                                                            'N')
					               END) AS PI_UNLINKED_GCV
					              FROM SCBT_R_CUST_PRODUCT_LIMIT L,SCBT_T_PROD_LIMIT_UTIL U
					             WHERE L.limit_id = U.limit_id(+) 
					               AND L.bank_group_code = U.bank_group_code(+)
					               AND L.cty_code = U.cty_code(+)
			  					   AND L.BANK_GROUP_CODE = ?
								   AND L.CTY_CODE = ?
								   AND CUST_ID = ?
								         ORDER BY L.LIMIT_SEQ_NO
			  ) WHERE CUSTOMERID = ? AND LIMITCATEGORYCODE  IN ('CI','CR') ORDER BY SEQNO ASC
INFO  - Fri Jun 21 01:28:37 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> CO_BORROWER_CUSTOMER_FACILITY_POSITION_DETAILS
Param [0]--> SCB
Param [1]--> CN
Param [2]--> SCB
Param [3]--> CN
Param [4]--> SCB
Param [5]--> CN
Param [6]--> SCB
Param [7]--> CN
Param [8]--> SCB
Param [9]--> CN
Param [10]--> SCB
Param [11]--> CN
Param [12]--> SCB
Param [13]--> CN
Param [14]--> SCB
Param [15]--> CN
Param [16]--> SCB
Param [17]--> CN
Param [18]--> SCB
Param [19]--> CN
Param [20]--> SCB
Param [21]--> CN
Param [22]--> SCB
Param [23]--> CN
Param [24]--> 800007314
Param [25]--> 800007314
Result Size --> 8
Execution time (ms)  --> 890
