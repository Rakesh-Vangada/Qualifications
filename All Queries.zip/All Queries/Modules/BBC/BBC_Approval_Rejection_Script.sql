--Script Name: SCBCOCOA22012014001D_Krishna.sql
--Date       : 22-01-2014
--Author     : Krishna
--Reviewed   : Sujeesh/Jivan
--Bug/TD     : 
--Root Cause Fixed  : Yes
--Impact to Reports : NO
--Impact to Infomanager: NO
--Description :  Approval or reject the BBC certificate : 'R' - Reject, 'A'-Approve 

---------------------------------------------------------------------------------------------------------------------------------------------
DECLARE
   actionType varchar2 (1) := 'A';
   ctyCode   varchar2 (2) := 'IN';
   bankGrpCode varchar2 (3) := 'SCB';
   custID varchar2 (16) := '800007438';
   coBorrowerID varchar2 (16) := '*';
   bbcStructure varchar2 (16) := 'CL';
   facilityGrpID varchar2 (16) := '*';
   exposureAmt    SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_PEND_INC_AMT%TYPE:=0;
   dPWniAmt   SCBT_R_BBC_DTLS_HIST.SCB_DP_WNI_CCY_AMT%TYPE:=0;
   dPAniAmt   SCBT_R_BBC_DTLS_HIST.SCB_DP_ANI_CCY_AMT%TYPE:=0;
   bbcID   SCBT_R_BBC_DTLS_HIST.BBC_ID%TYPE;
   
BEGIN

   BEGIN
     select bbc_id into bbcID FROM SCBT_R_BBC_GENERAL_DTLS_MST WHERE 
     bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID 
     and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
    EXCEPTION
    WHEN OTHERS THEN
      BEGIN
        select bbc_id into bbcID FROM SCBT_R_BBC_GENERAL_DTLS_HIST WHERE 
        bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID and step_status_code = '02'
        and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
       EXCEPTION
      WHEN OTHERS THEN 
        bbcID := null;
       END; 
    END;
    
   IF actionType = 'A' THEN
    --- General Dtls table
    
     delete FROM SCBT_R_BBC_GENERAL_DTLS_MST WHERE 
     bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID 
     and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;

    insert into SCBT_R_BBC_GENERAL_DTLS_MST (BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,CUST_ID,CO_BORROWER_ID,STRUCTURE_CODE,FACILITY_GROUP_ID,MARGIN_ON_STOCK_PCT,
    MARGIN_ON_DOM_DBTRS_PCT,MARGIN_ON_EXP_DBTRS_PCT,MARGIN_ON_ADV_SUPP_PCT,DP_CHECK_TYPE_CODE,BBC_J158_CODE,APPL_SHARE_CODE,
    CRC_SCB_SHARE_PCT,OS_SCB_SHARE_PCT,APPL_SCB_SHARE_PCT,TOTAL_INS_CCY_CODE,TOTAL_INS_CCY_AMT,ADPS_LIMIT_DROP_NO_DAYS,
    IDPS_LIMIT_DROP_NO_DAYS,ADPS_NO_DAYS_TYPE_CODE,IDPS_NO_DAYS_TYPE_CODE,
    SYNDICATION_TYPE,SYNDICATION_ID,SHARED_DB_FLAG)
    (select BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,CUST_ID,CO_BORROWER_ID,STRUCTURE_CODE,FACILITY_GROUP_ID,MARGIN_ON_STOCK_PCT,
    MARGIN_ON_DOM_DBTRS_PCT,MARGIN_ON_EXP_DBTRS_PCT,MARGIN_ON_ADV_SUPP_PCT,DP_CHECK_TYPE_CODE,BBC_J158_CODE,APPL_SHARE_CODE,
    CRC_SCB_SHARE_PCT,OS_SCB_SHARE_PCT,APPL_SCB_SHARE_PCT,TOTAL_INS_CCY_CODE,TOTAL_INS_CCY_AMT,ADPS_LIMIT_DROP_NO_DAYS,
    IDPS_LIMIT_DROP_NO_DAYS,ADPS_NO_DAYS_TYPE_CODE,IDPS_NO_DAYS_TYPE_CODE,
    SYNDICATION_TYPE,SYNDICATION_ID,SHARED_DB_FLAG from SCBT_R_BBC_GENERAL_DTLS_HIST WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID 
    and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID
    and step_status_code = '02');
    
    BEGIN
      SELECT BBC.SCB_DP_WNI_CCY_AMT,BBC.SCB_DP_ANI_CCY_AMT,
      SUM(Scbf_Tls_Exch_Rate(CORP.BANK_GROUP_CODE,CORP.CTY_CODE,CORP.LIMIT_CCY_CODE,
      (UTIL.LIMIT_CCY_PEND_INC_AMT - UTIL.LIMIT_CCY_PEND_DEC_AMT + 
      Scbk_P_Cocoa_Cdb.SCBF_GET_PROD_UTIL_AMOUNT(CORP.BANK_GROUP_CODE,CORP.CTY_CODE,CORP.CUST_ID,CORP.LIMIT_ID,CORP.LIMIT_CCY_CODE,CORP.LIMIT_PRODUCT_CODE)),BBC.BBC_OVERALL_CCY_CODE,'Y'))
      into dPWniAmt,dPAniAmt,exposureAmt       
      FROM SCBT_R_CUST_PRODUCT_LIMIT CORP,SCBT_T_PROD_LIMIT_UTIL UTIL,SCBT_R_BBC_GENERAL_DTLS_HIST GN,SCBT_R_BBC_DTLS_HIST BBC
      WHERE CORP.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND CORP.CTY_CODE = UTIL.CTY_CODE AND CORP.LIMIT_ID = UTIL.LIMIT_ID
      AND CORP.BANK_GROUP_CODE = GN.BANK_GROUP_CODE AND CORP.CTY_CODE = GN.CTY_CODE AND CORP.CUST_ID = GN.CUST_ID
      AND NVL(CORP.CO_BORROWER_ID,'*') = GN.CO_BORROWER_ID AND GN.STEP_STATUS_CODE = '02'
      AND BBC.BANK_GROUP_CODE = GN.BANK_GROUP_CODE AND BBC.CTY_CODE = GN.CTY_CODE AND BBC.BBC_ID = GN.BBC_ID AND BBC.ACTIVE_BBC_FLAG = 'Y'
      AND CORP.LIMIT_CAT_CODE <> 'V' AND CORP.SHORTFALL_OFFSET = 'CBB' AND NVL(CORP.BB_DP_FLAG,'N') = 'Y' 
      AND CORP.BANK_GROUP_CODE = bankGrpCode AND CORP.CTY_CODE = ctyCode AND GN.CUST_ID = custID
      AND NVL(GN.CO_BORROWER_ID,'*') = coBorrowerID AND BBC.BBC_ID = bbcID
      GROUP BY GN.CUST_ID,GN.BBC_ID,BBC.BBC_OVERALL_CCY_CODE,BBC.APPL_DP_CCY_AMT,BBC.SCB_DP_WNI_CCY_AMT,BBC.SCB_DP_ANI_CCY_AMT;
    EXCEPTION
    WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exception caught: '||SQLERRM);
    END;
  
     IF(exposureAmt >  dPWniAmt) THEN
        update SCBT_R_BBC_GENERAL_DTLS_MST set SHORTFALL_SINCE_WNI_DATE = (select business_date from scbt_s_daily_param 
        where bank_group_code=bankGrpCode and cty_code = ctyCode ) WHERE 
        bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID 
        and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
      END IF;
     IF(exposureAmt >  dPAniAmt) THEN
        update SCBT_R_BBC_GENERAL_DTLS_MST set SHORTFALL_SINCE_ANI_DATE = (select business_date from scbt_s_daily_param 
        where bank_group_code=bankGrpCode and cty_code = ctyCode ) WHERE 
        bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID 
        and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
      END IF; 
    
    update SCBT_R_BBC_GENERAL_DTLS_HIST set step_status_code ='03' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID and step_status_code ='02'
    and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
    
    update SCBT_R_BBC_DTLS_MST set active_bbc_flag='N' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and active_bbc_flag='Y';
    
    --- BBC Dtls Table
    insert into SCBT_R_BBC_DTLS_MST
    (BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,ACTIVE_BBC_FLAG,CERTIFICATE_DATE,RECEIVED_DATE,EXPIRY_DATE,GRACE_PERIOD,EXTENDED_EXPIRY_DATE,REMARKS,BBC_OVERALL_CCY_CODE,ROM_STOCK_CCY_CODE,ROM_STOCK_CCY_AMT,FIG_STOCK_CCY_CODE,FIG_STOCK_CCY_AMT,WIP_STOCK_CCY_CODE,WIP_STOCK_CCY_AMT,GIT_STOCK_CCY_CODE,GIT_STOCK_CCY_AMT,SNS_STOCK_CCY_CODE,SNS_STOCK_CCY_AMT,OTM_STOCK_CCY_CODE,OTM_STOCK_CCY_AMT,SLM_STOCK_CCY_CODE,SLM_STOCK_CCY_AMT,SCR_STOCK_CCY_CODE,SCR_STOCK_CCY_AMT,TOTAL_STOCK_CCY_CODE,TOTAL_STOCK_CCY_AMT,LESS_CREDITOR_CCY_CODE,LESS_CREDITOR_CCY_AMT,APPL_STOCK_CCY_CODE,APPL_STOCK_CCY_AMT,MARGIN_ON_STOCK_PCT,NET_STOCK_CCY_CODE,NET_STOCK_CCY_AMT,TOTAL_INS_CCY_CODE,TOTAL_INS_CCY_AMT,INS_WAIVER_CCY_CODE,INS_WAIVER_CCY_AMT,STOCK_RECOVER_INS_CCY_CODE,STOCK_RECOVER_INS_CCY_AMT,DOM_DBTR_CCY_CODE,DOM_DBTR_CCY_AMT,OVERDUE_CCY_CODE,OVERDUE_CCY_AMT,APPL_DBTR_CCY_CODE,APPL_DBTR_CCY_AMT,MARGIN_ON_DOM_DBTRS_PCT,NET_DOM_DBTR_CCY_CODE,NET_DOM_DBTR_CCY_AMT,ADV_SUPP_CCY_CODE,ADV_SUPP_CCY_AMT,MARGIN_ON_ADV_SUPP_PCT,NET_ADV_SUPP_CCY_CODE,NET_ADV_SUPP_CCY_AMT,EXP_DBTR_CCY_CODE,EXP_DBTR_CCY_AMT,MARGIN_ON_EXP_DBTRS_PCT,NET_EXP_DBTR_CCY_CODE,NET_EXP_DBTR_CCY_AMT,TOTAL_BD_AVAIL_DP_CCY_CODE,TOTAL_BD_AVAIL_DP_CCY_AMT,APPL_SCB_SHARE_PCT,GROSS_DP_ANI_CCY_CODE,GROSS_DP_ANI_CCY_AMT,SCB_DP_ANI_CCY_CODE
    ,SCB_DP_ANI_CCY_AMT,GROSS_DP_WNI_CCY_CODE,GROSS_DP_WNI_CCY_AMT,SCB_DP_WNI_CCY_CODE,SCB_DP_WNI_CCY_AMT,SCB_DP_BY_LB_CCY_CODE,SCB_DP_BY_LB_CCY_AMT,APPL_DP_CCY_CODE,APPL_DP_CCY_AMT,TOTAL_CMV_CCY_CODE,TOTAL_CMV_CCY_AMT,LAST_STOCK_DATE,COCOA_EXPOSURE_CCY_CODE,COCOA_EXPOSURE_CCY_AMT,LTP_EXPOSURE_CCY_CODE,LTP_EXPOSURE_CCY_AMT,SHORTFALL_FLAG,SHORTFALL_CCY_CODE,SHORTFALL_CCY_AMT,PARENT_REC_ID,SCB_SHARE_CMV_CCY_CODE,SCB_SHARE_CMV_CCY_AMT,INS_SHORTFALL_CCY_CODE,INS_SHORTFALL_CCY_AMT,TOTAL_NCV_CCY_CODE,TOTAL_NCV_CCY_AMT,TENOR,NEGATIVE_STOCK_CCY_CODE,NEGATIVE_STOCK_CCY_AMT)
    (select BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,ACTIVE_BBC_FLAG,CERTIFICATE_DATE,RECEIVED_DATE,EXPIRY_DATE,GRACE_PERIOD,EXTENDED_EXPIRY_DATE,REMARKS,BBC_OVERALL_CCY_CODE,ROM_STOCK_CCY_CODE,ROM_STOCK_CCY_AMT,FIG_STOCK_CCY_CODE,FIG_STOCK_CCY_AMT,WIP_STOCK_CCY_CODE,WIP_STOCK_CCY_AMT,GIT_STOCK_CCY_CODE,GIT_STOCK_CCY_AMT,SNS_STOCK_CCY_CODE,SNS_STOCK_CCY_AMT,OTM_STOCK_CCY_CODE,OTM_STOCK_CCY_AMT,SLM_STOCK_CCY_CODE,SLM_STOCK_CCY_AMT,SCR_STOCK_CCY_CODE,SCR_STOCK_CCY_AMT,TOTAL_STOCK_CCY_CODE,TOTAL_STOCK_CCY_AMT,LESS_CREDITOR_CCY_CODE,LESS_CREDITOR_CCY_AMT,APPL_STOCK_CCY_CODE,APPL_STOCK_CCY_AMT,MARGIN_ON_STOCK_PCT,NET_STOCK_CCY_CODE,NET_STOCK_CCY_AMT,TOTAL_INS_CCY_CODE,TOTAL_INS_CCY_AMT,INS_WAIVER_CCY_CODE,INS_WAIVER_CCY_AMT,STOCK_RECOVER_INS_CCY_CODE,STOCK_RECOVER_INS_CCY_AMT,DOM_DBTR_CCY_CODE,DOM_DBTR_CCY_AMT,OVERDUE_CCY_CODE,OVERDUE_CCY_AMT,APPL_DBTR_CCY_CODE,APPL_DBTR_CCY_AMT,MARGIN_ON_DOM_DBTRS_PCT,NET_DOM_DBTR_CCY_CODE,NET_DOM_DBTR_CCY_AMT,ADV_SUPP_CCY_CODE,ADV_SUPP_CCY_AMT,MARGIN_ON_ADV_SUPP_PCT,NET_ADV_SUPP_CCY_CODE,NET_ADV_SUPP_CCY_AMT,EXP_DBTR_CCY_CODE,EXP_DBTR_CCY_AMT,MARGIN_ON_EXP_DBTRS_PCT,NET_EXP_DBTR_CCY_CODE,NET_EXP_DBTR_CCY_AMT,TOTAL_BD_AVAIL_DP_CCY_CODE,TOTAL_BD_AVAIL_DP_CCY_AMT,APPL_SCB_SHARE_PCT,GROSS_DP_ANI_CCY_CODE,GROSS_DP_ANI_CCY_AMT,SCB_DP_ANI_CCY_CODE
    ,SCB_DP_ANI_CCY_AMT,GROSS_DP_WNI_CCY_CODE,GROSS_DP_WNI_CCY_AMT,SCB_DP_WNI_CCY_CODE,SCB_DP_WNI_CCY_AMT,SCB_DP_BY_LB_CCY_CODE,SCB_DP_BY_LB_CCY_AMT,APPL_DP_CCY_CODE,APPL_DP_CCY_AMT,TOTAL_CMV_CCY_CODE,TOTAL_CMV_CCY_AMT,LAST_STOCK_DATE,COCOA_EXPOSURE_CCY_CODE,COCOA_EXPOSURE_CCY_AMT,LTP_EXPOSURE_CCY_CODE,LTP_EXPOSURE_CCY_AMT,SHORTFALL_FLAG,SHORTFALL_CCY_CODE,SHORTFALL_CCY_AMT,PARENT_REC_ID,SCB_SHARE_CMV_CCY_CODE,SCB_SHARE_CMV_CCY_AMT,INS_SHORTFALL_CCY_CODE,INS_SHORTFALL_CCY_AMT,TOTAL_NCV_CCY_CODE,TOTAL_NCV_CCY_AMT,TENOR,NEGATIVE_STOCK_CCY_CODE,NEGATIVE_STOCK_CCY_AMT
     FROM SCBT_R_BBC_DTLS_HIST where bank_group_code =bankGrpCode and cty_Code = ctyCode and bbc_id = bbcID and active_bbc_flag='Y' and step_status_code = '02');
    
    update SCBT_R_BBC_DTLS_HIST set step_status_code ='03' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    -- BBC Bank table
    delete from SCBT_R_BBC_BANK_DTLS_MST WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID;
    
    insert into SCBT_R_BBC_BANK_DTLS_MST(BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,CUST_ID,BANK_OS_CCY_CODE,BANK_OS_CCY_AMT)
    (select BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,CUST_ID,BANK_OS_CCY_CODE,BANK_OS_CCY_AMT 
    from SCBT_R_BBC_BANK_DTLS_HIST WHERE bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code = '02');
    
    update SCBT_R_BBC_BANK_DTLS_HIST set step_status_code ='03' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    -- BBC INS Table
    delete from SCBT_R_BBC_INS_DTLS_MST WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID;
    
    insert into SCBT_R_BBC_INS_DTLS_MST(BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID, REC_ID,POLICY_NO,INS_COMPANY_ID,INS_CCY_CODE,
    INS_CCY_AMT,INS_EXPIRED_DATE,INS_INVALID_FLAG,INS_INVALID_REASON)
    (select BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID, REC_ID,POLICY_NO,INS_COMPANY_ID,INS_CCY_CODE,
    INS_CCY_AMT,INS_EXPIRED_DATE,INS_INVALID_FLAG,INS_INVALID_REASON from SCBT_R_BBC_INS_DTLS_HIST 
    where bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02');

    update SCBT_R_BBC_INS_DTLS_HIST set step_status_code ='03' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    -- BBC Collateral Dtls
    delete FROM SCBT_T_BBC_COLLATERAL_DTLS_MST WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID;

    insert into SCBT_T_BBC_COLLATERAL_DTLS_MST(BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,CUST_ID,J158_CODE,J158_CTY_CODE,
    FSV_PCT,CMV_CCY_AMT,CMV_CCY_CODE)
    (select BANK_GROUP_CODE,CTY_CODE,STEP_ID,BBC_ID,REC_ID,CUST_ID,J158_CODE,J158_CTY_CODE,
    FSV_PCT,CMV_CCY_AMT,CMV_CCY_CODE FROM SCBT_T_BBC_COLLATERAL_DTLS_HST WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02');
    
    update SCBT_T_BBC_COLLATERAL_DTLS_HST set step_status_code ='03' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';

   END IF;
   
   IF actionType = 'R' THEN
    update SCBT_R_BBC_GENERAL_DTLS_HIST set step_status_code ='11' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and CUST_ID=custID and step_status_code ='02'
    and co_borrower_id=coBorrowerID and structure_code=bbcStructure and facility_group_id=facilityGrpID;
    
    update SCBT_R_BBC_DTLS_HIST set step_status_code ='11' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    update SCBT_R_BBC_BANK_DTLS_HIST set step_status_code ='11' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    update SCBT_R_BBC_INS_DTLS_HIST set step_status_code ='11' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
    update SCBT_T_BBC_COLLATERAL_DTLS_HST set step_status_code ='11' WHERE 
    bank_group_code=bankGrpCode and cty_code = ctyCode and BBC_ID=bbcID and step_status_code ='02';
    
   END IF;
END;
/
---------------------------------------------------------------------------------------------------------------------------------------------
