select * from SCBT_T_CUST_GRP_CLT_OFFSET_MST where deal_step_id='GB779T00112M0001' and page_source='DDB' 
and client_group_indicator='CLIENT' and limit_classification='SC' ;

SELECT * FROM SCBT_T_CUST_SFALL_OFFSET_MST where deal_step_id = 'GB779T00112M0001' 
and page_source='DDB' 
and shortfall_offset='CUL' 
and limit_classification='SC';

--Customer maintenancne

select * from SCBT_R_CUST_ACCT_MAINTENANCE where cust_id='800000772';


--Customer limit setup

-- Collateral limit tab

SELECT * from SCBT_R_CUST_COLLAT_LIMIT where cust_id='800000772';

-- prod limit tab

select * from SCBT_R_CUST_PRODUCT_LIMIT where cust_id='800000772';

-- Deal registeration

select * from SCBT_T_DEAL_REGISTER_HDR_MST where cust_id='800000772' and deal_id='GB779T00112';

-- Transaction in DDB, while tab out from contengent to transaction

select * from SCBT_T_COLLATERAL_REGISTER_HST where cust_id='800000772' and deal_id='GB779T00112';

-- For the first time rec id will be differ and parcel type code as MST and CON
select * from SCBT_T_PARCEL_HST where deal_id='GB779T00112' ;

select * from SCBT_T_TXN_HST where cust_id='800000772' and deal_id='GB779T00112' ;

-- After Submit

select * from SCBT_T_LIMIT_RESP_HEADER where business_event_id='GB779T00112M0001';

select * from SCBT_T_LIMIT_RESP_DTLS where obligor_id='800000772' and limit_id='415100'; 

-- After RFA

select * from SCBT_T_DEAL_MST where cust_id='800000772' and deal_id='GB779T00112' ;

select * from SCBT_T_COLLATERAL_REGISTER_MST where cust_id='800000772' and deal_id='GB779T00112' ;

-- we are using collateral limit id

select * from SCBT_T_PARCEL_MST where deal_id='GB779T00112' and collateral_limit_id='415101';

-- we are using prod limit id

select * from SCBT_T_TXN_MST where cust_id='800000772' and deal_id='GB779T00112' ;

select * from SCBT_T_TXN_EVENTS_DTLS where deal_step_id='GB779T00112M0001';

select * from SCBT_T_TXN_CR_LINKAGE_MST where cust_id='800000772' and deal_id='GB779T00112' and deal_step_id='GB779T00112M0001';

select * from SCBT_T_PROD_LIMIT_REQ_LOG where bus_event_ref_no='GB779T00112M0001';

select * from SCBT_T_PROD_LIMIT_REQ_LOG_DTL where deal_id='GB779T00112' and init_req_id='103735445';

select * from SCBT_T_PROD_LIMIT_UTIL where limit_id='415100';

select * from SCBT_T_PROD_LIMIT_MVMT where obligor_id='800000772' and limit_id='415100';

select * from SCBT_T_DEAL_HIST where cust_id='800000772' and deal_id='GB779T00112';

select * from SCBT_T_COLL_LIMIT_REQ_LOG where  bus_event_ref_no='GB779T00112M0001';

select * from SCBT_T_COLL_LIMIT_UTIL where limit_id='415101';

select * from SCBT_T_COLL_LIMIT_MVMT where limit_id='415101';

select * from SCBT_T_PROD_LIMIT_REQ_LOG_DTL where obligor_id='800000772';
