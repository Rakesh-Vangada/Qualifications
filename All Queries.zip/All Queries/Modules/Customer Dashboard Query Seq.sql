
====================================================== Collateral Position========================================================
BB Shortfall

Shortfall
	Group
	
	RETRIEVE_RESP_COLL_SUMMARY (Group Summary)
	===========================================
	SELECT a.LIMIT_ID,
	(SELECT LIMIT_NAME FROM SCBT_R_CUST_PRODUCT_LIMIT 
	where BANK_GROUP_CODE = a.BANK_GROUP_CODE 
	AND CTY_CODE = a.CTY_CODE
	AND CUST_ID = a.CUST_ID 
	AND LIMIT_ID = a.LIMIT_ID) AS LIMIT_NAME,
	a.FACILITY_EXPOSURE_CCY,a.FACILITY_EXPOSURE_AMT,a.FACILITY_NCV_AMT,a.FACILITY_CMR_AMT,
	a.CASH_FOR_EXP_OFFSET_AMT,a.FACILITY_GROUP_NAME FROM SCBT_T_CUST_SFALL_OFFSET_MST a 
	WHERE a.BANK_GROUP_CODE = 'SCB'  AND a.CTY_CODE = 'GB'
	AND a.CUST_ID = '800002531' AND a.SHORTFALL_OFFSET = 'GFL' AND a.PAGE_SOURCE='CDB';
	
	
	
	
	
	Client
	
		RETRIEVE_RESP_CLIENT_SUMMARY_DTLS (Table)
		=========================================	       
		SELECT a.LIMIT_ID,
		(SELECT LIMIT_NAME FROM SCBT_R_CUST_PRODUCT_LIMIT 
		where BANK_GROUP_CODE = a.BANK_GROUP_CODE 
		AND CTY_CODE = a.CTY_CODE
		AND CUST_ID = a.CUST_ID 
		AND LIMIT_ID = a.LIMIT_ID) AS LIMIT_NAME,
		a.FACILITY_EXPOSURE_CCY,a.FACILITY_EXPOSURE_AMT,a.FACILITY_NCV_AMT,a.FACILITY_CMR_AMT,
		a.CASH_FOR_EXP_OFFSET_AMT,a.FACILITY_GROUP_ID FROM SCBT_T_CUST_SFALL_OFFSET_MST a 
		WHERE a.BANK_GROUP_CODE = 'SCB' AND a.CTY_CODE = 'GB' AND a.CUST_ID = '800002531'
		AND a.SHORTFALL_OFFSET = 'CUL' AND a.PAGE_SOURCE='CDB';
		
		RETRIEVE_RESP_CLIENT_GRP_SUMMARY
		================================
		SELECT LIMIT_ID, FACILITY_EXPOSURE_CCY, FACILITY_EXPOSURE_AMT, FACILITY_NCV_AMT, FACILITY_CMR_AMT,
		CASH_FOR_EXP_OFFSET_AMT, HF_ACC_BALANCE,LINKED_ACCOUNT_BALANCE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
		WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531'
		AND  CLIENT_GROUP_INDICATOR = 'CLIENT'  AND PAGE_SOURCE='CDB';
		
		CDB_CLIENT_UNSECURED_DETAILS
		============================
		SELECT FACILITY_EXPOSURE_AMT,FACILITY_NCV_AMT, FACILITY_CMR_AMT,CASH_FOR_EXP_OFFSET_AMT,
		EFF_NCV_COLL_CAP,EFF_NCV_COLL_GRP_CAP,HF_ACC_BALANCE,LINKED_ACCOUNT_BALANCE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
		WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531'
		AND CLIENT_GROUP_INDICATOR='CLIENT' AND PAGE_SOURCE='CDB' AND LIMIT_ID='CU';
		
		Effect Ncv coll cap(same is available in the above query)
		==========================================================
		SELECT NVL(sum( d.ncv_txn_ccy_amt), 0)
		FROM SCBT_T_coll_LIMIT_REQ_LOG R,
		SCBT_T_Coll_LIMIT_REQ_LOG_DTL D
		WHERE R.BANK_GROUP_CODE  = 'SCB'
		AND R.CTY_CODE             = 'GB'
		AND R.REQ_TYPE_CODE    = 'NEW'
		and d.obligor_id='800002531' 
		AND R.REQ_STATUS_CODE  in ('PEND','CON')
		AND R.BANK_GROUP_CODE = D.BANK_GROUP_CODE
		AND R.CTY_CODE = D.CTY_CODE
		AND R.INIT_REQ_ID         = D.INIT_REQ_ID
		AND D.COLLATERAL_LIMIT_ID in ('18622','18623','18624');
		
		
================================================= Customer Exposure =============================================================================================	
CUSTOMER_FACILITY_POSITION_DETAILS_UK
======================================
SELECT  limitcategory, limitid, scilimitid, innertoid, NVL (limitname, ' '),
         productcode, limitccy, activelimit, prodwise_util, utilisation,
         pendingincreaseamount,
         Scbf_Get_Acc_Balance (bgcode,
                               ctycode,
                               customerid,
                               limitid,
                               limitccy,
                               'O'
                              ) AS balance,
         availablity, pendingdecreaseamount, ncv, pi_ncv, csh_margin,
         pi_csh_margin, pd_csh_margin, shortfalloffset, desired_ltv,
         stop_loss_pct, stop_loss_value, calculated_ltv_pct,
         calculated_ltv_pct_with_pi, linked_gcv, pi_linked_gcv, unlinked_gcv,
         pi_unlinked_gcv, cash_top_up, total_ncv_wt_pi, total_ncv,
         shorfall_amt_gcv, group_name,
         NVL (Scbf_C_Get_Code_Desc ('SCB',
                                    '*',
                                    '*',
                                    'EN',
                                    'CI124',
                                    productcode,
                                    1
                                   ),
              ' '
             ),
         comments,LIMIT_REMARKS
    FROM (SELECT   l.bank_group_code "BGCODE", l.cty_code "CTYCODE",
                   l.limit_seq_no "SEQNO", l.cust_id "CUSTOMERID",
                   l.limit_cat_code "LIMITCATEGORY",
                   Scbf_C_Get_Code_Desc
                                       (l.bank_group_code,
                                        l.cty_code,
                                        '*',
                                        'EN',
                                        'CD032',
                                        l.shortfall_offset,
                                        1
                                       ) "SHORTFALLOFFSET",
                   l.limit_name "LIMITNAME",
                   DECODE (l.limit_product_code,
                           '*', 'OVERALL LIMIT',
                           l.limit_product_code
                          ) "PRODUCTCODE",
                   NVL
                      (Scbf_C_Get_Code_Desc ('SCB',
                                             '*',
                                             '*',
                                             'EN',
                                             'CI124',
                                             l.limit_product_code,
                                             1
                                            ),
                       ' '
                      ) "PRODUCTDESCRIPTION",
                   l.limit_id "LIMITID", l.ext_limit_id "SCILIMITID",
                   l.inner_to_id "INNERTOID", l.limit_ccy_code "LIMITCCY",
                   NVL (l.limit_ccy_active_amt, 0) "ACTIVELIMIT",
                   DECODE
                      (l.limit_product_code,
                       '*', 0,
                       NVL
                          (Scbk_P_Cocoa_Cdb.scbf_get_prod_util_amt_with_cb
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            l.ext_limit_id
                                                           ),
                           0
                          )
                      ) "PRODWISE_UTIL",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0) "UTILISATION",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0) "PENDINGINCREASEAMOUNT",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_dec_amt,
                                                   0)
                                             ), 0) "PENDINGDECREASEAMOUNT",
                   NVL (u.comments, '') "COMMENTS",NVL (u.LIMIT_REMARKS, '') "LIMIT_REMARKS",
                   (  NVL (l.limit_ccy_active_amt, 0)
                    +  NVL(Scbf_Get_Acc_Balance(l.Bank_Group_Code, l.Cty_Code, l.Cust_Id, l.Limit_Id, l.Limit_Ccy_Code,'O'),0)
                    - (  NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0)
                       + NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0)
                      )
                   ) "AVAILABLITY",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                       0
                      ) "NCV",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                       0
                      ) "PI_NCV",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                       0
                      ) "CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                       0
                      ) "PI_CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                        'SCB',
                                                         'GB',
                                                         'D'
                                                        ),
                       0
                      ) "PD_CSH_MARGIN",
                     NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        ) "TOTAL_NCV_WT_PI",
                     NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                         0
                        ) "TOTAL_NCV",
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS desired_ltv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS stop_loss_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_PARTY_MST
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND party_id = l.cust_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_PRODUCT_LIMIT
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_FACILITY_GRP
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                  0
                                 )
                       ELSE 0
                    END
                   ) AS stop_loss_value,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct_with_pi,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                    END
                   ) AS linked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                    END
                   ) AS pi_linked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                    END
                   ) AS unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                    END
                   ) AS pi_unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_topup_amt
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_topup_amt_by_level
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            '',
                                                            '',
                                                            '',
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            '',
                                                            'F'
                                                           )
                    END
                   ) AS cash_top_up,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_level_shortfall
                                        (l.bank_group_code,
                                         l.cty_code,
                                         l.cust_id,
                                         l.limit_id,
                                         Scbf_Get_Exp_Ccy (l.bank_group_code,
                                                           l.cty_code,
                                                           l.cust_id
                                                          ),
                                         'A'
                                        )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                    END
                   ) AS shorfall_amt_gcv,
                   (SELECT facliity_grp_name
                      FROM SCBT_R_CUST_FACILITY_GRP
                     WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ','))
                                      AS group_name
             FROM SCBT_R_CUST_PRODUCT_LIMIT l,SCBT_T_PROD_LIMIT_UTIL u
             WHERE l.limit_id = u.limit_id(+) 
               AND l.bank_group_code = u.bank_group_code(+)
               AND l.cty_code = u.cty_code(+)
               AND l.bank_group_code = 'SCB' AND l.cty_code = 'GB' AND cust_id = '800002531'
          ORDER BY l.limit_seq_no)
       WHERE bgcode = 'SCB' and ctycode = 'GB' and customerid = '800002531' AND limitcategory <>'CI'
     ORDER BY seqno ASC
	 
	 ==================================================== UTILISATION SUMMARY ======================================================
	 CUSTOMER_DASHBOARD_UTIL_DETAILS_FOR_OVERALL_LIMIT & CUSTOMER_DASHBOARD_UTIL_DETAILS_FOR_OVERALL_LIMIT_PI
	 
	 
	 CUSTOMER_DASHBOARD_UTIL_DETAILS_FOR_OVERALL_LIMIT (AE) on clicking customer exposure (limit)
	 ===============================================================================================
	 SELECT  Scbf_Get_Party_Name(P.BANK_GROUP_CODE, NVL(P.CO_BORROWER_ID, P.CUST_ID))AS CUST_NAME, T.TP_REF_ID,  T.DEAL_ID,
                       T.TXN_REF_ID,
                       TO_CHAR(T.MATURITY_DATE, 'DD-MM-YYYY'),
                        (CASE 
                         WHEN T.TXN_STEP_CODE = 'DRAW' THEN
                               'DWG'
                         WHEN T.TXN_STEP_CODE = 'SETT' THEN
                               'SETT'
                         ELSE
                               T.PRODUCT_CODE
                         END
                       ),                       
                        P.LIMIT_CCY_CODE,
                       Scbf_Tls_Exch_Rate(T.BANK_GROUP_CODE,
                                          T.CTY_CODE,
                                          T.TXN_CCY_CODE,
                                          (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                          P.LIMIT_CCY_CODE,
                                          'Y') AS LIMIT_AMT,
                       T.TXN_CCY_CODE,
                       (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) AS TXN_CCY_AMT,                             
                        Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                     T.cty_Code,
                                                                     T.CUST_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     T.TXN_REC_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     '') AS NCV_COVERAGE_AMT,
                     Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                            T.cty_Code,
                                            cash_margin_ccy_code,
                                            cash_margin_ccy_amt - NVL(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,
                                            'N') AS CASH_MARGIN,
                      CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' THEN                        
                     Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                     T.cty_Code,
                                                                     T.CUST_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     T.TXN_REC_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     '') +
                       Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                            T.cty_Code,
                                            cash_margin_ccy_code,
                                            NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,
                                            'N')||'' ELSE 'NA' END AS TOTAL_COVER,
                                            
                    CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' AND T.SHORTFALL_OFFSET_TYPE <>'PC' THEN                                            
                     DECODE(T.SHORTFALL_OFFSET_TYPE,'CL',0,(NVL((NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                              T.cty_Code,
                                                                              T.CUST_ID,
                                                                              T.TXN_CCY_CODE,
                                                                              T.TXN_REC_ID,
                                                                              T.TXN_CCY_CODE,
                                                                              'UTIL',
                                                                              'M',
                                                                              '')||'' +
                                Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                                     T.cty_Code,
                                                     cash_margin_ccy_code,
                                                     NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                                     TXN_CCY_CODE,
                                                     'N'),0))||'' -
                           ((NVL(T.TXN_CCY_NET_AMT, 0) - NVL(T.TXN_CCY_UTIL_AMT, 0))),
                           0)))||'' ELSE 'NA' END AS SFALLEXCESS,
                           NVL((SELECT LOAN_TO_VALUE_PCT 
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS DESIRED_LTV,
                           NVL((SELECT STOP_LOSS_PCT 
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS STOP_LOSS_PCT,
                           SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_LTV_ENQ(T.BANK_GROUP_CODE,
                                                          T.CTY_CODE,
                                                          T.CUST_ID,
                                                          T.TXN_REF_ID,
                                                          T.TXN_REC_ID,
                                                          T.PROD_LIMIT_ID,
                                                          T.TXN_CCY_CODE,
                                                          (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) ,
                                                           '',
                                                           'M',
                                                           T.TXN_STEP_CODE) AS CALC_LTV,
                          SCBK_P_COCOA_CDB.SCBF_C_GET_GCV_BY_TXN_REC_ID(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_REC_ID,
                                                            T.TXN_CCY_CODE,
                                                            'UTIL',
                                                             'M',
                                                             T.TXN_STEP_CODE) AS LINKED_GCV,
                          SCBK_P_COCOA_CDB.SCBF_GET_TOPUP_AMT_BY_LEVEL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                            T.TXN_CCY_CODE,
                                                            P.LIMIT_ID,
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_CCY_CODE,
                                                            'T') AS CASH_TOP_UP,
                           NVL((SELECT STOP_LOSS_CCY_AMT FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS STOP_LOSS_VALUE,
                           NVL(SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_SHORTFALL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                           (NVL(T.TXN_CCY_NET_AMT,0) - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_STEP_CODE, 
                                                           'N',
                                                           'M',
                                                           'N',
                                                           T.CASH_MARGIN_ADJ,                                                              
                                                           T.CASH_MARGIN_ADJ_AMT,
                                                           T.TXN_CCY_CODE,
                                                           NVL(T.cash_margin_ccy_amt,0) - NVL(T.CM_CCY_RELEASE_AMT,0),
                                                           T.CASH_MARGIN_CCY_AMT,
                                                           0,
                                                           T.PROD_LIMIT_ID),0) AS SHORTFALL_AMOUNT       
                  FROM SCBT_T_TXN_MST T, SCBT_R_CUST_PRODUCT_LIMIT P
                   WHERE T.PROD_LIMIT_ID = P.LIMIT_ID
                   AND(T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) <> 0
                   AND NVL(T.TXN_STATUS_CODE,'02') <> '11'                   
                   AND T.PRODUCT_CODE NOT IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = T.BANK_GROUP_CODE AND PM.PROD_REF_CODE ='OD')
                   AND NVL(P.FIN_HEDGE_MARGIN,'N') <> 'Y'                   
                   AND T.BANK_GROUP_CODE ='SCB'
                   AND T.CTY_CODE = 'AE'
                   AND T.CUST_ID = '800005815'
                   AND T.PROD_LIMIT_ID LIKE '%'
	 
	 CUST_DASHBORD_GET_OD_HEDGE_UTILISATION_LIMIT_QUERY
	 ===================================================
	 SELECT 'O' AS LIMIT_TYPE,SCBF_GET_PARTY_NAME (PROD.BANK_GROUP_CODE, PROD.CUST_ID) CUSTOMERNME,HST.DEAL_ID,PROD.LIMIT_PRODUCT_CODE,'' ACOUNT,'' AS ACC_TYPE,PROD.LIMIT_CCY_CODE,
				SUM(SCBF_GET_OD_UTIL_AMT(PROD.BANK_GROUP_CODE, PROD.CTY_CODE,PROD.CUST_ID,AM.ACC_CCY_CODE,AM.ACC_NO,PROD.LIMIT_CCY_CODE,'UM')) AS APPROVED_BALANCE,
				SUM(SCBF_GET_OD_UTIL_AMT(PROD.BANK_GROUP_CODE, PROD.CTY_CODE,PROD.CUST_ID,AM.ACC_CCY_CODE,AM.ACC_NO,PROD.LIMIT_CCY_CODE,'PI')) AS PI_BALANCE,
				SUM(SCBF_GET_OD_UTIL_AMT(PROD.BANK_GROUP_CODE, PROD.CTY_CODE,PROD.CUST_ID,AM.ACC_CCY_CODE,AM.ACC_NO,PROD.LIMIT_CCY_CODE,'PD')) AS PD_BALANCE,
				PROD.EXT_LIMIT_ID,''
			FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,
				 SCBT_R_CUST_ACCT_MAINTENANCE AM,
				 SCBT_T_DEAL_REGISTER_HDR_MST HST
			WHERE PROD.BANK_GROUP_CODE = AM.BANK_GROUP_CODE 
				AND PROD.CTY_CODE = AM.CTY_CODE 
				AND PROD.CUST_ID = AM.CUST_ID  
				AND PROD.BANK_GROUP_CODE = HST.BANK_GROUP_CODE 
				AND PROD.CTY_CODE = HST.CTY_CODE 
				AND PROD.CUST_ID = HST.CUST_ID
				AND AM.BANK_GROUP_CODE = HST.BANK_GROUP_CODE 
				AND AM.CTY_CODE = HST.CTY_CODE 
				AND AM.CUST_ID = HST.CUST_ID 
				AND PROD.LIMIT_ID = HST.PROD_LIMIT_ID 
				AND HST.BUSINESS_TYPE <> 'FLC'
				AND REGEXP_SUBSTR ( ',' || PROD.OVERDRAFT_FACILITY_ACCNO || ',' , ',' || AM.ACC_CCY_CODE||':'||AM.ACC_NO || ',', 1, 1 ) =( ',' || AM.ACC_CCY_CODE||':'||AM.ACC_NO|| ',')
				AND PROD.BANK_GROUP_CODE = ? AND PROD.CTY_CODE = ? AND PROD.CUST_ID = ? 
				AND PROD.LIMIT_ID IN(SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT 
			                     WHERE BANK_GROUP_CODE = HST.BANK_GROUP_CODE AND CTY_CODE = HST.CTY_CODE
			                           START WITH LIMIT_ID = ?
			                     	   CONNECT BY PRIOR EXT_LIMIT_ID = INNER_TO_ID 
			                     	           AND BANK_GROUP_CODE = ? 
			                     	           AND CTY_CODE = ? 
			                     	           AND CUST_ID = ?)                
			GROUP BY SCBF_GET_PARTY_NAME (PROD.BANK_GROUP_CODE, PROD.CUST_ID),HST.DEAL_ID,PROD.LIMIT_PRODUCT_CODE,PROD.LIMIT_CCY_CODE,PROD.EXT_LIMIT_ID                               
			UNION ALL
			SELECT LIMIT_TYPE, CUSTOMERNAME, DEAL_ID, LIMIT_PRODUCT_CODE, ACC_NO,ACC_TYPE, TXN_CCY_CODE,
				SCBF_GET_OD_UTIL_AMT(BANK_GROUP_CODE, CTY_CODE,CUST_ID,TXN_CCY_CODE,ACC_NO,TXN_CCY_CODE,'UM') AS APPROVED_BALANCE,
				SCBF_GET_OD_UTIL_AMT(BANK_GROUP_CODE, CTY_CODE,CUST_ID,TXN_CCY_CODE,ACC_NO,TXN_CCY_CODE,'PI') AS PI_BALANCE,
				SCBF_GET_OD_UTIL_AMT(BANK_GROUP_CODE, CTY_CODE,CUST_ID,TXN_CCY_CODE,ACC_NO,TXN_CCY_CODE,'PD') AS PD_BALANCE,
				'', EXT_LIMIT_ID FROM (
			      SELECT DISTINCT 'I' AS LIMIT_TYPE,'' CUSTOMERNAME,'' DEAL_ID,''LIMIT_PRODUCT_CODE,ACC.ACC_NO,
			      SCBF_C_GET_CODE_DESC(PROD.BANK_GROUP_CODE, PROD.CTY_CODE, '*', 'EN', 'CI223',AM.ACC_TYPE_CODE, 1) AS ACC_TYPE,ACC.TXN_CCY_CODE,                    
			      '',PROD.EXT_LIMIT_ID,PROD.BANK_GROUP_CODE,PROD.CTY_CODE, PROD.CUST_ID, AM.ACC_CCY_CODE,PROD.LIMIT_CCY_CODE
			      FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,
			      		SCBT_T_CUST_ACC_ACTIVITY_MST ACC,
			      		SCBT_R_CUST_ACCT_MAINTENANCE AM
			      WHERE ACC.BANK_GROUP_CODE = AM.BANK_GROUP_CODE 
			      		AND ACC.CTY_CODE = AM.CTY_CODE 
			      		AND AM.ACC_NO = ACC.ACC_NO 
			      		AND AM.ACC_CCY_CODE = ACC.TXN_CCY_CODE
			      		AND ACC.CUST_ID = AM.CUST_ID 
			      		AND PROD.BANK_GROUP_CODE = ACC.BANK_GROUP_CODE 
			      		AND PROD.CTY_CODE = ACC.CTY_CODE 
			      		AND PROD.CUST_ID = ACC.CUST_ID
			      		AND ACC.BANK_GROUP_CODE = PROD.BANK_GROUP_CODE 
			      		AND ACC.CTY_CODE = PROD.CTY_CODE 
			      		AND ACC.CUST_ID = PROD.CUST_ID 
			      		AND REGEXP_SUBSTR ( ',' || PROD.OVERDRAFT_FACILITY_ACCNO || ',' , ',' || AM.ACC_CCY_CODE||':'||AM.ACC_NO || ',', 1, 1 ) =( ',' || AM.ACC_CCY_CODE||':'||AM.ACC_NO|| ',')
			      		AND PROD.BANK_GROUP_CODE = ? 
			      		AND PROD.CTY_CODE = ? 
			      		AND PROD.CUST_ID = ? 
			      		AND PROD.LIMIT_ID IN(SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT 
			                           WHERE BANK_GROUP_CODE = ACC.BANK_GROUP_CODE 
			                           AND CTY_CODE = ACC.CTY_CODE 
			                           AND CUST_ID = ACC.CUST_ID
			                           START WITH LIMIT_ID = ? CONNECT BY PRIOR  EXT_LIMIT_ID = INNER_TO_ID
			                           AND BANK_GROUP_CODE = ? 
			                           AND CTY_CODE = ? 
			                           AND CUST_ID = ? )
	 ========================================================UK===============================================================
	 SELECT  Scbf_Get_Party_Name(P.BANK_GROUP_CODE, NVL(P.CO_BORROWER_ID, P.CUST_ID))AS CUST_NAME, T.TP_REF_ID,  T.DEAL_ID,
                       T.TXN_REF_ID,
                       TO_CHAR(T.MATURITY_DATE, 'DD-MM-YYYY'),
                        (CASE 
                         WHEN T.TXN_STEP_CODE = 'DRAW' THEN
                               'DWG'
                         WHEN T.TXN_STEP_CODE = 'SETT' THEN
                               'SETT'
                         ELSE
                               T.PRODUCT_CODE
                         END
                       ),                       
                        P.LIMIT_CCY_CODE,
                       Scbf_Tls_Exch_Rate(T.BANK_GROUP_CODE,
                                          T.CTY_CODE,
                                          T.TXN_CCY_CODE,
                                          (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                          P.LIMIT_CCY_CODE,
                                          'Y') AS LIMIT_AMT,
                       T.TXN_CCY_CODE,
                       (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) AS TXN_CCY_AMT,                             
                        Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                     T.cty_Code,
                                                                     T.CUST_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     T.TXN_REC_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     '') AS NCV_COVERAGE_AMT,
                     Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                            T.cty_Code,
                                            cash_margin_ccy_code,
                                            cash_margin_ccy_amt - NVL(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,
                                            'N') AS CASH_MARGIN,
                      CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' THEN                        
                     Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                     T.cty_Code,
                                                                     T.CUST_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     T.TXN_REC_ID,
                                                                     T.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     '') +
                       Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                            T.cty_Code,
                                            cash_margin_ccy_code,
                                            NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,
                                            'N')||'' ELSE 'NA' END AS TOTAL_COVER,
                                            
                    CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' AND T.SHORTFALL_OFFSET_TYPE <>'PC' THEN                                            
                     DECODE(T.SHORTFALL_OFFSET_TYPE,'CL',0,(NVL((NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                                              T.cty_Code,
                                                                              T.CUST_ID,
                                                                              T.TXN_CCY_CODE,
                                                                              T.TXN_REC_ID,
                                                                              T.TXN_CCY_CODE,
                                                                              'UTIL',
                                                                              'M',
                                                                              '')||'' +
                                Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                                     T.cty_Code,
                                                     cash_margin_ccy_code,
                                                     NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                                     TXN_CCY_CODE,
                                                     'N'),0))||'' -
                           ((NVL(T.TXN_CCY_NET_AMT, 0) - NVL(T.TXN_CCY_UTIL_AMT, 0))),
                           0)))||'' ELSE 'NA' END AS SFALLEXCESS,
                           NVL((SELECT LOAN_TO_VALUE_PCT 
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS DESIRED_LTV,
                           NVL((SELECT STOP_LOSS_PCT 
                              FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS STOP_LOSS_PCT,
                           SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_LTV_ENQ(T.BANK_GROUP_CODE,
                                                          T.CTY_CODE,
                                                          T.CUST_ID,
                                                          T.TXN_REF_ID,
                                                          T.TXN_REC_ID,
                                                          T.PROD_LIMIT_ID,
                                                          T.TXN_CCY_CODE,
                                                          (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) ,
                                                           '',
                                                           'M',
                                                           T.TXN_STEP_CODE) AS CALC_LTV,
                          SCBK_P_COCOA_CDB.SCBF_C_GET_GCV_BY_TXN_REC_ID(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_REC_ID,
                                                            T.TXN_CCY_CODE,
                                                            'UTIL',
                                                             'M',
                                                             T.TXN_STEP_CODE) AS LINKED_GCV,
                          SCBK_P_COCOA_CDB.SCBF_GET_TOPUP_AMT_BY_LEVEL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                            T.TXN_CCY_CODE,
                                                            P.LIMIT_ID,
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_CCY_CODE,
                                                            'T') AS CASH_TOP_UP,
                           NVL((SELECT STOP_LOSS_CCY_AMT FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = T.PROD_LIMIT_ID AND STOP_LOSS_APPL_FLAG='T'),0) AS STOP_LOSS_VALUE,
                           NVL(SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_SHORTFALL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                           (NVL(T.TXN_CCY_NET_AMT,0) - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_STEP_CODE, 
                                                           'N',
                                                           'M',
                                                           'N',
                                                           T.CASH_MARGIN_ADJ,                                                              
                                                           T.CASH_MARGIN_ADJ_AMT,
                                                           T.TXN_CCY_CODE,
                                                           NVL(T.cash_margin_ccy_amt,0) - NVL(T.CM_CCY_RELEASE_AMT,0),
                                                           T.CASH_MARGIN_CCY_AMT,
                                                           0,
                                                           T.PROD_LIMIT_ID),0) AS SHORTFALL_AMOUNT       
                  FROM SCBT_T_TXN_MST T, SCBT_R_CUST_PRODUCT_LIMIT P
                   WHERE T.PROD_LIMIT_ID = P.LIMIT_ID
                   AND(T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) <> 0
                   AND NVL(T.TXN_STATUS_CODE,'02') <> '11'
                   
                   AND T.PRODUCT_CODE NOT IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = T.BANK_GROUP_CODE AND PM.PROD_REF_CODE ='OD')
                   AND NVL(P.FIN_HEDGE_MARGIN,'N') <> 'Y'                   
                   AND T.BANK_GROUP_CODE ='SCB'
                   AND T.CTY_CODE = 'GB'
                   AND T.CUST_ID = '800007193'
                   AND T.PROD_LIMIT_ID LIKE '%';
====================================================================================================================================				   
	