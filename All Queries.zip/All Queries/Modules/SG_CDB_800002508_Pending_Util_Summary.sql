CUSTOMER_DASHBOARD_UTIL_DETAILS_PI
===================================

SELECT Scbf_Get_Party_Name(P.BANK_GROUP_CODE, NVL(P.CO_BORROWER_ID, P.CUST_ID))AS CUST_NAME, H.DEAL_ID,
                       H.TXN_REF_ID,
                       TO_CHAR(H.MATURITY_DATE, 'DD-MM-YYYY'),
                       (CASE 
                         WHEN H.TXN_STEP_CODE = 'DRAW' THEN
                               'DWG'
                         WHEN H.TXN_STEP_CODE = 'SETT' THEN
                               'SETT'
                         ELSE
                               H.PRODUCT_CODE
                         END
                       ),
                        P.LIMIT_CCY_CODE,
                       Scbf_Tls_Exch_Rate(H.BANK_GROUP_CODE,
                                          H.CTY_CODE,
                                          H.TXN_CCY_CODE,
                                          (H.TXN_CCY_NET_AMT - NVL(H.TXN_CCY_UTIL_AMT, 0)),
                                          P.LIMIT_CCY_CODE,
                                          'Y') AS LIMIT_AMT,
                       H.TXN_CCY_CODE,
                       (H.TXN_CCY_NET_AMT - NVL(H.TXN_CCY_UTIL_AMT, 0)) AS TXN_CCY_AMT,                  
                        decode(H.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(H.bank_Group_Code,
                                                                     H.cty_Code,
                                                                     H.CUST_ID,
                                                                     H.TXN_CCY_CODE,
                                                                     H.TXN_REC_ID,
                                                                     H.TXN_CCY_CODE,
                                                                     H.DEAL_STEP_ID,
                                                                     'H',
                                                                     '')) AS NCV_COVERAGE_AMT,
                       decode(H.PRODUCT_CODE,'OD','NA',Scbf_Fetch_Exch_Rate(H.bank_Group_Code,
                                            H.cty_Code,
                                            cash_margin_ccy_code,
                                            nvl(cash_margin_ccy_amt,0) - nvl(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,
                                            'N')) as CASH_MARGIN,
                    	CASE WHEN H.SHORTFALL_OFFSET_TYPE <> 'CBB' AND H.SHORTFALL_OFFSET_TYPE <>'GBB' THEN					
                       DECODE(H.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(H.bank_Group_Code,H.cty_Code,
					   												 H.CUST_ID,H.TXN_CCY_CODE,H.TXN_REC_ID,H.TXN_CCY_CODE,
                                                                     H.DEAL_STEP_ID,'H','') +
                       Scbf_Fetch_Exch_Rate(H.bank_Group_Code,H.cty_Code,cash_margin_ccy_code,NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                            TXN_CCY_CODE,'N'))ELSE 'NA' END AS TOTAL_COVER,
                                            
					  CASE WHEN H.SHORTFALL_OFFSET_TYPE <> 'CBB' AND H.SHORTFALL_OFFSET_TYPE <>'GBB' THEN
                      decode(H.PRODUCT_CODE,'OD','NA',decode(H.SHORTFALL_OFFSET_TYPE,'CL',0, (NVL((NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(H.bank_Group_Code,
                                                                              H.cty_Code,
                                                                              H.CUST_ID,
                                                                              H.TXN_CCY_CODE,
                                                                              H.TXN_REC_ID,
                                                                              H.TXN_CCY_CODE,
                                                                              H.DEAL_STEP_ID,
                                                                              'H',
                                                                              '') +
                                Scbf_Fetch_Exch_Rate(H.bank_Group_Code,
                                                     H.cty_Code,
                                                     cash_margin_ccy_code,
                                                     nvl(cash_margin_ccy_amt,0) - nvl(CM_CCY_RELEASE_AMT,0),
                                                     TXN_CCY_CODE,
                                                     'Y'),
                                0)) -
                           ((NVL(H.TXN_CCY_NET_AMT, 0) - NVL(H.TXN_CCY_UTIL_AMT, 0))),
                           0)))) ELSE 'NA' END AS SFALLEXCESS,
                           decode(H.PRODUCT_CODE,'OD','NA',NVL((SELECT LOAN_TO_VALUE_PCT 
                           	FROM SCBT_R_CUST_PRODUCT_LIMIT
                           	WHERE LIMIT_ID = ? AND STOP_LOSS_APPL_FLAG='T'),0)) AS DESIRED_LTV,
                           decode(H.PRODUCT_CODE,'OD','NA',NVL((SELECT STOP_LOSS_PCT 
                           	FROM SCBT_R_CUST_PRODUCT_LIMIT
                           	WHERE LIMIT_ID = ? AND STOP_LOSS_APPL_FLAG='T'),0)) AS STOP_LOSS_PCT,
                           decode(H.PRODUCT_CODE,'OD','NA',SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_LTV_ENQ(H.BANK_GROUP_CODE,
                                                          H.CTY_CODE,
                                                          H.CUST_ID,
													      H.TXN_REF_ID,
													      H.TXN_REC_ID,
													      H.PROD_LIMIT_ID,
													      H.TXN_CCY_CODE,
													      (NVL(DECODE(h.SCB_ROLE,'AG',h.SYNDICATED_TXN_AMT-NVL(h.SYNDICATED_UTIL_AMT,0),h.TXN_CCY_NET_AMT-NVL(h.TXN_CCY_UTIL_AMT,0)),0)),
													      H.DEAL_STEP_ID,
													      'H',
													      H.TXN_STEP_CODE)) AS CALC_LTV,
                           decode(H.PRODUCT_CODE,'OD','NA',SCBK_P_COCOA_CDB.SCBF_C_GET_GCV_BY_TXN_REC_ID(H.BANK_GROUP_CODE,
                                                                         H.CTY_CODE,
                                                                         H.CUST_ID,
                                                                         H.TXN_CCY_CODE,
                                                                         H.TXN_REC_ID,
                                                                         H.TXN_CCY_CODE,
                                                                         H.DEAL_STEP_ID,
                                                                         'H',
                                                                         H.TXN_STEP_CODE)) AS LINKED_NCV,
                           decode(H.PRODUCT_CODE,'OD','NA',SCBK_P_COCOA_CDB.SCBF_GET_TOPUP_AMT_BY_LEVEL(H.BANK_GROUP_CODE,
	                                                      H.CTY_CODE,
	                                                      H.CUST_ID,
													      H.TXN_REF_ID,
													      H.TXN_REC_ID,
													      H.TXN_CCY_CODE,
													      P.LIMIT_ID,
													      H.TXN_CCY_CODE,
													      H.TXN_CCY_CODE,
													      'T')) AS CASH_TOP_UP,
						   decode(H.PRODUCT_CODE,'OD','NA',NVL((SELECT STOP_LOSS_CCY_AMT 
                           	FROM SCBT_R_CUST_PRODUCT_LIMIT
                           	WHERE LIMIT_ID = ? AND STOP_LOSS_APPL_FLAG='T'),0)) AS STOP_LOSS_VALUE,
                            decode(H.PRODUCT_CODE,'OD','NA',NVL(SCBK_P_COCOA_CDB.SCBF_GET_TXN_LEVEL_SHORTFALL(H.BANK_GROUP_CODE,
	                                                      H.CTY_CODE,
	                                                      H.CUST_ID,
	                                                      H.TXN_REF_ID,
													      H.TXN_REC_ID,
                                             		     (NVL(H.TXN_CCY_NET_AMT,0) - NVL(H.TXN_CCY_UTIL_AMT, 0)),
                                             		      H.TXN_CCY_CODE,
                                             		      H.TXN_STEP_CODE, 
                                             		     'N',
                                             		     'H',
                                             		     H.DEAL_STEP_ID,
                                              		     H.CASH_MARGIN_ADJ,
                                              		     H.CASH_MARGIN_ADJ_AMT,
                                              		     H.TXN_CCY_CODE,
                                              		     nvl(H.cash_margin_ccy_amt,0) - nvl(H.CM_CCY_RELEASE_AMT,0),
                                              		     H.CASH_MARGIN_CCY_AMT,
                                              		     0,
                                              		     H.PROD_LIMIT_ID),0))AS SHORTFALL_AMOUNT  
                  FROM SCBT_T_TXN_HST H, SCBT_R_CUST_PRODUCT_LIMIT P, SCBT_T_DEAL_HIST DH
                 WHERE H.PROD_LIMIT_ID = P.LIMIT_ID
                   AND H.BANK_GROUP_CODE = ?
                   AND H.CUST_ID=DH.CUST_ID
                   AND H.DEAL_ID=DH.DEAL_ID
                   AND H.TXN_STEP_CODE != 'SETT' AND H.TXN_STEP_CODE != 'DSETT'
                   AND H.DEAL_STEP_ID = DH.DEAL_STEP_ID
                   AND DH.STEP_STATUS_CODE IN ('02', '10', '14')                   
                   AND H.CTY_CODE = ?
                   AND H.CUST_ID = ?
                   AND NVL(H.TXN_STATUS_CODE,'02') <> '11'
                   AND H.PROD_LIMIT_ID IN  (SELECT limit_id
                                            FROM SCBT_R_CUST_PRODUCT_LIMIT 
                                            WHERE bank_group_code = H.BANK_GROUP_CODE and cty_code = H.CTY_CODE
                                            START WITH limit_id = ?
                                            CONNECT BY PRIOR ext_limit_id = inner_to_id)
                                            
                          AND H.PRODUCT_CODE NOT IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = H.BANK_GROUP_CODE AND PM.PROD_REF_CODE ='OD')
                          					AND NVL(P.FIN_HEDGE_MARGIN,'N') <> 'Y'                   
                   AND H.TXN_REC_ID  in (SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = H.BANK_GROUP_CODE
                                      AND H1.cty_code = H.CTY_CODE
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID AND NVL(H2.txn_status_code,'0') NOT IN ('08','11')
                                      AND H1.TXN_REC_ID = H2.PARENT_TXN_REC_ID 
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
                                      UNION
                                      SELECT H1.TXN_REC_ID
                                      FROM SCBT_T_TXN_HST H1,SCBT_T_DEAL_HIST DH,SCBT_T_TXN_HST H2
                                      WHERE H1.BANK_GROUP_CODE = H.BANK_GROUP_CODE
                                      AND H1.cty_code = H.CTY_CODE
                                      AND H1.PROD_LIMIT_ID=H.PROD_LIMIT_ID
                                      AND H1.TXN_STEP_CODE <> 'DRAW'
                                      AND H1.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H1.CTY_CODE = DH.CTY_CODE
                                      AND H2.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND H2.CTY_CODE = DH.CTY_CODE
                                      AND H1.CUST_ID=DH.CUST_ID AND H1.DEAL_ID=DH.DEAL_ID AND H2.DEAL_ID=DH.DEAL_ID
                                      AND H1.DEAL_STEP_ID = DH.DEAL_STEP_ID AND H1.DEAL_STEP_ID = H2.DEAL_STEP_ID 
                                      AND H1.PARENT_TXN_REC_ID = H2.TXN_REC_ID AND  H1.TXN_REC_ID <> H2.TXN_REC_ID
                                      AND DH.STEP_STATUS_CODE IN ('02', '10', '14')) order by deal_id,txn_ref_id ,txn_rec_id asc
INFO  - Tue Mar 26 00:30:01 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> CUSTOMER_DASHBOARD_UTIL_DETAILS_PI