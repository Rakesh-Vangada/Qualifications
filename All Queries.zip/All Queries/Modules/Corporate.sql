prod limit summary tab (CTL_CORP_LIMIT_LIST_ENQ)
==========================
SELECT   corp.limit_cat_code,DECODE (corp.limit_product_code,'*', 'OVERALL LIMIT',corp.limit_product_code) "PRODUCTCODE",
         corp.limit_name,Scbf_C_Get_Code_Desc (corp.BANK_GROUP_CODE,corp.CTY_CODE,'*','EN','CD032',corp.shortfall_offset,1) "SHORTFALLOFFSET",
         corp.ext_limit_id, corp.inner_to_id, corp.limit_ccy_code,
         NVL (corp.limit_ccy_active_amt, 0),
         CASE
            WHEN corp.limit_product_code = '*'
               THEN null
            ELSE
                   (Scbk_P_Cocoa_Cdb.SCBF_GET_PROD_UTIL_AMT_WITH_CB
                                                      (corp.bank_group_code,
                                                       corp.cty_code,
                                                       corp.cust_id,
                                                       corp.limit_id,
                                                       corp.limit_ccy_code,
                                                       corp.limit_product_code
                                                      )
                   )
         END,
         NVL (util.limit_ccy_utilised_amt, 0),
         -- NVL (util.limit_ccy_pend_inc_amt, 0),
         NVL (Util.Limit_Ccy_Pend_Inc_Amt, 0) AS Limit_Ccy_Pend_Inc_Amt,
         Scbf_Get_Acc_Balance(Corp.Bank_Group_Code, Corp.Cty_Code, Corp.Cust_Id, Corp.Limit_Id, Corp.Limit_Ccy_Code, 'N') AS Balance,
         ( NVL (corp.limit_ccy_active_amt, 0) + NVL(Scbf_Get_Acc_Balance(Corp.Bank_Group_Code, Corp.Cty_Code, Corp.Cust_Id, Corp.Limit_Id, Corp.Limit_Ccy_Code, 'N'),0))- ( NVL (util.limit_ccy_utilised_amt, 0) + NVL (util.limit_ccy_pend_inc_amt, 0)) "AVAILABLITYUK",
         ( NVL (corp.limit_ccy_active_amt, 0))- ( NVL (util.limit_ccy_utilised_amt, 0) + NVL (util.limit_ccy_pend_inc_amt, 0)) "AVAILABLITY", 
         NVL(util.limit_ccy_pend_dec_amt, 0) AS limit_ccy_pend_dec_amt,
         corp.cash_margin_pct, '', corp.product_limit_expiry_date,
         corp.limit_shared_flag, corp.revolving_flag, corp.advised_flag,
         corp.committed_flag, corp.limit_seq_no, corp.limit_id, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate,
            (CASE WHEN (CORP.LIMIT_PRODUCT_CODE IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = corp.BANK_GROUP_CODE 
                         AND PM.PROD_REF_CODE ='OD') OR NVL(corp.FIN_HEDGE_MARGIN,'N') = 'Y') THEN 'Y'
            ELSE 'N' END) AS OD_UTIL_FLAG
         FROM scbt_r_cust_product_limit corp, scbt_t_prod_limit_util util
         WHERE corp.bank_group_code = 'SCB' AND corp.cty_code = 'AE' AND corp.cust_id LIKE '800005417'
         AND corp.limit_id = util.limit_id(+) AND corp.limit_cat_code != 'CI'
         AND corp.limit_cat_code != 'CR' ORDER BY corp.limit_seq_no ASC



1.ENQ_COLLATERAL_LIST
=====================
select * from ( select 
			loc.LOCATION_LIMIT_GROUP_NAME,
			loc.BONDED_WAREHOUSE_FLAG,
			loc.EXCH_DELIV_LOC_FLAG,
			loc.EXCH_CODE,
			loc.STORAGE_LOCATION_ID, 
			loc.STORAGE_COMPANY_ID,loc.LIMIT_CCY_CODE,
			NVL(loc.limit_ccy_active_amt,0),
			NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
             NVL(loc.limit_ccy_active_amt,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
              NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'', loc.LOCATION_LIMIT_GROUP_ID,  TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate from  
			SCBT_R_CUST_APPR_LOCATION loc,
			SCBT_T_coll_LIMIT_UTIL util 
			where loc.BANK_GROUP_CODE= 'SCB'
        AND loc.cty_code= 'AE' 
        AND loc.CUST_ID  like '800005815'
        AND  loc.LOCATION_LIMIT_GROUP_ID =util.limit_id  (+)     
		
		UNION all 
        (select 
			'-',
			loc.BONDED_WAREHOUSE_FLAG,
			loc.EXCH_DELIV_LOC_FLAG,
			loc.EXCH_CODE,
			TO_CLOB('') as stLocation, 
			TO_CLOB('') as stCompany,loc.LIMIT_CCY_CODE,
			NVL(loc.limit_ccy_active_amt,0),
			NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
             NVL(loc.limit_ccy_active_amt,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
              NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'ADHOC',loc.LOCATION_LIMIT_GROUP_ID , TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate from  
            SCBT_R_ADHC_APPR_LOCATION loc,
            SCBT_T_coll_LIMIT_UTIL util
            where loc.BANK_GROUP_CODE= 'SCB'
        AND loc.cty_code= 'AE' 
        AND loc.CUST_ID  like '800005815'
        AND  loc.LOCATION_LIMIT_GROUP_ID =util.limit_id  (+)  ) )


2.ENQ_COLLATERAL_GROUP_LIST
=============================

select * from ( select DISTINCT
			limt.COLLATERAL_GROUP_LIMIT_NAME,
			limt.COLLATERAL_LIMIT_ID,
			limt.LIMIT_CCY_CODE,
			NVL(limt.LIMIT_CCY_ACTIVE_AMT,0), 
            NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
            NVL(limt.LIMIT_CCY_ACTIVE_AMT,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
             NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'',COLLATERAL_GROUP_LIMIT_ID, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate
            from 
			SCBT_R_CUST_COL_GRP_LIMIT limt,
			SCBT_T_COLL_LIMIT_UTIL util  where limt.BANK_GROUP_CODE= 'SCB' and limt.cty_code= 'AE'
            and limt.CUST_ID like '800005815'
            AND  limt.COLLATERAL_GROUP_LIMIT_ID = util.limit_id(+) )


3.ENQ_INSURENCE_LIST
=======================
select * from ( SELECT DISTINCT isLimit.INS_POLICY_ID,
			isLimit.LIMIT_CCY_CODE,
			NVL(isLimit.LIMIT_CCY_ACTIVE_AMT,0),
			NVL(util.LIMIT_CCY_UTILISED_AMT,0),
            NVL(util.LIMIT_CCY_PEND_INC_AMT,0),
             NVL(isLimit.LIMIT_CCY_ACTIVE_AMT,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
            NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),
			isLimit.INSURANCE_EXPIRY,
			isLimit.INSURANCE_LIMIT_ID,
			TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate    
			FROM SCBT_R_CUST_INS_LIMIT isLimit,
			SCBT_T_COLL_LIMIT_UTIL util ,SCBT_R_INS_MST hist
			WHERE isLimit.BANK_GROUP_CODE= 'SCB'
			AND isLimit.cty_code=  'AE'
			AND isLimit.cust_id like  '800005815'
            AND isLimit.INSURANCE_LIMIT_ID = util.LIMIT_ID(+) )

4.ENQ_COMMODITIES_LIST
========================
select * from ( SELECT  '' AS AC1,Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*', 'EN', 'CD009', mst.commodity_type_code, 1) AS COMMODITY_TYPE_CODE,
         DECODE(mst.COMMODITY_CAT_code,'*',mst.COMMODITY_CAT_CODE,mst.COMMODITY_CAT_code),
         Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', mst.COMMODITY_CODE, 1),'' AS AC2 ,com.LIMIT_CCY_CODE,NVL(com.LIMIT_CCY_ACTIVE_AMT,0),
         NVL(util.LIMIT_CCY_UTILISED_AMT,0),NVL(util.LIMIT_CCY_PEND_INC_AMT,0), 
         NVL(com.LIMIT_CCY_ACTIVE_AMT,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
         NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'ADHOC',com.APPR_COMMODITY_LIMIT_ID, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate
         FROM SCBT_R_ADHC_APPR_COM com,SCBT_T_COLL_LIMIT_UTIL util ,SCBT_R_COMMODITY_MST mst
         WHERE com.BANK_GROUP_CODE= 'SCB' AND com.cty_code= 'AE' AND com.CUST_ID LIKE '800005815'
         AND com.APPR_COMMODITY_LIMIT_ID =UTIL.LIMIT_ID AND com.COMMODITY_ID =mst.COMMODITY_ID (+)
         UNION ALL
         (SELECT   '' AS AC3,Scbf_C_Get_Code_Desc(com.BANK_GROUP_CODE, com.CTY_CODE, '*', 'EN', 'CD009', com.commodity_type_code, 1) AS COMMODITY_TYPE_CODE,
         DECODE(com.COMMODITY_CAT_ID,'*',mst.COMMODITY_CAT_CODE,com.COMMODITY_CAT_ID),Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', mst.COMMODITY_CODE, 1),
         com.LOCATION_CTY_CODE,com.LIMIT_CCY_CODE,NVL(com.LIMIT_CCY_ACTIVE_AMT,0),NVL(util.LIMIT_CCY_UTILISED_AMT,0),
         NVL(util.LIMIT_CCY_PEND_INC_AMT,0), 
         NVL(com.LIMIT_CCY_ACTIVE_AMT,0) - (NVL(util.LIMIT_CCY_UTILISED_AMT,0) + NVL(util.LIMIT_CCY_PEND_INC_AMT,0)) ,
         NVL(util.LIMIT_CCY_PEND_DEC_AMT,0),'' AC4,com.APPR_COMMODITY_LIMIT_ID, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate
         FROM SCBT_R_CUST_APPR_COM com,SCBT_T_COLL_LIMIT_UTIL util,SCBT_R_COMMODITY_MST mst
         WHERE com.BANK_GROUP_CODE= 'SCB' AND com.cty_code= 'AE' AND com.CUST_ID LIKE '800005815'
         AND com.APPR_COMMODITY_LIMIT_ID =UTIL.LIMIT_ID(+) AND com.COMMODITY_ID =mst.COMMODITY_ID (+)) )

5.ENQ_BCA_CONDITION_LIST
========================
SELECT CAP_TYPE, CAP_NAME, cpty_COND, decode(CPTY_IDS,null,' ','*',' ',CPTY_IDS), PAYMENT_METHOD, 
              PRODUCT_LIMIT_IDS, TENOR, cty_OF_SALE, bca.limit_ccy_code, LIMIT_ccy_active_AMT, util.limit_ccy_utilised_amt, 
            util.limit_ccy_pend_inc_amt, 
            (NVL(bca.LIMIT_ccy_active_AMT,0) - (NVL(util.limit_ccy_utilised_amt,0) + NVL( util.limit_ccy_pend_inc_amt,0))) availamt,
            util.limit_ccy_pend_dec_amt, util.limit_excess_date, bca.limit_id, ' ', 'O' FROM SCBT_R_CUST_BCA_COND_LIMIT bca, 
              scbt_t_prod_limit_util util WHERE bca.bank_group_code = util.bank_group_code(+) and bca.cty_code = util.cty_code(+) and
            bca.limit_id = util.limit_id(+) and bca.cust_id like '800005815' AND bca.BANK_GROUP_CODE='SCB' AND bca.CTY_CODE='AE'
              union
              select  bca.cap_type,bca.cap_name,' ',bcaAdh.party_id,bca.payment_method,bca.product_limit_ids,bca.tenor, bca.cty_of_sale,bca.limit_ccy_code, bca.LIMIT_ccy_active_AMT, util.limit_ccy_utilised_amt, 
        util.limit_ccy_pend_inc_amt,
        (NVL(bca.LIMIT_ccy_active_AMT,0) - (NVL(util.limit_ccy_utilised_amt,0) + NVL( util.limit_ccy_pend_inc_amt,0))) availamt,
         util.limit_ccy_pend_dec_amt, util.limit_excess_date, bcaAdh.limit_id, bca_limit_id, 'I' from SCBT_R_CUST_BCA_COND_LIMIT bca, 
              scbt_r_cust_adh_bca_cond_mst bcaAdh, scbt_t_prod_limit_util util where 
        bca.limit_id = bcaAdh.bca_limit_id and bcaAdh.limit_id = util.limit_id and bca.cust_id like '800005815' AND bca.BANK_GROUP_CODE='SCB' AND bca.CTY_CODE='AE'

6.ENQ_COLL_LIMIT_LIST
=======================
select * from ( SELECT Scbf_C_Get_Code_Desc ('SCB',
                             '*',
                             '*',
                             'EN',
                             'CD012',
                             corp.collateral_type_code,
                             1
                            ) collateral_type_code,
       corp.collateral_limit_name,
	    corp.sold_status,
		 corp.max_adv_rate,
       corp.limit_ccy_code, NVL(corp.limit_ccy_active_amt,0),
	    NVL(util.limit_ccy_utilised_amt,0),
		NVL(util.limit_ccy_pend_inc_amt,0),(corp.limit_ccy_active_amt - (NVL(util.limit_ccy_utilised_amt,0) + NVL(limit_ccy_pend_inc_amt,0))) availamt,
       NVL(util.limit_ccy_pend_dec_amt,0), '' as cmv,
	   corp.product_limit_id,
	    corp.insurance_limit_id,
	   corp.price_basis_id,
	    corp.tenor, corp.follow_up_days, corp.collateral_limit_id, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate
 	 FROM SCBT_R_CUST_COLLAT_LIMIT corp, SCBT_T_COLL_LIMIT_UTIL util
	WHERE corp.bank_group_code = 'SCB'
   	AND corp.cty_code = 'AE'
  	 AND corp.cust_id like '800005815' AND  corp.COLLATERAL_LIMIT_ID = util.LIMIT_ID(+) )

7.ENQ_PRODUCT_FACILITY_CORPORATE_LIST
=====================================
select * from ( SELECT  '',
          corp.FACLIITY_GRP_NAME AS FacilityGroupName,
          corp.PROD_LIMIT_IDS AS ProductLimitIDs,
		  corp.LIMIT_AMT_CCY AS ccy,
		  corp.LIMIT_AMOUNT AS activeLimitAmount,
          NVL (util.limit_ccy_utilised_amt, 0) AS utilAmt,
          NVL (util.limit_ccy_pend_inc_amt, 0) AS pendIncAmt,
		  (NVL(corp.LIMIT_AMOUNT,0) - (NVL(util.limit_ccy_utilised_amt,0) + NVL(util.limit_ccy_pend_inc_amt,0))) AS availability,
          NVL (util.limit_ccy_pend_dec_amt, 0) AS pendDecAmt,
          corp.FACILITY_GRP_ID
          FROM SCBT_R_CUST_FACILITY_GRP corp, SCBT_T_PROD_LIMIT_UTIL util
          WHERE corp.bank_group_code = 'SCB' AND corp.cty_code = 'AE' AND corp.cust_id LIKE '800005815'
          AND corp.FACILITY_GRP_ID = util.limit_id(+)  AND corp.group_type='AMT' )

8.CTL_CORP_LIMIT_LIST_ENQ
===========================
select * from ( SELECT   corp.limit_cat_code,DECODE (corp.limit_product_code,'*', 'OVERALL LIMIT',corp.limit_product_code) "PRODUCTCODE",
         corp.limit_name,Scbf_C_Get_Code_Desc (corp.BANK_GROUP_CODE,corp.CTY_CODE,'*','EN','CD032',corp.shortfall_offset,1) "SHORTFALLOFFSET",
         corp.ext_limit_id, corp.inner_to_id, corp.limit_ccy_code,
         NVL (corp.limit_ccy_active_amt, 0),
         CASE
            WHEN corp.limit_product_code = '*'
               THEN null
            ELSE
                   (Scbk_P_Cocoa_Cdb.SCBF_GET_PROD_UTIL_AMT_WITH_CB
                                                      (corp.bank_group_code,
                                                       corp.cty_code,
                                                       corp.cust_id,
                                                       corp.limit_id,
                                                       corp.limit_ccy_code,
                                                       corp.limit_product_code
                                                      )
                   )
         END,
         NVL (util.limit_ccy_utilised_amt, 0),
         -- NVL (util.limit_ccy_pend_inc_amt, 0),
         NVL (Util.Limit_Ccy_Pend_Inc_Amt, 0) AS Limit_Ccy_Pend_Inc_Amt,
         Scbf_Get_Acc_Balance(Corp.Bank_Group_Code, Corp.Cty_Code, Corp.Cust_Id, Corp.Limit_Id, Corp.Limit_Ccy_Code, 'N') AS Balance,
         ( NVL (corp.limit_ccy_active_amt, 0) + NVL(Scbf_Get_Acc_Balance(Corp.Bank_Group_Code, Corp.Cty_Code, Corp.Cust_Id, Corp.Limit_Id, Corp.Limit_Ccy_Code, 'N'),0))- ( NVL (util.limit_ccy_utilised_amt, 0) + NVL (util.limit_ccy_pend_inc_amt, 0)) "AVAILABLITYUK",
         ( NVL (corp.limit_ccy_active_amt, 0))- ( NVL (util.limit_ccy_utilised_amt, 0) + NVL (util.limit_ccy_pend_inc_amt, 0)) "AVAILABLITY", 
         NVL(util.limit_ccy_pend_dec_amt, 0) AS limit_ccy_pend_dec_amt,
         corp.cash_margin_pct, '', corp.product_limit_expiry_date,
         corp.limit_shared_flag, corp.revolving_flag, corp.advised_flag,
         corp.committed_flag, corp.limit_seq_no, corp.limit_id, TO_CHAR(util.limit_excess_date,'dd-mm-yyyy') AS limitexcessdate,
         (CASE WHEN (CORP.LIMIT_PRODUCT_CODE IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = corp.BANK_GROUP_CODE 
                  AND PM.PROD_REF_CODE ='OD') OR NVL(corp.FIN_HEDGE_MARGIN,'N') = 'Y') THEN 'Y'
         ELSE 'N' END) AS OD_UTIL_FLAG
         FROM scbt_r_cust_product_limit corp, scbt_t_prod_limit_util util
         WHERE corp.bank_group_code = 'SCB' AND corp.cty_code = 'AE' AND corp.cust_id LIKE '800005815'
         AND corp.limit_id = util.limit_id(+) AND corp.limit_cat_code != 'CI'
         AND corp.limit_cat_code != 'CR' ORDER BY corp.limit_seq_no ASC )
         



=============================================
ENQ_GET_OVERALL_LIMIT_NAME (On clicking the limit)
==========================
SELECT  DISTINCT rd.DEAL_ID,rd.DEAL_ID,rd.TXN_REF_ID, TXN.TP_REF_ID,(CASE WHEN TXN_STEP_CODE = 'DRAW' THEN  'DWG' ELSE rd.LIMIT_PRODUCT_CODE END) AS STEP_CODE,                                           
            (SELECT cpl.limit_name FROM SCBT_R_CUST_PRODUCT_LIMIT cpl WHERE txn.prod_limit_id = cpl.limit_id 
                              AND txn.BANK_GROUP_CODE = cpl.BANK_GROUP_CODE AND txn.cty_code = cpl.cty_code) AS limit_name,
                  Scbf_C_Get_Code_Desc(prod.bank_group_code,txn.cty_code,'*','EN','CD032',prod.SHORTFALL_OFFSET,1) "SHORTFALLOFFSET",
            SUM(rd.txn_ccy_amt),  rd.txn_ccy_code, SUM(Scbf_Tls_Exch_Rate(mv.bank_group_code, mv.CTY_CODE, MV.TXN_CCY_CODE, MV.TXN_CCY_AMT,lim.LIMIT_CCY_CODE, 'N')),
            prod.limit_ccy_code,'',TXN.TENOR,TO_CHAR(TXN.MATURITY_DATE,'dd-MM-yyyy') AS  MATURITY_DATE  ,
           TXN.CMT_REF_NO,prod.cust_id,Scbf_Get_Party_Name (prod.bank_group_code, prod.cust_id) customerNme,
            prod.CO_BORROWER_ID,Scbf_Get_Party_Name (prod.bank_group_code, prod.CO_BORROWER_ID) coborrowerName
            FROM SCBT_T_PROD_LIMIT_MVMT mv,SCBT_T_PROD_LIMIT_REQ_LOG rh,SCBT_T_TXN_MST TXN,
            SCBT_R_CUST_PRODUCT_LIMIT prod,SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd,SCBT_T_PROD_LIMIT_UTIL lim
            WHERE mv.bank_group_code = rh.BANK_GROUP_CODE  AND rh.bank_group_code = rd.BANK_GROUP_CODE AND rh.bank_group_code = TXN.BANK_GROUP_CODE           
            AND mv.bank_group_code = rd.BANK_GROUP_CODE   AND mv.bank_group_code = lim.BANK_GROUP_CODE AND rh.cty_code = TXN.cty_CODE 
            AND mv.CTY_CODE = rh.cty_code   AND rh.CTY_CODE = rd.cty_code AND mv.CTY_CODE = rd.cty_code                        
            AND mv.CTY_CODE = lim.CTY_CODE  AND lim.cty_CODE = mv.cty_code AND rd.TXN_REF_ID = TXN.TXN_REF_ID 
			AND(TXN.TXN_CCY_NET_AMT - NVL(TXN.TXN_CCY_UTIL_AMT, 0)) <> 0
            AND mv.limit_id = prod.limit_id AND txn.txn_rec_id = rd.txn_rec_id
            AND mv.bank_group_code = 'SCB' AND mv.cty_code = 'AE' AND mv.limit_id <> '1230' AND mv.LIMIT_TREE_TYPE_CODE = 'PROD'
            AND mv.init_req_id IN (SELECT mvi.init_req_id FROM SCBT_T_PROD_LIMIT_MVMT mvi WHERE mvi.limit_id = '1230'
                  AND mv.INIT_REQ_ID = mvi.INIT_REQ_ID) AND txn.prod_limit_id = mv.limit_id
            AND mv.init_req_id = rd.init_req_id AND mv.req_sr_no = rd.REQ_SR_NO AND rh.init_req_id = rd.init_req_id
            AND rh.req_type_code = 'NEW' AND rh.req_status_code = 'CON' AND lim.limit_id = mv.limit_id
            GROUP BY rd.DEAL_ID,rd.TXN_REF_ID,TXN.TENOR,TXN.TP_REF_ID,prod.LIMIT_PRODUCT_CODE,TXN.MATURITY_DATE,prod.limit_name,prod.cust_id,prod.CO_BORROWER_ID,prod.bank_group_code,
            (CASE WHEN TXN_STEP_CODE = 'DRAW' THEN  'DWG' ELSE rd.LIMIT_PRODUCT_CODE END),
            rd.txn_ccy_code, prod.limit_ccy_code,prod.CUST_ID,prod.LIMIT_ID,prod.LIMIT_CCY_CODE,
            prod.CASH_MARGIN_PCT,rd.LIMIT_PRODUCT_CODE,prod.SHORTFALL_OFFSET,mv.bank_group_code, rh.cty_code, mv.limit_id,TXN.CMT_REF_NO,
                  txn.prod_limit_id,txn.BANK_GROUP_CODE,txn.cty_code                                                                                                               
            HAVING SUM(mv.txn_ccy_amt) <> 0
            
                      