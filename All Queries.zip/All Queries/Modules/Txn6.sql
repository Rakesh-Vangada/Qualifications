Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: SELECT DISTINCT T.ACCOUNT_NUMBER,T.ACCOUNT_CCY,T.DIFFERENCE FROM SCBT_T_CUST_RECONCIL_SMRY_MST T, SCBT_R_CUST_ACCT_MAINTENANCE W 
            WHERE 
            T.BANK_GROUP_CODE= ? AND T.CTY_CODE = ? AND T.CUSTOMER_ID = ?
			AND T.ACCOUNT_NUMBER = W.ACC_NO
			AND T.CUSTOMER_ID  = W.CUST_ID
			AND T.ACCOUNT_CCY = W.ACC_CCY_CODE
			AND T.BANK_GROUP_CODE = W.BANK_GROUP_CODE
			AND T.CTY_CODE = W.CTY_CODE
			AND W.INCLUDE_FOR_CASH_COLLATERAL='Y'
			AND NVL(T.RECONSILE_FLAG,'N')<>'Y' AND NVL(T.PASS_ADJ_FLAG,'N') <> 'Y'AND NVL(T.DIFFERENCE,0) <> 0
INFO  - Mon Apr 01 17:37:29 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> 
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PRODUCT_TYPE in (? , ?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (?))
Hibernate: select code_value_1 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:37:29 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_LIST
Param [0]--> SCB
Param [1]--> TXN_SUP_PROD
Result Size --> 22
Execution time (ms)  --> 0

Hibernate: select code_value_1, code_value_2 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_VALUE_DTLS
Param [0]--> SCB
Param [1]--> TXNISSUVAL
Result Size --> 36
Execution time (ms)  --> 31

Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: SELECT SC.SALES_REG_ID,SC.SALES_REG_ID AS ELC_ID,SC.MAX_CONTRACT_QNTY_UOM AS QNTY_UOM,
	   		(NVL(SC.MAX_CONTRACT_QNTY,0)-NVL(SC.TOTAL_ELC_QNTY,0)-NVL(SC.CONTRACT_UTIL_QNTY,0)) AS OS_QNTY,
	  		 SC.CV_CCY_CODE,(NVL(SC.CV_CCY_AMT,0)-NVL(SC.TOTAL_ELCV_CCY_AMT,0)-NVL(SC.CV_UTIL_CCY_AMT,0)) AS OS_AMT,
	  		 (CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC
		WHERE  SC.BANK_GROUP_CODE = ? AND SC.CTY_CODE = ? AND SC.CUST_ID = ?
		UNION ALL
		SELECT SC.SALES_REG_ID, EC.ELC_REC_ID AS ELC_ID, EC.MAX_ELC_QNTY_UOM AS QNTY_UOM,
			   (NVL(EC.MAX_ELC_QNTY,0)-NVL(EC.ELC_UTIL_QNTY,0)) AS OS_QNTY,EC.ELCV_CCY_CODE,
		       (NVL(EC.ELCV_CCY_AMT,0)-NVL(EC.ELCV_UTIL_CCY_AMT,0)) AS OS_AMT,
		 	(CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC,SCBT_T_EXPORT_LC_MST EC
		WHERE SC.BANK_GROUP_CODE = EC.BANK_GROUP_CODE AND SC.CTY_CODE = EC.CTY_CODE AND SC.SALES_REG_ID = EC.SALES_REG_ID 
		AND EC.BANK_GROUP_CODE =  ? AND EC.CTY_CODE = ? AND SC.CUST_ID = ?
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> EXPORT_REGISTER_OS_AMT_QNTY_DTLS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SCB
Param [4]--> SG
Param [5]--> 800002463
Param [6]--> SCB
Param [7]--> SG
Param [8]--> 800002463
Param [9]--> SCB
Param [10]--> SG
Param [11]--> 800002463
Result Size --> 65
Execution time (ms)  --> 94

Hibernate: SELECT FG.FACILITY_GRP_ID 
			FROM SCBT_T_TXN_HST TH,
				SCBT_R_CUST_FACILITY_GRP FG 
			WHERE 
				TH.BANK_GROUP_CODE = FG.BANK_GROUP_CODE AND TH.CTY_CODE = FG.CTY_CODE AND TH.CUST_ID = FG.CUST_ID 
				AND REGEXP_SUBSTR (','||FG.PROD_LIMIT_IDS||',', ','||TH.PROD_LIMIT_ID||',' , 1, 1) = ','||TH.PROD_LIMIT_ID||','
				AND TH.BANK_GROUP_CODE = ? AND TH.CTY_CODE = ? AND TH.CUST_ID=? AND FG.GROUP_TYPE = 'CAO' 
				AND TH.DEAL_STEP_ID = ?
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_GROUP_ID_FOR_CMR
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 32

Hibernate: SELECT DISTINCT CASH_HELD_FLAG 
			FROM SCBT_T_GRP_CAO_OFFSET_MST 
			WHERE BANK_GROUP_CODE = ?
				AND CTY_CODE = ? 
				AND CUST_ID = ? 
				AND GROUP_ID in (?) 
				AND DEAL_STEP_ID = ?
				AND PAGE_SOURCE='DDB'
				AND CASH_HELD_FLAG='N'
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_CASH_HELD_FLAG
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> [CLIENT]
Param [4]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 15

Hibernate: SELECT TOTAL_SHORTFALL_AMT FROM SCBT_T_CUST_SHORTFALL_SMRY_HST WHERE BANK_GROUP_CODE = ? AND CTY_CODE = ? AND CUST_ID = ?
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SHORT_FALL_CALCULATION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRODUCT_LIMIT_NAME
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> LCORS
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
ERROR - Mon Apr 01 17:37:30 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest = 1586,1586,4,4,4,
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest request Type = 5 for sessionID = tf.component.fmc.txn.module.38
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-327*SCB*1433068*SG957*20130401173730*20130401173717*20130401173717*20130401173730*OF*SG957T09056*null*TFTIP01*null
INFO  - Mon Apr 01 17:37:30 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-326*3*20130401172924*FPSRequest--3*tf.component.fmc.txn.module*20130401150726798
Appserver proc end: 1364809050265
Appserver proc total: 12969

==========
E4	Mandatory Field Transaction Amount<Field Name> not entered.	false
E4	Mandatory Field Supplier<Field Name> not entered.	false
E4	Mandatory Field Transaction Type<Field Name> not entered.	false
