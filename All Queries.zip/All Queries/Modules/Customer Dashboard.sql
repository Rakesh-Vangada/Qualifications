CUSTOMER_SFALL_DETAILS
======================
SELECT OVERALL_EXP_CCY_CODE,LOSS_ON_TPA_HEDGE_ACC_AMT,TPA_HEDGE_ACC_DEBT_BAL_AMT,COLL_SHORTFALL_TXN_ODFIN_AMT,
TOTAL_SHORTFALL_AMT,SHORTFALL_APPL_FULLOFFSET_AMT,COLL_EXCESS_TXN_ODFIN_AMT,NET_FULLOFFSET_SHORTFALL_AMT,
SHORTFALL_APPL_HEDGEOFFSET_AMT,TOTAL_HEDGE_COLL_AMT,NET_HEDGEOFFSET_SHORTFALL_AMT,SHORTFALL_APPL_CASHOFFSET_AMT,
TOTAL_CASH_COLL_AMT,NET_CASHOFFSET_SHORTFALL_AMT,TOTAL_CASH_MARGIN_REQ_AMT,TOTAL_CASH_AVBL_FOR_OFFSET_AMT
FROM SCBT_T_CUST_SHORTFALL_SMRY_MST
WHERE BANK_GROUP_CODE = 'SCB'
AND CTY_CODE = 'GB'
AND CUST_ID = '800002531';

RETRIEVE_CBB_CHK_FLAG
=====================
select NVL(SEP_BB_CERT_FLAG,'N') from SCBT_R_CUST_LIMIT_MST 
WHERE BANK_GROUP_CODE = 'SCB'
AND CTY_CODE = 'GB'
AND CUST_ID = '800002531';


SHORTFALL_SUMMARY_LIST
======================
SELECT  FACILITY_EXPOSURE_CCY, SUM(FACILITY_EXPOSURE_AMT),SUM(CASH_FOR_EXP_OFFSET_AMT),SUM(FACILITY_CMR_AMT), 
APPLICABLE_DP_AMT, SUM(LINKED_ACCOUNT_BALANCE), FACILITY_GROUP_NAME,EXPIRY_DATE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531' AND PAGE_SOURCE='CDB' AND CLIENT_GROUP_INDICATOR IN ('CBB','GBB')
GROUP BY FACILITY_GROUP_NAME,FACILITY_EXPOSURE_CCY,APPLICABLE_DP_AMT,EXPIRY_DATE; 

SHORTFALL_OFFSET_LIST
=====================
SELECT a.LIMIT_ID,a.FACILITY_GROUP_ID,a.FACILITY_EXPOSURE_CCY, a.FACILITY_EXPOSURE_AMT,a.CASH_FOR_EXP_OFFSET_AMT,a.FACILITY_CMR_AMT,
a.FACILITY_GROUP_NAME,
(SELECT LIMIT_NAME FROM SCBT_R_CUST_PRODUCT_LIMIT 
where BANK_GROUP_CODE = a.BANK_GROUP_CODE 
AND CTY_CODE = a.CTY_CODE
AND CUST_ID = a.CUST_ID 
AND LIMIT_ID = a.LIMIT_ID) AS LIMIT_NAME 
FROM  SCBT_T_CUST_SFALL_OFFSET_MST a WHERE a.BANK_GROUP_CODE = 'SCB' AND a.CTY_CODE = 'GB'
AND a.CUST_ID = '800002531' AND a.SHORTFALL_OFFSET IN ('CBB','GBB') AND a.PAGE_SOURCE='CDB'; 

CTL_CUSTOMER_ID_COBORROWER_LIST
===============================
select * from ( SELECT PARTY_ID,PARTY_NAME FROM SCBT_R_PARTY_MST 
WHERE BANK_GROUP_CODE='SCB' AND CTY_CODE = 'GB' AND party_id LIKE '%800002531%' AND party_name_upp LIKE UPPER('%')
AND NVL(UPPER(custodian),'N') LIKE UPPER('N')			
UNION			
SELECT CCB.CUST_CO_BORROWER_ID, Scbf_Get_Party_Name (CCB.BANK_GROUP_CODE, CCB.CUST_CO_BORROWER_ID ) AS party_name 
FROM SCBT_R_CUST_CO_BORROWER CCB, SCBT_R_PARTY_MST MST
WHERE CCB.BANK_GROUP_CODE = MST.BANK_GROUP_CODE AND CCB.CUST_CO_BORROWER_ID = MST.PARTY_ID AND MST.CTY_CODE = '*'
AND CCB.BANK_GROUP_CODE='SCB' AND CCB.CUST_CO_BORROWER_ID LIKE '%800002531%'  AND CCB.PARTY_ID LIKE '800002531' AND party_name_upp LIKE UPPER('%')); 

GET_CBB_OVERALL_STATUS_UNCHECKED
================================
SELECT LIMIT_ID,NVL(SHORTFALL_FLAG,'N') FROM  SCBT_T_CUST_GRP_CLT_OFFSET_MST  WHERE BANK_GROUP_CODE = 'SCB' 
AND CTY_CODE = 'GB'  AND CUST_ID = '800002531' AND CUST_CO_BORROWER_ID is NULL AND CLIENT_GROUP_INDICATOR ='CBB' 
AND PAGE_SOURCE='CDB' AND SHORTFALL_FLAG='Y'; 


RETRIEVE_RESP_UK_SHORTFALL
==========================
SELECT OVERALL_EXP_CCY_CODE,FACILITY_GROUP_NAME,FACILITY_EXPOSURE_AMT,FACILITY_NCV_AMT, 
FACILITY_CMR_AMT, CASH_FOR_EXP_OFFSET_AMT, LINKED_ACCOUNT_BALANCE,SECURED_CMR_AMT,
UNSECURED_CMR_AMT, EFF_NCV_COLL_CAP,EFF_NCV_COLL_GRP_CAP, APPLICABLE_DP_AMT,HF_ACC_BALANCE 
FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531' 
AND CLIENT_GROUP_INDICATOR = 'GROUP' AND PAGE_SOURCE='CDB';

RETRIEVE_RESP_COLL_SUMMARY
==========================
SELECT a.LIMIT_ID,
(SELECT LIMIT_NAME FROM SCBT_R_CUST_PRODUCT_LIMIT 
where BANK_GROUP_CODE = a.BANK_GROUP_CODE 
AND CTY_CODE = a.CTY_CODE
AND CUST_ID = a.CUST_ID 
AND LIMIT_ID = a.LIMIT_ID) AS LIMIT_NAME,
a.FACILITY_EXPOSURE_CCY,a.FACILITY_EXPOSURE_AMT,a.FACILITY_NCV_AMT,a.FACILITY_CMR_AMT,
a.CASH_FOR_EXP_OFFSET_AMT,a.FACILITY_GROUP_NAME FROM SCBT_T_CUST_SFALL_OFFSET_MST a 
WHERE a.BANK_GROUP_CODE = 'SCB'  AND a.CTY_CODE = 'GB'
AND a.CUST_ID = '800002531' AND a.SHORTFALL_OFFSET = 'GFL' AND a.PAGE_SOURCE='CDB';

CDB_CLIENT_SECURED_DETAILS
==========================
SELECT FACILITY_EXPOSURE_AMT,FACILITY_NCV_AMT, FACILITY_CMR_AMT,CASH_FOR_EXP_OFFSET_AMT,
EFF_NCV_COLL_CAP,EFF_NCV_COLL_GRP_CAP,HF_ACC_BALANCE,LINKED_ACCOUNT_BALANCE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531'
AND CLIENT_GROUP_INDICATOR='CLIENT' AND PAGE_SOURCE='CDB' AND LIMIT_ID='CS'

CDB_CLIENT_UNSECURED_DETAILS
============================
SELECT FACILITY_EXPOSURE_AMT,FACILITY_NCV_AMT, FACILITY_CMR_AMT,CASH_FOR_EXP_OFFSET_AMT,
EFF_NCV_COLL_CAP,EFF_NCV_COLL_GRP_CAP,HF_ACC_BALANCE,LINKED_ACCOUNT_BALANCE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531'
AND CLIENT_GROUP_INDICATOR='CLIENT' AND PAGE_SOURCE='CDB' AND LIMIT_ID='CU';

RETRIEVE_RESP_CLIENT_GRP_SUMMARY
================================
SELECT LIMIT_ID, FACILITY_EXPOSURE_CCY, FACILITY_EXPOSURE_AMT, FACILITY_NCV_AMT, FACILITY_CMR_AMT,
CASH_FOR_EXP_OFFSET_AMT, HF_ACC_BALANCE,LINKED_ACCOUNT_BALANCE FROM SCBT_T_CUST_GRP_CLT_OFFSET_MST 
WHERE BANK_GROUP_CODE = 'SCB' AND CTY_CODE = 'GB'  AND CUST_ID = '800002531'
AND  CLIENT_GROUP_INDICATOR = 'CLIENT'  AND PAGE_SOURCE='CDB';
			
RETRIEVE_RESP_CLIENT_SUMMARY_DTLS
=================================	       
SELECT a.LIMIT_ID,
(SELECT LIMIT_NAME FROM SCBT_R_CUST_PRODUCT_LIMIT 
where BANK_GROUP_CODE = a.BANK_GROUP_CODE 
AND CTY_CODE = a.CTY_CODE
AND CUST_ID = a.CUST_ID 
AND LIMIT_ID = a.LIMIT_ID) AS LIMIT_NAME,
a.FACILITY_EXPOSURE_CCY,a.FACILITY_EXPOSURE_AMT,a.FACILITY_NCV_AMT,a.FACILITY_CMR_AMT,
a.CASH_FOR_EXP_OFFSET_AMT,a.FACILITY_GROUP_ID FROM SCBT_T_CUST_SFALL_OFFSET_MST a 
WHERE a.BANK_GROUP_CODE = 'SCB' AND a.CTY_CODE = 'GB' AND a.CUST_ID = '800002531'
AND a.SHORTFALL_OFFSET = 'CUL' AND a.PAGE_SOURCE='CDB'

CUSTOMER_FACILITY_POSITION_DETAILS_UK
=====================================
SELECT  limitcategory, limitid, scilimitid, innertoid, NVL (limitname, ' '),
         productcode, limitccy, activelimit, prodwise_util, utilisation,
         pendingincreaseamount,
         Scbf_Get_Acc_Balance (bgcode,
                               ctycode,
                               customerid,
                               limitid,
                               limitccy,
                               'O'
                              ) AS balance,
         availablity, pendingdecreaseamount, ncv, pi_ncv, csh_margin,
         pi_csh_margin, pd_csh_margin, shortfalloffset, desired_ltv,
         stop_loss_pct, stop_loss_value, calculated_ltv_pct,
         calculated_ltv_pct_with_pi, linked_gcv, pi_linked_gcv, unlinked_gcv,
         pi_unlinked_gcv, cash_top_up, total_ncv_wt_pi, total_ncv,
         shorfall_amt_gcv, group_name,
         NVL (Scbf_C_Get_Code_Desc ('SCB',
                                    '*',
                                    '*',
                                    'EN',
                                    'CI124',
                                    productcode,
                                    1
                                   ),
              ' '
             ),
         comments,LIMIT_REMARKS
    FROM (SELECT   l.bank_group_code "BGCODE", l.cty_code "CTYCODE",
                   l.limit_seq_no "SEQNO", l.cust_id "CUSTOMERID",
                   l.limit_cat_code "LIMITCATEGORY",
                   Scbf_C_Get_Code_Desc
                                       (l.bank_group_code,
                                        l.cty_code,
                                        '*',
                                        'EN',
                                        'CD032',
                                        l.shortfall_offset,
                                        1
                                       ) "SHORTFALLOFFSET",
                   l.limit_name "LIMITNAME",
                   DECODE (l.limit_product_code,
                           '*', 'OVERALL LIMIT',
                           l.limit_product_code
                          ) "PRODUCTCODE",
                   NVL
                      (Scbf_C_Get_Code_Desc ('SCB',
                                             '*',
                                             '*',
                                             'EN',
                                             'CI124',
                                             l.limit_product_code,
                                             1
                                            ),
                       ' '
                      ) "PRODUCTDESCRIPTION",
                   l.limit_id "LIMITID", l.ext_limit_id "SCILIMITID",
                   l.inner_to_id "INNERTOID", l.limit_ccy_code "LIMITCCY",
                   NVL (l.limit_ccy_active_amt, 0) "ACTIVELIMIT",
                   DECODE
                      (l.limit_product_code,
                       '*', 0,
                       NVL
                          (Scbk_P_Cocoa_Cdb.scbf_get_prod_util_amt_with_cb
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            l.ext_limit_id
                                                           ),
                           0
                          )
                      ) "PRODWISE_UTIL",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0) "UTILISATION",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0) "PENDINGINCREASEAMOUNT",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_dec_amt,
                                                   0)
                                             ), 0) "PENDINGDECREASEAMOUNT",
                   NVL (u.comments, '') "COMMENTS",NVL (u.LIMIT_REMARKS, '') "LIMIT_REMARKS",
                   (  NVL (l.limit_ccy_active_amt, 0)
                    +  NVL(Scbf_Get_Acc_Balance(l.Bank_Group_Code, l.Cty_Code, l.Cust_Id, l.Limit_Id, l.Limit_Ccy_Code,'O'),0)
                    - (  NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0)
                       + NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0)
                      )
                   ) "AVAILABLITY",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                       0
                      ) "NCV",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                       0
                      ) "PI_NCV",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                       0
                      ) "CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                       0
                      ) "PI_CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                        'SCB',
                                                         'GB',
                                                         'D'
                                                        ),
                       0
                      ) "PD_CSH_MARGIN",
                     NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        ) "TOTAL_NCV_WT_PI",
                     NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'N'
                                                        ),
                         0
                        )
                   + NVL
                        (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'GB',
                                                         'Y'
                                                        ),
                         0
                        ) "TOTAL_NCV",
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS desired_ltv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS stop_loss_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_PARTY_MST
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND party_id = l.cust_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_PRODUCT_LIMIT
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND limit_id = l.limit_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_FACILITY_GRP
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                  0
                                 )
                       ELSE 0
                    END
                   ) AS stop_loss_value,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct_with_pi,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                    END
                   ) AS linked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                    END
                   ) AS pi_linked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                    END
                   ) AS unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                    END
                   ) AS pi_unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_topup_amt
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_topup_amt_by_level
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            '',
                                                            '',
                                                            '',
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            '',
                                                            'F'
                                                           )
                    END
                   ) AS cash_top_up,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_level_shortfall
                                        (l.bank_group_code,
                                         l.cty_code,
                                         l.cust_id,
                                         l.limit_id,
                                         Scbf_Get_Exp_Ccy (l.bank_group_code,
                                                           l.cty_code,
                                                           l.cust_id
                                                          ),
                                         'A'
                                        )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                    END
                   ) AS shorfall_amt_gcv,
                   (SELECT facliity_grp_name
                      FROM SCBT_R_CUST_FACILITY_GRP
                     WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ','))
                                      AS group_name
             FROM SCBT_R_CUST_PRODUCT_LIMIT l,SCBT_T_PROD_LIMIT_UTIL u
             WHERE l.limit_id = u.limit_id(+) 
               AND l.bank_group_code = u.bank_group_code(+)
               AND l.cty_code = u.cty_code(+)
               AND l.bank_group_code = 'SCB' AND l.cty_code = 'GB' AND cust_id = '800002531'
          ORDER BY l.limit_seq_no)
       WHERE bgcode = 'SCB' and ctycode = 'GB' and customerid = '800002531' AND limitcategory <>'CI'
     ORDER BY seqno ASC
	 
CUSTOMER_DASHBOARD_COLL_BANK_RISK_DETAILS
=========================================
SELECT PRODUCT_CODE,PRODUCT_DESC,EXP_CCY,SUM(OUTSTANDING_AMT),SUM(PENDING_INC),SUM(PENDING_DEC) FROM(
SELECT PRODUCT_CODE,
SCBF_C_GET_CODE_DESC('SCB', '*', '*', 'EN', 'CI124', PRODUCT_CODE, 1) AS PRODUCT_DESC,
SCBF_GET_EXP_CCY('SCB','GB','800002531') AS EXP_CCY,
SCBF_GET_VALUE_IN_EXP_CCY('SCB','GB','800002531',TXN_CCY_CODE,(TXN_CCY_NET_AMT - NVL(TXN_CCY_UTIL_AMT, 0))) AS OUTSTANDING_AMT,
0 AS PENDING_INC,
0 AS PENDING_DEC
FROM SCBT_T_TXN_MST
WHERE BANK_GROUP_CODE = 'SCB'
AND CTY_CODE= 'GB'
AND CUST_ID = '800002531'
AND PRODUCT_CODE IN
(SELECT PRODUCT_CODE FROM SCBT_R_PRODUCT_MST WHERE PRODUCT_TYPE = 'BRP' OR PRODUCT_TYPE = 'COP')
UNION ALL
SELECT PRODUCT_CODE,
SCBF_C_GET_CODE_DESC('SCB', '*', '*', 'EN', 'CI124', PRODUCT_CODE, 1) AS PRODUCT_DESC,
SCBF_GET_EXP_CCY('SCB','GB','800002531') AS EXP_CCY,
'0' AS OUTSTANDING_AMT,
NVL(SCBF_GET_PENDING_INC_AMT(H.bank_group_code,H.cty_code,H.PRODUCT_CODE,'800002531'),0) AS PENDING_INC,
NVL(SCBF_GET_PENDING_DEC_AMT(H.bank_group_code,H.cty_code,H.PRODUCT_CODE,'800002531'),0) AS PENDING_DEC
FROM SCBT_T_TXN_HST H,SCBT_T_DEAL_HIST DH
WHERE H.BANK_GROUP_CODE = 'SCB'
AND H.DEAL_STEP_ID = DH.DEAL_STEP_ID
AND NVL(H.TXN_STATUS_CODE,'00') NOT IN ('08','11')
AND DH.STEP_STATUS_CODE IN ('02', '10', '14')
AND H.CTY_CODE = 'GB'
AND H.CUST_ID = '800002531'
AND H.PRODUCT_CODE IN
(SELECT PRODUCT_CODE FROM SCBT_R_PRODUCT_MST WHERE PRODUCT_TYPE = 'BRP' OR PRODUCT_TYPE = 'COP'))
GROUP BY PRODUCT_CODE,PRODUCT_DESC,EXP_CCY

CDB_CH_TOP_UPS_CMR_OFFSET_DETAILS
==================================
SELECT DISTINCT Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD032',b.SHORTFALL_OFFSET,1) "B_SHORTFALLOFFSET",
Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1) "A_TOPUP_LEVEL",
(CASE WHEN a.TOPUP_LEVEL='T' THEN a.TXN_REF_ID WHEN a.TOPUP_LEVEL='F' THEN b.LIMIT_NAME END) as RefID,
a.exposure_ccy_code as CCY,
a.exposure_ccy_amt as OSAmt,
(CASE WHEN a.LTV_CALC_PCT > (CASE WHEN a.TOPUP_LEVEL='F' OR a.TOPUP_LEVEL='T' 
THEN b.STOP_LOSS_PCT END) THEN 'Stoploss Breached' WHEN a.SHORTFALL_CCY_AMT > 
(CASE WHEN a.TOPUP_LEVEL='F' THEN b.STOP_LOSS_CCY_AMT WHEN a.TOPUP_LEVEL='T' THEN b.STOP_LOSS_CCY_AMT END) THEN 'Stoploss Breached' 
WHEN a.LTV_CALC_PCT > (CASE WHEN a.TOPUP_LEVEL='F' OR  a.TOPUP_LEVEL='T' THEN b.LOAN_TO_VALUE_PCT END) AND 
(CASE WHEN a.TOPUP_LEVEL='F' OR  a.TOPUP_LEVEL='T' THEN b.LOAN_TO_VALUE_PCT END) < 
(CASE WHEN a.TOPUP_LEVEL='F' OR a.TOPUP_LEVEL='T' THEN b.STOP_LOSS_PCT END) THEN 'Topup Approaching' END) AS Top_up_approaching,  
a.ltv_calc_pct,
a.GCV_CCY_AMT GCV,
(CASE WHEN a.TOPUP_LEVEL='T' THEN NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(a.BANK_GROUP_CODE,
		   a.CTY_CODE,a.CUST_ID,a.exposure_ccy_code,a.TXN_REC_ID,b.LIMIT_CCY_CODE,'UTIL','M',''),0)
WHEN a.TOPUP_LEVEL='F' THEN    
NVL(Scbk_P_Cocoa_Cdb.SCBF_C_FACILITY_LEVEL_NCV_AMT(b.limit_id,b.LIMIT_CCY_CODE,b.BANK_GROUP_CODE,b.CTY_CODE,'N'),0) END) NCV,
a.shortfall_ccy_amt LTVShortfallAmt,
NVL(b.LOAN_TO_VALUE_PCT,0) as desiredLTV,
NVL(b.STOP_LOSS_PCT,0) as StopLossPrcnt,
NVL(b.STOP_LOSS_CCY_AMT,0) as StopLossAmt,
a.topup_req_flag as CashTopUpReqFlag, 
a.cashtopup_ccy_code as CashTopUpCode,
a.cashtopup_ccy_amt as CashTopUpAmt,
a.topup_req_ccy_code as TopUpReqCode,
a.topup_req_ccy_amt as TopUpReqAmt,
b.limit_product_code,
Scbf_C_Get_Code_Desc (b.bank_group_code,'*','*','EN','CI124', b.limit_product_code,1) AS prod_code_desc,
NVL(a.CMR_CCY_AMT,0),
NVL(a.CMR_PERCENT,0),
a.LTV_FORMULA
FROM SCBT_T_STOPLOSS_SUMMARY_MST a,
SCBT_R_CUST_PRODUCT_LIMIT b 
where a.bank_group_code= b.bank_group_code 
and a.cty_code=b.cty_code
and a.cust_id=b.cust_id 
and a.limit_id=b.limit_id 
and a.cust_id='800002531'
and a.bank_group_code='SCB'
and a.cty_code='GB'
and a.deal_step_id='M'
and a.TOPUP_LEVEL in ('T','F')
and nvl(a.exposure_ccy_amt,0) > 0
UNION ALL
SELECT  DISTINCT 'Collateralized' "B_SHORTFALLOFFSET",
Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1) "A_TOPUP_LEVEL",
a.GROUP_ID as RefID,
a.exposure_ccy_code as CCY,
a.exposure_ccy_amt as OSAmt,
'' AS Top_up_approaching,  
a.ltv_calc_pct,
a.GCV_CCY_AMT GCV,
(NVL(Scbk_P_Cocoa_Cdb.SCBF_GET_GROUP_UNLINKED_NCV(a.BANK_GROUP_CODE,a.CTY_CODE,a.CUST_ID,a.GROUP_ID,a.EXPOSURE_CCY_CODE,'N'),0)
+ NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_GROUP_NCV_AMT(a.GROUP_ID,a.CUST_ID,a.BANK_GROUP_CODE,a.CTY_CODE,'N'),0)) as NCV,
a.shortfall_ccy_amt LTVShortfallAmt,
NVL((select LOAN_TO_VALUE_PCT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as desiredLTV,
NVL((select STOP_LOSS_PCT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as StopLossPrcnt,
NVL((select STOP_LOSS_CCY_AMT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as StopLossAmt,
a.topup_req_flag as CashTopUpReqFlag, 
a.cashtopup_ccy_code as CashTopUpCode,
a.cashtopup_ccy_amt as CashTopUpAmt,
a.topup_req_ccy_code as TopUpReqCode,
a.topup_req_ccy_amt as TopUpReqAmt,
'',(select FACLIITY_GRP_NAME FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),
nvl(a.CMR_CCY_AMT,0),
NVL(a.CMR_PERCENT,0),
a.LTV_FORMULA
FROM SCBT_T_STOPLOSS_SUMMARY_MST a
where  a.cust_id='800002531'
and a.bank_group_code='SCB'
and a.cty_code='GB'
and a.deal_step_id='M'
and a.TOPUP_LEVEL='G'
and nvl(a.exposure_ccy_amt,0) > 0   
UNION ALL
SELECT DISTINCT Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD032',(SELECT SHORTFALL_OFFSET FROM SCBT_R_CUST_PRODUCT_LIMIT WHERE LIMIT_ID = a.limit_id ),1) "B_SHORTFALLOFFSET",
(CASE WHEN a.TOPUP_LEVEL='C' THEN Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1)
WHEN a.TOPUP_LEVEL='NONLTV' THEN 'Non LTV Transaction' END) "A_TOPUP_LEVEL",
a.TXN_REF_ID as RefID,
a.exposure_ccy_code as CCY,
a.exposure_ccy_amt as OSAmt,
'' AS Top_up_approaching,  
a.ltv_calc_pct,
a.GCV_CCY_AMT GCV,
NVL(a.NCV_CCY_AMT,0) NCV,
a.shortfall_ccy_amt LTVShortfallAmt,0,0,0,
a.topup_req_flag as CashTopUpReqFlag, 
a.cashtopup_ccy_code as CashTopUpCode,
a.cashtopup_ccy_amt as CashTopUpAmt,
a.topup_req_ccy_code as TopUpReqCode,
a.topup_req_ccy_amt as TopUpReqAmt,
'',
a.TXN_STEP_CODE,
nvl(a.CMR_CCY_AMT,0),
NVL(a.CMR_PERCENT,0),
a.LTV_FORMULA
FROM SCBT_T_STOPLOSS_SUMMARY_MST a       
where  a.cust_id='800002531'
and a.bank_group_code='SCB'
and a.cty_code='GB'
and a.deal_step_id='M'
and a.TOPUP_LEVEL in ('C','NONLTV')
and a.TXN_REF_ID is not null
and nvl(a.exposure_ccy_amt,0) > 0 


		