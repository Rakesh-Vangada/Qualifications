SELECT  DISTINCT rd.DEAL_ID,rd.TXN_REF_ID, TXN.TP_REF_ID,(CASE WHEN TXN_STEP_CODE = 'DRAW' THEN  'DWG' ELSE rd.LIMIT_PRODUCT_CODE END) AS STEP_CODE,                                           
            (SELECT cpl.limit_name FROM SCBT_R_CUST_PRODUCT_LIMIT cpl WHERE txn.prod_limit_id = cpl.limit_id 
                              AND txn.BANK_GROUP_CODE = cpl.BANK_GROUP_CODE AND txn.cty_code = cpl.cty_code) AS limit_name,
                  Scbf_C_Get_Code_Desc(prod.bank_group_code,txn.cty_code,'*','EN','CD032',prod.SHORTFALL_OFFSET,1) "SHORTFALLOFFSET",
            SUM(rd.txn_ccy_amt),  rd.txn_ccy_code, SUM(Scbf_Tls_Exch_Rate(mv.bank_group_code, mv.CTY_CODE, MV.TXN_CCY_CODE, MV.TXN_CCY_AMT,lim.LIMIT_CCY_CODE, 'N')),
            prod.limit_ccy_code,'',TXN.TENOR,TO_CHAR(TXN.MATURITY_DATE,'dd-MM-yyyy') AS  MATURITY_DATE  ,
           TXN.CMT_REF_NO,prod.cust_id,Scbf_Get_Party_Name (prod.bank_group_code, prod.cust_id) customerNme,
            prod.CO_BORROWER_ID,Scbf_Get_Party_Name (prod.bank_group_code, prod.CO_BORROWER_ID) coborrowerName
            FROM SCBT_T_PROD_LIMIT_MVMT mv,SCBT_T_PROD_LIMIT_REQ_LOG rh,SCBT_T_TXN_MST TXN,
            SCBT_R_CUST_PRODUCT_LIMIT prod,SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd,SCBT_T_PROD_LIMIT_UTIL lim
            WHERE mv.bank_group_code = rh.BANK_GROUP_CODE  AND rh.bank_group_code = rd.BANK_GROUP_CODE AND rh.bank_group_code = TXN.BANK_GROUP_CODE           
            AND mv.bank_group_code = rd.BANK_GROUP_CODE   AND mv.bank_group_code = lim.BANK_GROUP_CODE AND rh.cty_code = TXN.cty_CODE 
            AND mv.CTY_CODE = rh.cty_code   AND rh.CTY_CODE = rd.cty_code AND mv.CTY_CODE = rd.cty_code                        
            AND mv.CTY_CODE = lim.CTY_CODE  AND lim.cty_CODE = mv.cty_code AND rd.TXN_REF_ID = TXN.TXN_REF_ID 
            AND mv.limit_id = prod.limit_id AND txn.txn_rec_id = rd.txn_rec_id
            AND mv.bank_group_code = 'SCB' AND mv.cty_code = 'AE' AND mv.limit_id <> '1230' AND mv.LIMIT_TREE_TYPE_CODE = 'PROD'
            AND mv.init_req_id IN (SELECT mvi.init_req_id FROM SCBT_T_PROD_LIMIT_MVMT mvi WHERE mvi.limit_id = '1230'
                  AND mv.INIT_REQ_ID = mvi.INIT_REQ_ID) AND txn.prod_limit_id = mv.limit_id
            AND mv.init_req_id = rd.init_req_id AND mv.req_sr_no = rd.REQ_SR_NO AND rh.init_req_id = rd.init_req_id
            AND rh.req_type_code = 'NEW' AND rh.req_status_code = 'CON' AND lim.limit_id = mv.limit_id
            GROUP BY rd.DEAL_ID,rd.TXN_REF_ID,TXN.TENOR,TXN.TP_REF_ID,prod.LIMIT_PRODUCT_CODE,TXN.MATURITY_DATE,prod.limit_name,prod.cust_id,prod.CO_BORROWER_ID,prod.bank_group_code,
            (CASE WHEN TXN_STEP_CODE = 'DRAW' THEN  'DWG' ELSE rd.LIMIT_PRODUCT_CODE END),
            rd.txn_ccy_code, prod.limit_ccy_code,prod.CUST_ID,prod.LIMIT_ID,prod.LIMIT_CCY_CODE,
            prod.CASH_MARGIN_PCT,rd.LIMIT_PRODUCT_CODE,prod.SHORTFALL_OFFSET,mv.bank_group_code, rh.cty_code, mv.limit_id,TXN.CMT_REF_NO,
                  txn.prod_limit_id,txn.BANK_GROUP_CODE,txn.cty_code                                                                                                               
            HAVING SUM(mv.txn_ccy_amt) <> 0
            
O5204	Drawing transaction is not sufficiently collateralized - Transaction is tagged for Exception Approval.	false
                      