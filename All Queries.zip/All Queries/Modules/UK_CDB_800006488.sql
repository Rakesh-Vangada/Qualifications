SELECT A.DEAL_ID,DRH.DEAL_DESC,SCBF_GET_EXP_CCY('SCB','GB','800007220') AS EXP_CCY,OUTSTANDING,CMV_COVERAGE_AMT,GCV_COVERAGE_AMT,NCV_COVERAGE_AMT,
        CASH_MARGIN,NCV_COVERAGE_AMT+CASH_MARGIN AS TOTAL FROM
     (SELECT DEAL_ID,               
               SUM(NVL(OUTSTANDING, 0)) AS OUTSTANDING,               
               SUM( NVL(CMV_COVERAGE_AMT, 0)) AS CMV_COVERAGE_AMT,
                SUM( NVL(GCV_COVERAGE_AMT, 0)) AS GCV_COVERAGE_AMT,
              SUM( NVL(CASH_MARGIN, 0)) AS CASH_MARGIN,
               SUM( NVL(NCV_COVERAGE_AMT, 0)) AS NCV_COVERAGE_AMT      
          FROM (SELECT  MST.DEAL_ID,
                        NVL(Scbf_Tls_Exch_Rate(MST.BANK_GROUP_CODE,
                                          MST.CTY_CODE,
                                          MST.TXN_CCY_CODE,
                                          (NVL(MST.TXN_CCY_NET_AMT,0) - NVL(MST.TXN_CCY_UTIL_AMT,0)),
                                          SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                          'Y'),0) AS OUTSTANDING,
                       NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_CMV_BY_TXN_REC_ID(MST.bank_Group_Code,
                                                                     MST.cty_Code,
                                                                     MST.CUST_ID,
                                                                     SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                     MST.TXN_REC_ID,
                                                                     MST.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     ''),0) AS CMV_COVERAGE_AMT,
                        NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(MST.bank_Group_Code,
                                                                     MST.cty_Code,
                                                                     MST.CUST_ID,
                                                                     SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                     MST.TXN_REC_ID,
                                                                     MST.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     ''),0) AS GCV_COVERAGE_AMT,
                       NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(MST.bank_Group_Code,
                                                                     MST.cty_Code,
                                                                     MST.CUST_ID,
                                                                     SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                     MST.TXN_REC_ID,
                                                                     MST.TXN_CCY_CODE,
                                                                     'UTIL',
                                                                     'M',
                                                                     ''),0) AS NCV_COVERAGE_AMT,
                       NVL(Scbf_Tls_Exch_Rate(MST.BANK_GROUP_CODE,
                                          MST.CTY_CODE,
                                          MST.Cash_Margin_Ccy_Code,
                                          (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                                             ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                                             ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END),
                                          SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                          'Y'),0) AS CASH_MARGIN 
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = 'SCB'
                       AND MST.CTY_CODE = 'GB'
                       AND cust_id = '800007220'
                       and nvl(MST.txn_status_code,' ') <> '11'
                       AND MST.DEAL_ID IN (SELECT DEAL_ID
                                                     from scbt_t_deal_hist
                                                    where BANK_GROUP_CODE = MST.BANK_GROUP_CODE
                                                      and CTY_CODE = MST.CTY_CODE
                                                      AND DEAL_ID = MST.DEAL_ID)
                        UNION ALL
                         SELECT CRM.DEAL_ID,
                                       0 AS OUTSTANDING,
                                       NVL(Scbf_Fetch_Exch_Rate('SCB',
                                                                'GB',
                                                                TOTAL_CMV_CCY_CODE,
                                                                TOTAL_CMV_CCY_AMT,
                                                                SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                'N'),
                                           0) AS CMV_COVERAGE_AMT,
                                       NVL(Scbf_Fetch_Exch_Rate('SCB',
                                                                'GB',
                                                                TOTAL_GCV_CCY_CODE,
                                                                TOTAL_GCV_CCY_AMT,
                                                                SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                'N'),
                                           0) AS GCV_COVERAGE_AMT,
                                          NVL(Scbf_Fetch_Exch_Rate('SCB',
                                                                'GB',
                                                                TOTAL_NCV_CCY_CODE,
                                                                TOTAL_NCV_CCY_AMT,
                                                                SCBF_GET_EXP_CCY('SCB','GB','800007220'),
                                                                'N'),
                                           0) AS NCV_COVERAGE_AMT,
                                       0 AS CASH_MARGIN
                                FROM SCBT_T_COLLATERAL_REGISTER_MST CRM,
                                      SCBT_T_DEAL_REGISTER_HDR_MST   DRH
                                WHERE CRM.DEAL_ID = DRH.DEAL_ID
                                  AND CRM.CUST_ID = DRH.CUST_ID
                                  AND (DRH.BUSINESS_TYPE = 'FLC' OR DRH.BUSINESS_TYPE = 'OD')
                                  AND CRM.BANK_GROUP_CODE = DRH.BANK_GROUP_CODE
                                  AND CRM.CTY_CODE = DRH.CTY_CODE
                                  AND CRM.BANK_GROUP_CODE = 'SCB'
                                  AND CRM.CTY_CODE = 'GB'
                                  AND CRM.CUST_ID = '800007220'  AND CRM.COLLATERAL_CATEGORY <> 'REL'
                                ) group by deal_id order by deal_id) A, SCBT_T_DEAL_REGISTER_HDR_MST DRH WHERE A.deal_id=DRH.DEAL_ID
                                AND ((OUTSTANDING <> 0) OR (CMV_COVERAGE_AMT <> 0) OR (GCV_COVERAGE_AMT <> 0) OR (NCV_COVERAGE_AMT <> 0) OR (CASH_MARGIN <> 0));
