SELECT  Scbf_Get_Party_Name(P.BANK_GROUP_CODE, NVL(P.CO_BORROWER_ID, P.CUST_ID))AS CUST_NAME, T.TP_REF_ID,T.DEAL_ID,T.TXN_REF_ID,TO_CHAR(T.MATURITY_DATE, 'DD-MM-YYYY'),
       (CASE WHEN T.TXN_STEP_CODE = 'DRAW' THEN 'DWG' WHEN T.TXN_STEP_CODE = 'SETT' THEN 'SETT'
             ELSE T.PRODUCT_CODE END),
       P.LIMIT_CCY_CODE,Scbf_Tls_Exch_Rate(T.BANK_GROUP_CODE,T.CTY_CODE,T.TXN_CCY_CODE,
                                         (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                          P.LIMIT_CCY_CODE,
                                          'Y') AS LIMIT_AMT,
         T.TXN_CCY_CODE,
         (T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) AS TXN_CCY_AMT,                 
          DECODE(T.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                            T.cty_Code,
                                            T.CUST_ID,
                                            T.TXN_CCY_CODE,
                                            T.TXN_REC_ID,
                                            T.TXN_CCY_CODE,
                                            'UTIL',
                                            'M','')) AS NCV_COVERAGE_AMT,
           DECODE(T.PRODUCT_CODE,'OD','NA',Scbf_Fetch_Exch_Rate(T.bank_Group_Code,T.cty_Code,cash_margin_ccy_code,
                                           (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
											((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
											ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END),
                                            TXN_CCY_CODE,
                                            'N')) AS CASH_MARGIN,
                                            
           	CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' THEN                                 
           DECODE(T.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                             T.cty_Code,
                                             T.CUST_ID,
                                             T.TXN_CCY_CODE,
                                             T.TXN_REC_ID,
                                             T.TXN_CCY_CODE,
                                             'UTIL',
                                             'M',
                                             '') + Scbf_Fetch_Exch_Rate(T.bank_Group_Code,
                                             	   T.cty_Code,
                                            	   cash_margin_ccy_code,
                                            	   NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                            	   TXN_CCY_CODE,
                                            	   'N')) ELSE 'NA' END AS TOTAL_COVER,
                                            	   
               CASE WHEN T.SHORTFALL_OFFSET_TYPE <> 'CBB' AND T.SHORTFALL_OFFSET_TYPE <>'GBB' AND T.SHORTFALL_OFFSET_TYPE <>'PC' THEN                                            
               DECODE(T.PRODUCT_CODE,'OD','NA',DECODE(T.SHORTFALL_OFFSET_TYPE,'CL',0,(NVL((NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(T.bank_Group_Code,
                                                      T.cty_Code,
                                                      T.CUST_ID,
                                                      T.TXN_CCY_CODE,
                                                      T.TXN_REC_ID,
                                                      T.TXN_CCY_CODE,
                                                      'UTIL',
                                                       'M','') +
               Scbf_Fetch_Exch_Rate(T.bank_Group_Code,T.cty_Code,cash_margin_ccy_code,
                                                     NVL(cash_margin_ccy_amt,0) - NVL(CM_CCY_RELEASE_AMT,0),
                                                     TXN_CCY_CODE,
                                                     'N'),0)) - ((NVL(T.TXN_CCY_NET_AMT, 0) - NVL(T.TXN_CCY_UTIL_AMT, 0))),
                           0)))) ELSE 'NA' END AS SFALLEXCESS,
                DECODE(T.PRODUCT_CODE,'OD','NA',NVL((SELECT LOAN_TO_VALUE_PCT 							
                              FROM SCBT_R_CUST_PRODUCT_LIMIT							  
                              WHERE LIMIT_ID = '16841' AND STOP_LOSS_APPL_FLAG='T'),0)) AS DESIRED_LTV,
                            DECODE(T.PRODUCT_CODE,'OD','NA',NVL((SELECT STOP_LOSS_PCT FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = '16841' AND STOP_LOSS_APPL_FLAG='T'),0)) AS STOP_LOSS_PCT,
                            DECODE(T.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_GET_TXN_LEVEL_LTV_ENQ(T.BANK_GROUP_CODE,
                                                          T.CTY_CODE,
                                                          T.CUST_ID,
                                                          T.TXN_REF_ID,
                                                          T.TXN_REC_ID,
                                                          T.PROD_LIMIT_ID,
                                                          T.TXN_CCY_CODE,
                                                         (NVL(DECODE(T.SCB_ROLE,'AG',T.SYNDICATED_TXN_AMT-NVL(T.SYNDICATED_UTIL_AMT,0),T.TXN_CCY_NET_AMT-NVL(T.TXN_CCY_UTIL_AMT,0)),0)), 
                                                           'UTIL',
                                                           'M',
                                                           T.TXN_STEP_CODE)) AS CALC_LTV,
                            DECODE(T.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_C_GET_GCV_BY_TXN_REC_ID(T.BANK_GROUP_CODE,
                                                           T.CTY_CODE,
                                                           T.CUST_ID,
                                                           T.TXN_CCY_CODE,
                                                           T.TXN_REC_ID,
                                                           T.TXN_CCY_CODE,
                                                           'UTIL',
                                                           'M',
                                                           T.TXN_STEP_CODE)) AS LINKED_GCV,
                            DECODE(T.PRODUCT_CODE,'OD','NA',Scbk_P_Cocoa_Cdb.SCBF_GET_TOPUP_AMT_BY_LEVEL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                            T.TXN_CCY_CODE,
                                                            P.LIMIT_ID,
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_CCY_CODE,
                                                            'T')) AS CASH_TOP_UP,
                                        DECODE(T.PRODUCT_CODE,'OD','NA',NVL((SELECT STOP_LOSS_CCY_AMT FROM SCBT_R_CUST_PRODUCT_LIMIT
                              WHERE LIMIT_ID = '16841' AND STOP_LOSS_APPL_FLAG='T'),0)) AS STOP_LOSS_VALUE,
                            DECODE(T.PRODUCT_CODE,'OD','NA',NVL(Scbk_P_Cocoa_Cdb.SCBF_GET_TXN_LEVEL_SHORTFALL(T.BANK_GROUP_CODE,
                                                            T.CTY_CODE,
                                                            T.CUST_ID,
                                                            T.TXN_REF_ID,
                                                            T.TXN_REC_ID,
                                                           (NVL(T.TXN_CCY_NET_AMT,0) - NVL(T.TXN_CCY_UTIL_AMT, 0)),
                                                            T.TXN_CCY_CODE,
                                                            T.TXN_STEP_CODE, 
                                                           'N',
                                                           'M',
                                                           'N',
                                                           T.CASH_MARGIN_ADJ,
                                                           T.CASH_MARGIN_ADJ_AMT,                                                               
                                                           T.TXN_CCY_CODE,
                                                           NVL(T.cash_margin_ccy_amt,0) - NVL(T.CM_CCY_RELEASE_AMT,0),
                                                           T.CASH_MARGIN_CCY_AMT,
                                                           0,
                                                           T.PROD_LIMIT_ID),0))AS SHORTFALL_AMOUNT                        
                  										   FROM SCBT_T_TXN_MST T, SCBT_R_CUST_PRODUCT_LIMIT P
                 										   WHERE T.PROD_LIMIT_ID = P.LIMIT_ID
                          								   AND(T.TXN_CCY_NET_AMT - NVL(T.TXN_CCY_UTIL_AMT, 0)) <> 0
                         								   AND NVL(T.TXN_STATUS_CODE,'02') <> '11'
                   										   AND T.BANK_GROUP_CODE = 'SCB'
                   										   AND T.CTY_CODE = 'US'
                   										   AND T.CUST_ID = '800010955' 
														   
				   										   AND T.PRODUCT_CODE NOT IN (SELECT PM.PRODUCT_CODE FROM SCBT_R_PRODUCT_MST PM WHERE PM.BANK_GROUP_CODE = T.BANK_GROUP_CODE AND PM.PROD_REF_CODE ='OD')
                          								   AND NVL(P.FIN_HEDGE_MARGIN,'N') <> 'Y'

                  							AND T.PROD_LIMIT_ID IN  (SELECT limit_id
                                            FROM SCBT_R_CUST_PRODUCT_LIMIT 
                                            WHERE bank_group_code = T.BANK_GROUP_CODE AND cty_code = T.CTY_CODE
                                            START WITH limit_id = '17008'
                                            CONNECT BY PRIOR ext_limit_id = inner_to_id) ORDER BY deal_id,txn_ref_id
