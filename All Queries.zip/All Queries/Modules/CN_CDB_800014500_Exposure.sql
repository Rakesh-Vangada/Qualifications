SELECT   limitcategory, limitid, scilimitid, innertoid, NVL (limitname, ' '),
         productcode, limitccy, activelimit, prodwise_util, utilisation,
         pendingincreaseamount,
         Scbf_Get_Acc_Balance (bgcode,
                               ctycode,
                               customerid,
                               limitid,
                               limitccy,
                               'N'
                              ) AS balance,
         availablity, pendingdecreaseamount, ncv, pi_ncv, csh_margin,
         pi_csh_margin, pd_csh_margin, shortfalloffset, desired_ltv,
         stop_loss_pct, stop_loss_value, calculated_ltv_pct,
         calculated_ltv_pct_with_pi, linked_gcv, pi_linked_gcv, unlinked_gcv,
         pi_unlinked_gcv, cash_top_up, total_ncv_wt_pi, total_ncv,
         shorfall_amt_gcv, group_name,
         NVL (Scbf_C_Get_Code_Desc ('SCB',
                                    '*',
                                    '*',
                                    'EN',
                                    'CI124',
                                    productcode,
                                    1
                                   ),
              ' '
             ),
         comments,LIMIT_REMARKS
    FROM (SELECT   l.bank_group_code "BGCODE", l.cty_code "CTYCODE",
                   l.limit_seq_no "SEQNO", l.cust_id "CUSTOMERID",
                   l.limit_cat_code "LIMITCATEGORY",
                   Scbf_C_Get_Code_Desc
                                       (l.bank_group_code,
                                        l.cty_code,
                                        '*',
                                        'EN',
                                        'CD032',
                                        l.shortfall_offset,
                                        1
                                       ) "SHORTFALLOFFSET",
                   l.limit_name "LIMITNAME",
                   DECODE (l.limit_product_code,
                           '*', 'OVERALL LIMIT',
                           l.limit_product_code
                          ) "PRODUCTCODE",
                   NVL
                      (Scbf_C_Get_Code_Desc ('SCB',
                                             '*',
                                             '*',
                                             'EN',
                                             'CI124',
                                             l.limit_product_code,
                                             1
                                            ),
                       ' '
                      ) "PRODUCTDESCRIPTION",
                   l.limit_id "LIMITID", l.ext_limit_id "SCILIMITID",
                   l.inner_to_id "INNERTOID", l.limit_ccy_code "LIMITCCY",
                   NVL (l.limit_ccy_active_amt, 0) "ACTIVELIMIT",
                   DECODE
                      (l.limit_product_code,
                       '*', 0,
                       NVL
                          (Scbk_P_Cocoa_Cdb.scbf_get_prod_util_amt_with_cb
                                                         (l.bank_group_code,
                                                          l.cty_code,
                                                          l.cust_id,
                                                          l.limit_id,
                                                          l.limit_ccy_code,
                                                          l.limit_product_code
                                                         ),
                           0
                          )
                      ) "PRODWISE_UTIL",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0) "UTILISATION",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0) "PENDINGINCREASEAMOUNT",
                   NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_dec_amt,
                                                   0)
                                             ), 0) "PENDINGDECREASEAMOUNT",
                   NVL (u.comments, '') "COMMENTS",NVL (u.LIMIT_REMARKS, '') "LIMIT_REMARKS",
                     (  NVL (l.limit_ccy_active_amt, 0)
                      + Scbf_Get_Acc_Balance (l.bank_group_code,
                                              l.cty_code,
                                              l.cust_id,
                                              l.limit_id,
                                              l.limit_ccy_code,
                                              'N'
                                             )
                     )
                   - (  NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_utilised_amt,
                                                   0)
                                             ), 0)
                      + NVL (Scbf_Round_Amt_By_Ccy (u.bank_group_code,
                                              u.limit_ccy_code,
                                              NVL (u.limit_ccy_pend_inc_amt,
                                                   0)
                                             ), 0)
                     ) "AVAILABLITY",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                       0
                      ) "CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'Y'
                                                        ),
                       0
                      ) "PI_CSH_MARGIN",
                   NVL
                      (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'D'
                                                        ),
                       0
                      ) "PD_CSH_MARGIN",
                   (CASE
                       WHEN l.shortfall_offset <> 'CBB'
                       AND l.shortfall_offset <> 'GBB'
                          THEN    NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                                      0
                                     )
                               || ''
                       ELSE 'NA'
                    END
                   ) AS ncv,
                   (CASE
                       WHEN l.shortfall_offset <> 'CBB'
                       AND l.shortfall_offset <> 'GBB'
                          THEN    NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'Y'
                                                        ),
                                      0
                                     )
                               || ''
                       ELSE 'NA'
                    END
                   ) AS pi_ncv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT loan_to_value_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS desired_ltv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_PARTY_MST
                                      WHERE bank_group_code =
                                                             l.bank_group_code
                                        AND cty_code = l.cty_code
                                        AND party_id = l.cust_id),
                                    0
                                   )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_PRODUCT_LIMIT
                                      WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id AND limit_id = l.limit_id), 0)
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL ((SELECT stop_loss_pct
                                       FROM SCBT_R_CUST_FACILITY_GRP
                                      WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                    0
                                   )
                       ELSE 0
                    END
                   ) AS stop_loss_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_PARTY_MST
                                    WHERE bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND party_id = l.cust_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_PRODUCT_LIMIT
                                    WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id AND limit_id = l.limit_id),
                                  0
                                 )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN NVL
                                 ((SELECT Scbf_Fetch_Exch_Rate
                                                   (l.bank_group_code,
                                                    l.cty_code,
                                                    l.stop_loss_ccy_code,
                                                    NVL (l.stop_loss_ccy_amt,
                                                         0
                                                        ),
                                                    l.limit_ccy_code,
                                                    'N'
                                                   )
                                     FROM SCBT_R_CUST_FACILITY_GRP
                                    WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id 
                                      AND group_type = 'LTV'
                                      AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ',')),
                                  0
                                 )
                       ELSE 0
                    END
                   ) AS stop_loss_value,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A',
                                                            'LTV'
                                                           )
                       ELSE 0
                    END
                   ) AS calculated_ltv_pct_with_pi,
                   (CASE
                       WHEN l.shortfall_offset = 'CBB'
                       AND l.shortfall_offset = 'GBB'
                          THEN 0
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'GCV'
                                                           )
                    END
                   ) AS linked_gcv,
                   (CASE
                       WHEN l.shortfall_offset = 'CBB'
                       AND l.shortfall_offset = 'GBB'
                          THEN 0
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_ltv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'GCV'
                                                           )
                    END
                   ) AS pi_linked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'N',
                                                            'N'
                                                           )
                    END
                   ) AS unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_facility_unlinked_gcv
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'Y',
                                                            'N'
                                                           )
                    END
                   ) AS pi_unlinked_gcv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_topup_amt
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_topup_amt_by_level
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            '',
                                                            '',
                                                            '',
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            '',
                                                            'F'
                                                           )
                    END
                   ) AS cash_top_up,
                   (CASE
                       WHEN l.shortfall_offset <> 'CBB'
                       AND l.shortfall_offset <> 'GBB'
                          THEN    NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                                      0
                                     )
                               || ''
                               +  NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                                      0
                                     )
                               || ''
                       ELSE 'NA'
                    END
                   ) AS total_ncv_wt_pi,
                   (CASE
                       WHEN l.shortfall_offset <> 'CBB'
                       AND l.shortfall_offset <> 'GBB'
                          THEN    NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                                      0
                                     )
                               || ''
                               +  NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_ncv_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'Y'
                                                        ),
                                      0
                                     )
                               || ''
                               +  NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'N'
                                                        ),
                                      0
                                     )
                               || ''
                               +  NVL
                                     (Scbk_P_Cocoa_Cdb.scbf_c_get_overall_cm_amt
                                                        (l.limit_product_code,
                                                         cust_id,
                                                         l.limit_id,
                                                         l.limit_ccy_code,
                                                         'SCB',
                                                         'CN',
                                                         'Y'
                                                        ),
                                      0
                                     )
                               || ''
                       ELSE 'NA'
                    END
                   ) AS total_ncv,
                   (CASE
                       WHEN l.limit_product_code = '*'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_cust_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id
                                                           )
                       WHEN stop_loss_appl_flag = 'F'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                       WHEN stop_loss_appl_flag = 'G'
                          THEN Scbk_P_Cocoa_Cdb.scbf_get_group_level_shortfall
                                        (l.bank_group_code,
                                         l.cty_code,
                                         l.cust_id,
                                         l.limit_id,
                                         Scbf_Get_Exp_Ccy (l.bank_group_code,
                                                           l.cty_code,
                                                           l.cust_id
                                                          ),
                                         'A'
                                        )
                       ELSE Scbk_P_Cocoa_Cdb.scbf_get_limit_level_shortfall
                                                           (l.bank_group_code,
                                                            l.cty_code,
                                                            l.cust_id,
                                                            l.limit_id,
                                                            l.limit_ccy_code,
                                                            'A'
                                                           )
                    END
                   ) AS shorfall_amt_gcv,
                   (SELECT facliity_grp_name
                      FROM SCBT_R_CUST_FACILITY_GRP
                     WHERE  bank_group_code = l.bank_group_code
                                      AND cty_code = l.cty_code
                                      AND cust_id = l.cust_id AND group_type = 'LTV'
                                         AND regexp_substr ( ',' || prod_limit_ids || ',' , ',' || l.limit_id || ',', 1, 1 ) =( ',' || l.limit_id || ','))
                                                                AS group_name
              FROM SCBT_R_CUST_PRODUCT_LIMIT l,SCBT_T_PROD_LIMIT_UTIL u
             WHERE l.limit_id = u.limit_id(+) 
               AND l.bank_group_code = u.bank_group_code(+)
               AND l.cty_code = u.cty_code(+)
               AND l.bank_group_code = 'SCB'
               AND l.cty_code = 'CN'
               AND cust_id = '800014500'
          ORDER BY l.limit_seq_no)
    WHERE bgcode = 'SCB' and ctycode =  'CN' and   customerid = '800014500'  AND limitcategory <>'CI'
ORDER BY seqno ASC
