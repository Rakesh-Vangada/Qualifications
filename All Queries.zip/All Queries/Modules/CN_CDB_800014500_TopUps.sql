SELECT DISTINCT Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD032',b.SHORTFALL_OFFSET,1) "B_SHORTFALLOFFSET",
					   Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1) "A_TOPUP_LEVEL",
					   (CASE WHEN a.TOPUP_LEVEL='T' THEN a.TXN_REF_ID WHEN a.TOPUP_LEVEL='F' THEN b.LIMIT_NAME END) as RefID,
					   a.exposure_ccy_code as CCY,
					   a.exposure_ccy_amt as OSAmt,
					   (CASE WHEN a.LTV_CALC_PCT > (CASE WHEN a.TOPUP_LEVEL='F' OR a.TOPUP_LEVEL='T' 
				       THEN b.STOP_LOSS_PCT END) THEN 'Stoploss Breached' WHEN a.SHORTFALL_CCY_AMT > 
					   (CASE WHEN a.TOPUP_LEVEL='F' THEN b.STOP_LOSS_CCY_AMT WHEN a.TOPUP_LEVEL='T' THEN b.STOP_LOSS_CCY_AMT END) THEN 'Stoploss Breached' 
					   WHEN a.LTV_CALC_PCT > (CASE WHEN a.TOPUP_LEVEL='F' OR  a.TOPUP_LEVEL='T' THEN b.LOAN_TO_VALUE_PCT END) AND 
					   (CASE WHEN a.TOPUP_LEVEL='F' OR  a.TOPUP_LEVEL='T' THEN b.LOAN_TO_VALUE_PCT END) < 
					   (CASE WHEN a.TOPUP_LEVEL='F' OR a.TOPUP_LEVEL='T' THEN b.STOP_LOSS_PCT END) THEN 'Topup Approaching' END) AS Top_up_approaching,  
					   a.ltv_calc_pct,
					   a.GCV_CCY_AMT GCV,
					   (CASE WHEN a.TOPUP_LEVEL='T' THEN NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(a.BANK_GROUP_CODE,
					                   a.CTY_CODE,a.CUST_ID,a.exposure_ccy_code,a.TXN_REC_ID,b.LIMIT_CCY_CODE,'UTIL','M',''),0)
						WHEN a.TOPUP_LEVEL='F' THEN	
					   NVL(Scbk_P_Cocoa_Cdb.SCBF_C_FACILITY_LEVEL_NCV_AMT(b.limit_id,b.LIMIT_CCY_CODE,b.BANK_GROUP_CODE,b.CTY_CODE,'N'),0) END) NCV,
					   a.shortfall_ccy_amt LTVShortfallAmt,
					   NVL(b.LOAN_TO_VALUE_PCT,0) as desiredLTV,
				       NVL(b.STOP_LOSS_PCT,0) as StopLossPrcnt,
					   NVL(b.STOP_LOSS_CCY_AMT,0) as StopLossAmt,
					   a.topup_req_flag as CashTopUpReqFlag, 
					   a.cashtopup_ccy_code as CashTopUpCode,
					   a.cashtopup_ccy_amt as CashTopUpAmt,
					   a.topup_req_ccy_code as TopUpReqCode,
					   a.topup_req_ccy_amt as TopUpReqAmt,
					   b.limit_product_code,
				       Scbf_C_Get_Code_Desc (b.bank_group_code,'*','*','EN','CI124', b.limit_product_code,1) AS prod_code_desc,
				       NVL(a.CMR_CCY_AMT,0),
				       NVL(a.CMR_PERCENT,0),
				       a.LTV_FORMULA
				FROM SCBT_T_STOPLOSS_SUMMARY_MST a,
					 SCBT_R_CUST_PRODUCT_LIMIT b 
				where a.bank_group_code= b.bank_group_code 
					  and a.cty_code=b.cty_code
					  and a.cust_id=b.cust_id 
					  and a.limit_id=b.limit_id 
					  and a.cust_id='800014500'
					  and a.bank_group_code='SCB'
					  and a.cty_code='CN'
					  and a.deal_step_id='M'
					  and a.TOPUP_LEVEL in ('T','F')
					  and nvl(a.exposure_ccy_amt,0) > 0
	          UNION ALL
	          SELECT  DISTINCT 'Collateralized' "B_SHORTFALLOFFSET",
	                  Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1) "A_TOPUP_LEVEL",
	                  a.GROUP_ID as RefID,
	                  a.exposure_ccy_code as CCY,
	                  a.exposure_ccy_amt as OSAmt,
	                  '' AS Top_up_approaching,  
	                  a.ltv_calc_pct,
	                  a.GCV_CCY_AMT GCV,
	                  (NVL(Scbk_P_Cocoa_Cdb.SCBF_GET_GROUP_UNLINKED_NCV(a.BANK_GROUP_CODE,a.CTY_CODE,a.CUST_ID,a.GROUP_ID,a.EXPOSURE_CCY_CODE,'N'),0)
	                  + NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_GROUP_NCV_AMT(a.GROUP_ID,a.CUST_ID,a.BANK_GROUP_CODE,a.CTY_CODE,'N'),0)) as NCV,
	                  a.shortfall_ccy_amt LTVShortfallAmt,
	                  NVL((select LOAN_TO_VALUE_PCT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as desiredLTV,
	                  NVL((select STOP_LOSS_PCT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as StopLossPrcnt,
	                  NVL((select STOP_LOSS_CCY_AMT FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),0) as StopLossAmt,
	                  a.topup_req_flag as CashTopUpReqFlag, 
	                  a.cashtopup_ccy_code as CashTopUpCode,
	                  a.cashtopup_ccy_amt as CashTopUpAmt,
	                  a.topup_req_ccy_code as TopUpReqCode,
	                  a.topup_req_ccy_amt as TopUpReqAmt,
	                  '',(select FACLIITY_GRP_NAME FROM SCBT_R_CUST_FACILITY_GRP where cust_id=a.cust_id and facility_grp_id=a.GROUP_ID),
	                  nvl(a.CMR_CCY_AMT,0),
	                  NVL(a.CMR_PERCENT,0),
				      a.LTV_FORMULA
	                  FROM SCBT_T_STOPLOSS_SUMMARY_MST a
	                  where  a.cust_id='800014500'
	                  and a.bank_group_code='SCB'
	                  and a.cty_code='CN'
	                  and a.deal_step_id='M'
	                  and a.TOPUP_LEVEL='G'
	                  and nvl(a.exposure_ccy_amt,0) > 0   
	          UNION ALL
				SELECT DISTINCT Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD032',
					   (SELECT SHORTFALL_OFFSET_TYPE FROM SCBT_T_TXN_MST WHERE BANK_GROUP_CODE=a.bank_group_code
					   AND CTY_CODE=a.cty_code AND CUST_ID=a.cust_id AND PROD_LIMIT_ID=a.limit_id AND TXN_REC_ID= a.txn_rec_id ),1) "B_SHORTFALLOFFSET",
					   (CASE WHEN a.TOPUP_LEVEL='C' THEN Scbf_C_Get_Code_Desc(a.BANK_GROUP_CODE,a.CTY_CODE,'*','EN','CD052',a.TOPUP_LEVEL,1)
					   WHEN a.TOPUP_LEVEL='NONLTV' THEN 'Non LTV Transaction' END) "A_TOPUP_LEVEL",
					   a.TXN_REF_ID as RefID,
					   a.exposure_ccy_code as CCY,
					   a.exposure_ccy_amt as OSAmt,
					   '' AS Top_up_approaching,  
					   a.ltv_calc_pct,
					   a.GCV_CCY_AMT GCV,
					   NVL(a.NCV_CCY_AMT,0) NCV,
					   a.shortfall_ccy_amt LTVShortfallAmt,0,0,0,
					   a.topup_req_flag as CashTopUpReqFlag, 
					   a.cashtopup_ccy_code as CashTopUpCode,
					   a.cashtopup_ccy_amt as CashTopUpAmt,
					   a.topup_req_ccy_code as TopUpReqCode,
					   a.topup_req_ccy_amt as TopUpReqAmt,
					   '',
				       a.TXN_STEP_CODE,
				       nvl(a.CMR_CCY_AMT,0),
				       NVL(a.CMR_PERCENT,0),
				       a.LTV_FORMULA
				FROM SCBT_T_STOPLOSS_SUMMARY_MST a       
				where  a.cust_id='800014500'
	                  and a.bank_group_code='SCB'
	                  and a.cty_code='CN'
	                  and a.deal_step_id='M'
	                  and a.TOPUP_LEVEL in ('C','NONLTV')
	                  and a.TXN_REF_ID is not null
	                  and nvl(a.exposure_ccy_amt,0) > 0