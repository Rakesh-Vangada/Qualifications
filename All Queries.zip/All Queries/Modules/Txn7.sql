Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: SELECT DISTINCT T.ACCOUNT_NUMBER,T.ACCOUNT_CCY,T.DIFFERENCE FROM SCBT_T_CUST_RECONCIL_SMRY_MST T, SCBT_R_CUST_ACCT_MAINTENANCE W 
            WHERE 
            T.BANK_GROUP_CODE= ? AND T.CTY_CODE = ? AND T.CUSTOMER_ID = ?
			AND T.ACCOUNT_NUMBER = W.ACC_NO
			AND T.CUSTOMER_ID  = W.CUST_ID
			AND T.ACCOUNT_CCY = W.ACC_CCY_CODE
			AND T.BANK_GROUP_CODE = W.BANK_GROUP_CODE
			AND T.CTY_CODE = W.CTY_CODE
			AND W.INCLUDE_FOR_CASH_COLLATERAL='Y'
			AND NVL(T.RECONSILE_FLAG,'N')<>'Y' AND NVL(T.PASS_ADJ_FLAG,'N') <> 'Y'AND NVL(T.DIFFERENCE,0) <> 0
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> RECONCILE_EXCEPTION_LIST
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 15

Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PRODUCT_TYPE in (? , ?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (?))
Hibernate: select code_value_1 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_LIST
Param [0]--> SCB
Param [1]--> TXN_SUP_PROD
Result Size --> 22
Execution time (ms)  --> 16

Hibernate: select code_value_1, code_value_2 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_VALUE_DTLS
Param [0]--> SCB
Param [1]--> TXNISSUVAL
Result Size --> 36
Execution time (ms)  --> 0

Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: SELECT SC.SALES_REG_ID,SC.SALES_REG_ID AS ELC_ID,SC.MAX_CONTRACT_QNTY_UOM AS QNTY_UOM,
	   		(NVL(SC.MAX_CONTRACT_QNTY,0)-NVL(SC.TOTAL_ELC_QNTY,0)-NVL(SC.CONTRACT_UTIL_QNTY,0)) AS OS_QNTY,
	  		 SC.CV_CCY_CODE,(NVL(SC.CV_CCY_AMT,0)-NVL(SC.TOTAL_ELCV_CCY_AMT,0)-NVL(SC.CV_UTIL_CCY_AMT,0)) AS OS_AMT,
	  		 (CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC
		WHERE  SC.BANK_GROUP_CODE = ? AND SC.CTY_CODE = ? AND SC.CUST_ID = ?
		UNION ALL
		SELECT SC.SALES_REG_ID, EC.ELC_REC_ID AS ELC_ID, EC.MAX_ELC_QNTY_UOM AS QNTY_UOM,
			   (NVL(EC.MAX_ELC_QNTY,0)-NVL(EC.ELC_UTIL_QNTY,0)) AS OS_QNTY,EC.ELCV_CCY_CODE,
		       (NVL(EC.ELCV_CCY_AMT,0)-NVL(EC.ELCV_UTIL_CCY_AMT,0)) AS OS_AMT,
		 	(CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC,SCBT_T_EXPORT_LC_MST EC
		WHERE SC.BANK_GROUP_CODE = EC.BANK_GROUP_CODE AND SC.CTY_CODE = EC.CTY_CODE AND SC.SALES_REG_ID = EC.SALES_REG_ID 
		AND EC.BANK_GROUP_CODE =  ? AND EC.CTY_CODE = ? AND SC.CUST_ID = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> EXPORT_REGISTER_OS_AMT_QNTY_DTLS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SCB
Param [4]--> SG
Param [5]--> 800002463
Param [6]--> SCB
Param [7]--> SG
Param [8]--> 800002463
Param [9]--> SCB
Param [10]--> SG
Param [11]--> 800002463
Result Size --> 65
Execution time (ms)  --> 47

Hibernate: SELECT FG.FACILITY_GRP_ID 
			FROM SCBT_T_TXN_HST TH,
				SCBT_R_CUST_FACILITY_GRP FG 
			WHERE 
				TH.BANK_GROUP_CODE = FG.BANK_GROUP_CODE AND TH.CTY_CODE = FG.CTY_CODE AND TH.CUST_ID = FG.CUST_ID 
				AND REGEXP_SUBSTR (','||FG.PROD_LIMIT_IDS||',', ','||TH.PROD_LIMIT_ID||',' , 1, 1) = ','||TH.PROD_LIMIT_ID||','
				AND TH.BANK_GROUP_CODE = ? AND TH.CTY_CODE = ? AND TH.CUST_ID=? AND FG.GROUP_TYPE = 'CAO' 
				AND TH.DEAL_STEP_ID = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_GROUP_ID_FOR_CMR
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT DISTINCT CASH_HELD_FLAG 
			FROM SCBT_T_GRP_CAO_OFFSET_MST 
			WHERE BANK_GROUP_CODE = ?
				AND CTY_CODE = ? 
				AND CUST_ID = ? 
				AND GROUP_ID in (?) 
				AND DEAL_STEP_ID = ?
				AND PAGE_SOURCE='DDB'
				AND CASH_HELD_FLAG='N'
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_CASH_HELD_FLAG
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> [CLIENT]
Param [4]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT TOTAL_SHORTFALL_AMT FROM SCBT_T_CUST_SHORTFALL_SMRY_HST WHERE BANK_GROUP_CODE = ? AND CTY_CODE = ? AND CUST_ID = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SHORT_FALL_CALCULATION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRODUCT_LIMIT_NAME
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> LCORS
Result Size --> 1
Execution time (ms)  --> 0

ERROR - Mon Apr 01 17:40:49 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest = 1586,1586,4,4,
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest request Type = 5 for sessionID = tf.component.fmc.txn.module.38
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-329*SCB*1433068*SG957*20130401174049*20130401174035*20130401174035*20130401174049*OF*SG957T09056*null*TFTIP01*null
INFO  - Mon Apr 01 17:40:49 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-328*2*20130401173957*FPSRequest--2*tf.component.fmc.txn.module*20130401150726798
Appserver proc end: 1364809249296
Appserver proc total: 14031
Appserver proc start: 1364809313718
Hibernate: select * from ( select PARTY_ID,PARTY_NAME  from
			SCBT_R_PARTY_MST where CTY_CODE = '*' 
			and party_id like ? and upper(party_name) like upper(?)  and BANK_GROUP_CODE=?
			and nvl(Upper(custodian),'N') Like Upper('N') ) where rownum <= ?
INFO  - Mon Apr 01 17:41:53 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> CTL_CUST_NON_CUST_ID_LIST
First Result --> 0
Max Result --> 50
Param [0]--> %
Param [1]--> %
Param [2]--> SCB
Result Size --> 50
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:41:53 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-330*SCB*1433068*null*20130401174153*20130401174153*20130401174153*20130401174153*null*null*null*TFTIP01*null
INFO  - Mon Apr 01 17:41:53 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-329*5*20130401174049*FPSRequest--5*tf.component.fmc.txn.module*20130401150726798
Appserver proc end: 1364809313781
Appserver proc total: 63
Appserver proc start: 1364809328687
Generic Module Service Request <OUT> : preHandleProcessRequest-->Y
Generic Module Service Request <IN> : preHandleProcessRequest-->Y
java.lang.ArrayIndexOutOfBoundsException: 6 >= 6
	at java.util.Vector.elementAt(Unknown Source)
	at com.scb.tf.core.util.SCBTable.get(SCBTable.java:170)
	at com.scb.tf.core.util.SCBTable.setElementValue(SCBTable.java:610)
	at com.scb.tf.core.util.SCBTable.parseNSetValues(SCBTable.java:688)
	at com.scb.tf.core.util.SCBTable.setXMLValue(SCBTable.java:720)
	at com.scb.tf.cvc.core.types.SCBAcceptableWarningsTable.updateAcceptedWarnings(SCBAcceptableWarningsTable.java:49)
	at com.scb.tf.cvc.core.process.SCBValidationProcessHandler.setAcceptedWarnings(SCBValidationProcessHandler.java:175)
	at com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor.navigate(SCBGenericModuleServiceRequestProcessor.java:800)
	at com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor.clear4Release(SCBGenericModuleServiceRequestProcessor.java:427)
	at com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor.handleProcessRequest(SCBGenericModuleServiceRequestProcessor.java:1042)
	at com.scb.tf.core.process.SCBAppServerServiceRequestProcessor.processRequest(SCBAppServerServiceRequestProcessor.java:174)
	at com.scb.tf.appserver.crp.SCBClientRequestProcessHandler.processXMLRequest(SCBClientRequestProcessHandler.java:266)
	at com.scb.rmi.remote.SCBRemoteInterfaceImpl.processXMLRequest(SCBRemoteInterfaceImpl.java:44)
	at sun.reflect.GeneratedMethodAccessor31.invoke(Unknown Source)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
	at java.lang.reflect.Method.invoke(Unknown Source)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:304)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:172)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:139)
	at org.springframework.remoting.support.RemoteInvocationTraceInterceptor.invoke(RemoteInvocationTraceInterceptor.java:70)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:161)
	at org.springframework.aop.framework.JdkDynamicAopProxy.invoke(JdkDynamicAopProxy.java:204)
	at $Proxy106.processXMLRequest(Unknown Source)
	at sun.reflect.GeneratedMethodAccessor59.invoke(Unknown Source)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
	at java.lang.reflect.Method.invoke(Unknown Source)
	at org.springframework.remoting.support.RemoteInvocation.invoke(RemoteInvocation.java:205)
	at org.springframework.remoting.support.DefaultRemoteInvocationExecutor.invoke(DefaultRemoteInvocationExecutor.java:38)
	at org.springframework.remoting.support.RemoteInvocationBasedExporter.invoke(RemoteInvocationBasedExporter.java:76)
	at org.springframework.remoting.rmi.RmiBasedExporter.invoke(RmiBasedExporter.java:72)
	at org.springframework.remoting.rmi.RmiInvocationWrapper.invoke(RmiInvocationWrapper.java:72)
	at sun.reflect.GeneratedMethodAccessor29.invoke(Unknown Source)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
	at java.lang.reflect.Method.invoke(Unknown Source)
	at sun.rmi.server.UnicastServerRef.dispatch(Unknown Source)
	at sun.rmi.transport.Transport$1.run(Unknown Source)
	at java.security.AccessController.doPrivileged(Native Method)
	at sun.rmi.transport.Transport.serviceCall(Unknown Source)
	at sun.rmi.transport.tcp.TCPTransport.handleMessages(Unknown Source)
	at sun.rmi.transport.tcp.TCPTransport$ConnectionHandler.run0(Unknown Source)
	at sun.rmi.transport.tcp.TCPTransport$ConnectionHandler.run(Unknown Source)
	at java.util.concurrent.ThreadPoolExecutor$Worker.runTask(Unknown Source)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)
	at java.lang.Thread.run(Unknown Source)
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: select scbsoftloc0_.LOCK_KEY as LOCK1_146_, scbsoftloc0_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc0_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc0_.SESSION_ID as SESSION4_146_, scbsoftloc0_.USER_ID as USER5_146_, scbsoftloc0_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc0_.CTY_CODE as CTY7_146_, scbsoftloc0_.TBU_CODE as TBU8_146_, scbsoftloc0_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc0_ where scbsoftloc0_.LOCK_KEY=?
Hibernate: select scbsoftloc0_.LOCK_KEY as LOCK1_146_, scbsoftloc0_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc0_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc0_.SESSION_ID as SESSION4_146_, scbsoftloc0_.USER_ID as USER5_146_, scbsoftloc0_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc0_.CTY_CODE as CTY7_146_, scbsoftloc0_.TBU_CODE as TBU8_146_, scbsoftloc0_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc0_ where scbsoftloc0_.LOCK_KEY=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?) 	 
		UNION ALL 		
		SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.DELIV_SCHEDULE_CODE = 'CSH' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE 
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?)
INFO  - Mon Apr 01 17:42:08 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MARKET_PRICE_WITH_NO_ADJSTMENT
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Param [3]--> SG957
Param [4]--> SG957
Param [5]--> SCB
Param [6]--> CM10000314
Param [7]--> 200
Param [8]--> SG957
Param [9]--> SG957
Result Size --> 2
Execution time (ms)  --> 0

Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?) 	 
		UNION ALL 		
		SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.DELIV_SCHEDULE_CODE = 'CSH' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE 
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?)
INFO  - Mon Apr 01 17:42:08 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MARKET_PRICE_WITH_NO_ADJSTMENT
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Param [3]--> SG957
Param [4]--> SG957
Param [5]--> SCB
Param [6]--> CM10000314
Param [7]--> 200
Param [8]--> SG957
Param [9]--> SG957
Result Size --> 2
Execution time (ms)  --> 0

Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?) 	 
		UNION ALL 		
		SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.DELIV_SCHEDULE_CODE = 'CSH' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE 
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?)
INFO  - Mon Apr 01 17:42:08 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MARKET_PRICE_WITH_NO_ADJSTMENT
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Param [3]--> SG957
Param [4]--> SG957
Param [5]--> SCB
Param [6]--> CM10000314
Param [7]--> 200
Param [8]--> SG957
Param [9]--> SG957
Result Size --> 2
Execution time (ms)  --> 0

Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?) 	 
		UNION ALL 		
		SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.DELIV_SCHEDULE_CODE = 'CSH' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE 
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?)
INFO  - Mon Apr 01 17:42:08 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MARKET_PRICE_WITH_NO_ADJSTMENT
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Param [3]--> SG957
Param [4]--> SG957
Param [5]--> SCB
Param [6]--> CM10000314
Param [7]--> 200
Param [8]--> SG957
Param [9]--> SG957
Result Size --> 2
Execution time (ms)  --> 0

Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: SELECT DISTINCT T.ACCOUNT_NUMBER,T.ACCOUNT_CCY,T.DIFFERENCE FROM SCBT_T_CUST_RECONCIL_SMRY_MST T, SCBT_R_CUST_ACCT_MAINTENANCE W 
            WHERE 
            T.BANK_GROUP_CODE= ? AND T.CTY_CODE = ? AND T.CUSTOMER_ID = ?
			AND T.ACCOUNT_NUMBER = W.ACC_NO
			AND T.CUSTOMER_ID  = W.CUST_ID
			AND T.ACCOUNT_CCY = W.ACC_CCY_CODE
			AND T.BANK_GROUP_CODE = W.BANK_GROUP_CODE
			AND T.CTY_CODE = W.CTY_CODE
			AND W.INCLUDE_FOR_CASH_COLLATERAL='Y'
			AND NVL(T.RECONSILE_FLAG,'N')<>'Y' AND NVL(T.PASS_ADJ_FLAG,'N') <> 'Y'AND NVL(T.DIFFERENCE,0) <> 0
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> RECONCILE_EXCEPTION_LIST
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PRODUCT_TYPE in (? , ?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (?))
Hibernate: select code_value_1 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_LIST
Param [0]--> SCB
Param [1]--> TXN_SUP_PROD
Result Size --> 22
Execution time (ms)  --> 16

Hibernate: select code_value_1, code_value_2 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_VALUE_DTLS
Param [0]--> SCB
Param [1]--> TXNISSUVAL
Result Size --> 36
Execution time (ms)  --> 0

Hibernate: SELECT SC.SALES_REG_ID,SC.SALES_REG_ID AS ELC_ID,SC.MAX_CONTRACT_QNTY_UOM AS QNTY_UOM,
	   		(NVL(SC.MAX_CONTRACT_QNTY,0)-NVL(SC.TOTAL_ELC_QNTY,0)-NVL(SC.CONTRACT_UTIL_QNTY,0)) AS OS_QNTY,
	  		 SC.CV_CCY_CODE,(NVL(SC.CV_CCY_AMT,0)-NVL(SC.TOTAL_ELCV_CCY_AMT,0)-NVL(SC.CV_UTIL_CCY_AMT,0)) AS OS_AMT,
	  		 (CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC
		WHERE  SC.BANK_GROUP_CODE = ? AND SC.CTY_CODE = ? AND SC.CUST_ID = ?
		UNION ALL
		SELECT SC.SALES_REG_ID, EC.ELC_REC_ID AS ELC_ID, EC.MAX_ELC_QNTY_UOM AS QNTY_UOM,
			   (NVL(EC.MAX_ELC_QNTY,0)-NVL(EC.ELC_UTIL_QNTY,0)) AS OS_QNTY,EC.ELCV_CCY_CODE,
		       (NVL(EC.ELCV_CCY_AMT,0)-NVL(EC.ELCV_UTIL_CCY_AMT,0)) AS OS_AMT,
		 	(CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC,SCBT_T_EXPORT_LC_MST EC
		WHERE SC.BANK_GROUP_CODE = EC.BANK_GROUP_CODE AND SC.CTY_CODE = EC.CTY_CODE AND SC.SALES_REG_ID = EC.SALES_REG_ID 
		AND EC.BANK_GROUP_CODE =  ? AND EC.CTY_CODE = ? AND SC.CUST_ID = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> EXPORT_REGISTER_OS_AMT_QNTY_DTLS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SCB
Param [4]--> SG
Param [5]--> 800002463
Param [6]--> SCB
Param [7]--> SG
Param [8]--> 800002463
Param [9]--> SCB
Param [10]--> SG
Param [11]--> 800002463
Result Size --> 65
Execution time (ms)  --> 47

Hibernate: SELECT FG.FACILITY_GRP_ID 
			FROM SCBT_T_TXN_HST TH,
				SCBT_R_CUST_FACILITY_GRP FG 
			WHERE 
				TH.BANK_GROUP_CODE = FG.BANK_GROUP_CODE AND TH.CTY_CODE = FG.CTY_CODE AND TH.CUST_ID = FG.CUST_ID 
				AND REGEXP_SUBSTR (','||FG.PROD_LIMIT_IDS||',', ','||TH.PROD_LIMIT_ID||',' , 1, 1) = ','||TH.PROD_LIMIT_ID||','
				AND TH.BANK_GROUP_CODE = ? AND TH.CTY_CODE = ? AND TH.CUST_ID=? AND FG.GROUP_TYPE = 'CAO' 
				AND TH.DEAL_STEP_ID = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_GROUP_ID_FOR_CMR
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT DISTINCT CASH_HELD_FLAG 
			FROM SCBT_T_GRP_CAO_OFFSET_MST 
			WHERE BANK_GROUP_CODE = ?
				AND CTY_CODE = ? 
				AND CUST_ID = ? 
				AND GROUP_ID in (?) 
				AND DEAL_STEP_ID = ?
				AND PAGE_SOURCE='DDB'
				AND CASH_HELD_FLAG='N'
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_CASH_HELD_FLAG
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> [CLIENT]
Param [4]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT TOTAL_SHORTFALL_AMT FROM SCBT_T_CUST_SHORTFALL_SMRY_HST WHERE BANK_GROUP_CODE = ? AND CTY_CODE = ? AND CUST_ID = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SHORT_FALL_CALCULATION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRODUCT_LIMIT_NAME
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> LCORS
Result Size --> 1
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Notifyops row
Hibernate: select scbparamda0_.BANK_GROUP_CODE as col_0_0_, scbparamda0_.PARAM_ID as col_0_1_, scbparamda0_.PARAM_KEY_01 as col_0_2_, scbparamda0_.PARAM_KEY_02 as col_0_3_, scbparamda0_.PARAM_KEY_03 as col_0_4_, scbparamda0_.PARAM_KEY_04 as col_0_5_, scbparamda0_.PARAM_KEY_05 as col_0_6_, scbparamda0_.PARAM_KEY_06 as col_0_7_, scbparamda0_.PARAM_KEY_07 as col_0_8_, scbparamda0_.PARAM_KEY_08 as col_0_9_, scbparamda0_.PARAM_KEY_09 as col_0_10_, scbparamda0_.PARAM_KEY_10 as col_0_11_, scbparamda0_.CTY_CODE as col_0_12_, scbparamda0_.PARTY_ID as col_0_13_, scbparamda0_.TBU_CODE as col_0_14_ from SCBT_R_PARAM_DATA scbparamda0_ where (scbparamda0_.BANK_GROUP_CODE in (? , '*' , '**')) and (scbparamda0_.CTY_CODE in (? , '*' , '**')) and (scbparamda0_.PARTY_ID in (? , '*' , '**')) and (scbparamda0_.TBU_CODE in (? , '*' , '**')) and scbparamda0_.PARAM_ID=? and (scbparamda0_.PARAM_KEY_01 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_02 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_03 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_04 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_05 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_06 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_07 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_08 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_09 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_10 in (? , '*' , '**')) order by scbparamda0_.PARAM_KEY_SEQ_CODE desc
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::txnRemarksIF.getLimitOverAllStatus().getValue()null
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Notifyops row
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::txnRemarksIF.getLimitOverAllStatus().getValue()null
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: SELECT CR.COLLATERAL_CATEGORY ,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(P.UTILISED_QNTY,0)) AS PRIM_TOTAL_QNTY,SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(P.SEC_UTILISED_QNTY,0)) AS SEC_TOTAL_QNTY
		FROM SCBT_T_PARCEL_MST P,SCBT_R_COMMODITY_MST CM,SCBT_T_COLLATERAL_REGISTER_MST CR 
		WHERE P.COMMODITY_ID = CM.COMMODITY_ID AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL')
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CR.CUST_ID = ? AND CR.DEAL_ID LIKE ?
		AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE AND P.CTY_CODE = CR.CTY_CODE AND P.DEAL_ID = CR.DEAL_ID AND P.COLLATERAL_ID = CR.COLLATERAL_ID
		GROUP BY CR.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
		P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_TOTAL_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
        SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(PM.NET_COMMODITY_QNTY,0)) AS PRIM_PENDING_INWARD,
	    SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(PM.SEC_NET_COMMODITY_QNTY,0)) AS SEC_PENDING_INWARD
		FROM SCBT_T_PARCEL_HST P,SCBT_R_COMMODITY_MST CM,SCBT_T_DEAL_HIST DH,SCBT_T_PARCEL_MST PM,SCBT_T_COLLATERAL_REGISTER_MST CR,SCBT_T_COLLATERAL_REGISTER_HST CH 
		WHERE P.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND DH.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.CTY_CODE = DH.CTY_CODE
		AND P.BANK_GROUP_CODE = PM.BANK_GROUP_CODE(+) AND P.CTY_CODE = PM.CTY_CODE(+) AND P.PARCEL_ID = PM.PARCEL_ID(+)
		AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE(+) AND P.CTY_CODE = CR.CTY_CODE(+) AND P.COLLATERAL_ID = CR.COLLATERAL_ID(+)
		AND P.COMMODITY_ID = PM.COMMODITY_ID(+) AND P.COLLATERAL_TYPE_CODE = PM.COLLATERAL_TYPE_CODE(+)
		AND P.BANK_GROUP_CODE = CH.BANK_GROUP_CODE AND P.CTY_CODE = CH.CTY_CODE AND P.COLLATERAL_ID = CH.COLLATERAL_ID
		AND P.DEAL_ID = CH.DEAL_ID AND P.DEAL_ID = DH.DEAL_ID AND DH.DEAL_ID = CH.DEAL_ID AND DH.CUST_ID = CH.CUST_ID		
		AND DH.DEAL_STEP_ID = P.DEAL_STEP_ID  AND DH.DEAL_STEP_ID = CH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE <> '03' AND P.COMMODITY_ID = CM.COMMODITY_ID 
		AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL') 
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CH.CUST_ID = ? AND P.DEAL_ID LIKE ?
		GROUP BY CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
		P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_PENDING_INWARD_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Result Size --> 1
Execution time (ms)  --> 15

Hibernate: SELECT CH.COLLATERAL_CATEGORY,PH.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PH.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(P.NET_COMMODITY_QNTY,0)) AS PRIM_PENDING_OUTWARD,SUM(NVL(P.SEC_COMMODITY_QNTY,0)) AS SEC_PENDING_OUTWARD
		FROM SCBT_T_PARCEL_HST P,SCBT_R_COMMODITY_MST CM,SCBT_T_DEAL_HIST DH,SCBT_T_PARCEL_HST PH,SCBT_T_COLLATERAL_REGISTER_HST CH
		WHERE P.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND DH.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.CTY_CODE = DH.CTY_CODE
		AND P.BANK_GROUP_CODE = CH.BANK_GROUP_CODE AND P.CTY_CODE = CH.CTY_CODE AND PH.COLLATERAL_ID = CH.COLLATERAL_ID AND P.LINK_PARCEL_ID = PH.PARCEL_ID
		AND P.BANK_GROUP_CODE = PH.BANK_GROUP_CODE AND P.CTY_CODE = PH.CTY_CODE AND P.DEAL_ID = PH.DEAL_ID AND DH.DEAL_ID = PH.DEAL_ID
		AND P.DEAL_ID = CH.DEAL_ID AND P.DEAL_ID = DH.DEAL_ID AND DH.DEAL_ID = CH.DEAL_ID AND DH.CUST_ID = CH.CUST_ID 		
		AND DH.DEAL_STEP_ID = P.DEAL_STEP_ID AND DH.DEAL_STEP_ID = CH.DEAL_STEP_ID AND DH.DEAL_STEP_ID = PH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE <> '03' AND PH.COMMODITY_ID = CM.COMMODITY_ID 
		AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND PH.COMMODITY_ID = CM.COMMODITY_ID 
		AND (P.PARCEL_ID,P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,P.NET_COMMODITY_QNTY,P.SEC_COMMODITY_QNTY) NOT IN
			(SELECT NVL(PM.PARCEL_ID,'P1'),NVL(PM.NET_COMMODITY_UOM,'PUOM'),NVL(PM.SEC_NET_COMMODITY_QNTY_UOM,'SUOM'),NVL(PM.NET_COMMODITY_QNTY,0),NVL(PM.SEC_COMMODITY_QNTY,0) FROM 
			SCBT_T_PARCEL_MST PM WHERE P.BANK_GROUP_CODE = PM.BANK_GROUP_CODE AND P.CTY_CODE = PM.CTY_CODE AND P.DEAL_ID = PM.DEAL_ID AND P.PARCEL_ID = PM.PARCEL_ID)		
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CH.CUST_ID = ? AND P.DEAL_ID LIKE ?		
		GROUP BY CH.COLLATERAL_CATEGORY,PH.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PH.COMMODITY_ID,
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
		UNION 
		SELECT CR.COLLATERAL_CATEGORY,PM.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PM.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		PM.NET_COMMODITY_UOM,PM.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(PM.NET_COMMODITY_QNTY,0)) AS MST_PRIM_PENDING_OUTWARD,SUM(NVL(PM.SEC_COMMODITY_QNTY,0)) AS MST_SEC_PENDING_OUTWARD
		FROM SCBT_T_COLLATERAL_REGISTER_MST CR,SCBT_T_PARCEL_MST PM,SCBT_R_COMMODITY_MST CM,SCBT_T_PARCEL_HST PH,SCBT_T_DEAL_HIST DH
		WHERE PM.BANK_GROUP_CODE = CR.BANK_GROUP_CODE AND PM.CTY_CODE = CR.CTY_CODE AND PM.COLLATERAL_ID = CR.COLLATERAL_ID 
		AND PM.BANK_GROUP_CODE = CR.BANK_GROUP_CODE 
        AND PM.CTY_CODE = CR.CTY_CODE 
		AND PH.COLLATERAL_ID = PM.COLLATERAL_ID
        AND PM.BANK_GROUP_CODE = PH.BANK_GROUP_CODE  AND PM.CTY_CODE = PH.CTY_CODE AND PH.DEAL_ID = PM.DEAL_ID
		AND (PM.COLLATERAL_TYPE_CODE <> PH.COLLATERAL_TYPE_CODE OR PM.COMMODITY_ID <> PH.COMMODITY_ID 
			OR PM.NET_COMMODITY_UOM <> PH.NET_COMMODITY_UOM OR NVL(PM.SEC_NET_COMMODITY_QNTY_UOM,'NOUOM')<>NVL(PH.SEC_NET_COMMODITY_QNTY_UOM,'NOUOM'))
		AND DH.BANK_GROUP_CODE = PH.BANK_GROUP_CODE  AND DH.CTY_CODE = PH.CTY_CODE AND DH.DEAL_ID = PM.DEAL_ID		
		AND DH.STEP_STATUS_CODE <> '03' AND DH.DEAL_STEP_ID = PH.DEAL_STEP_ID AND CR.CUST_ID = DH.CUST_ID AND CR.DEAL_ID = DH.DEAL_ID	
		AND PM.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND CR.DEAL_ID = PM.DEAL_ID AND PM.PARCEL_ID = PH.PARCEL_ID
		AND PM.PARCEL_TYPE_CODE NOT IN ('MST','REL') AND PM.COMMODITY_ID = CM.COMMODITY_ID 
		AND PM.BANK_GROUP_CODE = ? AND PM.CTY_CODE = ? AND CR.CUST_ID = ? AND PM.DEAL_ID LIKE ?
		GROUP BY CR.COLLATERAL_CATEGORY,PM.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PM.COMMODITY_ID,PM.NET_COMMODITY_UOM,
		PM.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:42:11 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_PENDING_OUTWARD_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Param [4]--> SCB
Param [5]--> SG
Param [6]--> 800002463
Param [7]--> SG957T09056
Result Size --> 1
Execution time (ms)  --> 188

Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: select scbdealhis0_.bank_group_code as bank1_8_0_, scbdealhis0_.cty_code as cty2_8_0_, scbdealhis0_.DEAL_STEP_ID as DEAL3_8_0_, scbdealhis0_.deal_id as deal4_8_0_, scbdealhis0_.CUST_ID as CUST5_8_0_, scbdealhis0_.TP_REJECT_FLAG as TP6_8_0_, scbdealhis0_.TP_REJECT_REASON as TP7_8_0_, scbdealhis0_.TP_SYSTEM_CODE as TP8_8_0_, scbdealhis0_.TP_STEP_ID as TP9_8_0_, scbdealhis0_.TP_DEAL_ID as TP10_8_0_, scbdealhis0_.TP_CUST_ID as TP11_8_0_, scbdealhis0_.BU_CODE as BU12_8_0_, scbdealhis0_.STEP_CODE as STEP13_8_0_, scbdealhis0_.SUB_STEP_CODE as SUB14_8_0_, scbdealhis0_.STEP_STATUS_CODE as STEP15_8_0_, scbdealhis0_.MAKER_ID as MAKER16_8_0_, scbdealhis0_.maker_timestamp as maker17_8_0_, scbdealhis0_.CHECKER_ID as CHECKER18_8_0_, scbdealhis0_.checker_timestamp as checker19_8_0_, scbdealhis0_.VALUE_DATE as VALUE20_8_0_, scbdealhis0_.BUSINESS_DATE as BUSINESS21_8_0_, scbdealhis0_.OFFERING_ID as OFFERING22_8_0_, scbdealhis0_.OFFERING_TIMESTAMP as OFFERING23_8_0_, scbdealhis0_.CO_BORROWER_ID as CO24_8_0_, scbdealhis0_.MANUAL_EXCEPTION_FLAG as MANUAL25_8_0_, scbdealhis0_.MANUAL_EXCEPTION_REASON as MANUAL26_8_0_, scbdealhis0_.EXCEPTION_PRE_APPROVED_FLAG as EXCEPTION27_8_0_, scbdealhis0_.EXCEPTION_RM_APPROVED_FLAG as EXCEPTION28_8_0_, scbdealhis0_.DEAL_STEP_CCY_CODE as DEAL29_8_0_, scbdealhis0_.DEAL_STEP_CCY_AMT as DEAL30_8_0_, scbdealhis0_.TP_OFFERING_REASON_9 as TP31_8_0_ from SCBT_T_DEAL_HIST scbdealhis0_ where scbdealhis0_.bank_group_code=? and scbdealhis0_.cty_code=? and scbdealhis0_.DEAL_STEP_ID=? and scbdealhis0_.deal_id=? and scbdealhis0_.CUST_ID=?
inside of save remarks
Hibernate: delete from SCBT_T_REMARKS_DTLS where DEAL_STEP_ID=? and BANK_GROUP_CODE=? and CTY_CODE=?
Hibernate: select scbremarke0_.BANK_GROUP_CODE as BANK1_214_0_, scbremarke0_.CTY_CODE as CTY2_214_0_, scbremarke0_.DEAL_STEP_ID as DEAL3_214_0_, scbremarke0_.REC_ID as REC4_214_0_, scbremarke0_.USER_ID as USER5_214_0_, scbremarke0_.STEP_CODE as STEP6_214_0_, scbremarke0_.REMARKS_CAT_CODE as REMARKS7_214_0_, scbremarke0_.CREATED_DATE as CREATED8_214_0_, scbremarke0_.REMARKS as REMARKS214_0_, scbremarke0_.ATTACHED_FILE_PATH as ATTACHED10_214_0_, scbremarke0_.SEND_EMAIL_TO as SEND11_214_0_, scbremarke0_.SEND_EMAIL_CC as SEND12_214_0_, scbremarke0_.ATTACHED_FILE_CONTENT as ATTACHED13_214_0_, scbremarke0_.SEND_TO_EMAIL as SEND14_214_0_, scbremarke0_.EMAIL_SENT as EMAIL15_214_0_, scbremarke0_.ATTACHED_FILE_NAME as ATTACHED16_214_0_ from SCBT_T_REMARKS_DTLS scbremarke0_ where scbremarke0_.BANK_GROUP_CODE=? and scbremarke0_.CTY_CODE=? and scbremarke0_.DEAL_STEP_ID=? and scbremarke0_.REC_ID=?
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::Retrieving from file location::-->null
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::Generating file from the path
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::file >>>> \tmp\null
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::trying to read from file
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::File not found exception thrown in retrieveDataFromDownLoadServlet : java.io.FileNotFoundException: \tmp\null (The system cannot find the path specified)
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::finished creating the clob object
Hibernate: select scbremarke_.BANK_GROUP_CODE, scbremarke_.CTY_CODE, scbremarke_.DEAL_STEP_ID, scbremarke_.REC_ID, scbremarke_.USER_ID as USER5_214_, scbremarke_.STEP_CODE as STEP6_214_, scbremarke_.REMARKS_CAT_CODE as REMARKS7_214_, scbremarke_.CREATED_DATE as CREATED8_214_, scbremarke_.REMARKS as REMARKS214_, scbremarke_.ATTACHED_FILE_PATH as ATTACHED10_214_, scbremarke_.SEND_EMAIL_TO as SEND11_214_, scbremarke_.SEND_EMAIL_CC as SEND12_214_, scbremarke_.ATTACHED_FILE_CONTENT as ATTACHED13_214_, scbremarke_.SEND_TO_EMAIL as SEND14_214_, scbremarke_.EMAIL_SENT as EMAIL15_214_, scbremarke_.ATTACHED_FILE_NAME as ATTACHED16_214_ from SCBT_T_REMARKS_DTLS scbremarke_ where scbremarke_.BANK_GROUP_CODE=? and scbremarke_.CTY_CODE=? and scbremarke_.DEAL_STEP_ID=? and scbremarke_.REC_ID=?
Hibernate: select scbremarke0_.BANK_GROUP_CODE as BANK1_214_0_, scbremarke0_.CTY_CODE as CTY2_214_0_, scbremarke0_.DEAL_STEP_ID as DEAL3_214_0_, scbremarke0_.REC_ID as REC4_214_0_, scbremarke0_.USER_ID as USER5_214_0_, scbremarke0_.STEP_CODE as STEP6_214_0_, scbremarke0_.REMARKS_CAT_CODE as REMARKS7_214_0_, scbremarke0_.CREATED_DATE as CREATED8_214_0_, scbremarke0_.REMARKS as REMARKS214_0_, scbremarke0_.ATTACHED_FILE_PATH as ATTACHED10_214_0_, scbremarke0_.SEND_EMAIL_TO as SEND11_214_0_, scbremarke0_.SEND_EMAIL_CC as SEND12_214_0_, scbremarke0_.ATTACHED_FILE_CONTENT as ATTACHED13_214_0_, scbremarke0_.SEND_TO_EMAIL as SEND14_214_0_, scbremarke0_.EMAIL_SENT as EMAIL15_214_0_, scbremarke0_.ATTACHED_FILE_NAME as ATTACHED16_214_0_ from SCBT_T_REMARKS_DTLS scbremarke0_ where scbremarke0_.BANK_GROUP_CODE=? and scbremarke0_.CTY_CODE=? and scbremarke0_.DEAL_STEP_ID=? and scbremarke0_.REC_ID=?
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::Retrieving from file location::-->null
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::Generating file from the path
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::file >>>> \tmp\null
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::trying to read from file
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::File not found exception thrown in retrieveDataFromDownLoadServlet : java.io.FileNotFoundException: \tmp\null (The system cannot find the path specified)
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.sci.process.util.SCBDocumentLibraryUtility::finished creating the clob object
Hibernate: select scbremarke_.BANK_GROUP_CODE, scbremarke_.CTY_CODE, scbremarke_.DEAL_STEP_ID, scbremarke_.REC_ID, scbremarke_.USER_ID as USER5_214_, scbremarke_.STEP_CODE as STEP6_214_, scbremarke_.REMARKS_CAT_CODE as REMARKS7_214_, scbremarke_.CREATED_DATE as CREATED8_214_, scbremarke_.REMARKS as REMARKS214_, scbremarke_.ATTACHED_FILE_PATH as ATTACHED10_214_, scbremarke_.SEND_EMAIL_TO as SEND11_214_, scbremarke_.SEND_EMAIL_CC as SEND12_214_, scbremarke_.ATTACHED_FILE_CONTENT as ATTACHED13_214_, scbremarke_.SEND_TO_EMAIL as SEND14_214_, scbremarke_.EMAIL_SENT as EMAIL15_214_, scbremarke_.ATTACHED_FILE_NAME as ATTACHED16_214_ from SCBT_T_REMARKS_DTLS scbremarke_ where scbremarke_.BANK_GROUP_CODE=? and scbremarke_.CTY_CODE=? and scbremarke_.DEAL_STEP_ID=? and scbremarke_.REC_ID=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: SELECT Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, '*','*', 'EN', 'CD066', COMMODITY_CODE, 1), Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, ?,'*', 'EN', 'CD010', COMMODITY_CAT_CODE, 1) AS comm_cat_name
		 	FROM SCBT_R_COMMODITY_MST WHERE BANK_GROUP_CODE = ? AND COMMODITY_ID = ?
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_NAME
Param [0]--> SG
Param [1]--> SCB
Param [2]--> CM10000314
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: SELECT PRICE_FEED_ID||';'||FEED_PRICE_CCY||';'||FEED_PRICE_UOM||';'||FEED_PRICE_AMT 
			  FROM SCBT_R_COMMODITY_PRICE_MST P,SCBT_R_COMMODITY_DTLS C WHERE P.BANK_GROUP_CODE = C.BANK_GROUP_CODE  
			  AND P.FEED_ID = C.PRICE_FEED_ID AND P.BANK_GROUP_CODE = ? AND C.COMMODITY_ID =? and  C.COMMODITY_PRICE_ID = ?
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRICE_DTLS
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: SELECT COLLATERAL_LIMIT_ID, COLLATERAL_TYPE_CODE,PRICE_BASIS_ID,TENOR, FOLLOW_UP_DAYS, SOLD_STATUS,INSURANCE_LIMIT_ID,MAX_ADV_RATE 
		FROM SCBT_R_CUST_COLLAT_LIMIT WHERE CUST_ID=? AND BANK_GROUP_CODE=? AND COLLATERAL_LIMIT_NAME=?
INFO  - Mon Apr 01 17:42:12 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COLLATERAL_LIMIT_ID
Param [0]--> 800002463
Param [1]--> SCB
Param [2]--> Accepted Import Docs
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: delete from SCBT_T_COLLATERAL_REGISTER_HST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_PARCEL_HST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_CR_LOCK_DTLS where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_CR_LOCK_DTLS where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_CR_LOCK_DTLS where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_TXN_HST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_TXN_BCA_SALE_HST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_TXN_CR_LINKAGE_HST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: select scbtxnhste0_.DEAL_STEP_ID as DEAL1_103_0_, scbtxnhste0_.BANK_GROUP_CODE as BANK2_103_0_, scbtxnhste0_.CTY_CODE as CTY3_103_0_, scbtxnhste0_.TXN_REC_ID as TXN4_103_0_, scbtxnhste0_.TXN_REF_ID as TXN5_103_0_, scbtxnhste0_.PARENT_TXN_REC_ID as PARENT6_103_0_, scbtxnhste0_.LATEST_TXN_REC_ID as LATEST7_103_0_, scbtxnhste0_.PARENT_TXN_REF_ID as PARENT8_103_0_, scbtxnhste0_.DEAL_ID as DEAL9_103_0_, scbtxnhste0_.CUST_ID as CUST10_103_0_, scbtxnhste0_.PROD_LIMIT_ID as PROD11_103_0_, scbtxnhste0_.TXN_STEP_CODE as TXN12_103_0_, scbtxnhste0_.TXN_STEP_NO as TXN13_103_0_, scbtxnhste0_.TXN_REFER_STEP_CODE as TXN14_103_0_, scbtxnhste0_.TXN_REFER_STEP_NO as TXN15_103_0_, scbtxnhste0_.TP_REF_ID as TP16_103_0_, scbtxnhste0_.TP_STEP_CODE as TP17_103_0_, scbtxnhste0_.TP_REFER_STEP_CODE as TP18_103_0_, scbtxnhste0_.PRODUCT_CODE as PRODUCT19_103_0_, scbtxnhste0_.PRODUCT_SUB_TYPE as PRODUCT20_103_0_, scbtxnhste0_.SHORTFALL_OFFSET_TYPE as SHORTFALL21_103_0_, scbtxnhste0_.CPTY_ID as CPTY22_103_0_, scbtxnhste0_.CPTY_ROLE_CODE as CPTY23_103_0_, scbtxnhste0_.NEGATIVE_TOLERANCE_PCT as NEGATIVE24_103_0_, scbtxnhste0_.POSITIVE_TOLERANCE_PCT as POSITIVE25_103_0_, scbtxnhste0_.TXN_CCY_CODE as TXN26_103_0_, scbtxnhste0_.TXN_CCY_ORIGN_AMT as TXN27_103_0_, scbtxnhste0_.TXN_CCY_AMT as TXN28_103_0_, scbtxnhste0_.TXN_CCY_NET_AMT as TXN29_103_0_, scbtxnhste0_.TXN_CCY_UTIL_AMT as TXN30_103_0_, scbtxnhste0_.TXN_STATUS_CODE as TXN31_103_0_, scbtxnhste0_.SHIP_FROM as SHIP32_103_0_, scbtxnhste0_.SHIP_TO as SHIP33_103_0_, scbtxnhste0_.INCOTERM as INCOTERM103_0_, scbtxnhste0_.SHIP_DATE as SHIP35_103_0_, scbtxnhste0_.ISSUE_DATE as ISSUE36_103_0_, scbtxnhste0_.EFFECTIVE_DATE as EFFECTIVE37_103_0_, scbtxnhste0_.MATURITY_DATE as MATURITY38_103_0_, scbtxnhste0_.TENOR as TENOR103_0_, scbtxnhste0_.TOTAL_EXPIRY_DAYS as TOTAL40_103_0_, scbtxnhste0_.DUE_DATE as DUE41_103_0_, scbtxnhste0_.REMARKS as REMARKS103_0_, scbtxnhste0_.DOCUMENT_TYPE as DOCUMENT43_103_0_, scbtxnhste0_.ACCEPTED_FLAG as ACCEPTED44_103_0_, scbtxnhste0_.SECURITY_LEVEL as SECURITY45_103_0_, scbtxnhste0_.DELIV_SCHEDULE_DAYS as DELIV46_103_0_, scbtxnhste0_.DELIV_SCHEDULE_CODE as DELIV47_103_0_, scbtxnhste0_.DELIV_SCHEDULE_YEAR as DELIV48_103_0_, scbtxnhste0_.EXCHG_CONTRACT as EXCHG49_103_0_, scbtxnhste0_.HEDGE_DATE as HEDGE50_103_0_, scbtxnhste0_.CUST_ROLE_CODE as CUST51_103_0_, scbtxnhste0_.CASH_MARGIN_CCY_CODE as CASH52_103_0_, scbtxnhste0_.CASH_MARGIN_CCY_AMT as CASH53_103_0_, scbtxnhste0_.REVOLVING_LC_FLAG as REVOLVING54_103_0_, scbtxnhste0_.EVERGREEN_LC_FLAG as EVERGREEN55_103_0_, scbtxnhste0_.AUTO_REVERSAL_FLAG as AUTO56_103_0_, scbtxnhste0_.FINANCE_NO as FINANCE57_103_0_, scbtxnhste0_.MST_TXN_STEP_CODE as MST58_103_0_, scbtxnhste0_.LINKED_TXN_REF_ID as LINKED59_103_0_, scbtxnhste0_.CM_CCY_RELEASE_AMT as CM60_103_0_, scbtxnhste0_.CASH_MARGIN_PCT as CASH61_103_0_, scbtxnhste0_.TP_SYSTEM_CODE as TP62_103_0_, scbtxnhste0_.CASH_MARGIN_ADJ_AMT as CASH63_103_0_, scbtxnhste0_.CASH_MARGIN_ADJ as CASH64_103_0_, scbtxnhste0_.CASH_MARGIN_ORIGN_AMT as CASH65_103_0_, scbtxnhste0_.EFFECTIVE_DATE_IS_ZERO as EFFECTIVE66_103_0_, scbtxnhste0_.OD_COLLATERAL_REF as OD67_103_0_, scbtxnhste0_.CONTACT_ID as CONTACT68_103_0_, scbtxnhste0_.PREV_DEAL_STEP_ID as PREV69_103_0_, scbtxnhste0_.TRANSACTION_TYPE as TRANSAC70_103_0_, scbtxnhste0_.SYNDICATION_ID as SYNDICA71_103_0_, scbtxnhste0_.SCB_ROLE as SCB72_103_0_, scbtxnhste0_.SCB_RISK_SHARING_PCT as SCB73_103_0_, scbtxnhste0_.SYNDICATED_TXN_AMT_CCY as SYNDICATED74_103_0_, scbtxnhste0_.SYNDICATED_TXN_AMT as SYNDICATED75_103_0_, scbtxnhste0_.SYND_NEGATIVE_TOLERANCE_PCT as SYND76_103_0_, scbtxnhste0_.SYND_POSITIVE_TOLERANCE_PCT as SYND77_103_0_, scbtxnhste0_.MAX_SYNDICATED_TXN_AMT_CCY as MAX78_103_0_, scbtxnhste0_.MAX_SYNDICATED_TXN_AMT as MAX79_103_0_, scbtxnhste0_.SYNDICATED_UTIL_AMT_CCY as SYNDICATED80_103_0_, scbtxnhste0_.SYNDICATED_UTIL_AMT as SYNDICATED81_103_0_, scbtxnhste0_.ADDITIONAL_LIAB_AMT_CCY as ADDITIONAL82_103_0_, scbtxnhste0_.ADDITIONAL_LIAB_AMT as ADDITIONAL83_103_0_, scbtxnhste0_.CMT_REF_NO as CMT84_103_0_, scbtxnhste0_.BOOKING_BRANCH as BOOKING85_103_0_, scbtxnhste0_.LIMIT_TRANSFER as LIMIT86_103_0_ from SCBT_T_TXN_HST scbtxnhste0_ where scbtxnhste0_.DEAL_STEP_ID=? and scbtxnhste0_.BANK_GROUP_CODE=? and scbtxnhste0_.CTY_CODE=? and scbtxnhste0_.TXN_REC_ID=? and scbtxnhste0_.TXN_REF_ID=?
Hibernate: select scbtxnhste_.DEAL_STEP_ID, scbtxnhste_.BANK_GROUP_CODE, scbtxnhste_.CTY_CODE, scbtxnhste_.TXN_REC_ID, scbtxnhste_.TXN_REF_ID, scbtxnhste_.PARENT_TXN_REC_ID as PARENT6_103_, scbtxnhste_.LATEST_TXN_REC_ID as LATEST7_103_, scbtxnhste_.PARENT_TXN_REF_ID as PARENT8_103_, scbtxnhste_.DEAL_ID as DEAL9_103_, scbtxnhste_.CUST_ID as CUST10_103_, scbtxnhste_.PROD_LIMIT_ID as PROD11_103_, scbtxnhste_.TXN_STEP_CODE as TXN12_103_, scbtxnhste_.TXN_STEP_NO as TXN13_103_, scbtxnhste_.TXN_REFER_STEP_CODE as TXN14_103_, scbtxnhste_.TXN_REFER_STEP_NO as TXN15_103_, scbtxnhste_.TP_REF_ID as TP16_103_, scbtxnhste_.TP_STEP_CODE as TP17_103_, scbtxnhste_.TP_REFER_STEP_CODE as TP18_103_, scbtxnhste_.PRODUCT_CODE as PRODUCT19_103_, scbtxnhste_.PRODUCT_SUB_TYPE as PRODUCT20_103_, scbtxnhste_.SHORTFALL_OFFSET_TYPE as SHORTFALL21_103_, scbtxnhste_.CPTY_ID as CPTY22_103_, scbtxnhste_.CPTY_ROLE_CODE as CPTY23_103_, scbtxnhste_.NEGATIVE_TOLERANCE_PCT as NEGATIVE24_103_, scbtxnhste_.POSITIVE_TOLERANCE_PCT as POSITIVE25_103_, scbtxnhste_.TXN_CCY_CODE as TXN26_103_, scbtxnhste_.TXN_CCY_ORIGN_AMT as TXN27_103_, scbtxnhste_.TXN_CCY_AMT as TXN28_103_, scbtxnhste_.TXN_CCY_NET_AMT as TXN29_103_, scbtxnhste_.TXN_CCY_UTIL_AMT as TXN30_103_, scbtxnhste_.TXN_STATUS_CODE as TXN31_103_, scbtxnhste_.SHIP_FROM as SHIP32_103_, scbtxnhste_.SHIP_TO as SHIP33_103_, scbtxnhste_.INCOTERM as INCOTERM103_, scbtxnhste_.SHIP_DATE as SHIP35_103_, scbtxnhste_.ISSUE_DATE as ISSUE36_103_, scbtxnhste_.EFFECTIVE_DATE as EFFECTIVE37_103_, scbtxnhste_.MATURITY_DATE as MATURITY38_103_, scbtxnhste_.TENOR as TENOR103_, scbtxnhste_.TOTAL_EXPIRY_DAYS as TOTAL40_103_, scbtxnhste_.DUE_DATE as DUE41_103_, scbtxnhste_.REMARKS as REMARKS103_, scbtxnhste_.DOCUMENT_TYPE as DOCUMENT43_103_, scbtxnhste_.ACCEPTED_FLAG as ACCEPTED44_103_, scbtxnhste_.SECURITY_LEVEL as SECURITY45_103_, scbtxnhste_.DELIV_SCHEDULE_DAYS as DELIV46_103_, scbtxnhste_.DELIV_SCHEDULE_CODE as DELIV47_103_, scbtxnhste_.DELIV_SCHEDULE_YEAR as DELIV48_103_, scbtxnhste_.EXCHG_CONTRACT as EXCHG49_103_, scbtxnhste_.HEDGE_DATE as HEDGE50_103_, scbtxnhste_.CUST_ROLE_CODE as CUST51_103_, scbtxnhste_.CASH_MARGIN_CCY_CODE as CASH52_103_, scbtxnhste_.CASH_MARGIN_CCY_AMT as CASH53_103_, scbtxnhste_.REVOLVING_LC_FLAG as REVOLVING54_103_, scbtxnhste_.EVERGREEN_LC_FLAG as EVERGREEN55_103_, scbtxnhste_.AUTO_REVERSAL_FLAG as AUTO56_103_, scbtxnhste_.FINANCE_NO as FINANCE57_103_, scbtxnhste_.MST_TXN_STEP_CODE as MST58_103_, scbtxnhste_.LINKED_TXN_REF_ID as LINKED59_103_, scbtxnhste_.CM_CCY_RELEASE_AMT as CM60_103_, scbtxnhste_.CASH_MARGIN_PCT as CASH61_103_, scbtxnhste_.TP_SYSTEM_CODE as TP62_103_, scbtxnhste_.CASH_MARGIN_ADJ_AMT as CASH63_103_, scbtxnhste_.CASH_MARGIN_ADJ as CASH64_103_, scbtxnhste_.CASH_MARGIN_ORIGN_AMT as CASH65_103_, scbtxnhste_.EFFECTIVE_DATE_IS_ZERO as EFFECTIVE66_103_, scbtxnhste_.OD_COLLATERAL_REF as OD67_103_, scbtxnhste_.CONTACT_ID as CONTACT68_103_, scbtxnhste_.PREV_DEAL_STEP_ID as PREV69_103_, scbtxnhste_.TRANSACTION_TYPE as TRANSAC70_103_, scbtxnhste_.SYNDICATION_ID as SYNDICA71_103_, scbtxnhste_.SCB_ROLE as SCB72_103_, scbtxnhste_.SCB_RISK_SHARING_PCT as SCB73_103_, scbtxnhste_.SYNDICATED_TXN_AMT_CCY as SYNDICATED74_103_, scbtxnhste_.SYNDICATED_TXN_AMT as SYNDICATED75_103_, scbtxnhste_.SYND_NEGATIVE_TOLERANCE_PCT as SYND76_103_, scbtxnhste_.SYND_POSITIVE_TOLERANCE_PCT as SYND77_103_, scbtxnhste_.MAX_SYNDICATED_TXN_AMT_CCY as MAX78_103_, scbtxnhste_.MAX_SYNDICATED_TXN_AMT as MAX79_103_, scbtxnhste_.SYNDICATED_UTIL_AMT_CCY as SYNDICATED80_103_, scbtxnhste_.SYNDICATED_UTIL_AMT as SYNDICATED81_103_, scbtxnhste_.ADDITIONAL_LIAB_AMT_CCY as ADDITIONAL82_103_, scbtxnhste_.ADDITIONAL_LIAB_AMT as ADDITIONAL83_103_, scbtxnhste_.CMT_REF_NO as CMT84_103_, scbtxnhste_.BOOKING_BRANCH as BOOKING85_103_, scbtxnhste_.LIMIT_TRANSFER as LIMIT86_103_ from SCBT_T_TXN_HST scbtxnhste_ where scbtxnhste_.DEAL_STEP_ID=? and scbtxnhste_.BANK_GROUP_CODE=? and scbtxnhste_.CTY_CODE=? and scbtxnhste_.TXN_REC_ID=? and scbtxnhste_.TXN_REF_ID=?
Hibernate: delete from SCBT_T_TXN_EVENTS_DTLS where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: delete from SCBT_T_TXN_EVENTS_DTLS_HIST where BANK_GROUP_CODE=? and CTY_CODE=? and DEAL_STEP_ID=?
Hibernate: select scbtxneven0_.BANK_GROUP_CODE as BANK1_105_0_, scbtxneven0_.CTY_CODE as CTY2_105_0_, scbtxneven0_.EVENT_ID as EVENT3_105_0_, scbtxneven0_.DEAL_STEP_ID as DEAL4_105_0_, scbtxneven0_.TXN_REC_ID as TXN5_105_0_, scbtxneven0_.TXN_REF_ID as TXN6_105_0_, scbtxneven0_.EVENT_TXN_REC_ID as EVENT7_105_0_, scbtxneven0_.EVENT_TYPE_CODE  as EVENT8_105_0_, scbtxneven0_.EVENT_CCY_CODE as EVENT9_105_0_, scbtxneven0_.EVENT_CCY_AMT as EVENT10_105_0_, scbtxneven0_.TXN_CCY_CODE as TXN11_105_0_, scbtxneven0_.TXN_CCY_AMT as TXN12_105_0_, scbtxneven0_.EVENT_PAYMENT_METHOD as EVENT13_105_0_, scbtxneven0_.EVENT_TO_TXN_FX_RATE as EVENT14_105_0_, scbtxneven0_.CUST_ACCOUNT_NO as CUST15_105_0_, scbtxneven0_.EVENT_DATE as EVENT16_105_0_, scbtxneven0_.EVENT_SYNDICATED_CCY_CODE as EVENT17_105_0_, scbtxneven0_.EVENT_SYNDICATED_CCY_AMT as EVENT18_105_0_, scbtxneven0_.SYNDICATED_TXN_CCY_CODE as SYNDICATED19_105_0_, scbtxneven0_.SYNDICATED_TXN_CCY_AMT as SYNDICATED20_105_0_, scbtxneven0_.SETT_REMARKS as SETT21_105_0_ from SCBT_T_TXN_EVENTS_DTLS scbtxneven0_ where scbtxneven0_.BANK_GROUP_CODE=? and scbtxneven0_.CTY_CODE=? and scbtxneven0_.EVENT_ID=? and scbtxneven0_.DEAL_STEP_ID=?
Hibernate: select scbtxneven_.BANK_GROUP_CODE, scbtxneven_.CTY_CODE, scbtxneven_.EVENT_ID, scbtxneven_.DEAL_STEP_ID, scbtxneven_.TXN_REC_ID as TXN5_105_, scbtxneven_.TXN_REF_ID as TXN6_105_, scbtxneven_.EVENT_TXN_REC_ID as EVENT7_105_, scbtxneven_.EVENT_TYPE_CODE  as EVENT8_105_, scbtxneven_.EVENT_CCY_CODE as EVENT9_105_, scbtxneven_.EVENT_CCY_AMT as EVENT10_105_, scbtxneven_.TXN_CCY_CODE as TXN11_105_, scbtxneven_.TXN_CCY_AMT as TXN12_105_, scbtxneven_.EVENT_PAYMENT_METHOD as EVENT13_105_, scbtxneven_.EVENT_TO_TXN_FX_RATE as EVENT14_105_, scbtxneven_.CUST_ACCOUNT_NO as CUST15_105_, scbtxneven_.EVENT_DATE as EVENT16_105_, scbtxneven_.EVENT_SYNDICATED_CCY_CODE as EVENT17_105_, scbtxneven_.EVENT_SYNDICATED_CCY_AMT as EVENT18_105_, scbtxneven_.SYNDICATED_TXN_CCY_CODE as SYNDICATED19_105_, scbtxneven_.SYNDICATED_TXN_CCY_AMT as SYNDICATED20_105_, scbtxneven_.SETT_REMARKS as SETT21_105_ from SCBT_T_TXN_EVENTS_DTLS scbtxneven_ where scbtxneven_.BANK_GROUP_CODE=? and scbtxneven_.CTY_CODE=? and scbtxneven_.EVENT_ID=? and scbtxneven_.DEAL_STEP_ID=?
Hibernate: select scbtxneven0_.BANK_GROUP_CODE as BANK1_106_0_, scbtxneven0_.CTY_CODE as CTY2_106_0_, scbtxneven0_.EVENT_ID as EVENT3_106_0_, scbtxneven0_.DEAL_STEP_ID as DEAL4_106_0_, scbtxneven0_.TXN_REC_ID as TXN5_106_0_, scbtxneven0_.TXN_REF_ID as TXN6_106_0_, scbtxneven0_.EVENT_TXN_REC_ID as EVENT7_106_0_, scbtxneven0_.EVENT_TYPE_CODE  as EVENT8_106_0_, scbtxneven0_.EVENT_CCY_CODE as EVENT9_106_0_, scbtxneven0_.EVENT_CCY_AMT as EVENT10_106_0_, scbtxneven0_.TXN_CCY_CODE as TXN11_106_0_, scbtxneven0_.TXN_CCY_AMT as TXN12_106_0_, scbtxneven0_.EVENT_PAYMENT_METHOD as EVENT13_106_0_, scbtxneven0_.EVENT_TO_TXN_FX_RATE as EVENT14_106_0_, scbtxneven0_.CUST_ACCOUNT_NO as CUST15_106_0_, scbtxneven0_.EVENT_DATE as EVENT16_106_0_, scbtxneven0_.EVENT_SYNDICATED_CCY_CODE as EVENT17_106_0_, scbtxneven0_.EVENT_SYNDICATED_CCY_AMT as EVENT18_106_0_, scbtxneven0_.SYNDICATED_TXN_CCY_CODE as SYNDICATED19_106_0_, scbtxneven0_.SYNDICATED_TXN_CCY_AMT as SYNDICATED20_106_0_, scbtxneven0_.SETT_REMARKS as SETT21_106_0_ from SCBT_T_TXN_EVENTS_DTLS_HIST scbtxneven0_ where scbtxneven0_.BANK_GROUP_CODE=? and scbtxneven0_.CTY_CODE=? and scbtxneven0_.EVENT_ID=? and scbtxneven0_.DEAL_STEP_ID=?
Hibernate: select scbtxneven_.BANK_GROUP_CODE, scbtxneven_.CTY_CODE, scbtxneven_.EVENT_ID, scbtxneven_.DEAL_STEP_ID, scbtxneven_.TXN_REC_ID as TXN5_106_, scbtxneven_.TXN_REF_ID as TXN6_106_, scbtxneven_.EVENT_TXN_REC_ID as EVENT7_106_, scbtxneven_.EVENT_TYPE_CODE  as EVENT8_106_, scbtxneven_.EVENT_CCY_CODE as EVENT9_106_, scbtxneven_.EVENT_CCY_AMT as EVENT10_106_, scbtxneven_.TXN_CCY_CODE as TXN11_106_, scbtxneven_.TXN_CCY_AMT as TXN12_106_, scbtxneven_.EVENT_PAYMENT_METHOD as EVENT13_106_, scbtxneven_.EVENT_TO_TXN_FX_RATE as EVENT14_106_, scbtxneven_.CUST_ACCOUNT_NO as CUST15_106_, scbtxneven_.EVENT_DATE as EVENT16_106_, scbtxneven_.EVENT_SYNDICATED_CCY_CODE as EVENT17_106_, scbtxneven_.EVENT_SYNDICATED_CCY_AMT as EVENT18_106_, scbtxneven_.SYNDICATED_TXN_CCY_CODE as SYNDICATED19_106_, scbtxneven_.SYNDICATED_TXN_CCY_AMT as SYNDICATED20_106_, scbtxneven_.SETT_REMARKS as SETT21_106_ from SCBT_T_TXN_EVENTS_DTLS_HIST scbtxneven_ where scbtxneven_.BANK_GROUP_CODE=? and scbtxneven_.CTY_CODE=? and scbtxneven_.EVENT_ID=? and scbtxneven_.DEAL_STEP_ID=?
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (? , ? , ?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and scbproduct0_.PRODUCT_SUB_TYPE=?
Hibernate: delete from SCBT_T_PARTY where DEAL_STEP_ID=? and BANK_GROUP_CODE=? and CTY_CODE=?
Hibernate: select scbpartytx0_.PARTY_ID as PARTY1_210_0_, scbpartytx0_.BANK_GROUP_CODE as BANK2_210_0_, scbpartytx0_.CTY_CODE as CTY3_210_0_, scbpartytx0_.DEAL_STEP_ID as DEAL4_210_0_, scbpartytx0_.REC_ID as REC5_210_0_, scbpartytx0_.PARTY_ROLE_CODE as PARTY6_210_0_, scbpartytx0_.SI_VIEWED_BY_CHECKER as SI7_210_0_, scbpartytx0_.SI_VIEWED_BY_MAKER as SI8_210_0_ from SCBT_T_PARTY scbpartytx0_ where scbpartytx0_.PARTY_ID=? and scbpartytx0_.BANK_GROUP_CODE=? and scbpartytx0_.CTY_CODE=? and scbpartytx0_.DEAL_STEP_ID=?
Hibernate: select scbpartytx_.PARTY_ID, scbpartytx_.BANK_GROUP_CODE, scbpartytx_.CTY_CODE, scbpartytx_.DEAL_STEP_ID, scbpartytx_.REC_ID as REC5_210_, scbpartytx_.PARTY_ROLE_CODE as PARTY6_210_, scbpartytx_.SI_VIEWED_BY_CHECKER as SI7_210_, scbpartytx_.SI_VIEWED_BY_MAKER as SI8_210_ from SCBT_T_PARTY scbpartytx_ where scbpartytx_.PARTY_ID=? and scbpartytx_.BANK_GROUP_CODE=? and scbpartytx_.CTY_CODE=? and scbpartytx_.DEAL_STEP_ID=?
Hibernate: select scbpartytx0_.PARTY_ID as PARTY1_210_0_, scbpartytx0_.BANK_GROUP_CODE as BANK2_210_0_, scbpartytx0_.CTY_CODE as CTY3_210_0_, scbpartytx0_.DEAL_STEP_ID as DEAL4_210_0_, scbpartytx0_.REC_ID as REC5_210_0_, scbpartytx0_.PARTY_ROLE_CODE as PARTY6_210_0_, scbpartytx0_.SI_VIEWED_BY_CHECKER as SI7_210_0_, scbpartytx0_.SI_VIEWED_BY_MAKER as SI8_210_0_ from SCBT_T_PARTY scbpartytx0_ where scbpartytx0_.PARTY_ID=? and scbpartytx0_.BANK_GROUP_CODE=? and scbpartytx0_.CTY_CODE=? and scbpartytx0_.DEAL_STEP_ID=?
Hibernate: select scbpartytx_.PARTY_ID, scbpartytx_.BANK_GROUP_CODE, scbpartytx_.CTY_CODE, scbpartytx_.DEAL_STEP_ID, scbpartytx_.REC_ID as REC5_210_, scbpartytx_.PARTY_ROLE_CODE as PARTY6_210_, scbpartytx_.SI_VIEWED_BY_CHECKER as SI7_210_, scbpartytx_.SI_VIEWED_BY_MAKER as SI8_210_ from SCBT_T_PARTY scbpartytx_ where scbpartytx_.PARTY_ID=? and scbpartytx_.BANK_GROUP_CODE=? and scbpartytx_.CTY_CODE=? and scbpartytx_.DEAL_STEP_ID=?
INFO  - Mon Apr 01 17:42:13 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside Limits Service Session >>>>>>>>>> 
Hibernate: select scbprodlim0_.REC_ID as REC1_193_, scbprodlim0_.BUS_EVENT_REF_NO as BUS2_193_, scbprodlim0_.INIT_REQ_ID as INIT3_193_, scbprodlim0_.REQ_STATUS_CODE as REQ4_193_, scbprodlim0_.TBU_CODE as TBU5_193_, scbprodlim0_.BANK_GROUP_CODE as BANK6_193_, scbprodlim0_.LOG_STATUS_CODE as LOG7_193_, scbprodlim0_.REQ_ID as REQ8_193_, scbprodlim0_.REQ_TIMESTAMP as REQ9_193_, scbprodlim0_.REQ_TYPE_CODE as REQ10_193_, scbprodlim0_.CTY_CODE as CTY11_193_, scbprodlim0_.USER_ID as USER12_193_, scbprodlim0_.FORCE_POST_FLAG as FORCE13_193_, scbprodlim0_.SYS_CODE as SYS14_193_, scbprodlim0_.BUSINESS_DATE as BUSINESS15_193_ from SCBT_T_PROD_LIMIT_REQ_LOG scbprodlim0_ where scbprodlim0_.BUS_EVENT_REF_NO=? and scbprodlim0_.LOG_STATUS_CODE=? and scbprodlim0_.REQ_TYPE_CODE=? and (scbprodlim0_.REQ_STATUS_CODE in (? , ?)) and scbprodlim0_.BANK_GROUP_CODE=? and scbprodlim0_.CTY_CODE=? and scbprodlim0_.SYS_CODE=?
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_37_, scbcustlim0_.CTY_CODE as CTY2_37_, scbcustlim0_.LIMIT_ID as LIMIT3_37_, scbcustlim0_.CUST_ID as CUST4_37_, scbcustlim0_.STEP_ID as STEP5_37_, scbcustlim0_.ADVISED_FLAG as ADVISED6_37_, scbcustlim0_.BUSINESS_DATE as BUSINESS7_37_, scbcustlim0_.COMMITTED_FLAG as COMMITTED8_37_, scbcustlim0_.CPTY_CTY_CODE as CPTY9_37_, scbcustlim0_.CPTY_ID as CPTY10_37_, scbcustlim0_.CUST_CTY_CODE as CUST11_37_, scbcustlim0_.EXT_LIMIT_ID as EXT12_37_, scbcustlim0_.INNER_TO_ID as INNER13_37_, scbcustlim0_.LEGAL_ENTITY_ID as LEGAL14_37_, scbcustlim0_.LIMIT_CAT_CODE as LIMIT15_37_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT16_37_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT17_37_, scbcustlim0_.STOP_LOSS_PCT as STOP18_37_, scbcustlim0_.STOP_LOSS_CCY_CODE as STOP19_37_, scbcustlim0_.STOP_LOSS_CCY_AMT as STOP20_37_, scbcustlim0_.STOP_LOSS_APPL_FLAG as STOP21_37_, scbcustlim0_.LOAN_TO_VALUE_PCT as LOAN22_37_, scbcustlim0_.LIMIT_NAME as LIMIT23_37_, scbcustlim0_.LIMIT_PRODUCT_CODE as LIMIT24_37_, scbcustlim0_.LIMIT_SEQ_NO as LIMIT25_37_, scbcustlim0_.LIMIT_SHARE_ID as LIMIT26_37_, scbcustlim0_.LIMIT_SHARED_FLAG as LIMIT27_37_, scbcustlim0_.LIMIT_TYPE_CODE as LIMIT28_37_, scbcustlim0_.MAIN_BORROWER_ID as MAIN29_37_, scbcustlim0_.NOT_ALLOWED_PROD_CODES as NOT30_37_, scbcustlim0_.OMNIBUS_RISK as OMNIBUS31_37_, scbcustlim0_.PRODUCT_LIMIT_EXPIRY_DATE as PRODUCT32_37_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD33_37_, scbcustlim0_.REMARKS as REMARKS37_, scbcustlim0_.REMARKS2 as REMARKS35_37_, scbcustlim0_.REVOLVING_FLAG as REVOLVING36_37_, scbcustlim0_.SEQ_NO as SEQ37_37_, scbcustlim0_.SUB_PRODUCT_TYPE_CODE as SUB38_37_, scbcustlim0_.TENOR_TYPE_CODE as TENOR39_37_, scbcustlim0_.TO_TENOR as TO40_37_, scbcustlim0_.TO_TENOR_VALUE as TO41_37_, scbcustlim0_.TO_VALIDITY as TO42_37_, scbcustlim0_.TO_VALIDITY_VALUE as TO43_37_, scbcustlim0_.FROM_TENOR as FROM44_37_, scbcustlim0_.FROM_TENOR_VALUE as FROM45_37_, scbcustlim0_.FROM_VALIDITY as FROM46_37_, scbcustlim0_.FROM_VALIDITY_VALUE as FROM47_37_, scbcustlim0_.REVOLVING_LC_TYPE as REVOLVING48_37_, scbcustlim0_.EVERGREEN_LC_TYPE as EVERGREEN49_37_, scbcustlim0_.SHORTFALL_OFFSET as SHORTFALL50_37_, scbcustlim0_.CASH_MARGIN_PCT as CASH51_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACC_CCY as OVERDRAFT52_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACCNO as OVERDRAFT53_37_, scbcustlim0_.CO_BORROWER_ID as CO54_37_, scbcustlim0_.SURPLUS_CASH_ALLOCATION as SURPLUS55_37_, scbcustlim0_.MAX_TXN_CCY_CODE as MAX56_37_, scbcustlim0_.MAX_TXN_CCY_AMT as MAX57_37_, scbcustlim0_.LIMIT_CLASSIFICATION as LIMIT58_37_, scbcustlim0_.SYNDICATION_TYPE as SYNDICA59_37_, scbcustlim0_.SYNDICATION_ID as SYNDICA60_37_, scbcustlim0_.BB_DP_FLAG as BB61_37_, scbcustlim0_.BB_DEFERRAL_FLAG as BB62_37_, scbcustlim0_.FIN_HEDGE_MARGIN as FIN63_37_, scbcustlim0_.EXPOSURE_OFFSET_ACC_NO as EXPOSURE64_37_, scbcustlim0_.APPROVED_LIMIT_CCY_CODE as APPROVED65_37_, scbcustlim0_.LIMIT_CCY_APPROVED_AMT as LIMIT66_37_, scbcustlim0_.STOCK_DECLARATION_FLAG as STOCK67_37_, scbcustlim0_.FINANCE_FACILITY_FLAG as FINANCE68_37_, scbcustlim0_.COMMENTS as COMMENTS37_, scbcustlim0_.FOLLOWUP_REQUIRED as FOLLOWUP70_37_, scbcustlim0_.FOLLOWUP_REASON as FOLLOWUP71_37_ from SCBT_R_CUST_PRODUCT_LIMIT scbcustlim0_ where scbcustlim0_.LIMIT_ID=? and scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=?
INFO  - Mon Apr 01 17:42:13 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleNewRequest() start :: 


INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Tree Type code ::  com.scb.tf.core.types.SCBString10@aa1540
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside getCorporateLimitDetails() method ----------------------------->>> START
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside getCorporatelimits() Start :: Mon Apr 01 17:42:39 SGT 2013
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_37_, scbcustlim0_.CTY_CODE as CTY2_37_, scbcustlim0_.LIMIT_ID as LIMIT3_37_, scbcustlim0_.CUST_ID as CUST4_37_, scbcustlim0_.STEP_ID as STEP5_37_, scbcustlim0_.ADVISED_FLAG as ADVISED6_37_, scbcustlim0_.BUSINESS_DATE as BUSINESS7_37_, scbcustlim0_.COMMITTED_FLAG as COMMITTED8_37_, scbcustlim0_.CPTY_CTY_CODE as CPTY9_37_, scbcustlim0_.CPTY_ID as CPTY10_37_, scbcustlim0_.CUST_CTY_CODE as CUST11_37_, scbcustlim0_.EXT_LIMIT_ID as EXT12_37_, scbcustlim0_.INNER_TO_ID as INNER13_37_, scbcustlim0_.LEGAL_ENTITY_ID as LEGAL14_37_, scbcustlim0_.LIMIT_CAT_CODE as LIMIT15_37_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT16_37_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT17_37_, scbcustlim0_.STOP_LOSS_PCT as STOP18_37_, scbcustlim0_.STOP_LOSS_CCY_CODE as STOP19_37_, scbcustlim0_.STOP_LOSS_CCY_AMT as STOP20_37_, scbcustlim0_.STOP_LOSS_APPL_FLAG as STOP21_37_, scbcustlim0_.LOAN_TO_VALUE_PCT as LOAN22_37_, scbcustlim0_.LIMIT_NAME as LIMIT23_37_, scbcustlim0_.LIMIT_PRODUCT_CODE as LIMIT24_37_, scbcustlim0_.LIMIT_SEQ_NO as LIMIT25_37_, scbcustlim0_.LIMIT_SHARE_ID as LIMIT26_37_, scbcustlim0_.LIMIT_SHARED_FLAG as LIMIT27_37_, scbcustlim0_.LIMIT_TYPE_CODE as LIMIT28_37_, scbcustlim0_.MAIN_BORROWER_ID as MAIN29_37_, scbcustlim0_.NOT_ALLOWED_PROD_CODES as NOT30_37_, scbcustlim0_.OMNIBUS_RISK as OMNIBUS31_37_, scbcustlim0_.PRODUCT_LIMIT_EXPIRY_DATE as PRODUCT32_37_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD33_37_, scbcustlim0_.REMARKS as REMARKS37_, scbcustlim0_.REMARKS2 as REMARKS35_37_, scbcustlim0_.REVOLVING_FLAG as REVOLVING36_37_, scbcustlim0_.SEQ_NO as SEQ37_37_, scbcustlim0_.SUB_PRODUCT_TYPE_CODE as SUB38_37_, scbcustlim0_.TENOR_TYPE_CODE as TENOR39_37_, scbcustlim0_.TO_TENOR as TO40_37_, scbcustlim0_.TO_TENOR_VALUE as TO41_37_, scbcustlim0_.TO_VALIDITY as TO42_37_, scbcustlim0_.TO_VALIDITY_VALUE as TO43_37_, scbcustlim0_.FROM_TENOR as FROM44_37_, scbcustlim0_.FROM_TENOR_VALUE as FROM45_37_, scbcustlim0_.FROM_VALIDITY as FROM46_37_, scbcustlim0_.FROM_VALIDITY_VALUE as FROM47_37_, scbcustlim0_.REVOLVING_LC_TYPE as REVOLVING48_37_, scbcustlim0_.EVERGREEN_LC_TYPE as EVERGREEN49_37_, scbcustlim0_.SHORTFALL_OFFSET as SHORTFALL50_37_, scbcustlim0_.CASH_MARGIN_PCT as CASH51_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACC_CCY as OVERDRAFT52_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACCNO as OVERDRAFT53_37_, scbcustlim0_.CO_BORROWER_ID as CO54_37_, scbcustlim0_.SURPLUS_CASH_ALLOCATION as SURPLUS55_37_, scbcustlim0_.MAX_TXN_CCY_CODE as MAX56_37_, scbcustlim0_.MAX_TXN_CCY_AMT as MAX57_37_, scbcustlim0_.LIMIT_CLASSIFICATION as LIMIT58_37_, scbcustlim0_.SYNDICATION_TYPE as SYNDICA59_37_, scbcustlim0_.SYNDICATION_ID as SYNDICA60_37_, scbcustlim0_.BB_DP_FLAG as BB61_37_, scbcustlim0_.BB_DEFERRAL_FLAG as BB62_37_, scbcustlim0_.FIN_HEDGE_MARGIN as FIN63_37_, scbcustlim0_.EXPOSURE_OFFSET_ACC_NO as EXPOSURE64_37_, scbcustlim0_.APPROVED_LIMIT_CCY_CODE as APPROVED65_37_, scbcustlim0_.LIMIT_CCY_APPROVED_AMT as LIMIT66_37_, scbcustlim0_.STOCK_DECLARATION_FLAG as STOCK67_37_, scbcustlim0_.FINANCE_FACILITY_FLAG as FINANCE68_37_, scbcustlim0_.COMMENTS as COMMENTS37_, scbcustlim0_.FOLLOWUP_REQUIRED as FOLLOWUP70_37_, scbcustlim0_.FOLLOWUP_REASON as FOLLOWUP71_37_ from SCBT_R_CUST_PRODUCT_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and (scbcustlim0_.LIMIT_PRODUCT_CODE='*' or (scbcustlim0_.CPTY_ID=? or scbcustlim0_.CPTY_ID='*') and scbcustlim0_.LIMIT_ID=? or (scbcustlim0_.INNER_TO_ID in (select scbcustlim1_.EXT_LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT scbcustlim1_ where scbcustlim1_.BANK_GROUP_CODE=? and scbcustlim1_.CTY_CODE=? and scbcustlim1_.CUST_ID=? and (scbcustlim1_.CPTY_ID=? or scbcustlim1_.CPTY_ID='*') and scbcustlim1_.LIMIT_ID=?)) and scbcustlim0_.LIMIT_CAT_CODE='R')
tempToEffDate : Mon Apr 08 00:00:00 SGT 2013 tempToEffDate : Sat Mar 09 00:00:00 SGT 2013
tempFromEffDate : Sat Mar 09 00:00:00 SGT 2013
calcMinDays : 0
calcDays : 30
UITenorDays : 0
expDate : Sat Mar 09 00:00:00 SGT 2013 Effective Date : Sat Mar 09 00:00:00 SGT 2013
calculated From Days : 0
calculated To Days : 999999999
UITenorDays : 0
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside getCorporatelimits() End :: Mon Apr 01 17:42:39 SGT 2013
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside accumulateLimitUtil() Start :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::txnCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::limitCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside accumulateLimitUtil() End
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside accumulateLimitUtil() Start :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::txnCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::limitCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside accumulateLimitUtil() End
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Request Limit ID ::  20393575
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside getProductGroupLimitDetails 
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_229_, scbcustlim0_.CTY_CODE as CTY2_229_, scbcustlim0_.FACILITY_GRP_ID as FACILITY3_229_, scbcustlim0_.CUST_ID as CUST4_229_, scbcustlim0_.STEP_ID as STEP5_229_, scbcustlim0_.FACLIITY_GRP_NAME  as FACLIITY6_229_, scbcustlim0_.STOP_LOSS_PCT as STOP7_229_, scbcustlim0_.STOP_LOSS_CCY_AMT as STOP8_229_, scbcustlim0_.STOP_LOSS_CCY_CODE as STOP9_229_, scbcustlim0_.LOAN_TO_VALUE_PCT as LOAN10_229_, scbcustlim0_.PROD_LIMIT_IDS as PROD11_229_, scbcustlim0_.Group_Type as Group12_229_, scbcustlim0_.Tenor as Tenor229_, scbcustlim0_.Tenor_Value as Tenor14_229_, scbcustlim0_.Limit_Amt_Ccy as Limit15_229_, scbcustlim0_.Limit_Amount as Limit16_229_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD17_229_, scbcustlim0_.LINKED_ACC_NOS as LINKED18_229_, scbcustlim0_.BB_TENOR as BB19_229_, scbcustlim0_.BB_GRACE_PERIOD as BB20_229_ from SCBT_R_CUST_FACILITY_GRP scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and scbf_chk_prod_exists(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.FACILITY_GRP_ID, ?)>0 and (scbcustlim0_.Group_Type in ('AMT' , 'TNR'))
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Tree Type code ::  com.scb.tf.core.types.SCBString10@aa1540
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Cpty ID ::  800000092
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside if policy Id != null 
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_47_, scbcustlim0_.CTY_CODE as CTY2_47_, scbcustlim0_.CUST_ID as CUST3_47_, scbcustlim0_.LIMIT_ID as LIMIT4_47_, scbcustlim0_.CAP_TYPE as CAP5_47_, scbcustlim0_.CAP_NAME as CAP6_47_, scbcustlim0_.PRODUCT_LIMIT_IDS as PRODUCT7_47_, scbcustlim0_.CPTY_COND as CPTY8_47_, scbcustlim0_.CPTY_IDS as CPTY9_47_, scbcustlim0_.TENOR as TENOR47_, scbcustlim0_.PAYMENT_METHOD as PAYMENT11_47_, scbcustlim0_.CTY_OF_SALE as CTY12_47_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT13_47_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT14_47_, scbcustlim0_.STEP_ID as STEP15_47_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD16_47_, scbcustlim0_.OFFTAKER_IDS as OFFTAKER17_47_ from SCBT_R_CUST_BCA_COND_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and scbcustlim0_.CAP_TYPE=? and scbcustlim0_.CPTY_IDS=? and (scbcustlim0_.OFFTAKER_IDS='*' or scbf_compare_csv(scbcustlim0_.OFFTAKER_IDS, ?)>0) and (scbcustlim0_.PAYMENT_METHOD='*' or scbcustlim0_.PAYMENT_METHOD like ?) and (scbcustlim0_.CTY_OF_SALE='*' or scbcustlim0_.CTY_OF_SALE like ?) and scbcustlim0_.CPTY_COND='INC' and (scbcustlim0_.PRODUCT_LIMIT_IDS='*' or scbf_prod_exists_for_bca(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.LIMIT_ID, ?)>0)
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_47_, scbcustlim0_.CTY_CODE as CTY2_47_, scbcustlim0_.CUST_ID as CUST3_47_, scbcustlim0_.LIMIT_ID as LIMIT4_47_, scbcustlim0_.CAP_TYPE as CAP5_47_, scbcustlim0_.CAP_NAME as CAP6_47_, scbcustlim0_.PRODUCT_LIMIT_IDS as PRODUCT7_47_, scbcustlim0_.CPTY_COND as CPTY8_47_, scbcustlim0_.CPTY_IDS as CPTY9_47_, scbcustlim0_.TENOR as TENOR47_, scbcustlim0_.PAYMENT_METHOD as PAYMENT11_47_, scbcustlim0_.CTY_OF_SALE as CTY12_47_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT13_47_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT14_47_, scbcustlim0_.STEP_ID as STEP15_47_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD16_47_, scbcustlim0_.OFFTAKER_IDS as OFFTAKER17_47_ from SCBT_R_CUST_BCA_COND_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and scbcustlim0_.CAP_TYPE=? and (scbcustlim0_.OFFTAKER_IDS='*' or scbf_compare_csv(scbcustlim0_.OFFTAKER_IDS, ?)>0) and (scbcustlim0_.PAYMENT_METHOD='*' or scbcustlim0_.PAYMENT_METHOD like ?) and (scbcustlim0_.CTY_OF_SALE='*' or scbcustlim0_.CTY_OF_SALE like ?) and (scbcustlim0_.PRODUCT_LIMIT_IDS='*' or scbf_prod_exists_for_bca(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.LIMIT_ID, ?)>0) and (scbcustlim0_.CPTY_COND='INC' and (scbcustlim0_.CPTY_IDS='*' or scbf_cpty_exists_for_bca(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.LIMIT_ID, ?)>0) or scbcustlim0_.CPTY_COND='EXC' and scbf_cpty_exists_for_bca(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.LIMIT_ID, ?)=0)
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_47_, scbcustlim0_.CTY_CODE as CTY2_47_, scbcustlim0_.CUST_ID as CUST3_47_, scbcustlim0_.LIMIT_ID as LIMIT4_47_, scbcustlim0_.CAP_TYPE as CAP5_47_, scbcustlim0_.CAP_NAME as CAP6_47_, scbcustlim0_.PRODUCT_LIMIT_IDS as PRODUCT7_47_, scbcustlim0_.CPTY_COND as CPTY8_47_, scbcustlim0_.CPTY_IDS as CPTY9_47_, scbcustlim0_.TENOR as TENOR47_, scbcustlim0_.PAYMENT_METHOD as PAYMENT11_47_, scbcustlim0_.CTY_OF_SALE as CTY12_47_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT13_47_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT14_47_, scbcustlim0_.STEP_ID as STEP15_47_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD16_47_, scbcustlim0_.OFFTAKER_IDS as OFFTAKER17_47_ from SCBT_R_CUST_BCA_COND_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and scbcustlim0_.CAP_TYPE=? and (scbcustlim0_.OFFTAKER_IDS='*' or scbf_compare_csv(scbcustlim0_.OFFTAKER_IDS, ?)>0) and (scbcustlim0_.PAYMENT_METHOD='*' or scbcustlim0_.PAYMENT_METHOD like ?) and (scbcustlim0_.CTY_OF_SALE='*' or scbcustlim0_.CTY_OF_SALE like ?) and (scbcustlim0_.PRODUCT_LIMIT_IDS='*' or scbf_prod_exists_for_bca(scbcustlim0_.BANK_GROUP_CODE, scbcustlim0_.CTY_CODE, scbcustlim0_.CUST_ID, scbcustlim0_.LIMIT_ID, ?)>0) and scbcustlim0_.CPTY_COND='ANY'
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside handleDetailRequest() End :: 
Hibernate: select scbparamda0_.BANK_GROUP_CODE as col_0_0_, scbparamda0_.PARAM_ID as col_0_1_, scbparamda0_.PARAM_KEY_01 as col_0_2_, scbparamda0_.PARAM_KEY_02 as col_0_3_, scbparamda0_.PARAM_KEY_03 as col_0_4_, scbparamda0_.PARAM_KEY_04 as col_0_5_, scbparamda0_.PARAM_KEY_05 as col_0_6_, scbparamda0_.PARAM_KEY_06 as col_0_7_, scbparamda0_.PARAM_KEY_07 as col_0_8_, scbparamda0_.PARAM_KEY_08 as col_0_9_, scbparamda0_.PARAM_KEY_09 as col_0_10_, scbparamda0_.PARAM_KEY_10 as col_0_11_, scbparamda0_.CTY_CODE as col_0_12_, scbparamda0_.PARTY_ID as col_0_13_, scbparamda0_.TBU_CODE as col_0_14_ from SCBT_R_PARAM_DATA scbparamda0_ where (scbparamda0_.BANK_GROUP_CODE in (? , '*' , '**')) and (scbparamda0_.CTY_CODE in (? , '*' , '**')) and (scbparamda0_.PARTY_ID in (? , '*' , '**')) and (scbparamda0_.TBU_CODE in (? , '*' , '**')) and scbparamda0_.PARAM_ID=? and (scbparamda0_.PARAM_KEY_01 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_02 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_03 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_04 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_05 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_06 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_07 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_08 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_09 in (? , '*' , '**')) and (scbparamda0_.PARAM_KEY_10 in (? , '*' , '**')) order by scbparamda0_.PARAM_KEY_SEQ_CODE desc
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside updateLimitLogDetails ================ START
Hibernate: select scbprodlim0_.BANK_GROUP_CODE as BANK1_93_, scbprodlim0_.CTY_CODE as CTY2_93_, scbprodlim0_.LIMIT_ID as LIMIT3_93_, scbprodlim0_.LIMIT_TREE_TYPE_CODE as LIMIT4_93_, scbprodlim0_.LIMIT_CCY_CODE as LIMIT5_93_, scbprodlim0_.LIMIT_CCY_PEND_INC_AMT as LIMIT6_93_, scbprodlim0_.LIMIT_CCY_PEND_DEC_AMT as LIMIT7_93_, scbprodlim0_.LIMIT_CCY_UTILISED_AMT as LIMIT8_93_, scbprodlim0_.LIMIT_CCY_AVAILABLE_AMT as LIMIT9_93_ from SCBT_T_PROD_LIMIT_UTIL scbprodlim0_ where scbprodlim0_.LIMIT_ID=? and scbprodlim0_.BANK_GROUP_CODE=? and scbprodlim0_.CTY_CODE=?
Hibernate: insert into SCBT_T_REMARKS_DTLS (USER_ID, STEP_CODE, REMARKS_CAT_CODE, CREATED_DATE, REMARKS, ATTACHED_FILE_PATH, SEND_EMAIL_TO, SEND_EMAIL_CC, ATTACHED_FILE_CONTENT, SEND_TO_EMAIL, EMAIL_SENT, ATTACHED_FILE_NAME, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_REMARKS_DTLS (USER_ID, STEP_CODE, REMARKS_CAT_CODE, CREATED_DATE, REMARKS, ATTACHED_FILE_PATH, SEND_EMAIL_TO, SEND_EMAIL_CC, ATTACHED_FILE_CONTENT, SEND_TO_EMAIL, EMAIL_SENT, ATTACHED_FILE_NAME, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_COLLATERAL_REGISTER_HST (DEAL_STEP_ID, MST_DEAL_STEP_ID, COLLATERAL_CATEGORY, PAYMENT_METHOD_CODE, COLLATERAL_SUB_CATEGORY, INCOTERM_CODE, SUPPLIER_ID, BUYER_ID, CUST_ID, PURCHASE_SALE_DATE, LC_ISSUE_BANK_ID, LC_REFERENCE_NO, IS_LC_CONFIRMED, LC_CONFIRMING_BANK_ID, REMARKS, REFERENCE_NO, TOTAL_CMV_CCY_AMT, TOTAL_CMV_CCY_CODE, ISSUE_DATE, IS_COUNTER_SIGNED, COUNTER_SIGN_BANK_ID, IS_AMOUNT_PAID, GENERATE_REL_NOTE, RELEASE_AGAINST_CASH, PAYMENT_DATE, TOTAL_NCV_CCY_AMT, TOTAL_NCV_CCY_CODE, TOTAL_GCV_CCY_AMT, TOTAL_GCV_CCY_CODE, IS_SANCTION_CHECK_DONE, DUE_DATE, COLLATERAL_STATUS_CODE, CR_CCY_CODE, NCV_CCY_UTIL_AMT, RECEIVABLE_CCY_AMT, RECEIVABLE_CCY_CODE, NCV_UTIL_PCT, PYMT_CCY_AMT, PYMT_CCY_CODE, PARENT_COLLATERAL_ID, ADV_BANK_REF, CONF_BANK_REF, SALES_CONTRACT_REF, LC_TYPE, PAYMENT_TERMS, CONTROL_EXPORT_PROCEEDS, ACCOUNT_CREDITED, ELC_EXPIRY_DATE, ELC_CONT_RECEIPT_DATE, SCB_BILL_REF, Phy_Sale_Price_UOM, Phy_Sale_Price_Ccy_Code, PHY_SALE_PRICE_CCY_AMT, MULTIPLE_SHIPMENT_DATE, CR_STATUS_CODE, ORIGINAL_NCV_CCY_CODE, ORIGINAL_NCV_CCY_AMT, COLL_HEADER_NAME, IS_LC_PRICE_BASIS, BANK_GROUP_CODE, CTY_CODE, DEAL_ID, COLLATERAL_ID, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_COLLATERAL_REGISTER_HST (DEAL_STEP_ID, MST_DEAL_STEP_ID, COLLATERAL_CATEGORY, PAYMENT_METHOD_CODE, COLLATERAL_SUB_CATEGORY, INCOTERM_CODE, SUPPLIER_ID, BUYER_ID, CUST_ID, PURCHASE_SALE_DATE, LC_ISSUE_BANK_ID, LC_REFERENCE_NO, IS_LC_CONFIRMED, LC_CONFIRMING_BANK_ID, REMARKS, REFERENCE_NO, TOTAL_CMV_CCY_AMT, TOTAL_CMV_CCY_CODE, ISSUE_DATE, IS_COUNTER_SIGNED, COUNTER_SIGN_BANK_ID, IS_AMOUNT_PAID, GENERATE_REL_NOTE, RELEASE_AGAINST_CASH, PAYMENT_DATE, TOTAL_NCV_CCY_AMT, TOTAL_NCV_CCY_CODE, TOTAL_GCV_CCY_AMT, TOTAL_GCV_CCY_CODE, IS_SANCTION_CHECK_DONE, DUE_DATE, COLLATERAL_STATUS_CODE, CR_CCY_CODE, NCV_CCY_UTIL_AMT, RECEIVABLE_CCY_AMT, RECEIVABLE_CCY_CODE, NCV_UTIL_PCT, PYMT_CCY_AMT, PYMT_CCY_CODE, PARENT_COLLATERAL_ID, ADV_BANK_REF, CONF_BANK_REF, SALES_CONTRACT_REF, LC_TYPE, PAYMENT_TERMS, CONTROL_EXPORT_PROCEEDS, ACCOUNT_CREDITED, ELC_EXPIRY_DATE, ELC_CONT_RECEIPT_DATE, SCB_BILL_REF, Phy_Sale_Price_UOM, Phy_Sale_Price_Ccy_Code, PHY_SALE_PRICE_CCY_AMT, MULTIPLE_SHIPMENT_DATE, CR_STATUS_CODE, ORIGINAL_NCV_CCY_CODE, ORIGINAL_NCV_CCY_AMT, COLL_HEADER_NAME, IS_LC_PRICE_BASIS, BANK_GROUP_CODE, CTY_CODE, DEAL_ID, COLLATERAL_ID, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PARCEL_HST (COMMODITY_ID, COMMODITY_QNTY_UOM, SEC_COMMODITY_QNTY_UOM, PARCEL_TYPE_CODE, STORAGE_LOCATION_ID, DOCUMENT_NO, STORAGE_COMPANY_ID, STORAGE_REFERENCE, BRAND_ORIGIN_CODE, PACKING_SHAPE_CODE, PACKAGING_SHAPE_NO, GRADE_PURITY_CODE, IS_QLTY_CONDITION_MET, EXCHG_CONTRACT, USER_INPUT_SECURITY_LEVEL, SYSTEM_CALC_SECURITY_LEVEL, INS_LIMIT_ID, PRICE_BASIS_CODE, APPL_PRICE_BASIS_CODE, DELIV_SCHEDULE_CODE, MARKET_PRICE_CCY_CODE, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_UOM, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_UOM, REMARKS, COMMODITY_QNTY, SEC_COMMODITY_QNTY, UTILISED_QNTY, SEC_UTILISED_QNTY, ADJUSTMENT_QNTY, SEC_ADJUSTMENT_QNTY, DELIV_SCHEDULE_YEAR, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_AMT, PURCHASE_PRICE_CCY_AMT, SALE_PRICE_CCY_AMT, MANUAL_PRICE_CCY_AMT, DELIV_SCHEDULE_DAYS, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PARCEL_REL_DATE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, NET_COMMODITY_QNTY, SEC_NET_COMMODITY_QNTY, UTILISED_QNTY_UOM, SEC_UTILISED_QNTY_UOM, ADJUSTMENT_QNTY_UOM, SEC_ADJUSTMENT_QNTY_UOM, NET_COMMODITY_UOM, SEC_NET_COMMODITY_QNTY_UOM, POSITIVE_TOLERANCE_PCT, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, NEGATIVE_TOLERANCE_PCT, DEAL_ID, CERTIFICATE_EXPIRY_DATE, COLLATERAL_LIMIT_ID, STORAGE_CTY_CODE, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, VESSEL_NO, EXPECTED_ARRIVAL_DATE, LINK_PARCEL_ID, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_UOM, IS_MOP_ENABLED, MOP_FROM_DATE, MOP_TO_DATE, ADJUST_TYPE_CODE, PRICE_ADJUST, SOURCE_STORAGE, CUSTOMER_REFERENCE, PARENT_PARCEL_ID, RELEASE_ORDER_REFERENCE, PRIM_SEC_UOM_CONVERSION_FACTOR, PRICE_ADJUSTMENT_ID, CR_STATUS_CODE, INCOTERM_CODE, SUPPLIER_ID, BUYER_ID, RECEIVABLE_CCY_AMT, RECEIVABLE_CCY_CODE, PAYMENT_CCY_AMT, PAYMENT_CCY_CODE, ISSUE_DATE, PAYMENT_DATE, IS_AMOUNT_PAID, DUE_DATE, PREV_DEAL_STEP_ID, PARCEL_LEVEL_ADJ_FLAG, ADJ_FORMULA, TRANS_DIFFERENTIAL_CCY_AMT, TRANS_DIFFERENTIAL_CCY_CODE, TRANS_DIFFERENTIAL_UOM, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, CR_PARENT_ID, RECJ158_CODE, ORIGINAL_PRICE_BASE_AMT, ORIGINAL_PRICE_BASE_CCY, ORIGINAL_PRICE_BASE_UOM, BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PARCEL_HST (COMMODITY_ID, COMMODITY_QNTY_UOM, SEC_COMMODITY_QNTY_UOM, PARCEL_TYPE_CODE, STORAGE_LOCATION_ID, DOCUMENT_NO, STORAGE_COMPANY_ID, STORAGE_REFERENCE, BRAND_ORIGIN_CODE, PACKING_SHAPE_CODE, PACKAGING_SHAPE_NO, GRADE_PURITY_CODE, IS_QLTY_CONDITION_MET, EXCHG_CONTRACT, USER_INPUT_SECURITY_LEVEL, SYSTEM_CALC_SECURITY_LEVEL, INS_LIMIT_ID, PRICE_BASIS_CODE, APPL_PRICE_BASIS_CODE, DELIV_SCHEDULE_CODE, MARKET_PRICE_CCY_CODE, MARKET_PRICE_UOM, PURCHASE_PRICE_CCY_CODE, PURCHASE_PRICE_UOM, SALE_PRICE_CCY_CODE, SALE_PRICE_UOM, MANUAL_PRICE_CCY_CODE, MANUAL_PRICE_UOM, REMARKS, COMMODITY_QNTY, SEC_COMMODITY_QNTY, UTILISED_QNTY, SEC_UTILISED_QNTY, ADJUSTMENT_QNTY, SEC_ADJUSTMENT_QNTY, DELIV_SCHEDULE_YEAR, MAX_ADV_RATE_PCT, MARKET_PRICE_CCY_AMT, PURCHASE_PRICE_CCY_AMT, SALE_PRICE_CCY_AMT, MANUAL_PRICE_CCY_AMT, DELIV_SCHEDULE_DAYS, FIRST_COLLATERAL_DATE, EXPIRY_DATE, FOLLOWUP_DATE, PARCEL_REL_DATE, COLLATERAL_TYPE_CODE, SOLD_STATUS_CODE, NET_COMMODITY_QNTY, SEC_NET_COMMODITY_QNTY, UTILISED_QNTY_UOM, SEC_UTILISED_QNTY_UOM, ADJUSTMENT_QNTY_UOM, SEC_ADJUSTMENT_QNTY_UOM, NET_COMMODITY_UOM, SEC_NET_COMMODITY_QNTY_UOM, POSITIVE_TOLERANCE_PCT, CMV_CCY_AMT, CMV_CCY_CODE, GCV_CCY_AMT, GCV_CCY_CODE, NCV_CCY_AMT, NCV_CCY_CODE, NEGATIVE_TOLERANCE_PCT, DEAL_ID, CERTIFICATE_EXPIRY_DATE, COLLATERAL_LIMIT_ID, STORAGE_CTY_CODE, FOLLOWUP_DAYS, TENOR, GOODS_IN_TYPE_CODE, VESSEL_NO, EXPECTED_ARRIVAL_DATE, LINK_PARCEL_ID, MP_CR_CCY_FX_RATE, PARCEL_STATUS_CODE, PRICE_FEED_ID, CASH_MARKET_PRICE_CCY_AMT, CASH_MARKET_PRICE_CODE, CASH_MARKET_PRICE_UOM, IS_MOP_ENABLED, MOP_FROM_DATE, MOP_TO_DATE, ADJUST_TYPE_CODE, PRICE_ADJUST, SOURCE_STORAGE, CUSTOMER_REFERENCE, PARENT_PARCEL_ID, RELEASE_ORDER_REFERENCE, PRIM_SEC_UOM_CONVERSION_FACTOR, PRICE_ADJUSTMENT_ID, CR_STATUS_CODE, INCOTERM_CODE, SUPPLIER_ID, BUYER_ID, RECEIVABLE_CCY_AMT, RECEIVABLE_CCY_CODE, PAYMENT_CCY_AMT, PAYMENT_CCY_CODE, ISSUE_DATE, PAYMENT_DATE, IS_AMOUNT_PAID, DUE_DATE, PREV_DEAL_STEP_ID, PARCEL_LEVEL_ADJ_FLAG, ADJ_FORMULA, TRANS_DIFFERENTIAL_CCY_AMT, TRANS_DIFFERENTIAL_CCY_CODE, TRANS_DIFFERENTIAL_UOM, CONDITIONAL_RELEASE, INCLUDE_IN_INVOICE, CR_PARENT_ID, RECJ158_CODE, ORIGINAL_PRICE_BASE_AMT, ORIGINAL_PRICE_BASE_CCY, ORIGINAL_PRICE_BASE_UOM, BANK_GROUP_CODE, CTY_CODE, PARCEL_ID, COLLATERAL_ID, REC_ID, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_TXN_HST (PARENT_TXN_REC_ID, LATEST_TXN_REC_ID, PARENT_TXN_REF_ID, DEAL_ID, CUST_ID, PROD_LIMIT_ID, TXN_STEP_CODE, TXN_STEP_NO, TXN_REFER_STEP_CODE, TXN_REFER_STEP_NO, TP_REF_ID, TP_STEP_CODE, TP_REFER_STEP_CODE, PRODUCT_CODE, PRODUCT_SUB_TYPE, SHORTFALL_OFFSET_TYPE, CPTY_ID, CPTY_ROLE_CODE, NEGATIVE_TOLERANCE_PCT, POSITIVE_TOLERANCE_PCT, TXN_CCY_CODE, TXN_CCY_ORIGN_AMT, TXN_CCY_AMT, TXN_CCY_NET_AMT, TXN_CCY_UTIL_AMT, TXN_STATUS_CODE, SHIP_FROM, SHIP_TO, INCOTERM, SHIP_DATE, ISSUE_DATE, EFFECTIVE_DATE, MATURITY_DATE, TENOR, TOTAL_EXPIRY_DAYS, DUE_DATE, REMARKS, DOCUMENT_TYPE, ACCEPTED_FLAG, SECURITY_LEVEL, DELIV_SCHEDULE_DAYS, DELIV_SCHEDULE_CODE, DELIV_SCHEDULE_YEAR, EXCHG_CONTRACT, HEDGE_DATE, CUST_ROLE_CODE, CASH_MARGIN_CCY_CODE, CASH_MARGIN_CCY_AMT, REVOLVING_LC_FLAG, EVERGREEN_LC_FLAG, AUTO_REVERSAL_FLAG, FINANCE_NO, MST_TXN_STEP_CODE, LINKED_TXN_REF_ID, CM_CCY_RELEASE_AMT, CASH_MARGIN_PCT, TP_SYSTEM_CODE, CASH_MARGIN_ADJ_AMT, CASH_MARGIN_ADJ, CASH_MARGIN_ORIGN_AMT, EFFECTIVE_DATE_IS_ZERO, OD_COLLATERAL_REF, CONTACT_ID, PREV_DEAL_STEP_ID, TRANSACTION_TYPE, SYNDICATION_ID, SCB_ROLE, SCB_RISK_SHARING_PCT, SYNDICATED_TXN_AMT_CCY, SYNDICATED_TXN_AMT, SYND_NEGATIVE_TOLERANCE_PCT, SYND_POSITIVE_TOLERANCE_PCT, MAX_SYNDICATED_TXN_AMT_CCY, MAX_SYNDICATED_TXN_AMT, SYNDICATED_UTIL_AMT_CCY, SYNDICATED_UTIL_AMT, ADDITIONAL_LIAB_AMT_CCY, ADDITIONAL_LIAB_AMT, CMT_REF_NO, BOOKING_BRANCH, LIMIT_TRANSFER, DEAL_STEP_ID, BANK_GROUP_CODE, CTY_CODE, TXN_REC_ID, TXN_REF_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_TXN_EVENTS_DTLS (TXN_REC_ID, TXN_REF_ID, EVENT_TXN_REC_ID, EVENT_TYPE_CODE , EVENT_CCY_CODE, EVENT_CCY_AMT, TXN_CCY_CODE, TXN_CCY_AMT, EVENT_PAYMENT_METHOD, EVENT_TO_TXN_FX_RATE, CUST_ACCOUNT_NO, EVENT_DATE, EVENT_SYNDICATED_CCY_CODE, EVENT_SYNDICATED_CCY_AMT, SYNDICATED_TXN_CCY_CODE, SYNDICATED_TXN_CCY_AMT, SETT_REMARKS, BANK_GROUP_CODE, CTY_CODE, EVENT_ID, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_TXN_EVENTS_DTLS_HIST (TXN_REC_ID, TXN_REF_ID, EVENT_TXN_REC_ID, EVENT_TYPE_CODE , EVENT_CCY_CODE, EVENT_CCY_AMT, TXN_CCY_CODE, TXN_CCY_AMT, EVENT_PAYMENT_METHOD, EVENT_TO_TXN_FX_RATE, CUST_ACCOUNT_NO, EVENT_DATE, EVENT_SYNDICATED_CCY_CODE, EVENT_SYNDICATED_CCY_AMT, SYNDICATED_TXN_CCY_CODE, SYNDICATED_TXN_CCY_AMT, SETT_REMARKS, BANK_GROUP_CODE, CTY_CODE, EVENT_ID, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PARTY (REC_ID, PARTY_ROLE_CODE, SI_VIEWED_BY_CHECKER, SI_VIEWED_BY_MAKER, PARTY_ID, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PARTY (REC_ID, PARTY_ROLE_CODE, SI_VIEWED_BY_CHECKER, SI_VIEWED_BY_MAKER, PARTY_ID, BANK_GROUP_CODE, CTY_CODE, DEAL_STEP_ID) values (?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PROD_LIMIT_REQ_LOG (BUS_EVENT_REF_NO, INIT_REQ_ID, REQ_STATUS_CODE, TBU_CODE, BANK_GROUP_CODE, LOG_STATUS_CODE, REQ_ID, REQ_TIMESTAMP, REQ_TYPE_CODE, CTY_CODE, USER_ID, FORCE_POST_FLAG, SYS_CODE, BUSINESS_DATE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PROD_LIMIT_REQ_LOG_DTL (CPTY_ID, DEAL_ID, LIMIT_PRODUCT_CODE, LIMIT_TYPE_CODE, OBLIGOR_CTY_CODE, OBLIGOR_ID, REQ_ID, STEP_ID, CTY_CODE, TXN_CCY_AMT, TXN_CCY_CODE, CPTY_CTY_CODE, LIMIT_TREE_TYPE_CODE, EVERGREEN_LC_TYPE, REVOLVING_LC_TYPE, TOTAL_CREDIT_PERIOD, BILL_TENOR, SUB_PRODUCT_TYPE_CODE, CO_BORROWER_ID, CPTY_ROLE_CODE, PROD_LIMIT_ID, COLL_LIMIT_ID, TXN_REF_ID, TP_REF_NO, MATURITY_DATE, TXN_REC_ID, PAYMENT_METHOD, CTY_OF_SALE, BOOKING_BRANCH, ISS_BOOKING_BRANCH, SYN_TXN_CCY_AMT, OFFTAKER_ID, BANK_GROUP_CODE, INIT_REQ_ID, REQ_SR_NO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: update SCBT_T_DEAL_HIST set TP_REJECT_FLAG=?, TP_REJECT_REASON=?, TP_SYSTEM_CODE=?, TP_STEP_ID=?, TP_DEAL_ID=?, TP_CUST_ID=?, BU_CODE=?, STEP_CODE=?, SUB_STEP_CODE=?, STEP_STATUS_CODE=?, MAKER_ID=?, maker_timestamp=?, CHECKER_ID=?, checker_timestamp=?, VALUE_DATE=?, BUSINESS_DATE=?, OFFERING_ID=?, OFFERING_TIMESTAMP=?, CO_BORROWER_ID=?, MANUAL_EXCEPTION_FLAG=?, MANUAL_EXCEPTION_REASON=?, EXCEPTION_PRE_APPROVED_FLAG=?, EXCEPTION_RM_APPROVED_FLAG=?, DEAL_STEP_CCY_CODE=?, DEAL_STEP_CCY_AMT=?, TP_OFFERING_REASON_9=? where bank_group_code=? and cty_code=? and DEAL_STEP_ID=? and deal_id=? and CUST_ID=?
Hibernate: update SCBT_T_PROD_LIMIT_UTIL set LIMIT_TREE_TYPE_CODE=?, LIMIT_CCY_CODE=?, LIMIT_CCY_PEND_INC_AMT=?, LIMIT_CCY_PEND_DEC_AMT=?, LIMIT_CCY_UTILISED_AMT=?, LIMIT_CCY_AVAILABLE_AMT=? where BANK_GROUP_CODE=? and CTY_CODE=? and LIMIT_ID=?
Hibernate: select scbprodlim0_.BANK_GROUP_CODE as BANK1_93_, scbprodlim0_.CTY_CODE as CTY2_93_, scbprodlim0_.LIMIT_ID as LIMIT3_93_, scbprodlim0_.LIMIT_TREE_TYPE_CODE as LIMIT4_93_, scbprodlim0_.LIMIT_CCY_CODE as LIMIT5_93_, scbprodlim0_.LIMIT_CCY_PEND_INC_AMT as LIMIT6_93_, scbprodlim0_.LIMIT_CCY_PEND_DEC_AMT as LIMIT7_93_, scbprodlim0_.LIMIT_CCY_UTILISED_AMT as LIMIT8_93_, scbprodlim0_.LIMIT_CCY_AVAILABLE_AMT as LIMIT9_93_ from SCBT_T_PROD_LIMIT_UTIL scbprodlim0_ where scbprodlim0_.LIMIT_ID=? and scbprodlim0_.BANK_GROUP_CODE=? and scbprodlim0_.CTY_CODE=?
INFO  - Mon Apr 01 17:42:39 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside updateLimitLogDetails ================ END  


INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Tree Type code ::  com.scb.tf.core.types.SCBString10@ed8ca7
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside if policy Id != null 
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_33_, scbcustlim0_.CTY_CODE as CTY2_33_, scbcustlim0_.COLLATERAL_LIMIT_ID as COLLATERAL3_33_, scbcustlim0_.CUST_ID as CUST4_33_, scbcustlim0_.STEP_ID as STEP5_33_, scbcustlim0_.COLLATERAL_TYPE_CODE as COLLATERAL6_33_, scbcustlim0_.COLLATERAL_LIMIT_NAME as COLLATERAL7_33_, scbcustlim0_.SOLD_STATUS as SOLD8_33_, scbcustlim0_.PRODUCT_LIMIT_ID as PRODUCT9_33_, scbcustlim0_.INSURANCE_LIMIT_ID as INSURANCE10_33_, scbcustlim0_.LIMIT_TERMS as LIMIT11_33_, scbcustlim0_.PRICE_BASIS_ID as PRICE12_33_, scbcustlim0_.MAX_ADV_RATE as MAX13_33_, scbcustlim0_.CASH_MARGIN as CASH14_33_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT15_33_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT16_33_, scbcustlim0_.FOLLOW_UP_DAYS as FOLLOW17_33_, scbcustlim0_.TENOR as TENOR33_, scbcustlim0_.SEQ_NO as SEQ19_33_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD20_33_, scbcustlim0_.LIMIT_CAP_CCY_CODE as LIMIT21_33_, scbcustlim0_.LIMIT_CAP_CCY_ACTIVE_AMT as LIMIT22_33_ from SCBT_R_CUST_COLLAT_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and scbcustlim0_.COLLATERAL_LIMIT_ID=?
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Limits Id : ------- >>2486
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside accumulateLimitUtil() Start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::txnCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::limitCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside accumulateLimitUtil() End
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside if policy Id != null 
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_31_, scbcustlim0_.CTY_CODE as CTY2_31_, scbcustlim0_.COLLATERAL_GROUP_LIMIT_ID as COLLATERAL3_31_, scbcustlim0_.CUST_ID as CUST4_31_, scbcustlim0_.STEP_ID as STEP5_31_, scbcustlim0_.COLLATERAL_GROUP_LIMIT_NAME as COLLATERAL6_31_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT7_31_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT8_31_, scbcustlim0_.COLLATERAL_LIMIT_ID as COLLATERAL9_31_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD10_31_ from SCBT_R_CUST_COL_GRP_LIMIT scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and SCBF_CHECK_COLL_ID_EXISTS(scbcustlim0_.BANK_GROUP_CODE,scbcustlim0_.CTY_CODE,scbcustlim0_.CUST_ID,scbcustlim0_.COLLATERAL_GROUP_LIMIT_ID,?)>0
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Tree Type code ::  com.scb.tf.core.types.SCBString10@ed8ca7
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside if policy Id != null 
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_27_, scbcustlim0_.CTY_CODE as CTY2_27_, scbcustlim0_.APPR_COMMODITY_LIMIT_ID as APPR3_27_, scbcustlim0_.CUST_ID as CUST4_27_, scbcustlim0_.STEP_ID as STEP5_27_, scbcustlim0_.COMMODITY_CAT_ID as COMMODITY6_27_, scbcustlim0_.COMMODITY_ID as COMMODITY7_27_, scbcustlim0_.COMMODITY_TYPE_CODE as COMMODITY8_27_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT9_27_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT10_27_, scbcustlim0_.LIMIT_QTY as LIMIT11_27_, scbcustlim0_.LIMIT_QTY_UOM as LIMIT12_27_, scbcustlim0_.LOCATION_CTY_CODE as LOCATION13_27_, scbcustlim0_.SWF_MAX_ADV_RATE as SWF14_27_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD15_27_, scbcustlim0_.PROD_LIMIT_IDS as PROD16_27_ from SCBT_R_CUST_APPR_COM scbcustlim0_ where scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=? and scbcustlim0_.CUST_ID=? and (scbcustlim0_.COMMODITY_ID=? or scbcustlim0_.COMMODITY_ID='*' and (scbcustlim0_.COMMODITY_CAT_ID in (select scbcommodi1_.COMMODITY_CAT_CODE from SCBT_R_COMMODITY_MST scbcommodi1_ where scbcommodi1_.BANK_GROUP_CODE=? and scbcommodi1_.COMMODITY_ID=?)) or scbcustlim0_.COMMODITY_ID='*' and scbcustlim0_.COMMODITY_CAT_ID='*' and (scbcustlim0_.COMMODITY_TYPE_CODE in (select scbcommodi2_.COMMODITY_TYPE_CODE from SCBT_R_COMMODITY_MST scbcommodi2_ where scbcommodi2_.BANK_GROUP_CODE=? and scbcommodi2_.COMMODITY_ID=?)))
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Limits Id : ------- >>2488
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside accumulateLimitUtil() Start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::txnCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::limitCcyCode in accumulateLimitUtil >>>>>> USD
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside accumulateLimitUtil() End
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() End :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside handleDetailRequest() start :: 
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Tree Type code ::  com.scb.tf.core.types.SCBString10@ed8ca7
INFO  - Mon Apr 01 17:43:11 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::inside if policy Id != null 
Hibernate: select 	* from SCBT_R_CUST_APPR_LOCATION  s , TABLE(CLOB_SPLIT(s.STORAGE_LOCATION_ID)) TL, 
        TABLE(CLOB_SPLIT(s.STORAGE_COMPANY_ID)) TC where s.BANK_GROUP_CODE=? and s.CTY_CODE=? and s.CUST_ID=? and 
        (TC.COLUMN_VALUE like '*' or TC.COLUMN_VALUE like ?) and (TL.COLUMN_VALUE like '*' or TL.COLUMN_VALUE like ?)
INFO  - Mon Apr 01 17:43:12 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_APP_STORAGE_LOCATION_LIST
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SC000064
Param [4]--> SC000064001
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: select scbadhoccu0_.LOCATION_LIMIT_GROUP_ID as LOCATION1_40_, scbadhoccu0_.BANK_GROUP_CODE as BANK2_40_, scbadhoccu0_.CTY_CODE as CTY3_40_, scbadhoccu0_.CUST_ID as CUST4_40_, scbadhoccu0_.LIMIT_CCY_CODE as LIMIT5_40_, scbadhoccu0_.LIMIT_CCY_ACTIVE_AMT as LIMIT6_40_ from SCBT_R_ADHC_APPR_LOCATION scbadhoccu0_ where scbadhoccu0_.BANK_GROUP_CODE=? and scbadhoccu0_.CTY_CODE=? and scbadhoccu0_.CUST_ID=?
INFO  - Mon Apr 01 17:43:12 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::there is no adhoc Limit found....... creating new adhoc limit for App Location 
Hibernate: select SCB_C_LIMITID.nextval from dual
INFO  - Mon Apr 01 17:43:12 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::SQL Query Script --> select SCB_C_LIMITID.nextval from dual
Result Size --> 1
Execution time (ms)  --> 0


Hibernate: insert into SCBT_T_PROD_LIMIT_MVMT (OBLIGOR_ID, OFFERING_FLAG, OFFERING_REASON, LIMIT_TREE_TYPE_CODE, TXN_CCY_CODE, CTY_CODE, TXN_CCY_AMT, BANK_GROUP_CODE, LIMIT_ID, INIT_REQ_ID, REQ_SR_NO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_PROD_LIMIT_MVMT (OBLIGOR_ID, OFFERING_FLAG, OFFERING_REASON, LIMIT_TREE_TYPE_CODE, TXN_CCY_CODE, CTY_CODE, TXN_CCY_AMT, BANK_GROUP_CODE, LIMIT_ID, INIT_REQ_ID, REQ_SR_NO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_COLL_LIMIT_REQ_LOG (BUS_EVENT_REF_NO, INIT_REQ_ID, REQ_STATUS_CODE, TBU_CODE, BANK_GROUP_CODE, LOG_STATUS_CODE, REQ_ID, REQ_TIMESTAMP, REQ_TYPE_CODE, CTY_CODE, USER_ID, FORCE_POST_FLAG, SYS_CODE, BUSINESS_DATE, CTY_FORCE_POST_FLAG, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_COLL_LIMIT_REQ_LOG_DTL (DEAL_ID, REQ_ID, STEP_ID, CTY_CODE, LIMIT_TREE_TYPE_CODE, COMM_ID, EXCH_DELIV_LOCATION_FLAG, EXCHANGE_CODE, STORAGE_COMP_ID, STORAGE_LOCATION_ID, COLLATERAL_LIMIT_ID, BONDED_STORAGE_FLAG, OBLIGOR_ID, PROD_LIMIT_ID, MANUAL_OFFERING_FLAG, MANUAL_OFFERING_REASON, LIMIT_QTY_UOM, LIMIT_QTY, NCV_TXN_CCY_CODE, NCV_TXN_CCY_AMT, ORG_NCV_TXN_CCY_AMT, CMV_TXN_CCY_CODE, CMV_TXN_CCY_AMT, ORG_CMV_TXN_CCY_AMT, PRICE_BASIS_CODE, MAX_ADV_RATE, TXN_REF_ID, COLLATERAL_ID, TP_REF_NO, MATURITY_DATE, TENOR, BANK_GROUP_CODE, INIT_REQ_ID, REQ_SR_NO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_R_ADHC_APPR_LOCATION (BANK_GROUP_CODE, CTY_CODE, CUST_ID, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, LOCATION_LIMIT_GROUP_ID) values (?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_COLL_LIMIT_UTIL (LIMIT_TREE_TYPE_CODE, LIMIT_CCY_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_CCY_UTILISED_AMT, BANK_GROUP_CODE, CTY_CODE, LIMIT_ID) values (?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: update SCBT_T_PROD_LIMIT_REQ_LOG set BUS_EVENT_REF_NO=?, INIT_REQ_ID=?, REQ_STATUS_CODE=?, TBU_CODE=?, BANK_GROUP_CODE=?, LOG_STATUS_CODE=?, REQ_ID=?, REQ_TIMESTAMP=?, REQ_TYPE_CODE=?, CTY_CODE=?, USER_ID=?, FORCE_POST_FLAG=?, SYS_CODE=?, BUSINESS_DATE=? where REC_ID=?
Hibernate: update SCBT_T_PROD_LIMIT_UTIL set LIMIT_TREE_TYPE_CODE=?, LIMIT_CCY_CODE=?, LIMIT_CCY_PEND_INC_AMT=?, LIMIT_CCY_PEND_DEC_AMT=?, LIMIT_CCY_UTILISED_AMT=?, LIMIT_CCY_AVAILABLE_AMT=? where BANK_GROUP_CODE=? and CTY_CODE=? and LIMIT_ID=?
Hibernate: select scbcolllim0_.BANK_GROUP_CODE as BANK1_94_, scbcolllim0_.CTY_CODE as CTY2_94_, scbcolllim0_.LIMIT_ID as LIMIT3_94_, scbcolllim0_.LIMIT_TREE_TYPE_CODE as LIMIT4_94_, scbcolllim0_.LIMIT_CCY_CODE as LIMIT5_94_, scbcolllim0_.LIMIT_CCY_PEND_INC_AMT as LIMIT6_94_, scbcolllim0_.LIMIT_CCY_PEND_DEC_AMT as LIMIT7_94_, scbcolllim0_.LIMIT_CCY_UTILISED_AMT as LIMIT8_94_ from SCBT_T_COLL_LIMIT_UTIL scbcolllim0_ where scbcolllim0_.LIMIT_ID=? and scbcolllim0_.BANK_GROUP_CODE=? and scbcolllim0_.CTY_CODE=?



Hibernate: select scbcollate0_.BANK_GROUP_CODE as BANK1_1_, scbcollate0_.CTY_CODE as CTY2_1_, scbcollate0_.DEAL_ID as DEAL3_1_, scbcollate0_.COLLATERAL_ID as COLLATERAL4_1_, scbcollate0_.LATEST_DEAL_STEP_ID as LATEST5_1_, scbcollate0_.COLLATERAL_CATEGORY as COLLATERAL6_1_, scbcollate0_.PAYMENT_METHOD_CODE as PAYMENT7_1_, scbcollate0_.COLLATERAL_SUB_CATEGORY as COLLATERAL8_1_, scbcollate0_.INCOTERM_CODE as INCOTERM9_1_, scbcollate0_.SUPPLIER_ID as SUPPLIER10_1_, scbcollate0_.BUYER_ID as BUYER11_1_, scbcollate0_.CUST_ID as CUST12_1_, scbcollate0_.PURCHASE_SALE_DATE as PURCHASE13_1_, scbcollate0_.LC_ISSUE_BANK_ID as LC14_1_, scbcollate0_.LC_REFERENCE_NO as LC15_1_, scbcollate0_.IS_LC_CONFIRMED as IS16_1_, scbcollate0_.LC_CONFIRMING_BANK_ID as LC17_1_, scbcollate0_.REMARKS as REMARKS1_, scbcollate0_.REFERENCE_NO as REFERENCE19_1_, scbcollate0_.TOTAL_CMV_CCY_AMT as TOTAL20_1_, scbcollate0_.TOTAL_CMV_CCY_CODE as TOTAL21_1_, scbcollate0_.ISSUE_DATE as ISSUE22_1_, scbcollate0_.IS_COUNTER_SIGNED as IS23_1_, scbcollate0_.COUNTER_SIGN_BANK_ID as COUNTER24_1_, scbcollate0_.IS_AMOUNT_PAID as IS25_1_, scbcollate0_.GENERATE_REL_NOTE as GENERATE26_1_, scbcollate0_.RELEASE_AGAINST_CASH as RELEASE27_1_, scbcollate0_.PAYMENT_DATE as PAYMENT28_1_, scbcollate0_.TOTAL_NCV_CCY_AMT as TOTAL29_1_, scbcollate0_.TOTAL_NCV_CCY_CODE as TOTAL30_1_, scbcollate0_.TOTAL_GCV_CCY_AMT as TOTAL31_1_, scbcollate0_.TOTAL_GCV_CCY_CODE as TOTAL32_1_, scbcollate0_.IS_SANCTION_CHECK_DONE as IS33_1_, scbcollate0_.COLLATERAL_LOCK_FLAG as COLLATERAL34_1_, scbcollate0_.DUE_DATE as DUE35_1_, scbcollate0_.COLLATERAL_STATUS_CODE as COLLATERAL36_1_, scbcollate0_.CR_CCY_CODE as CR37_1_, scbcollate0_.NCV_CCY_UTIL_AMT as NCV38_1_, scbcollate0_.RECEIVABLE_CCY_AMT as RECEIVABLE39_1_, scbcollate0_.RECEIVABLE_CCY_CODE as RECEIVABLE40_1_, scbcollate0_.NCV_UTIL_PCT as NCV41_1_, scbcollate0_.PYMT_CCY_AMT as PYMT42_1_, scbcollate0_.PYMT_CCY_CODE as PYMT43_1_, scbcollate0_.PARENT_COLLATERAL_ID as PARENT44_1_, scbcollate0_.ADV_BANK_REF as ADV45_1_, scbcollate0_.CONF_BANK_REF as CONF46_1_, scbcollate0_.SALES_CONTRACT_REF as SALES47_1_, scbcollate0_.LC_TYPE as LC48_1_, scbcollate0_.PAYMENT_TERMS as PAYMENT49_1_, scbcollate0_.CONTROL_EXPORT_PROCEEDS as CONTROL50_1_, scbcollate0_.ACCOUNT_CREDITED as ACCOUNT51_1_, scbcollate0_.ELC_EXPIRY_DATE as ELC52_1_, scbcollate0_.ELC_CONT_RECEIPT_DATE as ELC53_1_, scbcollate0_.SCB_BILL_REF as SCB54_1_, scbcollate0_.Phy_Sale_Price_UOM as Phy55_1_, scbcollate0_.Phy_Sale_Price_Ccy_Code as Phy56_1_, scbcollate0_.PHY_SALE_PRICE_CCY_AMT as PHY57_1_, scbcollate0_.MULTIPLE_SHIPMENT_DATE as MULTIPLE58_1_, scbcollate0_.CR_STATUS_CODE as CR59_1_, scbcollate0_.ORIGINAL_NCV_CCY_CODE as ORIGINAL60_1_, scbcollate0_.ORIGINAL_NCV_CCY_AMT as ORIGINAL61_1_, scbcollate0_.COLL_HEADER_NAME as COLL62_1_, scbcollate0_.IS_LC_PRICE_BASIS as IS63_1_ from SCBT_T_COLLATERAL_REGISTER_MST scbcollate0_ where scbcollate0_.BANK_GROUP_CODE=? and scbcollate0_.CTY_CODE=? and scbcollate0_.DEAL_ID=?
Hibernate: SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?) 	 
		UNION ALL 		
		SELECT price.FEED_PRICE_UOM,price.FEED_PRICE_CCY AS MARKET_PRICE_CCY,
		Scbf_Get_Market_Price(dtls.BANK_GROUP_CODE,dtls.CTY_CODE,dtls.COMMODITY_ID,dtls.COMMODITY_PRICE_ID,'') AS MARKET_PRICE,dtls.ROUND_CODE,
		price.SOURCE_TYPE_CODE,price.LAST_TRADE_DATE,price.PRICE_DATE,
		NVL((Scbf_C_Get_Code_Desc(mst.BANK_GROUP_CODE, mst.CTY_CODE, '*',  'EN', 'CD066', mst.COMMODITY_CODE, 1)),mst.COMMODITY_NAME) AS COMMODITY_NAME
		FROM SCBT_R_COMMODITY_DTLS dtls,SCBT_R_COMMODITY_PRICE_MST price,SCBT_R_COMMODITY_MST mst
		WHERE dtls.BANK_GROUP_CODE = price.BANK_GROUP_CODE AND NVL(dtls.INACTIVE_FLAG,'N') <> 'Y' AND dtls.DELIV_SCHEDULE_CODE = 'CSH' AND dtls.PRICE_FEED_ID = price.FEED_ID
		AND mst.BANK_GROUP_CODE = dtls.BANK_GROUP_CODE AND dtls.COMMODITY_ID = mst.COMMODITY_ID AND mst.BANK_GROUP_CODE = price.BANK_GROUP_CODE 
		AND dtls.BANK_GROUP_CODE = ? AND dtls.COMMODITY_ID = ? AND dtls.COMMODITY_PRICE_ID = ? 				
		AND mst.HUB_BU_CODE IN (SELECT HUB_BU_CODE FROM SCBT_R_TBU_MST WHERE TBU_CODE = ?)
		AND (mst.BU_CODE = mst.CTY_CODE||'*' OR mst.BU_CODE = ?)
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MARKET_PRICE_WITH_NO_ADJSTMENT
Param [0]--> SCB
Param [1]--> CM10000314
Param [2]--> 200
Param [3]--> SG957
Param [4]--> SG957
Param [5]--> SCB
Param [6]--> CM10000314
Param [7]--> 200
Param [8]--> SG957
Param [9]--> SG957
Result Size --> 2
Execution time (ms)  --> 0

Hibernate: SELECT CR.COLLATERAL_CATEGORY ,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(P.UTILISED_QNTY,0)) AS PRIM_TOTAL_QNTY,SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(P.SEC_UTILISED_QNTY,0)) AS SEC_TOTAL_QNTY
		FROM SCBT_T_PARCEL_MST P,SCBT_R_COMMODITY_MST CM,SCBT_T_COLLATERAL_REGISTER_MST CR 
		WHERE P.COMMODITY_ID = CM.COMMODITY_ID AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL')
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CR.CUST_ID = ? AND CR.DEAL_ID LIKE ?
		AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE AND P.CTY_CODE = CR.CTY_CODE AND P.DEAL_ID = CR.DEAL_ID AND P.COLLATERAL_ID = CR.COLLATERAL_ID
		GROUP BY CR.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
		P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_TOTAL_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
        SUM(NVL(P.NET_COMMODITY_QNTY,0)-NVL(PM.NET_COMMODITY_QNTY,0)) AS PRIM_PENDING_INWARD,
	    SUM(NVL(P.SEC_NET_COMMODITY_QNTY,0)-NVL(PM.SEC_NET_COMMODITY_QNTY,0)) AS SEC_PENDING_INWARD
		FROM SCBT_T_PARCEL_HST P,SCBT_R_COMMODITY_MST CM,SCBT_T_DEAL_HIST DH,SCBT_T_PARCEL_MST PM,SCBT_T_COLLATERAL_REGISTER_MST CR,SCBT_T_COLLATERAL_REGISTER_HST CH 
		WHERE P.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND DH.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.CTY_CODE = DH.CTY_CODE
		AND P.BANK_GROUP_CODE = PM.BANK_GROUP_CODE(+) AND P.CTY_CODE = PM.CTY_CODE(+) AND P.PARCEL_ID = PM.PARCEL_ID(+)
		AND P.BANK_GROUP_CODE = CR.BANK_GROUP_CODE(+) AND P.CTY_CODE = CR.CTY_CODE(+) AND P.COLLATERAL_ID = CR.COLLATERAL_ID(+)
		AND P.COMMODITY_ID = PM.COMMODITY_ID(+) AND P.COLLATERAL_TYPE_CODE = PM.COLLATERAL_TYPE_CODE(+)
		AND P.BANK_GROUP_CODE = CH.BANK_GROUP_CODE AND P.CTY_CODE = CH.CTY_CODE AND P.COLLATERAL_ID = CH.COLLATERAL_ID
		AND P.DEAL_ID = CH.DEAL_ID AND P.DEAL_ID = DH.DEAL_ID AND DH.DEAL_ID = CH.DEAL_ID AND DH.CUST_ID = CH.CUST_ID		
		AND DH.DEAL_STEP_ID = P.DEAL_STEP_ID  AND DH.DEAL_STEP_ID = CH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE <> '03' AND P.COMMODITY_ID = CM.COMMODITY_ID 
		AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.PARCEL_TYPE_CODE NOT IN ('MST','REL') 
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CH.CUST_ID = ? AND P.DEAL_ID LIKE ?
		GROUP BY CH.COLLATERAL_CATEGORY,P.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,P.COMMODITY_ID,P.NET_COMMODITY_UOM,
		P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_PENDING_INWARD_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Result Size --> 1
Execution time (ms)  --> 16

Hibernate: SELECT CH.COLLATERAL_CATEGORY,PH.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PH.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(P.NET_COMMODITY_QNTY,0)) AS PRIM_PENDING_OUTWARD,SUM(NVL(P.SEC_COMMODITY_QNTY,0)) AS SEC_PENDING_OUTWARD
		FROM SCBT_T_PARCEL_HST P,SCBT_R_COMMODITY_MST CM,SCBT_T_DEAL_HIST DH,SCBT_T_PARCEL_HST PH,SCBT_T_COLLATERAL_REGISTER_HST CH
		WHERE P.BANK_GROUP_CODE = DH.BANK_GROUP_CODE AND DH.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND P.CTY_CODE = DH.CTY_CODE
		AND P.BANK_GROUP_CODE = CH.BANK_GROUP_CODE AND P.CTY_CODE = CH.CTY_CODE AND PH.COLLATERAL_ID = CH.COLLATERAL_ID AND P.LINK_PARCEL_ID = PH.PARCEL_ID
		AND P.BANK_GROUP_CODE = PH.BANK_GROUP_CODE AND P.CTY_CODE = PH.CTY_CODE AND P.DEAL_ID = PH.DEAL_ID AND DH.DEAL_ID = PH.DEAL_ID
		AND P.DEAL_ID = CH.DEAL_ID AND P.DEAL_ID = DH.DEAL_ID AND DH.DEAL_ID = CH.DEAL_ID AND DH.CUST_ID = CH.CUST_ID 		
		AND DH.DEAL_STEP_ID = P.DEAL_STEP_ID AND DH.DEAL_STEP_ID = CH.DEAL_STEP_ID AND DH.DEAL_STEP_ID = PH.DEAL_STEP_ID AND DH.STEP_STATUS_CODE <> '03' AND PH.COMMODITY_ID = CM.COMMODITY_ID 
		AND P.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND PH.COMMODITY_ID = CM.COMMODITY_ID 
		AND (P.PARCEL_ID,P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,P.NET_COMMODITY_QNTY,P.SEC_COMMODITY_QNTY) NOT IN
			(SELECT NVL(PM.PARCEL_ID,'P1'),NVL(PM.NET_COMMODITY_UOM,'PUOM'),NVL(PM.SEC_NET_COMMODITY_QNTY_UOM,'SUOM'),NVL(PM.NET_COMMODITY_QNTY,0),NVL(PM.SEC_COMMODITY_QNTY,0) FROM 
			SCBT_T_PARCEL_MST PM WHERE P.BANK_GROUP_CODE = PM.BANK_GROUP_CODE AND P.CTY_CODE = PM.CTY_CODE AND P.DEAL_ID = PM.DEAL_ID AND P.PARCEL_ID = PM.PARCEL_ID)		
		AND P.BANK_GROUP_CODE = ? AND P.CTY_CODE = ? AND CH.CUST_ID = ? AND P.DEAL_ID LIKE ?		
		GROUP BY CH.COLLATERAL_CATEGORY,PH.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PH.COMMODITY_ID,
		P.NET_COMMODITY_UOM,P.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
		UNION 
		SELECT CR.COLLATERAL_CATEGORY,PM.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PM.COMMODITY_ID,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1),
		PM.NET_COMMODITY_UOM,PM.SEC_NET_COMMODITY_QNTY_UOM,
		SUM(NVL(PM.NET_COMMODITY_QNTY,0)) AS MST_PRIM_PENDING_OUTWARD,SUM(NVL(PM.SEC_COMMODITY_QNTY,0)) AS MST_SEC_PENDING_OUTWARD
		FROM SCBT_T_COLLATERAL_REGISTER_MST CR,SCBT_T_PARCEL_MST PM,SCBT_R_COMMODITY_MST CM,SCBT_T_PARCEL_HST PH,SCBT_T_DEAL_HIST DH
		WHERE PM.BANK_GROUP_CODE = CR.BANK_GROUP_CODE AND PM.CTY_CODE = CR.CTY_CODE AND PM.COLLATERAL_ID = CR.COLLATERAL_ID 
		AND PM.BANK_GROUP_CODE = CR.BANK_GROUP_CODE 
        AND PM.CTY_CODE = CR.CTY_CODE 
		AND PH.COLLATERAL_ID = PM.COLLATERAL_ID
        AND PM.BANK_GROUP_CODE = PH.BANK_GROUP_CODE  AND PM.CTY_CODE = PH.CTY_CODE AND PH.DEAL_ID = PM.DEAL_ID
		AND (PM.COLLATERAL_TYPE_CODE <> PH.COLLATERAL_TYPE_CODE OR PM.COMMODITY_ID <> PH.COMMODITY_ID 
			OR PM.NET_COMMODITY_UOM <> PH.NET_COMMODITY_UOM OR NVL(PM.SEC_NET_COMMODITY_QNTY_UOM,'NOUOM')<>NVL(PH.SEC_NET_COMMODITY_QNTY_UOM,'NOUOM'))
		AND DH.BANK_GROUP_CODE = PH.BANK_GROUP_CODE  AND DH.CTY_CODE = PH.CTY_CODE AND DH.DEAL_ID = PM.DEAL_ID		
		AND DH.STEP_STATUS_CODE <> '03' AND DH.DEAL_STEP_ID = PH.DEAL_STEP_ID AND CR.CUST_ID = DH.CUST_ID AND CR.DEAL_ID = DH.DEAL_ID	
		AND PM.BANK_GROUP_CODE = CM.BANK_GROUP_CODE AND CR.DEAL_ID = PM.DEAL_ID AND PM.PARCEL_ID = PH.PARCEL_ID
		AND PM.PARCEL_TYPE_CODE NOT IN ('MST','REL') AND PM.COMMODITY_ID = CM.COMMODITY_ID 
		AND PM.BANK_GROUP_CODE = ? AND PM.CTY_CODE = ? AND CR.CUST_ID = ? AND PM.DEAL_ID LIKE ?
		GROUP BY CR.COLLATERAL_CATEGORY,PM.COLLATERAL_TYPE_CODE, CM.COMMODITY_CAT_CODE,PM.COMMODITY_ID,PM.NET_COMMODITY_UOM,
		PM.SEC_NET_COMMODITY_QNTY_UOM,Scbf_C_Get_Code_Desc(CM.BANK_GROUP_CODE, '*','*', 'EN', 'CD066', CM.COMMODITY_CODE, 1)
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_SUMMARY_PENDING_OUTWARD_QNTY
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056
Param [4]--> SCB
Param [5]--> SG
Param [6]--> 800002463
Param [7]--> SG957T09056
Result Size --> 1
Execution time (ms)  --> 187

Hibernate: select scbdiaryev0_.STEP_ID as STEP1_267_, scbdiaryev0_.OP_CODE as OP2_267_, scbdiaryev0_.EVENT_ID as EVENT3_267_, scbdiaryev0_.STEP_CODE as STEP4_267_, scbdiaryev0_.SUB_STEP_CODE as SUB5_267_, scbdiaryev0_.STEP_STATUS_CODE as STEP6_267_, scbdiaryev0_.DEAL_STEP_ID as DEAL7_267_, scbdiaryev0_.CHECKER_ID as CHECKER8_267_, scbdiaryev0_.CHECKER_TIMESTAMP as CHECKER9_267_, scbdiaryev0_.REMINDER_PERIOD as REMINDER10_267_, scbdiaryev0_.MAKER_TIMESTAMP as MAKER11_267_, scbdiaryev0_.BANK_GROUP_CODE as BANK12_267_, scbdiaryev0_.CTY_CODE as CTY13_267_, scbdiaryev0_.TBU_CODE as TBU14_267_, scbdiaryev0_.MAKER_ID as MAKER15_267_, scbdiaryev0_.EVENT_NAME as EVENT16_267_, scbdiaryev0_.EVENT_TYPE as EVENT17_267_, scbdiaryev0_.STATUS as STATUS267_, scbdiaryev0_.PRIORITY as PRIORITY267_, scbdiaryev0_.REMARKS as REMARKS267_, scbdiaryev0_.CUST_ID as CUST21_267_, scbdiaryev0_.TXN_REF_ID as TXN22_267_, scbdiaryev0_.TP_REF_ID as TP23_267_, scbdiaryev0_.REMINDER_VALUE as REMINDER24_267_, scbdiaryev0_.ALERT_DATE as ALERT25_267_, scbdiaryev0_.PARTY_ID as PARTY26_267_, scbdiaryev0_.FOLLOWUP_REASON as FOLLOWUP27_267_ from SCBT_T_EVENT_HST scbdiaryev0_ where scbdiaryev0_.DEAL_STEP_ID=? and scbdiaryev0_.BANK_GROUP_CODE=?
Hibernate: select scbtxnmste0_.BANK_GROUP_CODE as BANK1_104_, scbtxnmste0_.CTY_CODE as CTY2_104_, scbtxnmste0_.TXN_REC_ID as TXN3_104_, scbtxnmste0_.TXN_REF_ID as TXN4_104_, scbtxnmste0_.PARENT_TXN_REC_ID as PARENT5_104_, scbtxnmste0_.LATEST_TXN_REC_ID as LATEST6_104_, scbtxnmste0_.PARENT_TXN_REF_ID as PARENT7_104_, scbtxnmste0_.DEAL_ID as DEAL8_104_, scbtxnmste0_.CUST_ID as CUST9_104_, scbtxnmste0_.LATEST_DEAL_STEP_ID as LATEST10_104_, scbtxnmste0_.PROD_LIMIT_ID as PROD11_104_, scbtxnmste0_.TXN_STEP_CODE as TXN12_104_, scbtxnmste0_.TXN_STEP_NO as TXN13_104_, scbtxnmste0_.TXN_REFER_STEP_CODE as TXN14_104_, scbtxnmste0_.TXN_REFER_STEP_NO as TXN15_104_, scbtxnmste0_.TP_REF_ID as TP16_104_, scbtxnmste0_.TP_STEP_CODE as TP17_104_, scbtxnmste0_.TP_REFER_STEP_CODE as TP18_104_, scbtxnmste0_.PRODUCT_CODE as PRODUCT19_104_, scbtxnmste0_.PRODUCT_SUB_TYPE as PRODUCT20_104_, scbtxnmste0_.SHORTFALL_OFFSET_TYPE as SHORTFALL21_104_, scbtxnmste0_.CPTY_ID as CPTY22_104_, scbtxnmste0_.CPTY_ROLE_CODE as CPTY23_104_, scbtxnmste0_.NEGATIVE_TOLERANCE_PCT as NEGATIVE24_104_, scbtxnmste0_.POSITIVE_TOLERANCE_PCT as POSITIVE25_104_, scbtxnmste0_.TXN_CCY_CODE as TXN26_104_, scbtxnmste0_.TXN_CCY_ORIGN_AMT as TXN27_104_, scbtxnmste0_.TXN_CCY_AMT as TXN28_104_, scbtxnmste0_.TXN_CCY_NET_AMT as TXN29_104_, scbtxnmste0_.TXN_CCY_UTIL_AMT as TXN30_104_, scbtxnmste0_.TXN_STATUS_CODE as TXN31_104_, scbtxnmste0_.SHIP_FROM as SHIP32_104_, scbtxnmste0_.SHIP_TO as SHIP33_104_, scbtxnmste0_.INCOTERM as INCOTERM104_, scbtxnmste0_.SHIP_DATE as SHIP35_104_, scbtxnmste0_.ISSUE_DATE as ISSUE36_104_, scbtxnmste0_.EFFECTIVE_DATE as EFFECTIVE37_104_, scbtxnmste0_.MATURITY_DATE as MATURITY38_104_, scbtxnmste0_.TENOR as TENOR104_, scbtxnmste0_.TOTAL_EXPIRY_DAYS as TOTAL40_104_, scbtxnmste0_.DUE_DATE as DUE41_104_, scbtxnmste0_.REMARKS as REMARKS104_, scbtxnmste0_.DOCUMENT_TYPE as DOCUMENT43_104_, scbtxnmste0_.ACCEPTED_FLAG as ACCEPTED44_104_, scbtxnmste0_.SECURITY_LEVEL as SECURITY45_104_, scbtxnmste0_.DELIV_SCHEDULE_DAYS as DELIV46_104_, scbtxnmste0_.DELIV_SCHEDULE_CODE as DELIV47_104_, scbtxnmste0_.DELIV_SCHEDULE_YEAR as DELIV48_104_, scbtxnmste0_.EXCHG_CONTRACT as EXCHG49_104_, scbtxnmste0_.HEDGE_DATE as HEDGE50_104_, scbtxnmste0_.CUST_ROLE_CODE as CUST51_104_, scbtxnmste0_.CASH_MARGIN_CCY_CODE as CASH52_104_, scbtxnmste0_.CASH_MARGIN_CCY_AMT as CASH53_104_, scbtxnmste0_.REVOLVING_LC_FLAG as REVOLVING54_104_, scbtxnmste0_.EVERGREEN_LC_FLAG as EVERGREEN55_104_, scbtxnmste0_.AUTO_REVERSAL_FLAG as AUTO56_104_, scbtxnmste0_.FINANCE_NO as FINANCE57_104_, scbtxnmste0_.LINKED_TXN_REF_ID as LINKED58_104_, scbtxnmste0_.CM_CCY_RELEASE_AMT as CM59_104_, scbtxnmste0_.CASH_MARGIN_PCT as CASH60_104_, scbtxnmste0_.TP_SYSTEM_CODE as TP61_104_, scbtxnmste0_.CASH_MARGIN_ADJ_AMT as CASH62_104_, scbtxnmste0_.CASH_MARGIN_ADJ as CASH63_104_, scbtxnmste0_.CASH_MARGIN_ORIGN_AMT as CASH64_104_, scbtxnmste0_.EFFECTIVE_DATE_IS_ZERO as EFFECTIVE65_104_, scbtxnmste0_.OD_COLLATERAL_REF as OD66_104_, scbtxnmste0_.CONTACT_ID as CONTACT67_104_, scbtxnmste0_.PREV_DEAL_STEP_ID as PREV68_104_, scbtxnmste0_.TRANSACTION_TYPE as TRANSAC69_104_, scbtxnmste0_.SYNDICATION_ID as SYNDICA70_104_, scbtxnmste0_.SCB_ROLE as SCB71_104_, scbtxnmste0_.SCB_RISK_SHARING_PCT as SCB72_104_, scbtxnmste0_.SYNDICATED_TXN_AMT_CCY as SYNDICATED73_104_, scbtxnmste0_.SYNDICATED_TXN_AMT as SYNDICATED74_104_, scbtxnmste0_.SYND_NEGATIVE_TOLERANCE_PCT as SYND75_104_, scbtxnmste0_.SYND_POSITIVE_TOLERANCE_PCT as SYND76_104_, scbtxnmste0_.MAX_SYNDICATED_TXN_AMT_CCY as MAX77_104_, scbtxnmste0_.MAX_SYNDICATED_TXN_AMT as MAX78_104_, scbtxnmste0_.SYNDICATED_UTIL_AMT_CCY as SYNDICATED79_104_, scbtxnmste0_.SYNDICATED_UTIL_AMT as SYNDICATED80_104_, scbtxnmste0_.ADDITIONAL_LIAB_AMT_CCY as ADDITIONAL81_104_, scbtxnmste0_.ADDITIONAL_LIAB_AMT as ADDITIONAL82_104_, scbtxnmste0_.CMT_REF_NO as CMT83_104_, scbtxnmste0_.BOOKING_BRANCH as BOOKING84_104_, scbtxnmste0_.LIMIT_TRANSFER as LIMIT85_104_ from SCBT_T_TXN_MST scbtxnmste0_ where scbtxnmste0_.BANK_GROUP_CODE=? and scbtxnmste0_.CTY_CODE=? and scbtxnmste0_.CUST_ID=? and scbtxnmste0_.DEAL_ID=? and scbtxnmste0_.TXN_REC_ID=?
Hibernate: select scbtxnhste0_.DEAL_STEP_ID as DEAL1_103_, scbtxnhste0_.BANK_GROUP_CODE as BANK2_103_, scbtxnhste0_.CTY_CODE as CTY3_103_, scbtxnhste0_.TXN_REC_ID as TXN4_103_, scbtxnhste0_.TXN_REF_ID as TXN5_103_, scbtxnhste0_.PARENT_TXN_REC_ID as PARENT6_103_, scbtxnhste0_.LATEST_TXN_REC_ID as LATEST7_103_, scbtxnhste0_.PARENT_TXN_REF_ID as PARENT8_103_, scbtxnhste0_.DEAL_ID as DEAL9_103_, scbtxnhste0_.CUST_ID as CUST10_103_, scbtxnhste0_.PROD_LIMIT_ID as PROD11_103_, scbtxnhste0_.TXN_STEP_CODE as TXN12_103_, scbtxnhste0_.TXN_STEP_NO as TXN13_103_, scbtxnhste0_.TXN_REFER_STEP_CODE as TXN14_103_, scbtxnhste0_.TXN_REFER_STEP_NO as TXN15_103_, scbtxnhste0_.TP_REF_ID as TP16_103_, scbtxnhste0_.TP_STEP_CODE as TP17_103_, scbtxnhste0_.TP_REFER_STEP_CODE as TP18_103_, scbtxnhste0_.PRODUCT_CODE as PRODUCT19_103_, scbtxnhste0_.PRODUCT_SUB_TYPE as PRODUCT20_103_, scbtxnhste0_.SHORTFALL_OFFSET_TYPE as SHORTFALL21_103_, scbtxnhste0_.CPTY_ID as CPTY22_103_, scbtxnhste0_.CPTY_ROLE_CODE as CPTY23_103_, scbtxnhste0_.NEGATIVE_TOLERANCE_PCT as NEGATIVE24_103_, scbtxnhste0_.POSITIVE_TOLERANCE_PCT as POSITIVE25_103_, scbtxnhste0_.TXN_CCY_CODE as TXN26_103_, scbtxnhste0_.TXN_CCY_ORIGN_AMT as TXN27_103_, scbtxnhste0_.TXN_CCY_AMT as TXN28_103_, scbtxnhste0_.TXN_CCY_NET_AMT as TXN29_103_, scbtxnhste0_.TXN_CCY_UTIL_AMT as TXN30_103_, scbtxnhste0_.TXN_STATUS_CODE as TXN31_103_, scbtxnhste0_.SHIP_FROM as SHIP32_103_, scbtxnhste0_.SHIP_TO as SHIP33_103_, scbtxnhste0_.INCOTERM as INCOTERM103_, scbtxnhste0_.SHIP_DATE as SHIP35_103_, scbtxnhste0_.ISSUE_DATE as ISSUE36_103_, scbtxnhste0_.EFFECTIVE_DATE as EFFECTIVE37_103_, scbtxnhste0_.MATURITY_DATE as MATURITY38_103_, scbtxnhste0_.TENOR as TENOR103_, scbtxnhste0_.TOTAL_EXPIRY_DAYS as TOTAL40_103_, scbtxnhste0_.DUE_DATE as DUE41_103_, scbtxnhste0_.REMARKS as REMARKS103_, scbtxnhste0_.DOCUMENT_TYPE as DOCUMENT43_103_, scbtxnhste0_.ACCEPTED_FLAG as ACCEPTED44_103_, scbtxnhste0_.SECURITY_LEVEL as SECURITY45_103_, scbtxnhste0_.DELIV_SCHEDULE_DAYS as DELIV46_103_, scbtxnhste0_.DELIV_SCHEDULE_CODE as DELIV47_103_, scbtxnhste0_.DELIV_SCHEDULE_YEAR as DELIV48_103_, scbtxnhste0_.EXCHG_CONTRACT as EXCHG49_103_, scbtxnhste0_.HEDGE_DATE as HEDGE50_103_, scbtxnhste0_.CUST_ROLE_CODE as CUST51_103_, scbtxnhste0_.CASH_MARGIN_CCY_CODE as CASH52_103_, scbtxnhste0_.CASH_MARGIN_CCY_AMT as CASH53_103_, scbtxnhste0_.REVOLVING_LC_FLAG as REVOLVING54_103_, scbtxnhste0_.EVERGREEN_LC_FLAG as EVERGREEN55_103_, scbtxnhste0_.AUTO_REVERSAL_FLAG as AUTO56_103_, scbtxnhste0_.FINANCE_NO as FINANCE57_103_, scbtxnhste0_.MST_TXN_STEP_CODE as MST58_103_, scbtxnhste0_.LINKED_TXN_REF_ID as LINKED59_103_, scbtxnhste0_.CM_CCY_RELEASE_AMT as CM60_103_, scbtxnhste0_.CASH_MARGIN_PCT as CASH61_103_, scbtxnhste0_.TP_SYSTEM_CODE as TP62_103_, scbtxnhste0_.CASH_MARGIN_ADJ_AMT as CASH63_103_, scbtxnhste0_.CASH_MARGIN_ADJ as CASH64_103_, scbtxnhste0_.CASH_MARGIN_ORIGN_AMT as CASH65_103_, scbtxnhste0_.EFFECTIVE_DATE_IS_ZERO as EFFECTIVE66_103_, scbtxnhste0_.OD_COLLATERAL_REF as OD67_103_, scbtxnhste0_.CONTACT_ID as CONTACT68_103_, scbtxnhste0_.PREV_DEAL_STEP_ID as PREV69_103_, scbtxnhste0_.TRANSACTION_TYPE as TRANSAC70_103_, scbtxnhste0_.SYNDICATION_ID as SYNDICA71_103_, scbtxnhste0_.SCB_ROLE as SCB72_103_, scbtxnhste0_.SCB_RISK_SHARING_PCT as SCB73_103_, scbtxnhste0_.SYNDICATED_TXN_AMT_CCY as SYNDICATED74_103_, scbtxnhste0_.SYNDICATED_TXN_AMT as SYNDICATED75_103_, scbtxnhste0_.SYND_NEGATIVE_TOLERANCE_PCT as SYND76_103_, scbtxnhste0_.SYND_POSITIVE_TOLERANCE_PCT as SYND77_103_, scbtxnhste0_.MAX_SYNDICATED_TXN_AMT_CCY as MAX78_103_, scbtxnhste0_.MAX_SYNDICATED_TXN_AMT as MAX79_103_, scbtxnhste0_.SYNDICATED_UTIL_AMT_CCY as SYNDICATED80_103_, scbtxnhste0_.SYNDICATED_UTIL_AMT as SYNDICATED81_103_, scbtxnhste0_.ADDITIONAL_LIAB_AMT_CCY as ADDITIONAL82_103_, scbtxnhste0_.ADDITIONAL_LIAB_AMT as ADDITIONAL83_103_, scbtxnhste0_.CMT_REF_NO as CMT84_103_, scbtxnhste0_.BOOKING_BRANCH as BOOKING85_103_, scbtxnhste0_.LIMIT_TRANSFER as LIMIT86_103_ from SCBT_T_TXN_HST scbtxnhste0_ where scbtxnhste0_.BANK_GROUP_CODE=? and scbtxnhste0_.CTY_CODE=? and scbtxnhste0_.CUST_ID=? and scbtxnhste0_.DEAL_ID=? and scbtxnhste0_.DEAL_STEP_ID=? and (txn_status_code is null or txn_status_code<>'11')
Hibernate: SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRODUCT_LIMIT_NAME
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> LCORS
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: select scbtxneven0_.BANK_GROUP_CODE as BANK1_106_, scbtxneven0_.CTY_CODE as CTY2_106_, scbtxneven0_.EVENT_ID as EVENT3_106_, scbtxneven0_.DEAL_STEP_ID as DEAL4_106_, scbtxneven0_.TXN_REC_ID as TXN5_106_, scbtxneven0_.TXN_REF_ID as TXN6_106_, scbtxneven0_.EVENT_TXN_REC_ID as EVENT7_106_, scbtxneven0_.EVENT_TYPE_CODE  as EVENT8_106_, scbtxneven0_.EVENT_CCY_CODE as EVENT9_106_, scbtxneven0_.EVENT_CCY_AMT as EVENT10_106_, scbtxneven0_.TXN_CCY_CODE as TXN11_106_, scbtxneven0_.TXN_CCY_AMT as TXN12_106_, scbtxneven0_.EVENT_PAYMENT_METHOD as EVENT13_106_, scbtxneven0_.EVENT_TO_TXN_FX_RATE as EVENT14_106_, scbtxneven0_.CUST_ACCOUNT_NO as CUST15_106_, scbtxneven0_.EVENT_DATE as EVENT16_106_, scbtxneven0_.EVENT_SYNDICATED_CCY_CODE as EVENT17_106_, scbtxneven0_.EVENT_SYNDICATED_CCY_AMT as EVENT18_106_, scbtxneven0_.SYNDICATED_TXN_CCY_CODE as SYNDICATED19_106_, scbtxneven0_.SYNDICATED_TXN_CCY_AMT as SYNDICATED20_106_, scbtxneven0_.SETT_REMARKS as SETT21_106_ from SCBT_T_TXN_EVENTS_DTLS_HIST scbtxneven0_ where scbtxneven0_.BANK_GROUP_CODE=? and scbtxneven0_.CTY_CODE=? and scbtxneven0_.DEAL_STEP_ID=?
Hibernate: select scbtxnbcas0_.SALE_REC_ID as SALE1_111_, scbtxnbcas0_.BANK_GROUP_CODE as BANK2_111_, scbtxnbcas0_.CTY_CODE as CTY3_111_, scbtxnbcas0_.TXN_REF_ID as TXN4_111_, scbtxnbcas0_.TXN_REC_ID as TXN5_111_, scbtxnbcas0_.DEAL_STEP_ID as DEAL6_111_, scbtxnbcas0_.CUST_ID as CUST7_111_, scbtxnbcas0_.DEAL_ID as DEAL8_111_, scbtxnbcas0_.SALE_HEADER_ID as SALE9_111_, scbtxnbcas0_.SALE_BUYER_ID as SALE10_111_, scbtxnbcas0_.SALE_PAYMENT_METHOD as SALE11_111_, scbtxnbcas0_.SALE_CTY_CODE as SALE12_111_, scbtxnbcas0_.SALE_CCY_CODE as SALE13_111_, scbtxnbcas0_.SALE_AMOUNT as SALE14_111_, scbtxnbcas0_.SALE_TENOR_IN_DAYS as SALE15_111_, scbtxnbcas0_.COVERAGE_PCT as COVERAGE16_111_, scbtxnbcas0_.SETTELED_SALE_AMT as SETTELED17_111_, scbtxnbcas0_.SETTELED_SALE_QNTY as SETTELED18_111_, scbtxnbcas0_.ENDORSED_QNTY_UOM as ENDORSED19_111_, scbtxnbcas0_.ENDORSED_QNTY as ENDORSED20_111_, scbtxnbcas0_.EXPORT_LC_ID as EXPORT21_111_, scbtxnbcas0_.SALE_OFFTAKER_ID as SALE22_111_ from SCBT_T_TXN_BCA_SALE_MST scbtxnbcas0_ where scbtxnbcas0_.BANK_GROUP_CODE=? and scbtxnbcas0_.CTY_CODE=? and scbtxnbcas0_.TXN_REF_ID=?
Hibernate: select scbtxnbcas0_.BANK_GROUP_CODE as BANK1_110_, scbtxnbcas0_.CTY_CODE as CTY2_110_, scbtxnbcas0_.TXN_REF_ID as TXN3_110_, scbtxnbcas0_.TXN_REC_ID as TXN4_110_, scbtxnbcas0_.DEAL_STEP_ID as DEAL5_110_, scbtxnbcas0_.SALE_REC_ID as SALE6_110_, scbtxnbcas0_.CUST_ID as CUST7_110_, scbtxnbcas0_.DEAL_ID as DEAL8_110_, scbtxnbcas0_.SALE_HEADER_ID as SALE9_110_, scbtxnbcas0_.SALE_BUYER_ID as SALE10_110_, scbtxnbcas0_.SALE_PAYMENT_METHOD as SALE11_110_, scbtxnbcas0_.SALE_CTY_CODE as SALE12_110_, scbtxnbcas0_.SALE_CCY_CODE as SALE13_110_, scbtxnbcas0_.SALE_AMOUNT as SALE14_110_, scbtxnbcas0_.SALE_TENOR_IN_DAYS as SALE15_110_, scbtxnbcas0_.COVERAGE_PCT as COVERAGE16_110_, scbtxnbcas0_.SETTELED_SALE_AMT as SETTELED17_110_, scbtxnbcas0_.SETTELED_SALE_QNTY as SETTELED18_110_, scbtxnbcas0_.ENDORSED_QNTY_UOM as ENDORSED19_110_, scbtxnbcas0_.ENDORSED_QNTY as ENDORSED20_110_, scbtxnbcas0_.EXPORT_LC_ID as EXPORT21_110_, scbtxnbcas0_.SALE_OFFTAKER_ID as SALE22_110_ from SCBT_T_TXN_BCA_SALE_HST scbtxnbcas0_ where scbtxnbcas0_.BANK_GROUP_CODE=? and scbtxnbcas0_.CTY_CODE=? and scbtxnbcas0_.DEAL_STEP_ID=?
Hibernate: select scbtxncoll0_.BANK_GROUP_CODE as BANK1_109_, scbtxncoll0_.CTY_CODE as CTY2_109_, scbtxncoll0_.COLLATERAL_ID as COLLATERAL3_109_, scbtxncoll0_.TXN_REC_ID as TXN4_109_, scbtxncoll0_.CUST_ID as CUST5_109_, scbtxncoll0_.DEAL_ID as DEAL6_109_, scbtxncoll0_.TXN_REF_ID as TXN7_109_, scbtxncoll0_.TXN_CCY_COVERAGE_AMT as TXN8_109_, scbtxncoll0_.TXN_CCY_CODE as TXN9_109_, scbtxncoll0_.COVERAGE_PCT as COVERAGE10_109_, scbtxncoll0_.DEAL_STEP_ID as DEAL11_109_ from SCBT_T_TXN_CR_LINKAGE_MST scbtxncoll0_ where scbtxncoll0_.BANK_GROUP_CODE=? and scbtxncoll0_.CTY_CODE=? and (scbtxncoll0_.TXN_REC_ID in (?))
Hibernate: select scbtxncoll0_.BANK_GROUP_CODE as BANK1_108_, scbtxncoll0_.CTY_CODE as CTY2_108_, scbtxncoll0_.COLLATERAL_ID as COLLATERAL3_108_, scbtxncoll0_.TXN_REC_ID as TXN4_108_, scbtxncoll0_.DEAL_STEP_ID as DEAL5_108_, scbtxncoll0_.CUST_ID as CUST6_108_, scbtxncoll0_.DEAL_ID as DEAL7_108_, scbtxncoll0_.TXN_REF_ID as TXN8_108_, scbtxncoll0_.TXN_CCY_COVERAGE_AMT as TXN9_108_, scbtxncoll0_.TXN_CCY_CODE as TXN10_108_, scbtxncoll0_.COVERAGE_PCT as COVERAGE11_108_, scbtxncoll0_.OP_CODE as OP12_108_ from SCBT_T_TXN_CR_LINKAGE_HST scbtxncoll0_ where scbtxncoll0_.BANK_GROUP_CODE=? and scbtxncoll0_.CTY_CODE=? and scbtxncoll0_.DEAL_STEP_ID=?
Hibernate: SELECT (CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN Scbf_C_Get_Code_Desc(SYN_MST.BANK_GROUP_CODE, '*','*', 'EN', 'CD089', SYN_MST.SCB_ROLE, 1) ELSE NULL END) AS "Bank Role", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN TXN_HST.PRODUCT_CODE ELSE NULL END) AS "Product", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN  TXN_HST.TXN_REF_ID ELSE NULL END) AS "Txn Ref ID",
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN  TXN_HST.TXN_STEP_CODE ELSE NULL END) AS "Step", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID)ELSE NULL END) AS "Customer Exposure Ccy",
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN 
		 NVL(Scbf_Tls_Exch_Rate(TXN_HST.BANK_GROUP_CODE,TXN_HST.CTY_CODE,TXN_HST.TXN_CCY_CODE,(NVL(TXN_HST.MAX_SYNDICATED_TXN_AMT,0)-NVL(TXN_HST.SYNDICATED_UTIL_AMT,0)),Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),'Y'),0) ELSE NULL END AS "O/S Syn Txn Amt", 
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'CBB' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'GBB' THEN 
	NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID,Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),
	TXN_HST.TXN_REC_ID,TXN_HST.TXN_CCY_CODE,TXN_HST.DEAL_STEP_ID,'H',''),0)||'' 
	WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND (TXN_HST.SHORTFALL_OFFSET_TYPE = 'CBB' OR TXN_HST.SHORTFALL_OFFSET_TYPE = 'GBB') THEN 
	'BB Cert Amt' ELSE NULL END AS "Total Linked Collateral Amt",
	(Scbf_Get_Party_Name (RISK_SHARE_MST.bank_Group_Code,RISK_SHARE_MST.BANK_ID)) AS "Bank Name", RISK_SHARE_MST.RISK_PARTICIPATION_PCT AS "Share",
	Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID) AS "Customer Format Ccy", 
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN 
		 NVL(Scbf_Tls_Exch_Rate(TXN_HST.BANK_GROUP_CODE,TXN_HST.CTY_CODE,TXN_HST.TXN_CCY_CODE,(NVL(TXN_HST.MAX_SYNDICATED_TXN_AMT,0)-NVL(TXN_HST.SYNDICATED_UTIL_AMT,0)),Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),'Y'),0)
	ELSE NULL END AS "O/S Txn Amt", 
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'CBB' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'GBB' THEN 
	NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID,Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),
	TXN_HST.TXN_REC_ID,TXN_HST.TXN_CCY_CODE,TXN_HST.DEAL_STEP_ID,'H',''),0)||'' 
	WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND (TXN_HST.SHORTFALL_OFFSET_TYPE = 'CBB' OR TXN_HST.SHORTFALL_OFFSET_TYPE = 'GBB') THEN 
	'BB Cert Amt' ELSE NULL END AS "Linked NCV",TXN_HST.TXN_REF_ID,TXN_HST.TXN_REC_ID
	FROM SCBT_T_TXN_HST TXN_HST, SCBT_R_CUST_RISK_SHARING_MST RISK_SHARE_MST,SCBT_R_CUST_SYNDICATION_MST SYN_MST
	WHERE TXN_HST.SYNDICATION_ID = SYN_MST.SYNDICATION_ID AND TXN_HST.CUST_ID = RISK_SHARE_MST.CUST_ID 
	AND TXN_HST.BANK_GROUP_CODE = SYN_MST.BANK_GROUP_CODE AND TXN_HST.CTY_CODE = SYN_MST.CTY_CODE AND TXN_HST.CUST_ID = SYN_MST.CUST_ID	 
	AND RISK_SHARE_MST.SYNDICATION_ID = TXN_HST.SYNDICATION_ID AND RISK_SHARE_MST.SYNDICATION_ID = SYN_MST.SYNDICATION_ID 
	AND RISK_SHARE_MST.BANK_GROUP_CODE = SYN_MST.BANK_GROUP_CODE AND RISK_SHARE_MST.CTY_CODE = SYN_MST.CTY_CODE 
	AND (SYN_MST.SCB_ROLE = 'PA' AND RISK_SHARE_MST.BANK_ID = '800000000') AND NVL(TXN_HST.TXN_STATUS_CODE,'00') <> '11'
	AND TXN_HST.TXN_STEP_CODE IN ('NEW','DRAW','AMD','TROV') AND TXN_HST.SYNDICATION_ID IS NOT NULL 
	AND TXN_HST.BANK_GROUP_CODE = ? AND TXN_HST.CTY_CODE = ? AND TXN_HST.DEAL_ID= ? AND TXN_HST.DEAL_STEP_ID= ? 
	UNION ALL
	SELECT (CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN Scbf_C_Get_Code_Desc(SYN_MST.BANK_GROUP_CODE, '*','*', 'EN', 'CD089', SYN_MST.SCB_ROLE, 1) ELSE NULL END) AS "Bank Role", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN TXN_HST.PRODUCT_CODE ELSE NULL END) AS "Product", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN TXN_HST.TXN_REF_ID ELSE NULL END) AS "Txn Ref ID",
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN TXN_HST.TXN_STEP_CODE ELSE NULL END) AS "Step", 
	(CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID)ELSE NULL END) AS "Customer Exposure Ccy",
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' THEN 
		 NVL(Scbf_Tls_Exch_Rate(TXN_HST.BANK_GROUP_CODE,TXN_HST.CTY_CODE,TXN_HST.TXN_CCY_CODE,(NVL(TXN_HST.MAX_SYNDICATED_TXN_AMT,0)-NVL(TXN_HST.SYNDICATED_UTIL_AMT,0)),Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),'Y'),0) ELSE NULL END AS "O/S Syn Txn Amt", 
	CASE WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'CBB' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'GBB' THEN 
	NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID,Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),
	TXN_HST.TXN_REC_ID,TXN_HST.TXN_CCY_CODE,TXN_HST.DEAL_STEP_ID,'H',''),0)||'' 
	WHEN RISK_SHARE_MST.BANK_ID = '800000000' AND (TXN_HST.SHORTFALL_OFFSET_TYPE = 'CBB' OR TXN_HST.SHORTFALL_OFFSET_TYPE = 'GBB') THEN 
	'BB Cert Amt' ELSE NULL END AS "Total Linked Collateral Amt",
	(Scbf_Get_Party_Name (RISK_SHARE_MST.bank_Group_Code,RISK_SHARE_MST.BANK_ID)) AS "Bank Name", RISK_SHARE_MST.RISK_PARTICIPATION_PCT AS "Share",
	Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID) AS "Customer Format Ccy", 
	NVL(Scbf_Tls_Exch_Rate(TXN_HST.BANK_GROUP_CODE,TXN_HST.CTY_CODE,TXN_HST.TXN_CCY_CODE,(NVL(TXN_HST.MAX_SYNDICATED_TXN_AMT,0)-NVL(TXN_HST.SYNDICATED_UTIL_AMT,0)),Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),'Y'),0)*RISK_SHARE_MST.RISK_PARTICIPATION_PCT/100
	AS "O/S Txn Amt", 
	(CASE WHEN TXN_HST.SHORTFALL_OFFSET_TYPE <> 'CBB' AND TXN_HST.SHORTFALL_OFFSET_TYPE <> 'GBB' THEN 	
	(NVL(Scbk_P_Cocoa_Cdb.SCBF_C_GET_NCV_BY_TXN_REF_ID(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID,Scbf_Get_Exp_Ccy(TXN_HST.bank_Group_Code,TXN_HST.cty_Code,TXN_HST.CUST_ID),
	TXN_HST.TXN_REC_ID,TXN_HST.TXN_CCY_CODE,TXN_HST.DEAL_STEP_ID,'H',''),0)*RISK_SHARE_MST.RISK_PARTICIPATION_PCT/100)||'' 
	WHEN TXN_HST.SHORTFALL_OFFSET_TYPE = 'CBB' OR TXN_HST.SHORTFALL_OFFSET_TYPE = 'GBB' THEN 
	'BB Cert Amt' ELSE NULL END) AS "Linked NCV",TXN_HST.TXN_REF_ID,TXN_HST.TXN_REC_ID
	FROM SCBT_T_TXN_HST TXN_HST, SCBT_R_CUST_RISK_SHARING_MST RISK_SHARE_MST,SCBT_R_CUST_SYNDICATION_MST SYN_MST
	WHERE TXN_HST.SYNDICATION_ID = SYN_MST.SYNDICATION_ID AND TXN_HST.CUST_ID = RISK_SHARE_MST.CUST_ID 
	AND TXN_HST.BANK_GROUP_CODE = SYN_MST.BANK_GROUP_CODE AND TXN_HST.CTY_CODE = SYN_MST.CTY_CODE AND TXN_HST.CUST_ID = SYN_MST.CUST_ID	
	AND RISK_SHARE_MST.SYNDICATION_ID = TXN_HST.SYNDICATION_ID AND RISK_SHARE_MST.SYNDICATION_ID = SYN_MST.SYNDICATION_ID 
	AND RISK_SHARE_MST.BANK_GROUP_CODE = SYN_MST.BANK_GROUP_CODE AND RISK_SHARE_MST.CTY_CODE = SYN_MST.CTY_CODE 
	AND SYN_MST.SCB_ROLE = 'AG' AND NVL(TXN_HST.TXN_STATUS_CODE,'00') <> '11'
	AND TXN_HST.TXN_STEP_CODE IN ('NEW','DRAW','AMD','TROV') AND TXN_HST.SYNDICATION_ID IS NOT NULL 
	AND TXN_HST.BANK_GROUP_CODE = ? AND TXN_HST.CTY_CODE = ? AND TXN_HST.DEAL_ID= ? AND  TXN_HST.DEAL_STEP_ID= ? 
	ORDER BY TXN_REC_ID  DESC,1 ASC
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SYNDICATION_SUMMARY_DETAILS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> SG957T09056
Param [3]--> SG957T09056M0002
Param [4]--> SCB
Param [5]--> SG
Param [6]--> SG957T09056
Param [7]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: select scbdealint0_.TXN_REF_ID as TXN1_216_, scbdealint0_.BANK_GROUP_CODE as BANK2_216_, scbdealint0_.CTY_CODE as CTY3_216_, scbdealint0_.DEAL_ID as DEAL4_216_, scbdealint0_.REC_ID as REC5_216_, scbdealint0_.FINANCE_NO as FINANCE6_216_, scbdealint0_.PRINCIPAL_CCY_CODE as PRINCIPAL7_216_, scbdealint0_.PRINCIPAL_CCY_AMT as PRINCIPAL8_216_, scbdealint0_.INT_CCY_CODE as INT9_216_, scbdealint0_.INT_CCY_AMT as INT10_216_, scbdealint0_.ACCR_FROM as ACCR11_216_, scbdealint0_.ACCR_TO as ACCR12_216_, scbdealint0_.INT_PERIOD as INT13_216_, scbdealint0_.DAILY_ACCR_CCY_CODE as DAILY14_216_, scbdealint0_.DAILY_ACCR_CCY_AMT as DAILY15_216_, scbdealint0_.BASE_INDEX_RATE as BASE16_216_, scbdealint0_.INDEX_TENOR as INDEX17_216_, scbdealint0_.BASE_RATE_VALUE_PCT as BASE18_216_, scbdealint0_.VARIABLE_MARGIN_PCT as VARIABLE19_216_, scbdealint0_.MARGIN_PCT as MARGIN20_216_, scbdealint0_.INTEREST_RATE as INTEREST21_216_, scbdealint0_.INT_REPAY_CCY_CODE as INT22_216_, scbdealint0_.INT_REPAY_CCY_AMT as INT23_216_, scbdealint0_.COLLECTION_OPTION_CODE as COLLECTION24_216_, scbdealint0_.YEAR_BASIS as YEAR25_216_, scbdealint0_.CUST_ID as CUST26_216_ from SCBT_T_TXN_INT_MST scbdealint0_ where scbdealint0_.BANK_GROUP_CODE=? and scbdealint0_.CTY_CODE=? and scbdealint0_.DEAL_ID=? and scbdealint0_.TXN_REF_ID=? and (scbdealint0_.REC_ID not in  (select scbdealint1_.REC_ID from SCBT_T_TXN_INT_HST scbdealint1_ where scbdealint1_.BANK_GROUP_CODE=scbdealint0_.BANK_GROUP_CODE and scbdealint1_.CTY_CODE=scbdealint0_.CTY_CODE and scbdealint0_.DEAL_ID=scbdealint1_.DEAL_ID and scbdealint0_.TXN_REF_ID=scbdealint1_.TXN_REF_ID and scbdealint1_.BANK_GROUP_CODE=? and scbdealint1_.CTY_CODE=? and scbdealint1_.DEAL_ID=? and scbdealint1_.TXN_REF_ID=? and scbdealint1_.DEAL_STEP_ID=?))
Hibernate: select scbdealint0_.DEAL_STEP_ID as DEAL1_215_, scbdealint0_.TXN_REF_ID as TXN2_215_, scbdealint0_.BANK_GROUP_CODE as BANK3_215_, scbdealint0_.CTY_CODE as CTY4_215_, scbdealint0_.DEAL_ID as DEAL5_215_, scbdealint0_.REC_ID as REC6_215_, scbdealint0_.CUST_ID as CUST7_215_, scbdealint0_.FINANCE_NO as FINANCE8_215_, scbdealint0_.PRINCIPAL_CCY_CODE as PRINCIPAL9_215_, scbdealint0_.PRINCIPAL_CCY_AMT as PRINCIPAL10_215_, scbdealint0_.INT_CCY_CODE as INT11_215_, scbdealint0_.INT_CCY_AMT as INT12_215_, scbdealint0_.ACCR_FROM as ACCR13_215_, scbdealint0_.ACCR_TO as ACCR14_215_, scbdealint0_.INT_PERIOD as INT15_215_, scbdealint0_.DAILY_ACCR_CCY_CODE as DAILY16_215_, scbdealint0_.DAILY_ACCR_CCY_AMT as DAILY17_215_, scbdealint0_.BASE_INDEX_RATE as BASE18_215_, scbdealint0_.INDEX_TENOR as INDEX19_215_, scbdealint0_.BASE_RATE_VALUE_PCT as BASE20_215_, scbdealint0_.VARIABLE_MARGIN_PCT as VARIABLE21_215_, scbdealint0_.MARGIN_PCT as MARGIN22_215_, scbdealint0_.INTEREST_RATE as INTEREST23_215_, scbdealint0_.INT_REPAY_CCY_CODE as INT24_215_, scbdealint0_.INT_REPAY_CCY_AMT as INT25_215_, scbdealint0_.COLLECTION_OPTION_CODE as COLLECTION26_215_, scbdealint0_.YEAR_BASIS as YEAR27_215_ from SCBT_T_TXN_INT_HST scbdealint0_ where scbdealint0_.BANK_GROUP_CODE=? and scbdealint0_.CTY_CODE=? and scbdealint0_.DEAL_ID=? and scbdealint0_.DEAL_STEP_ID=? and scbdealint0_.TXN_REF_ID=?
Hibernate: select scbpartytx0_.PARTY_ID as PARTY1_210_, scbpartytx0_.BANK_GROUP_CODE as BANK2_210_, scbpartytx0_.CTY_CODE as CTY3_210_, scbpartytx0_.DEAL_STEP_ID as DEAL4_210_, scbpartytx0_.REC_ID as REC5_210_, scbpartytx0_.PARTY_ROLE_CODE as PARTY6_210_, scbpartytx0_.SI_VIEWED_BY_CHECKER as SI7_210_, scbpartytx0_.SI_VIEWED_BY_MAKER as SI8_210_ from SCBT_T_PARTY scbpartytx0_ where scbpartytx0_.BANK_GROUP_CODE=? and scbpartytx0_.CTY_CODE=? and scbpartytx0_.DEAL_STEP_ID=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbadviced0_.ADVICE_ID as ADVICE1_212_, scbadviced0_.BANK_GROUP_CODE as BANK2_212_, scbadviced0_.DEAL_STEP_ID as DEAL3_212_, scbadviced0_.CTY_CODE as CTY4_212_, scbadviced0_.REC_ID as REC5_212_, scbadviced0_.NO_OF_COPIES as NO6_212_, scbadviced0_.NO_OF_PAGES as NO7_212_, scbadviced0_.PRINTER_NAME as PRINTER8_212_, scbadviced0_.ADV_DELIVERY as ADV9_212_, scbadviced0_.STATUS_CODE as STATUS10_212_, scbadviced0_.ADVICE_LOCATION as ADVICE11_212_, scbadviced0_.FILE_CHECKSUM as FILE12_212_, scbadviced0_.SHOW_LOGO as SHOW13_212_, scbadviced0_.PRINT_DELIVERY_FLAG as PRINT14_212_, scbadviced0_.EMAIL_DELIVERY_FLAG as EMAIL15_212_, scbadviced0_.REMARKS as REMARKS212_, scbadviced0_.ADVICE_TITLE as ADVICE17_212_, scbadviced0_.XML_DOC as XML18_212_, scbadviced0_.PDF_FILE as PDF20_212_, scbadviced0_.RECEIVER_PARTY_ID as RECEIVER21_212_, scbadviced0_.RECEIVER_ADD_ID as RECEIVER22_212_, scbadviced0_.RECEIVER_CONTACT_ID as RECEIVER23_212_, scbadviced0_.CC_PARTY_ID as CC24_212_, scbadviced0_.CC_CONTACT_ID as CC25_212_, scbadviced0_.CC_ADD_ID as CC26_212_, scbadviced0_.COLLATERAL_ID as COLLATERAL27_212_, scbadviced0_.STORAGE_COMPANY_ID as STORAGE28_212_, scbadviced0_.TEMPLATE_TYPE_CODE as TEMPLATE29_212_, scbadviced0_.RELEASE_TO_PARTY_CODE as RELEASE30_212_, scbadviced0_.RELEASE_TO_PARTY_ID as RELEASE31_212_, scbadviced0_.RELEASE_TO_PARTY_NAME as RELEASE32_212_, scbadviced0_.RELEASE_TO_PARTY_ADD1 as RELEASE33_212_, scbadviced0_.RELEASE_TO_PARTY_ADD2 as RELEASE34_212_, scbadviced0_.RELEASE_TO_PARTY_ADD3 as RELEASE35_212_, scbadviced0_.LANG_CODE as LANG36_212_, scbadviced0_.BENIFICIARY_NAME as BENIFIC37_212_, scbadviced0_.ACCOUNT_NUMBER as ACCOUNT38_212_, scbadviced0_.ACCOUNT_WITH_BANK as ACCOUNT39_212_, scbadviced0_.REFERENCE_NUMBER as REFERENCE40_212_, scbadviced0_.ADMIN_FEE_AMT_CCY as ADMIN41_212_, scbadviced0_.ADMIN_FEE_AMT as ADMIN42_212_, scbadviced0_.TAX_AMT_CCY as TAX43_212_, scbadviced0_.TAX_AMT as TAX44_212_, scbadviced0_.BRANCH_CODE as BRANCH45_212_, scbadviced0_.SUBJECT as SUBJECT212_, scbadviced0_.PURCHASE_PRICE_FLAG as PURCHASE47_212_, scbadviced0_.DUE_DATE as DUE48_212_ from SCBT_T_ADVICE_DTLS scbadviced0_ where scbadviced0_.DEAL_STEP_ID=? and scbadviced0_.BANK_GROUP_CODE=?
Hibernate: select scbacbsdtl0_.TXN_REF_ID as TXN1_213_, scbacbsdtl0_.BANK_GROUP_CODE as BANK2_213_, scbacbsdtl0_.DEAL_STEP_ID as DEAL3_213_, scbacbsdtl0_.CTY_CODE as CTY4_213_, scbacbsdtl0_.DEAL_ID as DEAL5_213_, scbacbsdtl0_.REC_ID as REC6_213_, scbacbsdtl0_.STEP as STEP213_, scbacbsdtl0_.CCY_CODE as CCY8_213_, scbacbsdtl0_.AMOUNT as AMOUNT213_, scbacbsdtl0_.INSTALLMENT_DETAILS as INSTALL10_213_, scbacbsdtl0_.LOAN_CATEGORY as LOAN11_213_, scbacbsdtl0_.VALUE_DATE as VALUE12_213_, scbacbsdtl0_.RATE_MATURITY_DATE as RATE13_213_, scbacbsdtl0_.FINAL_MATURITY_DATE as FINAL14_213_, scbacbsdtl0_.LIBORCOF as LIBORCOF213_, scbacbsdtl0_.LP as LP213_, scbacbsdtl0_.FTP_LIBOR_LP_COF as FTP17_213_, scbacbsdtl0_.FTP as FTP213_, scbacbsdtl0_.MARGIN as MARGIN213_, scbacbsdtl0_.ALL_IN_RATE as ALL20_213_, scbacbsdtl0_.BREAK_FUNDING_COST as BREAK21_213_, scbacbsdtl0_.SETTLEMENT_ACCOUNT as SETTLEMENT22_213_, scbacbsdtl0_.SETTLEMENT_ACCOUNT_REMARKS as SETTLEMENT23_213_, scbacbsdtl0_.ADDITIONAL_REMARKS as ADDITIONAL24_213_, scbacbsdtl0_.PRODUCT_CODE as PRODUCT25_213_, scbacbsdtl0_.PRODUCT_DESC as PRODUCT26_213_, scbacbsdtl0_.ACBS_STATUS_CODE as ACBS27_213_, scbacbsdtl0_.ADVICE_REC_ID as ADVICE28_213_, scbacbsdtl0_.TXN_TYPE as TXN29_213_, scbacbsdtl0_.TENOR as TENOR213_, scbacbsdtl0_.TP_TXN_REF_NO as TP31_213_ from SCBT_T_ACBS_DTLS scbacbsdtl0_ where scbacbsdtl0_.DEAL_ID=?
Hibernate: select scbremarke0_.BANK_GROUP_CODE as BANK1_214_, scbremarke0_.CTY_CODE as CTY2_214_, scbremarke0_.DEAL_STEP_ID as DEAL3_214_, scbremarke0_.REC_ID as REC4_214_, scbremarke0_.USER_ID as USER5_214_, scbremarke0_.STEP_CODE as STEP6_214_, scbremarke0_.REMARKS_CAT_CODE as REMARKS7_214_, scbremarke0_.CREATED_DATE as CREATED8_214_, scbremarke0_.REMARKS as REMARKS214_, scbremarke0_.ATTACHED_FILE_PATH as ATTACHED10_214_, scbremarke0_.SEND_EMAIL_TO as SEND11_214_, scbremarke0_.SEND_EMAIL_CC as SEND12_214_, scbremarke0_.ATTACHED_FILE_CONTENT as ATTACHED13_214_, scbremarke0_.SEND_TO_EMAIL as SEND14_214_, scbremarke0_.EMAIL_SENT as EMAIL15_214_, scbremarke0_.ATTACHED_FILE_NAME as ATTACHED16_214_ from SCBT_T_REMARKS_DTLS scbremarke0_ where scbremarke0_.DEAL_STEP_ID=? and scbremarke0_.BANK_GROUP_CODE=? and scbremarke0_.CTY_CODE=?
Hibernate: select scbbbcshor0_.BANK_GROUP_CODE as BANK1_124_, scbbbcshor0_.CTY_CODE as CTY2_124_, scbbbcshor0_.DEAL_ID as DEAL3_124_, scbbbcshor0_.DEAL_STEP_ID as DEAL4_124_, scbbbcshor0_.BBC_ID as BBC5_124_, scbbbcshor0_.BBC_OVERALL_CCY_CODE as BBC6_124_, scbbbcshor0_.EXPIRY_DATE as EXPIRY7_124_, scbbbcshor0_.GRACE_PERIOD as GRACE8_124_, scbbbcshor0_.EXTENDED_EXPIRY_DATE as EXTENDED9_124_, scbbbcshor0_.GROSS_DP_ANI_AMT as GROSS10_124_, scbbbcshor0_.SCB_DP_ANI_AMT as SCB11_124_, scbbbcshor0_.GROSS_DP_WNI_AMT as GROSS12_124_, scbbbcshor0_.SCB_DP_WNI_AMT as SCB13_124_, scbbbcshor0_.SCB_DP_BY_LB_AMT as SCB14_124_, scbbbcshor0_.APPL_DP_AMT as APPL15_124_, scbbbcshor0_.TOTAL_EXPOSURE_AMT as TOTAL16_124_, scbbbcshor0_.SF_SP_AMT as SF17_124_ from SCBT_T_BBC_SHORTFALL_DTLS scbbbcshor0_ where scbbbcshor0_.BANK_GROUP_CODE=? and scbbbcshor0_.CTY_CODE=? and scbbbcshor0_.DEAL_ID=? and scbbbcshor0_.DEAL_STEP_ID=?
Hibernate: select scbbbclimi0_.BANK_GROUP_CODE as BANK1_125_, scbbbclimi0_.CTY_CODE as CTY2_125_, scbbbclimi0_.DEAL_ID as DEAL3_125_, scbbbclimi0_.DEAL_STEP_ID as DEAL4_125_, scbbbclimi0_.CUST_ID as CUST5_125_, scbbbclimi0_.LIMIT_ID as LIMIT6_125_, scbbbclimi0_.EXPOSURE_CCY_CODE as EXPOSURE7_125_, scbbbclimi0_.PRODUCT_CODE as PRODUCT8_125_, scbbbclimi0_.EXPOSURE_CCY_AMT as EXPOSURE9_125_, scbbbclimi0_.DP_CCY_CODE as DP10_125_, scbbbclimi0_.DP_CCY_EXPOSURE_AMT as DP11_125_, scbbbclimi0_.DP_CHECK_APPL_FLAG as DP12_125_ from SCBT_T_BBC_EXPOSURE_DTLS scbbbclimi0_ where scbbbclimi0_.BANK_GROUP_CODE=? and scbbbclimi0_.CTY_CODE=? and scbbbclimi0_.CUST_ID=? and scbbbclimi0_.DEAL_ID=? and scbbbclimi0_.DEAL_STEP_ID=?
Hibernate: select scbcustsho0_.BANK_GROUP_CODE as BANK1_117_, scbcustsho0_.CTY_CODE as CTY2_117_, scbcustsho0_.CUST_ID as CUST3_117_, scbcustsho0_.TOTAL_CASH_AVBL_FOR_OFFSET_AMT as TOTAL4_117_, scbcustsho0_.TOTAL_CASH_MARGIN_REQ_AMT as TOTAL5_117_, scbcustsho0_.COLL_EXCESS_TXN_ODFIN_AMT as COLL6_117_, scbcustsho0_.COLL_SHORTFALL_TXN_ODFIN_AMT as COLL7_117_, scbcustsho0_.LOSS_ON_TPA_HEDGE_ACC_AMT as LOSS8_117_, scbcustsho0_.NET_CASHOFFSET_SHORTFALL_AMT as NET9_117_, scbcustsho0_.NET_FULLOFFSET_SHORTFALL_AMT as NET10_117_, scbcustsho0_.NET_HEDGEOFFSET_SHORTFALL_AMT as NET11_117_, scbcustsho0_.OVERALL_EXP_CCY_CODE as OVERALL12_117_, scbcustsho0_.SHORTFALL_APPL_CASHOFFSET_AMT as SHORTFALL13_117_, scbcustsho0_.SHORTFALL_APPL_FULLOFFSET_AMT as SHORTFALL14_117_, scbcustsho0_.SHORTFALL_APPL_HEDGEOFFSET_AMT as SHORTFALL15_117_, scbcustsho0_.TOTAL_CASH_COLL_AMT as TOTAL16_117_, scbcustsho0_.TOTAL_HEDGE_COLL_AMT as TOTAL17_117_, scbcustsho0_.TOTAL_SHORTFALL_AMT as TOTAL18_117_, scbcustsho0_.TPA_HEDGE_ACC_DEBT_BAL_AMT as TPA19_117_ from SCBT_T_CUST_SHORTFALL_SMRY_MST scbcustsho0_ where scbcustsho0_.BANK_GROUP_CODE=? and scbcustsho0_.CTY_CODE=? and scbcustsho0_.CUST_ID=?
Hibernate: SELECT SCBK_P_COCOA_CDB.SCBF_GET_TOPUP_AMT_BY_LEVEL(?, ?, ?, ?, ?, ?, ?, ?, ?, ?) FROM DUAL
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> COLLATERAL_TOPUP_AMOUNT_BY_LEVEL
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056LC001
Param [4]--> 15110655
Param [5]--> USD
Param [6]--> 20393575
Param [7]--> USD
Param [8]--> N
Param [9]--> T
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: delete from SCBT_T_TXN_SHORTFALL_DTLS where BANK_GROUP_CODE=? and CTY_CODE=? and CUST_ID=? and DEAL_STEP_ID=? and TXN_REF_ID=?
Hibernate: select scbtxnshor0_.BANK_GROUP_CODE as BANK1_112_0_, scbtxnshor0_.CTY_CODE as CTY2_112_0_, scbtxnshor0_.CUST_ID as CUST3_112_0_, scbtxnshor0_.DEAL_STEP_ID as DEAL4_112_0_, scbtxnshor0_.TXN_REC_ID as TXN5_112_0_, scbtxnshor0_.TXN_REF_ID as TXN6_112_0_, scbtxnshor0_.TXN_CCY_CODE as TXN7_112_0_, scbtxnshor0_.TXN_CCY_AMT as TXN8_112_0_, scbtxnshor0_.LINKED_COLL_COV_CCY_CODE as LINKED9_112_0_, scbtxnshor0_.LINKED_COLL_COV_CCY_AMT as LINKED10_112_0_, scbtxnshor0_.CASH_MARGIN_CCY_CODE as CASH11_112_0_, scbtxnshor0_.CASH_MARGIN_CCY_AMT as CASH12_112_0_, scbtxnshor0_.TOPUP_CCY_CODE as TOPUP13_112_0_, scbtxnshor0_.TOPUP_CCY_AMT as TOPUP14_112_0_, scbtxnshor0_.SHORTFALL_CCY_CODE as SHORTFALL15_112_0_, scbtxnshor0_.SHORTFALL_CCY_AMT as SHORTFALL16_112_0_, scbtxnshor0_.TXN_STEP_CODE as TXN17_112_0_, scbtxnshor0_.SHORTFALL_STATUS as SHORTFALL18_112_0_ from SCBT_T_TXN_SHORTFALL_DTLS scbtxnshor0_ where scbtxnshor0_.BANK_GROUP_CODE=? and scbtxnshor0_.CTY_CODE=? and scbtxnshor0_.CUST_ID=? and scbtxnshor0_.DEAL_STEP_ID=? and scbtxnshor0_.TXN_REC_ID=? and scbtxnshor0_.TXN_REF_ID=?
Hibernate: select scbtxnshor_.BANK_GROUP_CODE, scbtxnshor_.CTY_CODE, scbtxnshor_.CUST_ID, scbtxnshor_.DEAL_STEP_ID, scbtxnshor_.TXN_REC_ID, scbtxnshor_.TXN_REF_ID, scbtxnshor_.TXN_CCY_CODE as TXN7_112_, scbtxnshor_.TXN_CCY_AMT as TXN8_112_, scbtxnshor_.LINKED_COLL_COV_CCY_CODE as LINKED9_112_, scbtxnshor_.LINKED_COLL_COV_CCY_AMT as LINKED10_112_, scbtxnshor_.CASH_MARGIN_CCY_CODE as CASH11_112_, scbtxnshor_.CASH_MARGIN_CCY_AMT as CASH12_112_, scbtxnshor_.TOPUP_CCY_CODE as TOPUP13_112_, scbtxnshor_.TOPUP_CCY_AMT as TOPUP14_112_, scbtxnshor_.SHORTFALL_CCY_CODE as SHORTFALL15_112_, scbtxnshor_.SHORTFALL_CCY_AMT as SHORTFALL16_112_, scbtxnshor_.TXN_STEP_CODE as TXN17_112_, scbtxnshor_.SHORTFALL_STATUS as SHORTFALL18_112_ from SCBT_T_TXN_SHORTFALL_DTLS scbtxnshor_ where scbtxnshor_.BANK_GROUP_CODE=? and scbtxnshor_.CTY_CODE=? and scbtxnshor_.CUST_ID=? and scbtxnshor_.DEAL_STEP_ID=? and scbtxnshor_.TXN_REC_ID=? and scbtxnshor_.TXN_REF_ID=?
Hibernate: insert into SCBT_T_TXN_SHORTFALL_DTLS (TXN_CCY_CODE, TXN_CCY_AMT, LINKED_COLL_COV_CCY_CODE, LINKED_COLL_COV_CCY_AMT, CASH_MARGIN_CCY_CODE, CASH_MARGIN_CCY_AMT, TOPUP_CCY_CODE, TOPUP_CCY_AMT, SHORTFALL_CCY_CODE, SHORTFALL_CCY_AMT, TXN_STEP_CODE, SHORTFALL_STATUS, BANK_GROUP_CODE, CTY_CODE, CUST_ID, DEAL_STEP_ID, TXN_REC_ID, TXN_REF_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: select scbstoplos0_.BANK_GROUP_CODE as BANK1_126_, scbstoplos0_.CTY_CODE as CTY2_126_, scbstoplos0_.REC_ID as REC3_126_, scbstoplos0_.CMR_CCY_CODE as CMR4_126_, scbstoplos0_.CMR_CCY_AMT as CMR5_126_, scbstoplos0_.CUST_ID as CUST6_126_, scbstoplos0_.DEAL_STEP_ID as DEAL7_126_, scbstoplos0_.TXN_REF_ID as TXN8_126_, scbstoplos0_.TXN_REC_ID as TXN9_126_, scbstoplos0_.LIMIT_ID as LIMIT10_126_, scbstoplos0_.GROUP_ID as GROUP11_126_, scbstoplos0_.ACTIVITY_ID as ACTIVITY12_126_, scbstoplos0_.TOPUP_LEVEL as TOPUP13_126_, scbstoplos0_.LTV_CALC_PCT as LTV14_126_, scbstoplos0_.SHORTFALL_CCY_CODE as SHORTFALL15_126_, scbstoplos0_.SHORTFALL_CCY_AMT as SHORTFALL16_126_, scbstoplos0_.TOPUP_REQ_FLAG as TOPUP17_126_, scbstoplos0_.TOPUP_REQ_CCY_CODE as TOPUP18_126_, scbstoplos0_.TOPUP_REQ_CCY_AMT as TOPUP19_126_, scbstoplos0_.TOPUP_REQ_PCT as TOPUP20_126_, scbstoplos0_.TXN_STEP_CODE as TXN21_126_, scbstoplos0_.EXPOSURE_CCY_CODE as EXPOSURE22_126_, scbstoplos0_.EXPOSURE_CCY_AMT as EXPOSURE23_126_, scbstoplos0_.GCV_CCY_CODE as GCV24_126_, scbstoplos0_.GCV_CCY_AMT as GCV25_126_, scbstoplos0_.CASHTOPUP_CCY_CODE as CASHTOPUP26_126_, scbstoplos0_.CASHTOPUP_CCY_AMT as CASHTOPUP27_126_, scbstoplos0_.LTV_FORMULA as LTV28_126_, scbstoplos0_.CMR_PERCENT as CMR29_126_ from SCBT_T_STOPLOSS_SUMMARY_MST scbstoplos0_ where scbstoplos0_.BANK_GROUP_CODE=? and scbstoplos0_.CTY_CODE=? and scbstoplos0_.CUST_ID=? and scbstoplos0_.DEAL_STEP_ID=?
Hibernate: SELECT GROUP_ID,CMR_CCY_CODE,CMR_CCY_AMT,TOP_UP_CCY_CODE,TOP_UP_CCY_AMT,CASH_BALANCE_CCY_CODE,CASH_BALANCE_CCY_AMT,CASH_HELD_FLAG,
		  		   CASH_TOPUP_REQ_CCY_CODE,CASH_TOPUP_REQ_CCY_AMT from SCBT_T_GRP_CAO_OFFSET_MST
		  	WHERE BANK_GROUP_CODE = ? AND CTY_CODE = ? AND CUST_ID = ? AND DEAL_STEP_ID = ? AND PAGE_SOURCE = 'DDB'
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> DDB_CMR_OFFSET_DETAILS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 1
Execution time (ms)  --> 15

INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside Limits Service Session >>> retrieveCurrentlimitDtls >>> START 
Hibernate: select scbprodlim0_.REC_ID as REC1_193_, scbprodlim0_.BUS_EVENT_REF_NO as BUS2_193_, scbprodlim0_.INIT_REQ_ID as INIT3_193_, scbprodlim0_.REQ_STATUS_CODE as REQ4_193_, scbprodlim0_.TBU_CODE as TBU5_193_, scbprodlim0_.BANK_GROUP_CODE as BANK6_193_, scbprodlim0_.LOG_STATUS_CODE as LOG7_193_, scbprodlim0_.REQ_ID as REQ8_193_, scbprodlim0_.REQ_TIMESTAMP as REQ9_193_, scbprodlim0_.REQ_TYPE_CODE as REQ10_193_, scbprodlim0_.CTY_CODE as CTY11_193_, scbprodlim0_.USER_ID as USER12_193_, scbprodlim0_.FORCE_POST_FLAG as FORCE13_193_, scbprodlim0_.SYS_CODE as SYS14_193_, scbprodlim0_.BUSINESS_DATE as BUSINESS15_193_ from SCBT_T_PROD_LIMIT_REQ_LOG scbprodlim0_ where scbprodlim0_.BUS_EVENT_REF_NO=? and scbprodlim0_.LOG_STATUS_CODE=? and scbprodlim0_.REQ_TYPE_CODE=? and (scbprodlim0_.REQ_STATUS_CODE in (? , ?)) and scbprodlim0_.BANK_GROUP_CODE=? and scbprodlim0_.CTY_CODE=? and scbprodlim0_.SYS_CODE=?
Hibernate: select lim_res.LIMIT_ID, lim_res.LIMIT_TREE_TYPE_CODE, lim_res.LIMIT_CCY_CODE, 
			lim_res.LIMIT_CCY_UTILISED_AMT, lim_res.AVAIL_AMT,
			 lim_res.APP_AMT, lim_res.LIMIT_CCY_PEND_INC_AMT, lim_res.LIMIT_CCY_PEND_DEC_AMT, lim_res.OBLIGOR_ID, 
			 (select mv.offering_flag from scbt_t_prod_limit_mvmt mv where mv.LIMIT_ID = lim_res.limit_id and 
			 mv.init_req_id = lim_res.init_req_id and lim_res.APP_AMT>=0 and mv.txn_ccy_amt>0
			and mv.offering_reason is not null and rownum = 1) as "OFF Flag",
			  (select mv.offering_reason from scbt_t_prod_limit_mvmt mv where mv.LIMIT_ID = lim_res.limit_id and 
			  mv.init_req_id = lim_res.init_req_id and lim_res.APP_AMT>=0 and mv.txn_ccy_amt>0 and mv.offering_reason is not null and rownum = 1) as "OFF Reason", 
			lim_res.MV_LIMIT_SEQ_NO, lim_res.limit_product_code from (
			SELECT UTIL.LIMIT_ID, UTIL.LIMIT_TREE_TYPE_CODE, UTIL.LIMIT_CCY_CODE,
			UTIL.LIMIT_CCY_UTILISED_AMT,   SCBF_TLS_GET_ACTIVE_AMT(UTIL.Bank_Group_Code,UTIL.Cty_Code,UTIL.LIMIT_TREE_TYPE_CODE,UTIL.LIMIT_ID) - 
			UTIL.LIMIT_CCY_UTILISED_AMT - UTIL.LIMIT_CCY_PEND_INC_AMT AVAIL_AMT,
			SUM(SCBF_TLS_EXCH_RATE(?, ?, MV.TXN_CCY_CODE, MV.TXN_CCY_AMT,UTIL.LIMIT_CCY_CODE, 'Y'))AS APP_AMT,
			UTIL.LIMIT_CCY_PEND_INC_AMT, UTIL.LIMIT_CCY_PEND_DEC_AMT, MV.OBLIGOR_ID, NVL(CL.LIMIT_SEQ_NO,99) as MV_LIMIT_SEQ_NO,cl.limit_product_code, mv.init_req_id
			FROM SCBT_T_PROD_LIMIT_MVMT MV, SCBT_T_PROD_LIMIT_UTIL UTIL, SCBT_R_CUST_PRODUCT_LIMIT CL
			WHERE
			MV.INIT_REQ_ID = ? AND
			UTIL.LIMIT_ID = MV.LIMIT_ID AND
			UTIL.LIMIT_TREE_TYPE_CODE = MV.LIMIT_TREE_TYPE_CODE
			AND CL.BANK_GROUP_CODE(+) = UTIL.BANK_GROUP_CODE
			AND CL.CTY_CODE(+) = UTIL.CTY_CODE
			AND CL.LIMIT_ID(+) = UTIL.LIMIT_ID
			GROUP BY UTIL.LIMIT_ID, UTIL.LIMIT_TREE_TYPE_CODE, UTIL.LIMIT_CCY_CODE, UTIL.LIMIT_CCY_UTILISED_AMT, 
			SCBF_TLS_GET_ACTIVE_AMT(UTIL.Bank_Group_Code,UTIL.Cty_Code,UTIL.LIMIT_TREE_TYPE_CODE,UTIL.LIMIT_ID) - UTIL.LIMIT_CCY_UTILISED_AMT - UTIL.LIMIT_CCY_PEND_INC_AMT,
			UTIL.LIMIT_CCY_PEND_INC_AMT, UTIL.LIMIT_CCY_PEND_DEC_AMT, MV.OBLIGOR_ID, UTIL.Bank_Group_Code, UTIL.Cty_Code,
			CL.LIMIT_SEQ_NO,cl.limit_product_code, mv.init_req_id) lim_res order by lim_res.OBLIGOR_ID, lim_res.MV_LIMIT_SEQ_NO
INFO  - Mon Apr 01 17:43:57 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> PROD_LIMIT_RET_CONFIRM_ACTION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 15110687
Result Size --> 2
Execution time (ms)  --> 47

Hibernate: select scbprodlim0_.BANK_GROUP_CODE as BANK1_194_, scbprodlim0_.INIT_REQ_ID as INIT2_194_, scbprodlim0_.REQ_SR_NO as REQ3_194_, scbprodlim0_.CPTY_ID as CPTY4_194_, scbprodlim0_.DEAL_ID as DEAL5_194_, scbprodlim0_.LIMIT_PRODUCT_CODE as LIMIT6_194_, scbprodlim0_.LIMIT_TYPE_CODE as LIMIT7_194_, scbprodlim0_.OBLIGOR_CTY_CODE as OBLIGOR8_194_, scbprodlim0_.OBLIGOR_ID as OBLIGOR9_194_, scbprodlim0_.REQ_ID as REQ10_194_, scbprodlim0_.STEP_ID as STEP11_194_, scbprodlim0_.CTY_CODE as CTY12_194_, scbprodlim0_.TXN_CCY_AMT as TXN13_194_, scbprodlim0_.TXN_CCY_CODE as TXN14_194_, scbprodlim0_.CPTY_CTY_CODE as CPTY15_194_, scbprodlim0_.LIMIT_TREE_TYPE_CODE as LIMIT16_194_, scbprodlim0_.EVERGREEN_LC_TYPE as EVERGREEN17_194_, scbprodlim0_.REVOLVING_LC_TYPE as REVOLVING18_194_, scbprodlim0_.TOTAL_CREDIT_PERIOD as TOTAL19_194_, scbprodlim0_.BILL_TENOR as BILL20_194_, scbprodlim0_.SUB_PRODUCT_TYPE_CODE as SUB21_194_, scbprodlim0_.CO_BORROWER_ID as CO22_194_, scbprodlim0_.CPTY_ROLE_CODE as CPTY23_194_, scbprodlim0_.PROD_LIMIT_ID as PROD24_194_, scbprodlim0_.COLL_LIMIT_ID as COLL25_194_, scbprodlim0_.TXN_REF_ID as TXN26_194_, scbprodlim0_.TP_REF_NO as TP27_194_, scbprodlim0_.MATURITY_DATE as MATURITY28_194_, scbprodlim0_.TXN_REC_ID as TXN29_194_, scbprodlim0_.PAYMENT_METHOD as PAYMENT30_194_, scbprodlim0_.CTY_OF_SALE as CTY31_194_, scbprodlim0_.BOOKING_BRANCH as BOOKING32_194_, scbprodlim0_.ISS_BOOKING_BRANCH as ISS33_194_, scbprodlim0_.SYN_TXN_CCY_AMT as SYN34_194_, scbprodlim0_.OFFTAKER_ID as OFFTAKER35_194_ from SCBT_T_PROD_LIMIT_REQ_LOG_DTL scbprodlim0_ where scbprodlim0_.INIT_REQ_ID=? and scbprodlim0_.BANK_GROUP_CODE=? and scbprodlim0_.CTY_CODE=?
Hibernate: SELECT Scbf_Get_Acc_Balance(?, ?, ?, ?, ?,'O') FROM DUAL
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SCBF_TLS_RET_ACC_BAL
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 2871
Param [4]--> USD
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_37_, scbcustlim0_.CTY_CODE as CTY2_37_, scbcustlim0_.LIMIT_ID as LIMIT3_37_, scbcustlim0_.CUST_ID as CUST4_37_, scbcustlim0_.STEP_ID as STEP5_37_, scbcustlim0_.ADVISED_FLAG as ADVISED6_37_, scbcustlim0_.BUSINESS_DATE as BUSINESS7_37_, scbcustlim0_.COMMITTED_FLAG as COMMITTED8_37_, scbcustlim0_.CPTY_CTY_CODE as CPTY9_37_, scbcustlim0_.CPTY_ID as CPTY10_37_, scbcustlim0_.CUST_CTY_CODE as CUST11_37_, scbcustlim0_.EXT_LIMIT_ID as EXT12_37_, scbcustlim0_.INNER_TO_ID as INNER13_37_, scbcustlim0_.LEGAL_ENTITY_ID as LEGAL14_37_, scbcustlim0_.LIMIT_CAT_CODE as LIMIT15_37_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT16_37_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT17_37_, scbcustlim0_.STOP_LOSS_PCT as STOP18_37_, scbcustlim0_.STOP_LOSS_CCY_CODE as STOP19_37_, scbcustlim0_.STOP_LOSS_CCY_AMT as STOP20_37_, scbcustlim0_.STOP_LOSS_APPL_FLAG as STOP21_37_, scbcustlim0_.LOAN_TO_VALUE_PCT as LOAN22_37_, scbcustlim0_.LIMIT_NAME as LIMIT23_37_, scbcustlim0_.LIMIT_PRODUCT_CODE as LIMIT24_37_, scbcustlim0_.LIMIT_SEQ_NO as LIMIT25_37_, scbcustlim0_.LIMIT_SHARE_ID as LIMIT26_37_, scbcustlim0_.LIMIT_SHARED_FLAG as LIMIT27_37_, scbcustlim0_.LIMIT_TYPE_CODE as LIMIT28_37_, scbcustlim0_.MAIN_BORROWER_ID as MAIN29_37_, scbcustlim0_.NOT_ALLOWED_PROD_CODES as NOT30_37_, scbcustlim0_.OMNIBUS_RISK as OMNIBUS31_37_, scbcustlim0_.PRODUCT_LIMIT_EXPIRY_DATE as PRODUCT32_37_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD33_37_, scbcustlim0_.REMARKS as REMARKS37_, scbcustlim0_.REMARKS2 as REMARKS35_37_, scbcustlim0_.REVOLVING_FLAG as REVOLVING36_37_, scbcustlim0_.SEQ_NO as SEQ37_37_, scbcustlim0_.SUB_PRODUCT_TYPE_CODE as SUB38_37_, scbcustlim0_.TENOR_TYPE_CODE as TENOR39_37_, scbcustlim0_.TO_TENOR as TO40_37_, scbcustlim0_.TO_TENOR_VALUE as TO41_37_, scbcustlim0_.TO_VALIDITY as TO42_37_, scbcustlim0_.TO_VALIDITY_VALUE as TO43_37_, scbcustlim0_.FROM_TENOR as FROM44_37_, scbcustlim0_.FROM_TENOR_VALUE as FROM45_37_, scbcustlim0_.FROM_VALIDITY as FROM46_37_, scbcustlim0_.FROM_VALIDITY_VALUE as FROM47_37_, scbcustlim0_.REVOLVING_LC_TYPE as REVOLVING48_37_, scbcustlim0_.EVERGREEN_LC_TYPE as EVERGREEN49_37_, scbcustlim0_.SHORTFALL_OFFSET as SHORTFALL50_37_, scbcustlim0_.CASH_MARGIN_PCT as CASH51_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACC_CCY as OVERDRAFT52_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACCNO as OVERDRAFT53_37_, scbcustlim0_.CO_BORROWER_ID as CO54_37_, scbcustlim0_.SURPLUS_CASH_ALLOCATION as SURPLUS55_37_, scbcustlim0_.MAX_TXN_CCY_CODE as MAX56_37_, scbcustlim0_.MAX_TXN_CCY_AMT as MAX57_37_, scbcustlim0_.LIMIT_CLASSIFICATION as LIMIT58_37_, scbcustlim0_.SYNDICATION_TYPE as SYNDICA59_37_, scbcustlim0_.SYNDICATION_ID as SYNDICA60_37_, scbcustlim0_.BB_DP_FLAG as BB61_37_, scbcustlim0_.BB_DEFERRAL_FLAG as BB62_37_, scbcustlim0_.FIN_HEDGE_MARGIN as FIN63_37_, scbcustlim0_.EXPOSURE_OFFSET_ACC_NO as EXPOSURE64_37_, scbcustlim0_.APPROVED_LIMIT_CCY_CODE as APPROVED65_37_, scbcustlim0_.LIMIT_CCY_APPROVED_AMT as LIMIT66_37_, scbcustlim0_.STOCK_DECLARATION_FLAG as STOCK67_37_, scbcustlim0_.FINANCE_FACILITY_FLAG as FINANCE68_37_, scbcustlim0_.COMMENTS as COMMENTS37_, scbcustlim0_.FOLLOWUP_REQUIRED as FOLLOWUP70_37_, scbcustlim0_.FOLLOWUP_REASON as FOLLOWUP71_37_ from SCBT_R_CUST_PRODUCT_LIMIT scbcustlim0_ where scbcustlim0_.LIMIT_ID=? and scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::resp DetailsVO--->*-------2871<-Err-->null---
Hibernate: SELECT Scbf_Get_Acc_Balance(?, ?, ?, ?, ?,'O') FROM DUAL
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SCBF_TLS_RET_ACC_BAL
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> USD
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_37_, scbcustlim0_.CTY_CODE as CTY2_37_, scbcustlim0_.LIMIT_ID as LIMIT3_37_, scbcustlim0_.CUST_ID as CUST4_37_, scbcustlim0_.STEP_ID as STEP5_37_, scbcustlim0_.ADVISED_FLAG as ADVISED6_37_, scbcustlim0_.BUSINESS_DATE as BUSINESS7_37_, scbcustlim0_.COMMITTED_FLAG as COMMITTED8_37_, scbcustlim0_.CPTY_CTY_CODE as CPTY9_37_, scbcustlim0_.CPTY_ID as CPTY10_37_, scbcustlim0_.CUST_CTY_CODE as CUST11_37_, scbcustlim0_.EXT_LIMIT_ID as EXT12_37_, scbcustlim0_.INNER_TO_ID as INNER13_37_, scbcustlim0_.LEGAL_ENTITY_ID as LEGAL14_37_, scbcustlim0_.LIMIT_CAT_CODE as LIMIT15_37_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT16_37_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT17_37_, scbcustlim0_.STOP_LOSS_PCT as STOP18_37_, scbcustlim0_.STOP_LOSS_CCY_CODE as STOP19_37_, scbcustlim0_.STOP_LOSS_CCY_AMT as STOP20_37_, scbcustlim0_.STOP_LOSS_APPL_FLAG as STOP21_37_, scbcustlim0_.LOAN_TO_VALUE_PCT as LOAN22_37_, scbcustlim0_.LIMIT_NAME as LIMIT23_37_, scbcustlim0_.LIMIT_PRODUCT_CODE as LIMIT24_37_, scbcustlim0_.LIMIT_SEQ_NO as LIMIT25_37_, scbcustlim0_.LIMIT_SHARE_ID as LIMIT26_37_, scbcustlim0_.LIMIT_SHARED_FLAG as LIMIT27_37_, scbcustlim0_.LIMIT_TYPE_CODE as LIMIT28_37_, scbcustlim0_.MAIN_BORROWER_ID as MAIN29_37_, scbcustlim0_.NOT_ALLOWED_PROD_CODES as NOT30_37_, scbcustlim0_.OMNIBUS_RISK as OMNIBUS31_37_, scbcustlim0_.PRODUCT_LIMIT_EXPIRY_DATE as PRODUCT32_37_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD33_37_, scbcustlim0_.REMARKS as REMARKS37_, scbcustlim0_.REMARKS2 as REMARKS35_37_, scbcustlim0_.REVOLVING_FLAG as REVOLVING36_37_, scbcustlim0_.SEQ_NO as SEQ37_37_, scbcustlim0_.SUB_PRODUCT_TYPE_CODE as SUB38_37_, scbcustlim0_.TENOR_TYPE_CODE as TENOR39_37_, scbcustlim0_.TO_TENOR as TO40_37_, scbcustlim0_.TO_TENOR_VALUE as TO41_37_, scbcustlim0_.TO_VALIDITY as TO42_37_, scbcustlim0_.TO_VALIDITY_VALUE as TO43_37_, scbcustlim0_.FROM_TENOR as FROM44_37_, scbcustlim0_.FROM_TENOR_VALUE as FROM45_37_, scbcustlim0_.FROM_VALIDITY as FROM46_37_, scbcustlim0_.FROM_VALIDITY_VALUE as FROM47_37_, scbcustlim0_.REVOLVING_LC_TYPE as REVOLVING48_37_, scbcustlim0_.EVERGREEN_LC_TYPE as EVERGREEN49_37_, scbcustlim0_.SHORTFALL_OFFSET as SHORTFALL50_37_, scbcustlim0_.CASH_MARGIN_PCT as CASH51_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACC_CCY as OVERDRAFT52_37_, scbcustlim0_.OVERDRAFT_FACILITY_ACCNO as OVERDRAFT53_37_, scbcustlim0_.CO_BORROWER_ID as CO54_37_, scbcustlim0_.SURPLUS_CASH_ALLOCATION as SURPLUS55_37_, scbcustlim0_.MAX_TXN_CCY_CODE as MAX56_37_, scbcustlim0_.MAX_TXN_CCY_AMT as MAX57_37_, scbcustlim0_.LIMIT_CLASSIFICATION as LIMIT58_37_, scbcustlim0_.SYNDICATION_TYPE as SYNDICA59_37_, scbcustlim0_.SYNDICATION_ID as SYNDICA60_37_, scbcustlim0_.BB_DP_FLAG as BB61_37_, scbcustlim0_.BB_DEFERRAL_FLAG as BB62_37_, scbcustlim0_.FIN_HEDGE_MARGIN as FIN63_37_, scbcustlim0_.EXPOSURE_OFFSET_ACC_NO as EXPOSURE64_37_, scbcustlim0_.APPROVED_LIMIT_CCY_CODE as APPROVED65_37_, scbcustlim0_.LIMIT_CCY_APPROVED_AMT as LIMIT66_37_, scbcustlim0_.STOCK_DECLARATION_FLAG as STOCK67_37_, scbcustlim0_.FINANCE_FACILITY_FLAG as FINANCE68_37_, scbcustlim0_.COMMENTS as COMMENTS37_, scbcustlim0_.FOLLOWUP_REQUIRED as FOLLOWUP70_37_, scbcustlim0_.FOLLOWUP_REASON as FOLLOWUP71_37_ from SCBT_R_CUST_PRODUCT_LIMIT scbcustlim0_ where scbcustlim0_.LIMIT_ID=? and scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::resp DetailsVO--->LCORS-------20393575<-Err-->null---
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_, scbpartyma0_.CTY_CODE as CTY3_74_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_, scbpartyma0_.GAM_CODE as GAM9_74_, scbpartyma0_.BU_LIST as BU10_74_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_, scbpartyma0_.STEP_ID as STEP21_74_, scbpartyma0_.ADD_1 as ADD22_74_, scbpartyma0_.ADD_2 as ADD23_74_, scbpartyma0_.ADD_3 as ADD24_74_, scbpartyma0_.PARTY_NAME as PARTY25_74_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_, scbpartyma0_.OPEN_DATE as OPEN27_74_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_, scbpartyma0_.RM_CODE as RM29_74_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_, scbpartyma0_.SEG_CODE as SEG31_74_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_, scbpartyma0_.REMARKS as REMARKS74_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_, scbpartyma0_.FI_FLAG as FI41_74_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_, scbpartyma0_.TAX_NO as TAX48_74_, scbpartyma0_.LTV_FORMULA as LTV49_74_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_, scbpartyma0_.CTY_CODE as CTY3_74_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_, scbpartyma0_.GAM_CODE as GAM9_74_, scbpartyma0_.BU_LIST as BU10_74_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_, scbpartyma0_.STEP_ID as STEP21_74_, scbpartyma0_.ADD_1 as ADD22_74_, scbpartyma0_.ADD_2 as ADD23_74_, scbpartyma0_.ADD_3 as ADD24_74_, scbpartyma0_.PARTY_NAME as PARTY25_74_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_, scbpartyma0_.OPEN_DATE as OPEN27_74_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_, scbpartyma0_.RM_CODE as RM29_74_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_, scbpartyma0_.SEG_CODE as SEG31_74_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_, scbpartyma0_.REMARKS as REMARKS74_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_, scbpartyma0_.FI_FLAG as FI41_74_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_, scbpartyma0_.TAX_NO as TAX48_74_, scbpartyma0_.LTV_FORMULA as LTV49_74_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_, scbpartyma0_.CTY_CODE as CTY3_74_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_, scbpartyma0_.GAM_CODE as GAM9_74_, scbpartyma0_.BU_LIST as BU10_74_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_, scbpartyma0_.STEP_ID as STEP21_74_, scbpartyma0_.ADD_1 as ADD22_74_, scbpartyma0_.ADD_2 as ADD23_74_, scbpartyma0_.ADD_3 as ADD24_74_, scbpartyma0_.PARTY_NAME as PARTY25_74_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_, scbpartyma0_.OPEN_DATE as OPEN27_74_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_, scbpartyma0_.RM_CODE as RM29_74_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_, scbpartyma0_.SEG_CODE as SEG31_74_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_, scbpartyma0_.REMARKS as REMARKS74_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_, scbpartyma0_.FI_FLAG as FI41_74_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_, scbpartyma0_.TAX_NO as TAX48_74_, scbpartyma0_.LTV_FORMULA as LTV49_74_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::limit id-->2871<-->*<-->USD<-->1000.0<-->null<-->SUCC
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::limit id-->20393575<-->LCORS<-->USD<-->1000.0<-->null<-->SUCC
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside Limits util DM >> inside retrieveCurrentLimitsDtls >> START 
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside Limits util DM >> inside retrieveCurrentLimitsDtls >> END 
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBProdLimitsServiceSession::Inside Limits Service Session >>> retrieveCurrentlimitDtls >>> END 
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside Limits Service Session >>> retrieveCurrentlimitDtls >>> START 
Hibernate: select scbcolllim0_.REC_ID as REC1_197_, scbcolllim0_.BUS_EVENT_REF_NO as BUS2_197_, scbcolllim0_.INIT_REQ_ID as INIT3_197_, scbcolllim0_.REQ_STATUS_CODE as REQ4_197_, scbcolllim0_.TBU_CODE as TBU5_197_, scbcolllim0_.BANK_GROUP_CODE as BANK6_197_, scbcolllim0_.LOG_STATUS_CODE as LOG7_197_, scbcolllim0_.REQ_ID as REQ8_197_, scbcolllim0_.REQ_TIMESTAMP as REQ9_197_, scbcolllim0_.REQ_TYPE_CODE as REQ10_197_, scbcolllim0_.CTY_CODE as CTY11_197_, scbcolllim0_.USER_ID as USER12_197_, scbcolllim0_.FORCE_POST_FLAG as FORCE13_197_, scbcolllim0_.SYS_CODE as SYS14_197_, scbcolllim0_.BUSINESS_DATE as BUSINESS15_197_, scbcolllim0_.CTY_FORCE_POST_FLAG as CTY16_197_ from SCBT_T_COLL_LIMIT_REQ_LOG scbcolllim0_ where scbcolllim0_.BUS_EVENT_REF_NO=? and scbcolllim0_.LOG_STATUS_CODE=? and scbcolllim0_.REQ_TYPE_CODE=? and (scbcolllim0_.REQ_STATUS_CODE in (? , ?)) and scbcolllim0_.BANK_GROUP_CODE=? and scbcolllim0_.CTY_CODE=? and scbcolllim0_.SYS_CODE=?
Hibernate: SELECT UTIL.LIMIT_ID, UTIL.LIMIT_TREE_TYPE_CODE, UTIL.LIMIT_CCY_CODE,
			UTIL.LIMIT_CCY_UTILISED_AMT,   SCBF_TLS_GET_ACTIVE_AMT(UTIL.Bank_Group_Code,
			UTIL.Cty_Code,UTIL.LIMIT_TREE_TYPE_CODE,UTIL.LIMIT_ID) - UTIL.LIMIT_CCY_UTILISED_AMT - UTIL.LIMIT_CCY_PEND_INC_AMT,
			SUM(SCBF_TLS_EXCH_RATE(?, ?, MV.TXN_CCY_CODE, MV.TXN_CCY_AMT,UTIL.LIMIT_CCY_CODE, 'Y'))AS APP_AMT,
			UTIL.LIMIT_CCY_PEND_INC_AMT, UTIL.LIMIT_CCY_PEND_DEC_AMT, MV.OBLIGOR_ID, mv.offering_flag, mv.offering_reason, mv.commodity_id
			FROM SCBT_T_COLL_LIMIT_MVMT MV, SCBT_T_COLL_LIMIT_UTIL UTIL
			WHERE
			MV.INIT_REQ_ID = ? AND
			UTIL.LIMIT_ID = MV.LIMIT_ID AND
			UTIL.LIMIT_TREE_TYPE_CODE = MV.LIMIT_TREE_TYPE_CODE
			AND MV.BANK_GROUP_CODE(+) = UTIL.BANK_GROUP_CODE
			AND MV.CTY_CODE(+) = UTIL.CTY_CODE
			AND MV.LIMIT_ID(+) = UTIL.LIMIT_ID
			GROUP BY UTIL.LIMIT_ID, UTIL.LIMIT_TREE_TYPE_CODE, UTIL.LIMIT_CCY_CODE, UTIL.LIMIT_CCY_UTILISED_AMT, 
			SCBF_TLS_GET_ACTIVE_AMT(UTIL.Bank_Group_Code,UTIL.Cty_Code,UTIL.LIMIT_TREE_TYPE_CODE,UTIL.LIMIT_ID) - UTIL.LIMIT_CCY_UTILISED_AMT - UTIL.LIMIT_CCY_PEND_INC_AMT,
			UTIL.LIMIT_CCY_PEND_INC_AMT, UTIL.LIMIT_CCY_PEND_DEC_AMT, MV.OBLIGOR_ID, UTIL.Bank_Group_Code, UTIL.Cty_Code, mv.offering_flag, mv.offering_reason, mv.commodity_id
			ORDER BY MV.OBLIGOR_ID
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> COLL_LIMIT_RET_CONFIRM_ACTION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 15110689
Result Size --> 2
Execution time (ms)  --> 578

INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Limit id --->2488
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_27_, scbcustlim0_.CTY_CODE as CTY2_27_, scbcustlim0_.APPR_COMMODITY_LIMIT_ID as APPR3_27_, scbcustlim0_.CUST_ID as CUST4_27_, scbcustlim0_.STEP_ID as STEP5_27_, scbcustlim0_.COMMODITY_CAT_ID as COMMODITY6_27_, scbcustlim0_.COMMODITY_ID as COMMODITY7_27_, scbcustlim0_.COMMODITY_TYPE_CODE as COMMODITY8_27_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT9_27_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT10_27_, scbcustlim0_.LIMIT_QTY as LIMIT11_27_, scbcustlim0_.LIMIT_QTY_UOM as LIMIT12_27_, scbcustlim0_.LOCATION_CTY_CODE as LOCATION13_27_, scbcustlim0_.SWF_MAX_ADV_RATE as SWF14_27_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD15_27_, scbcustlim0_.PROD_LIMIT_IDS as PROD16_27_ from SCBT_R_CUST_APPR_COM scbcustlim0_ where scbcustlim0_.APPR_COMMODITY_LIMIT_ID=? and scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=?
Hibernate: select scbcommodi0_.BANK_GROUP_CODE as BANK1_62_, scbcommodi0_.COMMODITY_ID as COMMODITY2_62_, scbcommodi0_.CTY_CODE as CTY3_62_, scbcommodi0_.EXCH_CODE as EXCH4_62_, scbcommodi0_.HUB_BU_CODE as HUB5_62_, scbcommodi0_.BU_CODE as BU6_62_, scbcommodi0_.COMMODITY_CODE as COMMODITY7_62_, scbcommodi0_.COMMODITY_CAT_CODE as COMMODITY8_62_, scbcommodi0_.COMMODITY_NAME as COMMODITY9_62_, scbcommodi0_.COMMODITY_OWNER as COMMODITY10_62_, scbcommodi0_.COMMODITY_TYPE_CODE as COMMODITY11_62_, scbcommodi0_.REMARKS as REMARKS62_, scbcommodi0_.STEP_ID as STEP13_62_ from SCBT_R_COMMODITY_MST scbcommodi0_ where scbcommodi0_.BANK_GROUP_CODE=? and scbcommodi0_.COMMODITY_ID=?
Hibernate: SELECT Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, '*','*', 'EN', 'CD066', COMMODITY_CODE, 1), Scbf_C_Get_Code_Desc(BANK_GROUP_CODE, ?,'*', 'EN', 'CD010', COMMODITY_CAT_CODE, 1) AS comm_cat_name
		 	FROM SCBT_R_COMMODITY_MST WHERE BANK_GROUP_CODE = ? AND COMMODITY_ID = ?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_COMMODITY_NAME
Param [0]--> SG
Param [1]--> SCB
Param [2]--> CM10000314
Result Size --> 1
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::resp DetailsVO--->null-------2488<-Err-->null---
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Limit id --->2486
Hibernate: select scbcustlim0_.BANK_GROUP_CODE as BANK1_33_, scbcustlim0_.CTY_CODE as CTY2_33_, scbcustlim0_.COLLATERAL_LIMIT_ID as COLLATERAL3_33_, scbcustlim0_.CUST_ID as CUST4_33_, scbcustlim0_.STEP_ID as STEP5_33_, scbcustlim0_.COLLATERAL_TYPE_CODE as COLLATERAL6_33_, scbcustlim0_.COLLATERAL_LIMIT_NAME as COLLATERAL7_33_, scbcustlim0_.SOLD_STATUS as SOLD8_33_, scbcustlim0_.PRODUCT_LIMIT_ID as PRODUCT9_33_, scbcustlim0_.INSURANCE_LIMIT_ID as INSURANCE10_33_, scbcustlim0_.LIMIT_TERMS as LIMIT11_33_, scbcustlim0_.PRICE_BASIS_ID as PRICE12_33_, scbcustlim0_.MAX_ADV_RATE as MAX13_33_, scbcustlim0_.CASH_MARGIN as CASH14_33_, scbcustlim0_.LIMIT_CCY_CODE as LIMIT15_33_, scbcustlim0_.LIMIT_CCY_ACTIVE_AMT as LIMIT16_33_, scbcustlim0_.FOLLOW_UP_DAYS as FOLLOW17_33_, scbcustlim0_.TENOR as TENOR33_, scbcustlim0_.SEQ_NO as SEQ19_33_, scbcustlim0_.RECORD_LOCK_FLAG as RECORD20_33_, scbcustlim0_.LIMIT_CAP_CCY_CODE as LIMIT21_33_, scbcustlim0_.LIMIT_CAP_CCY_ACTIVE_AMT as LIMIT22_33_ from SCBT_R_CUST_COLLAT_LIMIT scbcustlim0_ where scbcustlim0_.COLLATERAL_LIMIT_ID=? and scbcustlim0_.BANK_GROUP_CODE=? and scbcustlim0_.CTY_CODE=?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::resp DetailsVO--->null-------2486<-Err-->null---
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_, scbpartyma0_.CTY_CODE as CTY3_74_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_, scbpartyma0_.GAM_CODE as GAM9_74_, scbpartyma0_.BU_LIST as BU10_74_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_, scbpartyma0_.STEP_ID as STEP21_74_, scbpartyma0_.ADD_1 as ADD22_74_, scbpartyma0_.ADD_2 as ADD23_74_, scbpartyma0_.ADD_3 as ADD24_74_, scbpartyma0_.PARTY_NAME as PARTY25_74_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_, scbpartyma0_.OPEN_DATE as OPEN27_74_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_, scbpartyma0_.RM_CODE as RM29_74_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_, scbpartyma0_.SEG_CODE as SEG31_74_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_, scbpartyma0_.REMARKS as REMARKS74_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_, scbpartyma0_.FI_FLAG as FI41_74_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_, scbpartyma0_.TAX_NO as TAX48_74_, scbpartyma0_.LTV_FORMULA as LTV49_74_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_, scbpartyma0_.CTY_CODE as CTY3_74_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_, scbpartyma0_.GAM_CODE as GAM9_74_, scbpartyma0_.BU_LIST as BU10_74_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_, scbpartyma0_.STEP_ID as STEP21_74_, scbpartyma0_.ADD_1 as ADD22_74_, scbpartyma0_.ADD_2 as ADD23_74_, scbpartyma0_.ADD_3 as ADD24_74_, scbpartyma0_.PARTY_NAME as PARTY25_74_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_, scbpartyma0_.OPEN_DATE as OPEN27_74_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_, scbpartyma0_.RM_CODE as RM29_74_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_, scbpartyma0_.SEG_CODE as SEG31_74_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_, scbpartyma0_.REMARKS as REMARKS74_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_, scbpartyma0_.FI_FLAG as FI41_74_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_, scbpartyma0_.TAX_NO as TAX48_74_, scbpartyma0_.LTV_FORMULA as LTV49_74_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::limit id-->2488<-->null<-->USD<-->0.0<-->9.99999999999E11<-->null<-->SUCC
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::limit id-->2486<-->null<-->USD<-->0.0<-->9.99999999999E11<-->null<-->SUCC
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside Limits util DM >> inside retrieveCurrentLimitsDtls >> START 
Hibernate: SELECT FG.FACILITY_GRP_ID 
			FROM SCBT_T_TXN_HST TH,
				SCBT_R_CUST_FACILITY_GRP FG 
			WHERE 
				TH.BANK_GROUP_CODE = FG.BANK_GROUP_CODE AND TH.CTY_CODE = FG.CTY_CODE AND TH.CUST_ID = FG.CUST_ID 
				AND REGEXP_SUBSTR (','||FG.PROD_LIMIT_IDS||',', ','||TH.PROD_LIMIT_ID||',' , 1, 1) = ','||TH.PROD_LIMIT_ID||','
				AND TH.BANK_GROUP_CODE = ? AND TH.CTY_CODE = ? AND TH.CUST_ID=? AND FG.GROUP_TYPE = 'CAO' 
				AND TH.DEAL_STEP_ID = ?
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_GROUP_ID_FOR_CMR
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: SELECT DISTINCT CASH_HELD_FLAG 
			FROM SCBT_T_GRP_CAO_OFFSET_MST 
			WHERE BANK_GROUP_CODE = ?
				AND CTY_CODE = ? 
				AND CUST_ID = ? 
				AND GROUP_ID in (?) 
				AND DEAL_STEP_ID = ?
				AND PAGE_SOURCE='DDB'
				AND CASH_HELD_FLAG='N'
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_CASH_HELD_FLAG
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> [CLIENT]
Param [4]--> SG957T09056M0002
Result Size --> 1
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::The Customer Margin is not met
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Cash Margin --> N
INFO  - Mon Apr 01 17:43:58 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside Limits util DM >> inside retrieveCurrentLimitsDtls >> START 
Hibernate: select scbcodedat0_.BANK_GROUP_CODE as BANK1_84_0_, scbcodedat0_.CODE_ID as CODE3_84_0_, scbcodedat0_.CODE_VALUE as CODE2_84_0_, scbcodedat0_.CTY_CODE as CTY6_84_0_, scbcodedat0_.LANG_CODE as LANG4_84_0_, scbcodedat0_.TBU_CODE as TBU5_84_0_, scbcodedat0_.PARENT_CODE_VALUE as PARENT10_84_0_, scbcodedat0_.STEP_ID as STEP9_84_0_, scbcodedat0_.DESC_1 as DESC8_84_0_, scbcodedat0_.DESC_2 as DESC7_84_0_, scbcodedat0_.RECORD_LOCK_FLAG as RECORD11_84_0_ from SCBT_R_CODE_DATA scbcodedat0_ where scbcodedat0_.BANK_GROUP_CODE=? and scbcodedat0_.CODE_ID=? and scbcodedat0_.CODE_VALUE=? and scbcodedat0_.CTY_CODE=? and scbcodedat0_.LANG_CODE=? and scbcodedat0_.TBU_CODE=?
Hibernate: select scblimitsr0_.REC_ID as REC1_95_, scblimitsr0_.BANK_GROUP_CODE as BANK2_95_, scblimitsr0_.COND_REMARKS_FLAG as COND3_95_, scblimitsr0_.OVERALL_STATUS_CODE as OVERALL4_95_, scblimitsr0_.REQ_TYPE_CODE as REQ5_95_, scblimitsr0_.BUSINESS_EVENT_ID as BUSINESS6_95_, scblimitsr0_.CTY_CODE as CTY7_95_, scblimitsr0_.LIMIT_SETUP_FLAG as LIMIT8_95_, scblimitsr0_.TXN_TIMESTAMP as TXN9_95_ from SCBT_T_LIMIT_RESP_HEADER scblimitsr0_ where scblimitsr0_.BANK_GROUP_CODE=? and scblimitsr0_.CTY_CODE=? and scblimitsr0_.BUSINESS_EVENT_ID=?

Hibernate: insert into SCBT_T_LIMIT_RESP_HEADER (BANK_GROUP_CODE, COND_REMARKS_FLAG, OVERALL_STATUS_CODE, REQ_TYPE_CODE, BUSINESS_EVENT_ID, CTY_CODE, LIMIT_SETUP_FLAG, TXN_TIMESTAMP, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_LIMIT_RESP_DTLS (BANK_GROUP_CODE, OBLIGOR_ID, COLLATERAL_TYPE_CODE, RESP_STATUS_CODE, COMMODITY_CAT_ID, CTY_CODE, ERROR_CODE, LIMIT_TREE_TYPE_CODE, LIMIT_ID, LIMIT_NAME, COMMODITY_TYPE_CODE, LIMIT_CCY_APPLN_AMT, LIMIT_CCY_MAX_TXN_AMT_CCY, LIMIT_CCY_ACC_BAL_AMT, LIMIT_CCY_MAX_TXN_AMT, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_AVAILABLE_AMT, LIMIT_CCY_CODE, LIMIT_CCY_EXCESS_AMT, LIMIT_CCY_UTILISED_AMT, COMMODITY_ID, LIMIT_CAT_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_EXPIRY_DATE, LIMIT_PRODUCT_CODE, REMARKS, HEADER_ID, SYNDICATION_TYPE_CODE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_LIMIT_RESP_DTLS (BANK_GROUP_CODE, OBLIGOR_ID, COLLATERAL_TYPE_CODE, RESP_STATUS_CODE, COMMODITY_CAT_ID, CTY_CODE, ERROR_CODE, LIMIT_TREE_TYPE_CODE, LIMIT_ID, LIMIT_NAME, COMMODITY_TYPE_CODE, LIMIT_CCY_APPLN_AMT, LIMIT_CCY_MAX_TXN_AMT_CCY, LIMIT_CCY_ACC_BAL_AMT, LIMIT_CCY_MAX_TXN_AMT, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_AVAILABLE_AMT, LIMIT_CCY_CODE, LIMIT_CCY_EXCESS_AMT, LIMIT_CCY_UTILISED_AMT, COMMODITY_ID, LIMIT_CAT_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_EXPIRY_DATE, LIMIT_PRODUCT_CODE, REMARKS, HEADER_ID, SYNDICATION_TYPE_CODE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

Hibernate: insert into SCBT_T_LIMIT_RESP_DTLS (BANK_GROUP_CODE, OBLIGOR_ID, COLLATERAL_TYPE_CODE, RESP_STATUS_CODE, COMMODITY_CAT_ID, CTY_CODE, ERROR_CODE, LIMIT_TREE_TYPE_CODE, LIMIT_ID, LIMIT_NAME, COMMODITY_TYPE_CODE, LIMIT_CCY_APPLN_AMT, LIMIT_CCY_MAX_TXN_AMT_CCY, LIMIT_CCY_ACC_BAL_AMT, LIMIT_CCY_MAX_TXN_AMT, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_AVAILABLE_AMT, LIMIT_CCY_CODE, LIMIT_CCY_EXCESS_AMT, LIMIT_CCY_UTILISED_AMT, COMMODITY_ID, LIMIT_CAT_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_EXPIRY_DATE, LIMIT_PRODUCT_CODE, REMARKS, HEADER_ID, SYNDICATION_TYPE_CODE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_LIMIT_RESP_DTLS (BANK_GROUP_CODE, OBLIGOR_ID, COLLATERAL_TYPE_CODE, RESP_STATUS_CODE, COMMODITY_CAT_ID, CTY_CODE, ERROR_CODE, LIMIT_TREE_TYPE_CODE, LIMIT_ID, LIMIT_NAME, COMMODITY_TYPE_CODE, LIMIT_CCY_APPLN_AMT, LIMIT_CCY_MAX_TXN_AMT_CCY, LIMIT_CCY_ACC_BAL_AMT, LIMIT_CCY_MAX_TXN_AMT, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_AVAILABLE_AMT, LIMIT_CCY_CODE, LIMIT_CCY_EXCESS_AMT, LIMIT_CCY_UTILISED_AMT, COMMODITY_ID, LIMIT_CAT_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_EXPIRY_DATE, LIMIT_PRODUCT_CODE, REMARKS, HEADER_ID, SYNDICATION_TYPE_CODE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: insert into SCBT_T_LIMIT_RESP_DTLS (BANK_GROUP_CODE, OBLIGOR_ID, COLLATERAL_TYPE_CODE, RESP_STATUS_CODE, COMMODITY_CAT_ID, CTY_CODE, ERROR_CODE, LIMIT_TREE_TYPE_CODE, LIMIT_ID, LIMIT_NAME, COMMODITY_TYPE_CODE, LIMIT_CCY_APPLN_AMT, LIMIT_CCY_MAX_TXN_AMT_CCY, LIMIT_CCY_ACC_BAL_AMT, LIMIT_CCY_MAX_TXN_AMT, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_AVAILABLE_AMT, LIMIT_CCY_CODE, LIMIT_CCY_EXCESS_AMT, LIMIT_CCY_UTILISED_AMT, COMMODITY_ID, LIMIT_CAT_CODE, LIMIT_CCY_PEND_INC_AMT, LIMIT_CCY_PEND_DEC_AMT, LIMIT_EXPIRY_DATE, LIMIT_PRODUCT_CODE, REMARKS, HEADER_ID, SYNDICATION_TYPE_CODE, REC_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
INFO  - Mon Apr 01 17:45:15 SGT 2013 com.scb.tf.bfc.cocoa.limits.dm.SCBProdLimitsUtilDataManager::Inside Limits util DM >> inside retrieveCurrentLimitsDtls >> END 
INFO  - Mon Apr 01 17:45:15 SGT 2013 com.scb.tf.bfc.cocoa.limits.session.SCBCollLimitsServiceSession::Inside Limits Service Session >>> retrieveCurrentlimitDtls >>> END 
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: select scbsoftloc0_.LOCK_KEY as LOCK1_146_, scbsoftloc0_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc0_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc0_.SESSION_ID as SESSION4_146_, scbsoftloc0_.USER_ID as USER5_146_, scbsoftloc0_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc0_.CTY_CODE as CTY7_146_, scbsoftloc0_.TBU_CODE as TBU8_146_, scbsoftloc0_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc0_ where scbsoftloc0_.LOCK_KEY=?
Hibernate: select scbsoftloc_.LOCK_KEY, scbsoftloc_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc_.SESSION_ID as SESSION4_146_, scbsoftloc_.USER_ID as USER5_146_, scbsoftloc_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc_.CTY_CODE as CTY7_146_, scbsoftloc_.TBU_CODE as TBU8_146_, scbsoftloc_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc_ where scbsoftloc_.LOCK_KEY=?
Hibernate: insert into SCBT_T_SOFT_LOCK (COMPONENT_ID, LOCK_TIMESTAMP, SESSION_ID, USER_ID, BANK_GROUP_CODE, CTY_CODE, TBU_CODE, HOST_NAME, LOCK_KEY) values (?, ?, ?, ?, ?, ?, ?, ?, ?)
Hibernate: select scbsoftloc0_.LOCK_KEY as LOCK1_146_, scbsoftloc0_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc0_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc0_.SESSION_ID as SESSION4_146_, scbsoftloc0_.USER_ID as USER5_146_, scbsoftloc0_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc0_.CTY_CODE as CTY7_146_, scbsoftloc0_.TBU_CODE as TBU8_146_, scbsoftloc0_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc0_ where scbsoftloc0_.LOCK_KEY=?
Hibernate: select scbsoftloc_.LOCK_KEY, scbsoftloc_.COMPONENT_ID as COMPONENT2_146_, scbsoftloc_.LOCK_TIMESTAMP as LOCK3_146_, scbsoftloc_.SESSION_ID as SESSION4_146_, scbsoftloc_.USER_ID as USER5_146_, scbsoftloc_.BANK_GROUP_CODE as BANK6_146_, scbsoftloc_.CTY_CODE as CTY7_146_, scbsoftloc_.TBU_CODE as TBU8_146_, scbsoftloc_.HOST_NAME as HOST9_146_ from SCBT_T_SOFT_LOCK scbsoftloc_ where scbsoftloc_.LOCK_KEY=?
Hibernate: insert into SCBT_T_SOFT_LOCK (COMPONENT_ID, LOCK_TIMESTAMP, SESSION_ID, USER_ID, BANK_GROUP_CODE, CTY_CODE, TBU_CODE, HOST_NAME, LOCK_KEY) values (?, ?, ?, ?, ?, ?, ?, ?, ?)


Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
Hibernate: SELECT DISTINCT T.ACCOUNT_NUMBER,T.ACCOUNT_CCY,T.DIFFERENCE FROM SCBT_T_CUST_RECONCIL_SMRY_MST T, SCBT_R_CUST_ACCT_MAINTENANCE W 
            WHERE 
            T.BANK_GROUP_CODE= ? AND T.CTY_CODE = ? AND T.CUSTOMER_ID = ?
			AND T.ACCOUNT_NUMBER = W.ACC_NO
			AND T.CUSTOMER_ID  = W.CUST_ID
			AND T.ACCOUNT_CCY = W.ACC_CCY_CODE
			AND T.BANK_GROUP_CODE = W.BANK_GROUP_CODE
			AND T.CTY_CODE = W.CTY_CODE
			AND W.INCLUDE_FOR_CASH_COLLATERAL='Y'
			AND NVL(T.RECONSILE_FLAG,'N')<>'Y' AND NVL(T.PASS_ADJ_FLAG,'N') <> 'Y'AND NVL(T.DIFFERENCE,0) <> 0
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> RECONCILE_EXCEPTION_LIST
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 0

Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PRODUCT_TYPE in (? , ?))
Hibernate: select scbproduct0_.PRODUCT_CODE as col_0_0_, scbproduct0_.PRODUCT_DESC as col_1_0_ from SCBT_R_PRODUCT_MST scbproduct0_ where scbproduct0_.BANK_GROUP_CODE=? and (scbproduct0_.PROD_REF_CODE in (?))
Hibernate: select code_value_1 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_LIST
Param [0]--> SCB
Param [1]--> TXN_SUP_PROD
Result Size --> 22
Execution time (ms)  --> 16

Hibernate: select code_value_1, code_value_2 from scbt_r_map_info where bank_group_code = ? and map_id = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_MAP_INFO_VALUE_DTLS
Param [0]--> SCB
Param [1]--> TXNISSUVAL
Result Size --> 36
Execution time (ms)  --> 0

Hibernate: SELECT SC.SALES_REG_ID,SC.SALES_REG_ID AS ELC_ID,SC.MAX_CONTRACT_QNTY_UOM AS QNTY_UOM,
	   		(NVL(SC.MAX_CONTRACT_QNTY,0)-NVL(SC.TOTAL_ELC_QNTY,0)-NVL(SC.CONTRACT_UTIL_QNTY,0)) AS OS_QNTY,
	  		 SC.CV_CCY_CODE,(NVL(SC.CV_CCY_AMT,0)-NVL(SC.TOTAL_ELCV_CCY_AMT,0)-NVL(SC.CV_UTIL_CCY_AMT,0)) AS OS_AMT,
	  		 (CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC
		WHERE  SC.BANK_GROUP_CODE = ? AND SC.CTY_CODE = ? AND SC.CUST_ID = ?
		UNION ALL
		SELECT SC.SALES_REG_ID, EC.ELC_REC_ID AS ELC_ID, EC.MAX_ELC_QNTY_UOM AS QNTY_UOM,
			   (NVL(EC.MAX_ELC_QNTY,0)-NVL(EC.ELC_UTIL_QNTY,0)) AS OS_QNTY,EC.ELCV_CCY_CODE,
		       (NVL(EC.ELCV_CCY_AMT,0)-NVL(EC.ELCV_UTIL_CCY_AMT,0)) AS OS_AMT,
		 	(CASE WHEN (SELECT COUNT(1) FROM SCBT_T_SALES_CONTRACT_HST SH WHERE 
          		SC.BANK_GROUP_CODE = SH.BANK_GROUP_CODE AND SC.CTY_CODE = SH.CTY_CODE AND SC.SALES_REG_ID = SH.SALES_REG_ID AND SC.CUST_ID = SH.CUST_ID AND  
        		SH.BANK_GROUP_CODE =  ? AND SH.CTY_CODE = ? AND SH.CUST_ID = ? AND step_status_code <> '03')>0 
			THEN 'Pending' ELSE 'Approved' END ) AS STATUS
		FROM SCBT_T_SALES_CONTRACT_MST SC,SCBT_T_EXPORT_LC_MST EC
		WHERE SC.BANK_GROUP_CODE = EC.BANK_GROUP_CODE AND SC.CTY_CODE = EC.CTY_CODE AND SC.SALES_REG_ID = EC.SALES_REG_ID 
		AND EC.BANK_GROUP_CODE =  ? AND EC.CTY_CODE = ? AND SC.CUST_ID = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> EXPORT_REGISTER_OS_AMT_QNTY_DTLS
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SCB
Param [4]--> SG
Param [5]--> 800002463
Param [6]--> SCB
Param [7]--> SG
Param [8]--> 800002463
Param [9]--> SCB
Param [10]--> SG
Param [11]--> 800002463
Result Size --> 65
Execution time (ms)  --> 32

Hibernate: SELECT FG.FACILITY_GRP_ID 
			FROM SCBT_T_TXN_HST TH,
				SCBT_R_CUST_FACILITY_GRP FG 
			WHERE 
				TH.BANK_GROUP_CODE = FG.BANK_GROUP_CODE AND TH.CTY_CODE = FG.CTY_CODE AND TH.CUST_ID = FG.CUST_ID 
				AND REGEXP_SUBSTR (','||FG.PROD_LIMIT_IDS||',', ','||TH.PROD_LIMIT_ID||',' , 1, 1) = ','||TH.PROD_LIMIT_ID||','
				AND TH.BANK_GROUP_CODE = ? AND TH.CTY_CODE = ? AND TH.CUST_ID=? AND FG.GROUP_TYPE = 'CAO' 
				AND TH.DEAL_STEP_ID = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_GROUP_ID_FOR_CMR
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> SG957T09056M0002
Result Size --> 0
Execution time (ms)  --> 15

Hibernate: SELECT DISTINCT CASH_HELD_FLAG 
			FROM SCBT_T_GRP_CAO_OFFSET_MST 
			WHERE BANK_GROUP_CODE = ?
				AND CTY_CODE = ? 
				AND CUST_ID = ? 
				AND GROUP_ID in (?) 
				AND DEAL_STEP_ID = ?
				AND PAGE_SOURCE='DDB'
				AND CASH_HELD_FLAG='N'
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_CASH_HELD_FLAG
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> [CLIENT]
Param [4]--> SG957T09056M0002
Result Size --> 1
Execution time (ms)  --> 0

Hibernate: select scbcachedn0_.TBU_CODE as TBU1_145_0_, scbcachedn0_.LANG_CODE as LANG2_145_0_, scbcachedn0_.ERROR_CODE as ERROR3_145_0_, scbcachedn0_.BANK_GROUP_CODE as BANK4_145_0_, scbcachedn0_.ERROR_MSG as ERROR5_145_0_ from SCBT_S_ERROR_MSG scbcachedn0_ where scbcachedn0_.TBU_CODE=? and scbcachedn0_.LANG_CODE=? and scbcachedn0_.ERROR_CODE=? and scbcachedn0_.BANK_GROUP_CODE=?
Hibernate: SELECT TOTAL_SHORTFALL_AMT FROM SCBT_T_CUST_SHORTFALL_SMRY_HST WHERE BANK_GROUP_CODE = ? AND CTY_CODE = ? AND CUST_ID = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> SHORT_FALL_CALCULATION
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Result Size --> 0
Execution time (ms)  --> 16

Hibernate: SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> GET_PRODUCT_LIMIT_NAME
Param [0]--> SCB
Param [1]--> SG
Param [2]--> 800002463
Param [3]--> 20393575
Param [4]--> LCORS
Result Size --> 1
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Notifyops row
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::txnRemarksIF.getLimitOverAllStatus().getValue()FAIL
INFO  - Mon Apr 01 17:45:33 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Exception row
Hibernate: select scbpartyma0_.PARTY_ID as PARTY1_74_0_, scbpartyma0_.BANK_GROUP_CODE as BANK2_74_0_, scbpartyma0_.CTY_CODE as CTY3_74_0_, scbpartyma0_.LIMIT_SETUP_APPLN_REF as LIMIT4_74_0_, scbpartyma0_.CURRENT_SCB_CG as CURRENT5_74_0_, scbpartyma0_.NEXT_REVIEW_DATE as NEXT6_74_0_, scbpartyma0_.NEXT_INTERIM_REVIEW_DATE as NEXT7_74_0_, scbpartyma0_.NEXT_EXT_REVIEW_DATE as NEXT8_74_0_, scbpartyma0_.GAM_CODE as GAM9_74_0_, scbpartyma0_.BU_LIST as BU10_74_0_, scbpartyma0_.CUST_FACILITY_TYPE_CODE as CUST11_74_0_, scbpartyma0_.INSURANCE_COVERED_BY as INSURANCE12_74_0_, scbpartyma0_.SUSPEND_FLAG as SUSPEND13_74_0_, scbpartyma0_.SUSPEND_REASON as SUSPEND14_74_0_, scbpartyma0_.OVERALL_EXP_CURRENCY as OVERALL15_74_0_, scbpartyma0_.CMT_MGR_PWID as CMT16_74_0_, scbpartyma0_.BACKUP_CMT_MGR_PWID as BACKUP17_74_0_, scbpartyma0_.SIP_MGR_PWID as SIP18_74_0_, scbpartyma0_.BUSINESS_DIVISION as BUSINESS19_74_0_, scbpartyma0_.BACKUP_SIP_MGR_PWID as BACKUP20_74_0_, scbpartyma0_.STEP_ID as STEP21_74_0_, scbpartyma0_.ADD_1 as ADD22_74_0_, scbpartyma0_.ADD_2 as ADD23_74_0_, scbpartyma0_.ADD_3 as ADD24_74_0_, scbpartyma0_.PARTY_NAME as PARTY25_74_0_, scbpartyma0_.PARTY_NAME_UPP as PARTY26_74_0_, scbpartyma0_.OPEN_DATE as OPEN27_74_0_, scbpartyma0_.RESIDENCE_CTY_CODE as RESIDENCE28_74_0_, scbpartyma0_.RM_CODE as RM29_74_0_, scbpartyma0_.SPECIAL_REMARKS as SPECIAL30_74_0_, scbpartyma0_.SEG_CODE as SEG31_74_0_, scbpartyma0_.SUB_SEG_CODE as SUB32_74_0_, scbpartyma0_.ADD_CTY_CODE as ADD33_74_0_, scbpartyma0_.BLACKLISTED_FLAG as BLACKLI34_74_0_, scbpartyma0_.CUST_SLA_CLASS as CUST35_74_0_, scbpartyma0_.DUPLICATE_PARTY_FLAG as DUPLICATE36_74_0_, scbpartyma0_.REMARKS as REMARKS74_0_, scbpartyma0_.BLACKLIST_REASON as BLACKLIST38_74_0_, scbpartyma0_.INDUSTRY_CODE as INDUSTRY39_74_0_, scbpartyma0_.CUSTODIAN as CUSTODIAN74_0_, scbpartyma0_.FI_FLAG as FI41_74_0_, scbpartyma0_.STOP_LOSS_PCT as STOP42_74_0_, scbpartyma0_.STOP_LOSS_CCY_CODE as STOP43_74_0_, scbpartyma0_.STOP_LOSS_CCY_AMT as STOP44_74_0_, scbpartyma0_.LOAN_TO_VALUE_PCT as LOAN45_74_0_, scbpartyma0_.SIP_CMT_MGR_PWID as SIP46_74_0_, scbpartyma0_.BACKUP_SIP_CMT_MGR_PWID as BACKUP47_74_0_, scbpartyma0_.TAX_NO as TAX48_74_0_, scbpartyma0_.LTV_FORMULA as LTV49_74_0_, scbpartyma0_.RECORD_LOCK_FLAG as RECORD50_74_0_ from SCBT_R_PARTY_MST scbpartyma0_ where scbpartyma0_.PARTY_ID=? and scbpartyma0_.BANK_GROUP_CODE=? and scbpartyma0_.CTY_CODE=?
Hibernate: select scbrmmaste0_.BANK_GROUP_CODE as BANK1_97_, scbrmmaste0_.RM_CODE as RM2_97_, scbrmmaste0_.CTY_CODE as CTY3_97_, scbrmmaste0_.EMAIL_CC_LIST as EMAIL4_97_, scbrmmaste0_.PEOPLEWISE_ID as PEOPLEWISE5_97_, scbrmmaste0_.PEOPLEWISE_NAME as PEOPLEWISE6_97_, scbrmmaste0_.RM_NAME as RM7_97_, scbrmmaste0_.TO_EMAIL_ID as TO8_97_, scbrmmaste0_.STEP_ID as STEP9_97_, scbrmmaste0_.RECORD_LOCK_FLAG as RECORD10_97_ from SCBT_R_RM_MST scbrmmaste0_ where scbrmmaste0_.RM_CODE=? and scbrmmaste0_.BANK_GROUP_CODE=? and scbrmmaste0_.CTY_CODE=?
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::RM exists.Collecting to =>Rahul.Indoria@sc.com and cc ==>null
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Notifyops row
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::txnRemarksIF.getLimitOverAllStatus().getValue()FAIL
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.server.cocoa.bfc.remarks.service.SCBRemarkServiceSession::Adding Exception row
Hibernate: select scbparamda0_.BANK_GROUP_CODE as BANK1_86_0_, scbparamda0_.PARAM_ID as PARAM2_86_0_, scbparamda0_.PARAM_KEY_01 as PARAM3_86_0_, scbparamda0_.PARAM_KEY_02 as PARAM4_86_0_, scbparamda0_.PARAM_KEY_03 as PARAM5_86_0_, scbparamda0_.PARAM_KEY_04 as PARAM6_86_0_, scbparamda0_.PARAM_KEY_05 as PARAM7_86_0_, scbparamda0_.PARAM_KEY_06 as PARAM8_86_0_, scbparamda0_.PARAM_KEY_07 as PARAM9_86_0_, scbparamda0_.PARAM_KEY_08 as PARAM10_86_0_, scbparamda0_.PARAM_KEY_09 as PARAM11_86_0_, scbparamda0_.PARAM_KEY_10 as PARAM12_86_0_, scbparamda0_.CTY_CODE as CTY13_86_0_, scbparamda0_.PARTY_ID as PARTY14_86_0_, scbparamda0_.TBU_CODE as TBU15_86_0_, scbparamda0_.STEP_ID as STEP16_86_0_, scbparamda0_.PARAM_DATA_01 as PARAM17_86_0_, scbparamda0_.PARAM_DATA_02 as PARAM18_86_0_, scbparamda0_.PARAM_DATA_03 as PARAM19_86_0_, scbparamda0_.PARAM_DATA_04 as PARAM20_86_0_, scbparamda0_.PARAM_DATA_05 as PARAM21_86_0_, scbparamda0_.PARAM_DATA_06 as PARAM22_86_0_, scbparamda0_.PARAM_DATA_07 as PARAM23_86_0_, scbparamda0_.PARAM_DATA_08 as PARAM24_86_0_, scbparamda0_.PARAM_DATA_09 as PARAM25_86_0_, scbparamda0_.PARAM_DATA_10 as PARAM26_86_0_, scbparamda0_.PARAM_DATA_11 as PARAM27_86_0_, scbparamda0_.PARAM_DATA_12 as PARAM28_86_0_, scbparamda0_.PARAM_DATA_13 as PARAM29_86_0_, scbparamda0_.PARAM_DATA_14 as PARAM30_86_0_, scbparamda0_.PARAM_DATA_15 as PARAM31_86_0_, scbparamda0_.PARAM_DATA_16 as PARAM32_86_0_, scbparamda0_.PARAM_DATA_17 as PARAM33_86_0_, scbparamda0_.PARAM_DATA_18 as PARAM34_86_0_, scbparamda0_.PARAM_DATA_19 as PARAM35_86_0_, scbparamda0_.PARAM_DATA_20 as PARAM36_86_0_, scbparamda0_.PARAM_KEY_SEQ_CODE as PARAM37_86_0_, scbparamda0_.RECORD_LOCK_FLAG as RECORD38_86_0_ from SCBT_R_PARAM_DATA scbparamda0_ where scbparamda0_.BANK_GROUP_CODE=? and scbparamda0_.PARAM_ID=? and scbparamda0_.PARAM_KEY_01=? and scbparamda0_.PARAM_KEY_02=? and scbparamda0_.PARAM_KEY_03=? and scbparamda0_.PARAM_KEY_04=? and scbparamda0_.PARAM_KEY_05=? and scbparamda0_.PARAM_KEY_06=? and scbparamda0_.PARAM_KEY_07=? and scbparamda0_.PARAM_KEY_08=? and scbparamda0_.PARAM_KEY_09=? and scbparamda0_.PARAM_KEY_10=? and scbparamda0_.CTY_CODE=? and scbparamda0_.PARTY_ID=? and scbparamda0_.TBU_CODE=?
ERROR - Mon Apr 01 17:45:34 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest = 5204,1586,1586,5205,
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.tf.prod.core.process.SCBGenericModuleServiceRequestProcessor::postProcessRequest request Type = 11 for sessionID = tf.component.fmc.txn.module.40
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-343*SCB*1433068*SG957*20130401174534*20130401174357*20130401174357*20130401174534*OF*SG957T09056*GZ9WVPCPP7-304*TFTIP01*null
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-342*1*20130401174357*FPSRequest--1*tf.component.fmc.txn.module*20130401150726798
Appserver proc end: 1364809534063
Appserver proc total: 96969
Appserver proc start: 1364809534360
Hibernate: select * from ( select PARTY_ID,PARTY_NAME  from
			SCBT_R_PARTY_MST where CTY_CODE = '*' 
			and party_id like ? and upper(party_name) like upper(?)  and BANK_GROUP_CODE=?
			and nvl(Upper(custodian),'N') Like Upper('N') ) where rownum <= ?
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.server.dm.dao.SCBBaseGenericSQLDAOImpl::Template Name --> CTL_CUST_NON_CUST_ID_LIST
First Result --> 0
Max Result --> 50
Param [0]--> %800000092%
Param [1]--> %
Param [2]--> SCB
Result Size --> 1
Execution time (ms)  --> 0

INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-344*null*1433068*null*20130401174534*20130401174534*20130401174534*20130401174534*null*null*null*TFTIP01*null
INFO  - Mon Apr 01 17:45:34 SGT 2013 com.scb.logger.server.dbappender.SCBActivityParentLogger::GZ9WVPCPP7-343*11*20130401174534*FPSRequest--11*tf.component.fmc.txn.module*20130401150726798
Appserver proc end: 1364809534423
Appserver proc total: 63



