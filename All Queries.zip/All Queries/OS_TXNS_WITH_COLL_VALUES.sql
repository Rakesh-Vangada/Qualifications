SELECT MST.TXN_REC_ID,MST.DEAL_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        txn_step_code,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT
                  FROM SCBT_T_TXN_MST MST
                 WHERE MST.BANK_GROUP_CODE = 'SCB'
                       AND MST.CTY_CODE ='SG'
                       AND MST.cust_id = '800002542'
                       AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                       --AND MST.prod_limit_id = limitID
                       AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11','08') 
                       AND (ABS(TXN_CCY_NET_AMT)-NVL(TXN_CCY_UTIL_AMT,0)) > 0 
                    
                    UNION ALL  
                    
                    SELECT MST.TXN_REC_ID,MST.DEAL_ID,
                       MST.TXN_CCY_CODE AS TXN_CCY,
                       (NVL(DECODE(MST.SCB_ROLE,'AG',MST.SYNDICATED_TXN_AMT-NVL(MST.SYNDICATED_UTIL_AMT,0),MST.TXN_CCY_NET_AMT-NVL(MST.TXN_CCY_UTIL_AMT,0)),0)) AS OUTSTANDING,
                       --CR.TOTAL_CMV_CCY_AMT,CR.TOTAL_GCV_CCY_AMT,CR.TOTAL_NCV_CCY_AMT,
                       --MST.CASH_MARGIN_CCY_CODE AS CM_CCY,
                       (CASE WHEN NVL(MST.CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
                       ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) - NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0))
                       ELSE ((NVL(MST.CASH_MARGIN_ORIGN_AMT,0) + NVL(MST.CASH_MARGIN_ADJ_AMT,0)) - NVL(MST.CM_CCY_RELEASE_AMT,0)) END) AS CASH_MARGIN,
                       '03' AS STEP_STATUS_CODE,
                        'M' AS SOURCE,
                        MST.SHORTFALL_OFFSET_TYPE,
                        '' AS DEAL_STEP_ID,
                        MST.txn_step_code,
                         MST.CASH_MARGIN_ADJ_AMT AS CM_ADJ_AMT,
                         MST.CASH_MARGIN_ADJ AS CM_ADJ_AMT_FACTOR,
                         MST.CASH_MARGIN_ORIGN_AMT  AS CM_ORIGIN_AMT
                  FROM SCBT_T_TXN_MST MST,SCBT_T_TXN_CR_LINKAGE_MST TCL,SCBT_T_COLLATERAL_REGISTER_MST CR
                   WHERE MST.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND MST.CTY_CODE=TCL.CTY_CODE
                        AND CR.BANK_GROUP_CODE=TCL.BANK_GROUP_CODE
                        AND CR.CTY_CODE=TCL.CTY_CODE
                        AND MST.CUST_ID=TCL.CUST_ID
                        AND MST.DEAL_ID=TCL.DEAL_ID
                        AND CR.CUST_ID=TCL.CUST_ID
                        AND CR.DEAL_ID=TCL.DEAL_ID
                        AND MST.TXN_REC_ID=TCL.TXN_REC_ID
                        AND MST.TXN_REF_ID=TCL.TXN_REF_ID
                        AND TCL.COLLATERAL_ID=CR.COLLATERAL_ID
                        AND MST.BANK_GROUP_CODE = 'SCB'
                        AND MST.CTY_CODE ='SG'
                        AND MST.cust_id = '800002542'
                        AND NVL(MST.SHORTFALL_OFFSET_TYPE,' ') <> 'CL'
                        --AND MST.prod_limit_id = limitID
                        AND NVL(LIMIT_TRANSFER,'N') <> 'Y' 
                        AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11','08') 
                                            AND (TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) = 0 
                        AND (CR.TOTAL_CMV_CCY_AMT > 0 OR CR.TOTAL_GCV_CCY_AMT > 0 OR CR.TOTAL_NCV_CCY_AMT > 0)
                     
                     
