--CASH_BALANCE_CCY_AMT
   
       SELECT * --SUM(A.ACC_CCY_ANTICIPATED_AMT), A.ACC_CCY_CODE 
          FROM SCBT_T_CUST_ACC_SMRY_MST A,
               SCBT_R_CUST_ACCT_MAINTENANCE M
         WHERE A.BANK_GROUP_CODE = 'SCB'
           AND A.CTY_CODE        = 'HK'
           AND A.CUST_ID         = '800009800'
           AND M.BANK_GROUP_CODE = A.BANK_GROUP_CODE
           AND M.CTY_CODE        = A.CTY_CODE
           AND M.CUST_ID         = A.CUST_ID
           AND M.ACC_NO          = A.ACC_NO
           AND M.ACC_CCY_CODE    = A.ACC_CCY_ANTICIPATED_CCY
           AND nvl(M.ACCOUNT_LINKED, 'N')  = 'N'
           AND M.INCLUDE_FOR_CASH_COLLATERAL = 'Y'
               AND A.ACC_CCY_ANTICIPATED_AMT > 0
               
           GROUP BY A.ACC_CCY_CODE HAVING SUM(A.ACC_CCY_ANTICIPATED_AMT) > 0;   



CMR Caluculation for cash margin infor tab for Client

          SELECT CASH_MARGIN_CCY_CODE,sum(CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) AS AMT
                      FROM SCBT_T_TXN_MST TM
           WHERE TM.BANK_GROUP_CODE = 'SCB'
           AND TM.CTY_CODE = 'HK'
           --AND TM.PROD_LIMIT_ID = limitID
           AND TM.CUST_ID = '800009800'
           AND NVL(LIMIT_TRANSFER,'N') <> 'Y' AND NVL(TXN_STATUS_CODE,'01') NOT IN ('05','11') -- Start COCOAPERF_18122012
                                AND ((TXN_CCY_NET_AMT-NVL(TXN_CCY_UTIL_AMT,0)) > 0 
            OR (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END) > 0) -- End COCOAPERF_18122012
           AND NOT EXISTS  ( SELECT TXN_REC_ID
                             FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
                             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                             AND TH.CUST_ID = DH.CUST_ID
                             AND TH.DEAL_ID = DH.DEAL_ID
                             AND TH.CTY_CODE = DH.CTY_CODE
                             AND TH.DEAL_STEP_ID = DH.DEAL_STEP_ID
                             AND DH.STEP_STATUS_CODE IN ( '02','10','14') -- Changed for CMR issue
                             --AND TH.BANK_GROUP_CODE = TM.BANK_GROUP_CODE  -- Commented on 21-MAY-2012 for perf issue
                             AND TH.BANK_GROUP_CODE = 'SCB'
                             --AND TH.CTY_CODE = TM.CTY_CODE -- Commented on 21-MAY-2012 for perf issue
                             AND TH.CTY_CODE = 'HK'
                             --AND TH.PROD_LIMIT_ID = limitID -- COCOAPERF_12122012 -- COCOAFIX_13022013
                             --AND NVL(TH.TXN_STATUS_CODE,'01') <> '11'  -- COCOAFUNC_18122012 --COCOAFUNC_18012013
                             AND TH.CUST_ID = '800009800' -- Added on 21-MAY-2012 for perf issue
                             AND TH.TXN_REC_ID = TM.TXN_REC_ID) group by CASH_MARGIN_CCY_CODE; 
                                           

            SELECT TH.TXN_STEP_CODE,TH.TXN_REF_ID,TH.CASH_MARGIN_CCY_CODE,
              --(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))
              (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
              ((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
              ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
            AS AMT
              FROM SCBT_T_TXN_HST TH,SCBT_T_DEAL_HIST DH
             WHERE TH.BANK_GROUP_CODE = DH.BANK_GROUP_CODE
                   AND TH.CTY_CODE = DH.CTY_CODE
                   AND TH.BANK_GROUP_CODE = 'SCB'
           AND TH.CTY_CODE = 'HK'
           --AND TM.PROD_LIMIT_ID = limitID
           AND TH.CUST_ID = '800009800'
                   AND TH.CUST_ID = DH.CUST_ID AND TH.DEAL_ID = DH.DEAL_ID
                   AND TH.Deal_Step_Id = DH.Deal_Step_Id
                   --AND TH.TXN_STEP_CODE NOT IN ('DSETT','SETT','CANC') 
                   AND DH.STEP_STATUS_CODE IN( '02','10','14')
                   AND NVL(TH.TXN_STATUS_CODE,'01')<>'11'
                 
                           AND TH.PROD_LIMIT_ID = limitID;                                      
