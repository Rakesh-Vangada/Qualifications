RETRIEVE_LATEST_DEAL_STEP_ID : select m.latest_deal_step_id from scbt_t_deal_mst m where m.deal_id='SG957T12645'  --800002479

SELECT * from SCBT_T_TXN_HST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  CUST_ID='800002479' and  DEAL_ID='SG957T12645'and  DEAL_STEP_ID='' and (txn_status_code is null or txn_status_code<>'11'

SELECT * from SCBT_T_CR_LOCK_DTLS where  BANK_GROUP_CODE= BANK_GROUP_CODE and  CTY_CODE= CTY_CODE)) and ( CR_STATUS_CODE not in  ('10')

SELECT * from SCBT_T_COLLATERAL_REGISTER_HST where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_STEP_ID=? and nvl( CR_STATUS_CODE, '00')<>'12'

SELECT * from SCBT_T_EVENT_MST where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  TXN_REF_ID=? and rownum<2

SELECT * from SCBT_T_EVENT_MST where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and ( LATEST_DEAL_STEP_ID like ?) and rownum<2

SELECT * from SCBT_T_EVENT_HST where  DEAL_STEP_ID=? and  BANK_GROUP_CODE='SCB'

SELECT * from SCBT_T_TXN_MST where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  CUST_ID='800002479' and  DEAL_ID='SG957T12645'and  TXN_REC_ID=?

SELECT * from SCBT_T_TXN_HST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  CUST_ID='800002479' and  DEAL_ID='SG957T12645'and  DEAL_STEP_ID=? and (txn_status_code is null or txn_status_code<>'11')

GET_PRODUCT_LIMIT_NAME :
SELECT limit_id, limit_name,followup_required,followup_reason
	  FROM scbt_r_cust_product_limit 
	 WHERE bank_group_code = ?
	   AND cty_code = ?
	   AND cust_id = ?
	   AND limit_id = ?
	   AND limit_product_code = ?
	   
SELECT * from SCBT_T_TXN_EVENTS_DTLS_HIST where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_STEP_ID=?

SELECT * from SCBT_T_TXN_BCA_SALE_MST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  TXN_REF_ID=?

SELECT * from SCBT_T_TXN_BCA_SALE_HST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_STEP_ID=?

SELECT * from SCBT_T_TXN_CR_LINKAGE_MST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and ( TXN_REC_ID in (?))

SELECT * from SCBT_T_TXN_CR_LINKAGE_HST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_STEP_ID=?

SELECT * from SCBT_T_TXN_INT_HST   where  BANK_GROUP_CODE= BANK_GROUP_CODE and  CTY_CODE= CTY_CODE and  DEAL_ID= DEAL_ID and  TXN_REF_ID= TXN_REF_ID and  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_ID='SG957T12645'and  TXN_REF_ID=? and  DEAL_STEP_ID=?))

SELECT * from SCBT_T_TXN_INT_HST   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_ID='SG957T12645'and  DEAL_STEP_ID=? and  TXN_REF_ID=?

SELECT * from SCBT_T_PARTY   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_STEP_ID=?

SELECT * from SCBT_T_ACBS_DTLS scbacbsdtl0_ where scbacbsdtl0_.DEAL_ID=?

SELECT * from SCBT_T_REMARKS_DTLS   where  DEAL_STEP_ID=? and  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG'

DEAL_TXN_REF_ID_LOCK_FALG_RETRIVE :  SELECT 'Y' ,h.deal_step_id ,h.maker_id,h.checker_id,h.step_status_code,h.step_code,h.offering_id
		FROM scbt_t_deal_hist h,scbt_t_txn_hst th 
		WHERE h.deal_id = th.deal_id AND h.bank_group_code = th.bank_group_code AND h.cty_code = th.cty_code
		AND h.deal_step_id = th.deal_step_id 
		AND h.DEAL_ID='SG957T12645'AND th.txn_ref_id = ? AND h.BANK_GROUP_CODE='SCB' AND h.CTY_CODE='SG' AND h.step_status_code <> '03'

Param [0]--> HK514T05676
Param [1]--> HK514T05676EB002
Param [2]--> SCB
Param [3]--> HK

SELECT * from SCBT_R_PARAM_DATA   where ( BANK_GROUP_CODE in (? , '*' , '**')) and ( CTY_CODE in (? , '*' , '**')) and ( PARTY_ID in (? , '*' , '**')) and ( TBU_CODE in (? , '*' , '**')) and  PARAM_ID=? and ( PARAM_KEY_01 in (? , '*' , '**')) and ( PARAM_KEY_02 in (? , '*' , '**')) and ( PARAM_KEY_03 in (? , '*' , '**')) and ( PARAM_KEY_04 in (? , '*' , '**')) and ( PARAM_KEY_05 in (? , '*' , '**')) and ( PARAM_KEY_06 in (? , '*' , '**')) and ( PARAM_KEY_07 in (? , '*' , '**')) and ( PARAM_KEY_08 in (? , '*' , '**')) and ( PARAM_KEY_09 in (? , '*' , '**')) and ( PARAM_KEY_10 in (? , '*' , '**')) order by  PARAM_KEY_SEQ_CODE desc

SELECT * from SCBT_R_PARAM_DATA   where  BANK_GROUP_CODE='SCB' and  PARAM_ID=? and  PARAM_KEY_01=? and  PARAM_KEY_02=? and  PARAM_KEY_03=? and  PARAM_KEY_04=? and  PARAM_KEY_05=? and  PARAM_KEY_06=? and  PARAM_KEY_07=? and  PARAM_KEY_08=? and  PARAM_KEY_09=? and  PARAM_KEY_10=? and  CTY_CODE='SG' and  PARTY_ID=? and  TBU_CODE=?

update SCBT_T_DEAL_MST set RECORD_LOCK_FLAG=? where DEAL_ID='SG957T12645'and BANK_GROUP_CODE='SCB' and CTY_CODE='SG'

SELECT * from SCBT_T_BBC_SHORTFALL_DTLS   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  DEAL_ID='SG957T12645'and  DEAL_STEP_ID=?

SELECT * from SCBT_T_BBC_EXPOSURE_DTLS   where  BANK_GROUP_CODE='SCB' and  CTY_CODE='SG' and  CUST_ID='800002479' and  DEAL_ID='SG957T12645'and  DEAL_STEP_ID=?

SELECT * from SCBT_R_PARAM_DATA   where  BANK_GROUP_CODE='SCB' and  PARAM_ID=? and  PARAM_KEY_01=? and  PARAM_KEY_02=? and  PARAM_KEY_03=? and  PARAM_KEY_04=? and  PARAM_KEY_05=? and  PARAM_KEY_06=? and  PARAM_KEY_07=? and  PARAM_KEY_08=? and  PARAM_KEY_09=? and  PARAM_KEY_10=? and  CTY_CODE='SG' and  PARTY_ID=? and  TBU_CODE=?

SELECT * from SCBT_T_SOFT_LOCK   where  LOCK_KEY=?

insert into SCBT_T_SOFT_LOCK (COMPONENT_ID, LOCK_TIMESTAMP, USER_ID, BANK_GROUP_CODE, CTY_CODE, TBU_CODE, HOST_NAME, LOCK_KEY, SESSION_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?)

from SCBT_R_PARAM_DATA   where ( BANK_GROUP_CODE in (? , '*' , '**')) and ( CTY_CODE in (? , '*' , '**')) and ( PARTY_ID in (? , '*' , '**')) and ( TBU_CODE in (? , '*' , '**')) and  PARAM_ID=? and ( PARAM_KEY_01 in (? , '*' , '**')) and ( PARAM_KEY_02 in (? , '*' , '**')) and ( PARAM_KEY_03 in (? , '*' , '**')) and ( PARAM_KEY_04 in (? , '*' , '**')) and ( PARAM_KEY_05 in (? , '*' , '**')) and ( PARAM_KEY_06 in (? , '*' , '**')) and ( PARAM_KEY_07 in (? , '*' , '**')) and ( PARAM_KEY_08 in (? , '*' , '**')) and ( PARAM_KEY_09 in (? , '*' , '**')) and ( PARAM_KEY_10 in (? , '*' , '**')) order by  PARAM_KEY_SEQ_CODE desc

SELECT * from SCBT_R_PARAM_DATA   where  BANK_GROUP_CODE='SCB' and  PARAM_ID=? and  PARAM_KEY_01=? and  PARAM_KEY_02=? and  PARAM_KEY_03=? and  PARAM_KEY_04=? and  PARAM_KEY_05=? and  PARAM_KEY_06=? and  PARAM_KEY_07=? and  PARAM_KEY_08=? and  PARAM_KEY_09=? and  PARAM_KEY_10=? and  CTY_CODE='SG' and  PARTY_ID=? and  TBU_CODE=?

SELECT * from SCBT_R_PARAM_DATA   where  BANK_GROUP_CODE='SCB' and  PARAM_ID=? and  PARAM_KEY_01=? and  PARAM_KEY_02=? and  PARAM_KEY_03=? and  PARAM_KEY_04=? and  PARAM_KEY_05=? and  PARAM_KEY_06=? and  PARAM_KEY_07=? and  PARAM_KEY_08=? and  PARAM_KEY_09=? and  PARAM_KEY_10=? and  CTY_CODE='SG' and  PARTY_ID=? and  TBU_CODE=?


		