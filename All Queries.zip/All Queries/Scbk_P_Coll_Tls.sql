CREATE OR REPLACE PACKAGE BODY COCOOWNER.Scbk_P_Prod_Tls IS

CURSOR cOldCustLimit
(in_Bank_Group_Code IN SCBT_R_CUST_PRODUCT_LIMIT.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_PRODUCT_LIMIT.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_PRODUCT_LIMIT.cust_id%TYPE
  )
IS
SELECT
LIMIT_PRODUCT_CODE, CUST_CTY_CODE, CPTY_ID, CUST_ID,  
CPTY_CTY_CODE, LIMIT_ID, LIMIT_TYPE_CODE,  EXT_LIMIT_ID, omnibus_risk,
NVL((SELECT t2.limit_id FROM SCBT_R_CUST_PRODUCT_LIMIT t2 WHERE t2.ext_limit_id = t1.inner_to_id
AND t2.cust_id = t1.cust_id AND ROWNUM = 1),' ') AS INNER_TO_ID,
LIMIT_CAT_CODE, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT,
--NVL(t1.limit_share_id,'') AS LIMIT_SHARE_ID,
STEP_ID, --NVL(MAIN_BORROWER_ID,' ') AS MAIN_BORROWER_ID, 
SUB_PRODUCT_TYPE_CODE,
FROM_TENOR, TO_TENOR, FROM_VALIDITY, TO_VALIDITY, REVOLVING_LC_TYPE, EVERGREEN_LC_TYPE
FROM SCBT_R_CUST_PRODUCT_LIMIT t1
 WHERE bank_group_code = in_bank_group_code AND
cty_code = in_cty_code AND limit_cat_code <> 'V' AND
Cust_id = in_cust_id
START WITH DECODE(limit_cat_code,'O',NULL,inner_to_id) IS NULL
AND bank_group_code = in_bank_group_code
AND cty_code = in_cty_code
AND limit_cat_code <> 'V'
AND cust_id = in_cust_id
CONNECT BY NOCYCLE PRIOR ext_limit_id = inner_to_id
ORDER BY LEVEL DESC;

CURSOR cNewCustLimit
(in_Bank_Group_Code IN SCBT_R_CUST_PRODUCT_LIMIT.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_PRODUCT_LIMIT.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_PRODUCT_LIMIT.cust_id%TYPE,
 in_Step_ID         IN SCBT_R_CUST_PRODUCT_LIMIT.step_id%TYPE
  )
IS
SELECT
LIMIT_PRODUCT_CODE, CUST_CTY_CODE, CPTY_ID, CUST_ID,  
CPTY_CTY_CODE, LIMIT_ID, LIMIT_TYPE_CODE,  EXT_LIMIT_ID, omnibus_risk,
NVL((SELECT t2.limit_id FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST t2 WHERE t2.ext_limit_id = t1.inner_to_id
AND t2.cust_id = t1.cust_id AND t2.step_id = t1.step_id AND ROWNUM = 1),' ') AS INNER_TO_ID,
LIMIT_CAT_CODE, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT,
--NVL(t1.limit_share_id,'') AS LIMIT_SHARE_ID,
STEP_ID, --NVL(MAIN_BORROWER_ID,' ') AS MAIN_BORROWER_ID, 
SUB_PRODUCT_TYPE_CODE,
FROM_TENOR, TO_TENOR, FROM_VALIDITY, TO_VALIDITY, REVOLVING_LC_TYPE, EVERGREEN_LC_TYPE
FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST t1
WHERE bank_group_code = in_bank_group_code AND
Cty_code = in_cty_code AND
Cust_id = in_cust_id AND
step_code <> '06' AND (op_code <> 'D' OR op_code IS NULL) AND limit_cat_code <> 'V' AND
Step_id = in_Step_ID
START WITH DECODE(limit_cat_code,'O',NULL,inner_to_id) IS NULL
AND bank_group_code = in_bank_group_code
AND Cty_code = in_cty_code
AND Cust_id = in_cust_id
AND step_code <> '06' AND (op_code <> 'D' OR op_code IS NULL) AND limit_cat_code <> 'V'
AND Step_id = in_Step_ID
CONNECT BY NOCYCLE PRIOR ext_limit_id = inner_to_id AND PRIOR step_id = in_Step_ID
ORDER BY LEVEL;

TYPE CustLimit_tab_type IS TABLE OF cOldCustLimit%ROWTYPE INDEX BY BINARY_INTEGER;

tNew_Structure CustLimit_tab_type;
tOld_Structure CustLimit_tab_type;

--JP

CURSOR cOldBcaLimit
(in_Bank_Group_Code IN SCBT_R_CUST_APPR_BUY_SUP.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_APPR_BUY_SUP.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_APPR_BUY_SUP.CUST_ID%TYPE
  )
IS
select * from (SELECT CAP_TYPE, CPTY_COND, CPTY_IDS, CTY_OF_SALE, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_CODE, 
       LIMIT_ID, PAYMENT_METHOD, PRODUCT_LIMIT_IDS, TENOR, decode(t1.cpty_cond, 'INC',1, 'EXC', 2, 'ANY', 3) as order_clause
  FROM SCBT_R_CUST_BCA_COND_LIMIT t1
 WHERE bank_group_code = in_bank_group_code 
   AND cty_code = in_cty_code 
   AND Cust_id = in_cust_id) order by order_clause;
   --ORDER BY CPTY_COND, CAP_TYPE;

CURSOR cNewbCALimit
(in_Bank_Group_Code IN SCBT_R_CUST_APPR_BUY_SUP.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_APPR_BUY_SUP.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_APPR_BUY_SUP.cust_id%TYPE,
 in_Step_ID         IN SCBT_R_CUST_APPR_BUY_SUP.step_id%TYPE
  )
IS
select * from (SELECT CAP_TYPE, CPTY_COND, CPTY_IDS, CTY_OF_SALE, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_CODE, 
       LIMIT_ID, PAYMENT_METHOD, PRODUCT_LIMIT_IDS, TENOR,decode(t1.cpty_cond, 'INC',1, 'EXC', 2, 'ANY', 3) as order_clause
  FROM SCBT_R_CUST_BCA_COND_LIMIT_HST t1
 WHERE bank_group_code = in_bank_group_code 
   AND Cty_code = in_cty_code 
   AND Cust_id = in_cust_id 
   AND step_code <> '06' 
   AND (op_code <> 'D' OR op_code IS NULL)
   AND Step_id = in_Step_ID) order by order_clause;

TYPE BcaLimit_tab_type IS TABLE OF cOldBcaLimit%ROWTYPE INDEX BY BINARY_INTEGER;
TYPE BcaLimit_tab_type_new IS TABLE OF cOldBcaLimit%ROWTYPE INDEX BY BINARY_INTEGER;

tNew_BcaStructure BcaLimit_tab_type_new;
tOld_BcaStructure BcaLimit_tab_type;

-- PRODUCT GROUP FACILITY START --

CURSOR cOldPgfLimit
(in_Bank_Group_Code IN SCBT_R_CUST_FACILITY_GRP.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_FACILITY_GRP.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_FACILITY_GRP.CUST_ID%TYPE
  )
IS
SELECT FACILITY_GRP_ID, FACLIITY_GRP_NAME, STOP_LOSS_PCT, STOP_LOSS_CCY_CODE  
     STOP_LOSS_CCY_AMT, LOAN_TO_VALUE_PCT, PROD_LIMIT_IDS, GROUP_TYPE, TENOR,
     LIMIT_AMT_CCY, LIMIT_AMOUNT, TENOR_VALUE
  FROM SCBT_R_CUST_FACILITY_GRP t1
 WHERE bank_group_code = in_bank_group_code 
   AND cty_code = in_cty_code 
   AND Cust_id = in_cust_id
   AND group_type <> 'LTV';

CURSOR cNewPgfLimit
(in_Bank_Group_Code IN SCBT_R_CUST_FACILITY_GRP_HIST.BANK_GROUP_CODE%TYPE,
 in_Cty_Code        IN SCBT_R_CUST_FACILITY_GRP_HIST.CTY_CODE%TYPE,
 in_Cust_ID         IN SCBT_R_CUST_FACILITY_GRP_HIST.cust_id%TYPE,
 in_Step_ID         IN SCBT_R_CUST_FACILITY_GRP_HIST.step_id%TYPE
  )
IS
SELECT FACILITY_GRP_ID, FACLIITY_GRP_NAME, STOP_LOSS_PCT, STOP_LOSS_CCY_CODE  
     STOP_LOSS_CCY_AMT, LOAN_TO_VALUE_PCT, PROD_LIMIT_IDS, GROUP_TYPE, TENOR,
     LIMIT_AMT_CCY, LIMIT_AMOUNT, TENOR_VALUE
  FROM SCBT_R_CUST_FACILITY_GRP_HIST t1
 WHERE bank_group_code = in_bank_group_code 
   AND Cty_code = in_cty_code 
   AND Cust_id = in_cust_id 
   AND step_code <> '06' 
   AND (op_code <> 'D' OR op_code IS NULL)
   AND Step_id = in_Step_ID
   AND group_type <> 'LTV';

TYPE PgfLimit_tab_type IS TABLE OF cOldPgfLimit%ROWTYPE INDEX BY BINARY_INTEGER;

tNew_PgfStructure PgfLimit_tab_type;
tOld_PgfStructure PgfLimit_tab_type;

-- PRODUCT GROUP FACILITY END --

-------------------------- LOCAL ----------------------------------------------

PROCEDURE SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code IN OUT VARCHAR2,
                                           p_BankGroupCode IN VARCHAR2,
                                           p_CtyCode IN VARCHAR2,
                                           p_limit_id   SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE,
                                           p_lim_ccy    SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE,
                       p_tree_type  SCBT_T_PROD_LIMIT_UTIL.limit_tree_type_code%TYPE)
IS
BEGIN

DECLARE
        pend_inc_amt                NUMBER := 0;
        pend_dec_amt                NUMBER := 0;
        util_amt                    NUMBER := 0;
      util_limit_id               SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE;

BEGIN
-- CHECK UTIL AVAILABILITY and CREATE IF NOT FOUND --
     BEGIN 
        SELECT LIMIT_ID INTO util_limit_id
            FROM SCBT_T_PROD_LIMIT_UTIL
    WHERE LIMIT_ID = p_limit_id
      AND BANK_GROUP_CODE = p_BankGroupCode
     AND CTY_CODE = p_Ctycode;

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
         INSERT INTO SCBT_T_PROD_LIMIT_UTIL(BANK_GROUP_CODE,CTY_CODE,LIMIT_ID,LIMIT_TREE_TYPE_CODE,
                                   LIMIT_CCY_CODE,LIMIT_CCY_PEND_INC_AMT,LIMIT_CCY_PEND_DEC_AMT,
                               LIMIT_CCY_UTILISED_AMT,LIMIT_CCY_AVAILABLE_AMT)
                                          VALUES (p_BankGroupCode, p_Ctycode, p_limit_id,p_tree_type,p_lim_ccy,0,0,0,0);
      END;
           
-- CHECK UTIL AVAILABILITY and CREATE IF NOT FOUND --   
     BEGIN
         SELECT SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, p_lim_ccy, 'N'))
              INTO util_amt
              FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh
              WHERE rh.bank_group_code = p_BankGroupCode
     AND rh.cty_code = p_CtyCode
     AND rh.req_type_code = 'NEW'
     AND rh.req_status_code = 'CON'
     AND mv.init_req_id = rh.init_req_id
     AND mv.limit_id = p_limit_id;

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
               NULL;
      END;

      BEGIN

         SELECT SUM(amt) INTO pend_inc_amt
                FROM
                (
                SELECT mv.init_req_id,
                SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, p_lim_ccy, 'N')) amt
                FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh
                WHERE rh.bank_group_code = p_BankGroupCode
    AND rh.cty_code = p_CtyCode
        AND rh.req_type_code = 'NEW'
    AND rh.req_status_code = 'PEND'
    AND mv.init_req_id = rh.init_req_id
    AND mv.limit_id = p_limit_id
                GROUP BY mv.init_req_id
                HAVING SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, p_lim_ccy, 'N')) > 0
                );

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
               NULL;
      END;

      BEGIN

        SELECT SUM(amt) INTO pend_dec_amt
              FROM
              (
              SELECT mv.init_req_id,
              SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, p_lim_ccy, 'N')) amt
              FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh
              WHERE rh.bank_group_code = p_BankGroupCode
     AND rh.cty_code = p_CtyCode
     AND rh.req_type_code = 'NEW'
     AND rh.req_status_code = 'PEND'
     AND mv.init_req_id = rh.init_req_id
     AND mv.limit_id = p_limit_id
              GROUP BY mv.init_req_id
              HAVING SUM(Scbf_Tls_Exch_Rate(rh.bank_group_code, rh.cty_code, mv.txn_ccy_code, mv.txn_ccy_amt, p_lim_ccy, 'N')) < 0
              );

      EXCEPTION
          WHEN NO_DATA_FOUND THEN
               NULL;
      END;

      UPDATE SCBT_T_PROD_LIMIT_UTIL
            SET limit_ccy_utilised_amt = NVL(util_amt,0),
            limit_ccy_pend_inc_amt = NVL(pend_inc_amt,0),
            limit_ccy_pend_dec_amt = NVL(pend_dec_amt,0) * -1
            WHERE limit_id = p_limit_id;


   RETURN;
EXCEPTION
WHEN OTHERS THEN
     p_ret_code := 'Exception while updating Product limit util for limit id : ' || p_limit_id;
END;

END SCBP_TLS_UPDATE_LIMIT_UTIL;

--*****************************************************************************


FUNCTION SCBF_TLS_GET_RELATED_PROD (p_BankGroupCode VARCHAR2,
                                    p_LimitProductCode VARCHAR2)
RETURN VARCHAR2 IS
BEGIN
DECLARE
   --l_OuterProductCode SCBT_R_CUST_LIMIT.LIMIT_PRODUCT_CODE%TYPE;
   l_RelatedProductCode SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE;
BEGIN

--   Code to be used once the map_info is created...

  BEGIN
   SELECT code_value_2 INTO l_RelatedProductCode FROM SCBT_R_MAP_INFO
   WHERE bank_group_code = p_BankGroupCode AND
   cty_code = '*' AND
   tbu_code = '*' AND
   map_id = 'MLM01' AND
   code_value_1 = p_LimitProductCode;
   RETURN l_RelatedProductCode;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN
     RETURN NULL;
 END;
END;
END SCBF_TLS_GET_RELATED_PROD;

--*************************************************************

PROCEDURE SCBP_ADJUST_PROD_OVERALL_LIMIT(p_Bank_Group_Code IN VARCHAR2,
                                        p_Cty_Code IN VARCHAR2,
                                       p_Cust_Id IN VARCHAR2,
                                       p_tLimit CustLimit_tab_type,
                                         p_Step_ID SCBT_R_CUST_PRODUCT_LIMIT.step_id%TYPE,
                                         p_ret_code IN OUT VARCHAR2)
IS
BEGIN
DECLARE
      ov_limit_id            SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE;
      b_Ov_Limit_Found       BOOLEAN;
      ov_Limit_Ccy           SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE;
    ov_Old_Ccy             SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE;
      ov_limit_amt           SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_active_amt%TYPE;
BEGIN

    BEGIN
          b_OV_Limit_Found := TRUE;

          SELECT limit_id, limit_ccy_code INTO ov_limit_id, ov_Old_Ccy
      FROM SCBT_R_CUST_PRODUCT_LIMIT
           WHERE bank_group_code = p_Bank_Group_Code
       AND cty_code = p_Cty_Code
      AND cust_id = p_Cust_Id
    AND limit_cat_code = 'V';

     EXCEPTION

     WHEN NO_DATA_FOUND THEN
           b_OV_Limit_Found := FALSE;
            SELECT scb_c_limitid.NEXTVAL INTO ov_limit_id FROM dual;

     WHEN OTHERS THEN
             DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
             p_ret_code := SUBSTR(SQLERRM, 1, 150);

        RETURN;

    END;

    IF b_OV_Limit_Found = TRUE AND p_tLimit.COUNT = 0 THEN

        DELETE FROM SCBT_T_PROD_LIMIT_UTIL
              WHERE bank_group_code = p_Bank_Group_Code
       AND limit_id = ov_limit_id;

        DELETE FROM SCBT_R_CUST_PRODUCT_LIMIT
              WHERE bank_group_code = p_Bank_Group_code
       AND cty_code = p_Cty_code
    AND cust_id = p_Cust_Id
    AND limit_cat_code = 'V';

        RETURN;

    END IF;


    IF ov_limit_ccy IS NULL THEN

        /*SELECT cm.ccy_code INTO ov_Limit_Ccy
          FROM SCBT_R_CTY_MST  cm
         WHERE bank_group_code = p_Bank_Group_Code
           AND cty_code = p_Cty_Code;*/

--*** OVERALL EXPOSURE HAS TO BE ARRIVED FROM PARTY SETUP INSTEAD OF COUNTRY'S LOCAL CURRENCY ***--
       
    SELECT cm.overall_exp_currency 
      INTO ov_Limit_Ccy
          FROM SCBT_R_PARTY_MST  cm
         WHERE bank_group_code = p_Bank_Group_Code
           AND cty_code = p_Cty_Code
           AND party_id = p_Cust_Id;  

    END IF;

    ov_limit_amt := 0;

    IF p_tLimit.COUNT=0 THEN

       ov_limit_amt := 0;

    ELSE

        SELECT SUM(AMT) INTO ov_limit_amt FROM 
        (
        SELECT NVL(SUM(Scbf_Tls_Exch_Rate(p_Bank_Group_Code, p_Cty_Code, limit_ccy_code, limit_ccy_active_amt,
                       ov_Limit_Ccy, 'N')),0) AS AMT
          FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST
         WHERE bank_group_code = p_Bank_Group_Code
           AND cty_code = p_Cty_Code
           AND cust_id = p_Cust_ID
           AND step_id = p_Step_ID
           AND limit_cat_code = 'O'
           AND (op_code <> 'D' OR OP_CODE IS NULL)
           HAVING SUM(Scbf_Tls_Exch_Rate(p_Bank_Group_Code, p_Cty_Code, limit_ccy_code, limit_ccy_active_amt,
                       ov_Limit_Ccy, 'N')) > 0
        );

    END IF;

/*    INSERT INTO SCBT_R_CUST_PRODUCT_LIMIT_HIST(BANK_GROUP_CODE,CPTY_CTY_CODE,CPTY_ID,CTY_CODE,
               CUST_CTY_CODE,CUST_ID,FROM_TENOR,FROM_VALIDITY,
               LIMIT_CAT_CODE,LIMIT_CCY_ACTIVE_AMT,LIMIT_CCY_CODE,LIMIT_ID,
              LIMIT_PRODUCT_CODE,LIMIT_SEQ_NO,LIMIT_SHARED_FLAG,
              LIMIT_TYPE_CODE,STEP_ID,SUB_PRODUCT_TYPE_CODE,TO_TENOR,TO_VALIDITY)
           VALUES  (p_Bank_Group_Code,'*','*',p_Cty_Code,'*',p_Cust_Id,0,0,
                 'V',ov_limit_amt,ov_limit_ccy,ov_limit_id,'*',0,'N','*',
              p_step_id,'*',9999,9999);*/

    IF b_Ov_Limit_Found = FALSE THEN

       INSERT INTO SCBT_R_CUST_PRODUCT_LIMIT   (BANK_GROUP_CODE,CTY_CODE,CUST_ID,LIMIT_PRODUCT_CODE,CUST_CTY_CODE,
                                CPTY_ID,CPTY_CTY_CODE,LIMIT_ID,LIMIT_TYPE_CODE,LIMIT_CAT_CODE,
            LIMIT_CCY_CODE,LIMIT_CCY_ACTIVE_AMT,LIMIT_SHARED_FLAG,STEP_ID,
            SUB_PRODUCT_TYPE_CODE,FROM_TENOR,FROM_VALIDITY,TO_TENOR,TO_VALIDITY,LIMIT_SEQ_NO)
                            VALUES   (p_Bank_Group_Code,p_Cty_Code,p_Cust_Id,'*','*','*','*',ov_limit_id,
                '*','V',ov_limit_ccy,ov_limit_amt,'N',p_step_id,'*',0,0,9999,9999,0)                ;

       INSERT INTO SCBT_T_PROD_LIMIT_UTIL      (BANK_GROUP_CODE,CTY_CODE,LIMIT_ID,LIMIT_TREE_TYPE_CODE,
                                 LIMIT_CCY_CODE,LIMIT_CCY_PEND_INC_AMT,LIMIT_CCY_PEND_DEC_AMT,
                             LIMIT_CCY_UTILISED_AMT,LIMIT_CCY_AVAILABLE_AMT)
                                      VALUES   (p_Bank_Group_Code, p_Cty_Code,ov_limit_id,'PROD',ov_limit_ccy,0,0,0,0);

    ELSE


            UPDATE SCBT_R_CUST_PRODUCT_LIMIT
               SET limit_ccy_code = ov_limit_ccy,
                    limit_ccy_active_amt = ov_limit_amt,
                   step_id = p_step_id
             WHERE bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code
               AND cust_id  = p_Cust_ID
               AND limit_id = ov_limit_id;
               
       IF ov_Old_Ccy <> ov_limit_ccy THEN

        BEGIN 

            UPDATE SCBT_T_PROD_LIMIT_UTIL 
         SET limit_ccy_code = ov_limit_ccy 
             WHERE bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code
               AND limit_id = ov_limit_id; 


             SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                         p_Bank_Group_Code,
                                         p_Cty_Code,
                                         ov_limit_id,
                                         ov_limit_ccy,
                     'PROD');
                 

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 NULL;
       
      END;

    END IF;
    
    END IF;

    p_ret_code := '0000';

 RETURN;

EXCEPTION

    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
      p_ret_code := SUBSTR(SQLERRM, 1, 150);

END;

END SCBP_ADJUST_PROD_OVERALL_LIMIT;

--******************************************************************************--

PROCEDURE SCBP_TLS_PROD_CHANGE_CCY (p_ret_code IN OUT VARCHAR2,
                                    p_bank_group_code VARCHAR2,
                                    p_cty_code VARCHAR2,
                                    p_limit_id VARCHAR2,
                                    p_old_ccy_code VARCHAR2,
                                    p_new_ccy_code VARCHAR2)
IS
BEGIN

     UPDATE SCBT_T_PROD_LIMIT_UTIL
     SET
     limit_ccy_code = p_new_ccy_code,

     limit_ccy_pend_inc_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_pend_inc_amt,0),
                                                 p_new_ccy_code,
                                                'N'),
     limit_ccy_pend_dec_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_pend_dec_amt,0),
                                                 p_new_ccy_code,
                                                 'N'),
     limit_ccy_utilised_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_utilised_amt,0),
                                                 p_new_ccy_code,
                                                 'N')
     WHERE limit_id = p_limit_id;

     RETURN;

EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_TLS_PROD_CHANGE_CCY;

--******************************************************************************--
PROCEDURE SCBP_BCA_AMT_CCY_CHANGE (p_ret_code IN OUT VARCHAR2,
                                   p_bank_group_code VARCHAR2,
                                   p_cty_code VARCHAR2,
                                   p_limit_id VARCHAR2,
                                   p_new_active_amt NUMBER,
                                   p_old_ccy_code VARCHAR2,
                                   p_new_ccy_code VARCHAR2,
                                   p_cust_id VARCHAR2) IS
                                   
 t_bca_limit_id    SCBT_R_CUST_ADH_BCA_COND_MST.LIMIT_ID%TYPE;
 
CURSOR bca_limit IS
SELECT LIMIT_ID, LIMIT_CCY_CODE
  FROM SCBT_R_CUST_ADH_BCA_COND_MST
 WHERE bca_limit_id = t_bca_limit_id
   AND bank_group_code = p_bank_group_code
   AND cty_code = p_cty_code;
   
BEGIN

     t_bca_limit_id := p_limit_id;
     
     UPDATE SCBT_R_CUST_ADH_BCA_COND_MST
        SET LIMIT_CCY_CODE       = p_new_ccy_code,
            LIMIT_CCY_ACTIVE_AMT = p_new_active_amt
      WHERE bca_limit_id         = p_limit_id
        AND bank_group_code      = p_bank_group_code
        AND cust_id              = p_cust_id
        AND cty_code             = p_cty_code;
               
     FOR bca IN bca_limit LOOP

         SCBP_TLS_PROD_CHANGE_CCY (p_ret_code, 
                                   p_bank_group_code,
                                   p_cty_code,
                                   bca.limit_id,
                                   p_old_ccy_code,
                                   p_new_ccy_code);
                                   
         SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                     p_Bank_Group_Code,
                                     p_Cty_Code,
                                     bca.limit_id,
                                     p_new_ccy_code,
                                     'ABCAP');                                   
                                     
     END LOOP;

EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_BCA_AMT_CCY_CHANGE;

--******************************************************************************--
/*FUNCTION SCBF_CHK_LMT_EXIST_BUY_SUP(p_ret_code        IN OUT VARCHAR2,
                                   p_bank_group_code IN VARCHAR2,
                                   p_cty_code        IN VARCHAR2,
                                   p_cust_id         IN VARCHAR2,
                                   p_party_id        IN VARCHAR2,
                                   p_limit_id        IN VARCHAR2, 
                                   p_party_role_code IN VARCHAR2) 
RETURN VARCHAR2  IS                  
  p_ret_val VARCHAR2(1);
BEGIN

DECLARE

  n_cust_id                    SCBT_R_CUST_APPR_BUY_SUP.CUST_ID%TYPE;
                    
  CURSOR abs_limit IS
                    SELECT h.APPR_BUYER_SUPPLIER_LIMIT_ID, h.PARTY_ROLE
                      FROM SCBT_R_CUST_APPR_BUY_SUP_HIST h, SCBT_R_CUST_APPR_BUY_SUP m 
                     WHERE h.bank_group_code = m.bank_group_code 
                       AND h.cty_code = m.cty_code 
                    AND h.cust_id = p_cust_id
                    AND h.step_status_code = '02' 
                    AND h.op_code = 'O' 
                    AND h.APPR_BUYER_SUPPLIER_LIMIT_ID = m.APPR_BUYER_SUPPLIER_LIMIT_ID 
                    AND h.party_id IN('*', p_party_id)
                    AND h.APPR_BUYER_SUPPLIER_LIMIT_ID <> p_limit_id;
    
  BEGIN
       p_ret_val:='N';
    FOR lmt IN abs_limit LOOP
    
       IF (lmt.party_role = '*') THEN
          p_ret_val:='Y';  
       ELSIF(lmt.party_role=p_party_role_code) THEN
         p_ret_val:='Y';
       END IF;
         
    END LOOP;
    
  END;  
  RETURN p_ret_val;
EXCEPTION
WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);


END SCBF_CHK_LMT_EXIST_BUY_SUP;

--******************************************************************************--
PROCEDURE SCBP_CREATE_BUYER_SUPP_MVMT (p_ret_code IN OUT VARCHAR2,
                                    p_bank_group_code VARCHAR2,
                                    p_cty_code VARCHAR2,
                  p_cust_id VARCHAR2,
                  p_abs_limit_id VARCHAR2,
                  p_role_code IN VARCHAR2, p_party_id VARCHAR2) IS
                                
BEGIN
  
     IF(p_role_code= '*' AND p_party_id = '*') THEN
         INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, LIMIT_TREE_TYPE_CODE,
                              TXN_CCY_CODE, TXN_CCY_AMT, OBLIGOR_ID, INIT_REQ_ID, REQ_SR_NO)
                              SELECT  p_bank_group_code, p_cty_code, p_abs_limit_id, 'BSLI',
            d.TXN_CCY_CODE, d.TXN_CCY_AMT,d.cpty_id, d.INIT_REQ_ID, d.REQ_SR_NO
        FROM   SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
         WHERE d.cty_code       = p_cty_code
         AND  d.bank_group_code = p_bank_group_code
         AND  d.obligor_id      = p_cust_id
         AND d.cpty_role_code  IN ('P01','P09');
         
        DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO,LIMIT_ID) IN (SELECT  PROD.INIT_REQ_ID, PROD.REQ_SR_NO,PROD.LIMIT_ID FROM
          SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_MVMT PROD,SCBT_R_ADHC_APPR_BUY_SUP sup
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           /*and d.cpty_id = p_party_id
           AND d.cpty_role_code =p_role_code*/
           /*AND PROD.Init_Req_Id = d.init_req_id
           AND prod.cty_code = d.cty_code
           AND prod.bank_group_code = d.bank_group_code
           AND prod.req_sr_no = d.req_sr_no
           AND sup.adhc_buyer_supplier_limit_id = prod.limit_id
           );
         
         DELETE FROM SCBT_R_ADHC_APPR_BUY_SUP sup WHERE EXISTS(SELECT  1 FROM
          SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND sup.cust_id = d.obligor_id
           );
     ELSIF(p_role_code<> '*' AND p_party_id = '*') THEN
       INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, LIMIT_TREE_TYPE_CODE,
                              TXN_CCY_CODE, TXN_CCY_AMT, OBLIGOR_ID, INIT_REQ_ID, REQ_SR_NO)
                              SELECT  p_bank_group_code, p_cty_code, p_abs_limit_id, 'BSLI',
            d.TXN_CCY_CODE, d.TXN_CCY_AMT,d.cpty_id, d.INIT_REQ_ID, d.REQ_SR_NO
        FROM   SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
         WHERE   d.cty_code       = p_cty_code
         AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_role_code  =p_role_code;
           
           DELETE FROM  SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO,LIMIT_ID) IN (SELECT  PROD.INIT_REQ_ID, PROD.REQ_SR_NO,PROD.LIMIT_ID FROM
           SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_MVMT PROD,SCBT_R_ADHC_APPR_BUY_SUP sup
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           /*and d.cpty_id = p_party_id*/
           /*AND d.cpty_role_code =p_role_code
           AND PROD.Init_Req_Id = d.init_req_id
           AND prod.cty_code = d.cty_code
           AND prod.bank_group_code = d.bank_group_code
           AND prod.req_sr_no = d.req_sr_no
           AND sup.adhc_buyer_supplier_limit_id = prod.limit_id
           );
           
           
           DELETE FROM SCBT_R_ADHC_APPR_BUY_SUP sup WHERE EXISTS(SELECT  1 FROM
          SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           /*and d.cpty_id = p_party_id*/
           /*AND d.cpty_role_code =p_role_code
           AND sup.party_id = d.cpty_id
           );
     ELSIF(p_role_code= '*' AND p_party_id <> '*') THEN
        INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, LIMIT_TREE_TYPE_CODE,
                              TXN_CCY_CODE, TXN_CCY_AMT, OBLIGOR_ID, INIT_REQ_ID, REQ_SR_NO)
                              SELECT  p_bank_group_code, p_cty_code, p_abs_limit_id, 'BSLI',
            d.TXN_CCY_CODE, d.TXN_CCY_AMT,d.cpty_id, d.INIT_REQ_ID, d.REQ_SR_NO
        FROM   SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
         WHERE   d.cty_code       = p_cty_code
         AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           AND d.cpty_role_code  IN('P01','P09');
           
           DELETE FROM  SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO,LIMIT_ID) IN (SELECT  PROD.INIT_REQ_ID, PROD.REQ_SR_NO,PROD.LIMIT_ID FROM
          SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_MVMT PROD,SCBT_R_ADHC_APPR_BUY_SUP sup
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           AND PROD.Init_Req_Id = d.init_req_id
           AND prod.cty_code = d.cty_code
           AND prod.bank_group_code = d.bank_group_code
           AND prod.req_sr_no = d.req_sr_no
           AND sup.adhc_buyer_supplier_limit_id = prod.limit_id
           AND sup.bank_group_code = p_bank_group_code
           AND sup.party_id = p_party_id
           ) ;
           
           DELETE FROM SCBT_R_ADHC_APPR_BUY_SUP sup WHERE EXISTS(SELECT  1 FROM
          SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           ) AND sup.bank_group_code = p_bank_group_code
           AND sup.party_id = p_party_id;
     ELSIF(p_role_code<> '*' AND p_party_id <> '*') THEN
        INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, LIMIT_TREE_TYPE_CODE,
                              TXN_CCY_CODE, TXN_CCY_AMT, OBLIGOR_ID, INIT_REQ_ID, REQ_SR_NO)
                              SELECT  p_bank_group_code, p_cty_code, p_abs_limit_id, 'BSLI',
            d.TXN_CCY_CODE, d.TXN_CCY_AMT,d.cpty_id, d.INIT_REQ_ID, d.REQ_SR_NO
          FROM   SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           AND d.cpty_role_code =p_role_code;
           
           DELETE FROM  SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO,LIMIT_ID) IN (SELECT  PROD.INIT_REQ_ID, PROD.REQ_SR_NO,PROD.LIMIT_ID FROM
           SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_MVMT PROD,SCBT_R_ADHC_APPR_BUY_SUP sup
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           AND d.cpty_role_code =p_role_code
           AND PROD.Init_Req_Id = d.init_req_id
           AND prod.cty_code = d.cty_code
           AND prod.bank_group_code = d.bank_group_code
           AND prod.req_sr_no = d.req_sr_no
           AND sup.adhc_buyer_supplier_limit_id = prod.limit_id
           AND sup.bank_group_code = p_bank_group_code
           AND sup.party_id = p_party_id
           );
           
           DELETE FROM SCBT_R_ADHC_APPR_BUY_SUP sup WHERE NOT EXISTS(SELECT  1 FROM
           SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
           WHERE   d.cty_code       = p_cty_code
           AND  d.bank_group_code = p_bank_group_code
           AND  d.obligor_id      = p_cust_id
           AND d.cpty_id = p_party_id
           AND d.cpty_role_code <> p_role_code
           ) AND sup.bank_group_code = p_bank_group_code
           AND sup.party_id = p_party_id;
     END IF;
   
   /*END LOOP;*/
                                
/*EXCEPTION

WHEN NO_DATA_FOUND THEN
     RETURN;
   
WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_CREATE_BUYER_SUPP_MVMT;
--******************************************************************************--
PROCEDURE SCBP_CRE_ADHOC_ABS_LIMIT (p_ret_code IN OUT VARCHAR2,
                                    p_bank_group_code VARCHAR2,
                                    p_cty_code VARCHAR2,
                  p_cust_id VARCHAR2,
                                    p_limit_id VARCHAR2,
                  p_party_id VARCHAR2,
                  p_limit_cur VARCHAR2,
                  p_role_code VARCHAR2,
                  p_limit_amt NUMBER) IS
BEGIN
DECLARE

  v_adhoc_id       SCBT_R_ADHC_APPR_BUY_SUP.ADHC_BUYER_SUPPLIER_LIMIT_ID%TYPE;
 
   v_count INT;
      
BEGIN
      
      IF(p_party_id='*') THEN
       --  if(p_role_code='*') then
         FOR m IN (SELECT m.BANK_GROUP_CODE,m.CTY_CODE,v_adhoc_id,m.INIT_REQ_ID,m.REQ_SR_NO,m.TXN_CCY_CODE,m.TXN_CCY_AMT,m.LIMIT_TREE_TYPE_CODE,m.OBLIGOR_ID,m.OFFERING_FLAG,m.OFFERING_REASON,d.cpty_id
            FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_REQ_LOG l, SCBT_T_PROD_LIMIT_MVMT m
           WHERE d.bank_group_code = p_bank_group_code
             AND d.obligor_id = p_cust_id
           AND d.cty_code = p_cty_Code
           AND M.LIMIT_ID = p_limit_id
           AND (d.cpty_role_code = p_role_code OR p_role_code = '*')
           AND l.req_status_code IN('CON','PEND')
           AND L.init_req_id = m.init_req_id
           AND l.req_type_code = 'NEW'
           AND m.init_req_id = d.init_req_id
           AND NOT EXISTS(SELECT 1
                      FROM SCBT_R_CUST_APPR_BUY_SUP_HIST h, SCBT_R_CUST_APPR_BUY_SUP m 
                     WHERE h.bank_group_code = m.bank_group_code 
                       AND h.cty_code = m.cty_code 
                    AND h.cust_id = p_cust_id
                    AND h.step_status_code = '02' 
                    AND h.op_code = 'O' 
                    AND h.APPR_BUYER_SUPPLIER_LIMIT_ID = m.APPR_BUYER_SUPPLIER_LIMIT_ID 
                    AND h.party_id IN('*', d.cpty_id)
                    AND h.party_role IN('*', d.cpty_role_code)
                    AND m.limit_id<>h.APPR_BUYER_SUPPLIER_LIMIT_ID
           )) LOOP
           
           SELECT COUNT(*) INTO v_count FROM SCBT_R_ADHC_APPR_BUY_SUP
            WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
            AND cust_id = p_cust_id AND party_id = m.cpty_id;
           
           IF(v_count>0) THEN
                  SELECT ADHC_BUYER_SUPPLIER_LIMIT_ID INTO v_adhoc_id FROM SCBT_R_ADHC_APPR_BUY_SUP
                  WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
                  AND cust_id = p_cust_id AND party_id = m.cpty_id;
            
           ELSE
                SELECT scb_c_limitid.NEXTVAL INTO v_adhoc_id FROM dual;
                        
                INSERT INTO SCBT_R_ADHC_APPR_BUY_SUP(BANK_GROUP_CODE, CTY_CODE, CUST_ID, PARTY_ID, PARTY_ROLE,
                        LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, ADHC_BUYER_SUPPLIER_LIMIT_ID)
                VALUES (p_bank_group_code, p_cty_code, p_cust_id, m.cpty_id,
                         '*', p_limit_cur, p_limit_amt, v_adhoc_id);
          END IF;  
          v_count:=0;
          SELECT COUNT(*) INTO v_count FROM SCBT_T_PROD_LIMIT_MVMT WHERE init_req_id = m.INIT_REQ_ID AND req_sr_no = m.REQ_SR_NO AND limit_id = v_adhoc_id;
          IF(v_count=0) THEN
            INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID, OFFERING_FLAG, OFFERING_REASON)
            VALUES(m.BANK_GROUP_CODE,m.CTY_CODE,v_adhoc_id,m.INIT_REQ_ID,m.REQ_SR_NO,m.TXN_CCY_CODE,m.TXN_CCY_AMT,m.LIMIT_TREE_TYPE_CODE,m.cpty_ID,m.OFFERING_FLAG,m.OFFERING_REASON);
          END IF;
          SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                    p_Bank_Group_Code,
                                    p_Cty_Code,
                                    v_adhoc_id,
                                    p_limit_cur,
                  'AABS');
       END LOOP;   
      ELSE
      SELECT COUNT(*) INTO v_count FROM SCBT_R_ADHC_APPR_BUY_SUP
        WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
        AND cust_id = p_cust_id AND party_id = p_party_id;
        IF(v_count>0) THEN
              SELECT ADHC_BUYER_SUPPLIER_LIMIT_ID INTO v_adhoc_id FROM SCBT_R_ADHC_APPR_BUY_SUP
              WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
              AND cust_id = p_cust_id AND party_id = p_party_id;
        
        ELSE
          SELECT scb_c_limitid.NEXTVAL INTO v_adhoc_id FROM dual;
                
          INSERT INTO SCBT_R_ADHC_APPR_BUY_SUP(BANK_GROUP_CODE, CTY_CODE, CUST_ID, PARTY_ID, PARTY_ROLE,
                                LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, ADHC_BUYER_SUPPLIER_LIMIT_ID)
                         VALUES (p_bank_group_code, p_cty_code, p_cust_id, p_party_id,
                                 '*', p_limit_cur, p_limit_amt, v_adhoc_id);
        END IF;    
    
       INSERT INTO SCBT_T_PROD_LIMIT_MVMT(BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID, OFFERING_FLAG, OFFERING_REASON)
       (SELECT m.BANK_GROUP_CODE,m.CTY_CODE,v_adhoc_id,m.INIT_REQ_ID,m.REQ_SR_NO,m.TXN_CCY_CODE,m.TXN_CCY_AMT,m.LIMIT_TREE_TYPE_CODE,m.OBLIGOR_ID,m.OFFERING_FLAG,m.OFFERING_REASON
            FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL d, SCBT_T_PROD_LIMIT_REQ_LOG l, SCBT_T_PROD_LIMIT_MVMT m
           WHERE d.bank_group_code = p_bank_group_code
             AND d.obligor_id = p_cust_id
           AND d.cty_code = p_cty_Code
           AND M.LIMIT_ID = p_limit_id
           AND d.cpty_id = p_party_id
           AND (d.cpty_role_code = p_role_code OR p_role_code = '*')
           AND l.req_status_code IN('CON','PEND')
           AND L.init_req_id = m.init_req_id
           AND l.req_type_code = 'NEW'
           AND m.init_req_id = d.init_req_id
           AND NOT EXISTS(SELECT 1 FROM SCBT_T_PROD_LIMIT_MVMT mvmt 
           WHERE mvmt.init_req_id =m.init_req_id AND mvmt.req_sr_no = m.req_sr_no
           AND mvmt.limit_id =  v_adhoc_id)
           AND NOT EXISTS(SELECT 1
                      FROM SCBT_R_CUST_APPR_BUY_SUP_HIST h, SCBT_R_CUST_APPR_BUY_SUP m 
                     WHERE h.bank_group_code = m.bank_group_code 
                       AND h.cty_code = m.cty_code 
                    AND h.cust_id = p_cust_id
                    AND h.step_status_code = '02' 
                    AND h.op_code = 'O' 
                    AND h.APPR_BUYER_SUPPLIER_LIMIT_ID = m.APPR_BUYER_SUPPLIER_LIMIT_ID 
                    AND h.party_id IN('*', d.cpty_id)
                    AND h.party_role IN('*', d.cpty_role_code)
                    AND m.limit_id<>h.APPR_BUYER_SUPPLIER_LIMIT_ID
           )
         );
         SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                    p_Bank_Group_Code,
                                    p_Cty_Code,
                                    v_adhoc_id,
                                    p_limit_cur,
                  'AABS');
         END IF;
        
     
     END;
   
EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_CRE_ADHOC_ABS_LIMIT;*/

--***************************************************************************************--

/*PROCEDURE SCBP_DEL_MOVE_TO_ADHOC(p_ret_code        IN OUT VARCHAR2,
                                 p_bank_group_code IN VARCHAR2,
                                 p_cty_code        IN VARCHAR2,
                    p_ret_value       IN OUT BOOLEAN,
                    p_cust_id         IN VARCHAR2,
                                  p_party_id        IN VARCHAR2,
                    p_party_role_code      IN VARCHAR2,                 
                    p_limit_id        IN VARCHAR2,
                    p_limit_curr      IN VARCHAR2,
                    p_limit_amt       IN NUMBER) IS
                 
    p_buyer_found     BOOLEAN;
  p_supplier_found  BOOLEAN;
  abs_limit_id      SCBT_R_CUST_APPR_BUY_SUP.APPR_BUYER_SUPPLIER_LIMIT_ID%TYPE;                 
    abs_limit_cur     SCBT_R_CUST_APPR_BUY_SUP.LIMIT_CCY_CODE%TYPE;
    abs_role_code     SCBT_R_CUST_APPR_BUY_SUP.PARTY_ROLE%TYPE;                     
    v_check_val VARCHAR2(1);            
BEGIN

   p_ret_value      := TRUE;
   p_buyer_found    := FALSE;        
   p_supplier_found := FALSE;


   v_check_val:= SCBF_CHK_LMT_EXIST_BUY_SUP(p_ret_code,p_bank_group_code,
                                   p_cty_code,p_cust_id, p_party_id,p_limit_id, p_party_role_code) ;
   IF(v_check_val='N') THEN
      
      SCBP_CRE_ADHOC_ABS_LIMIT (p_ret_code,
                                p_bank_group_code,
                          p_cty_code,
                        p_cust_id,
                                             p_limit_id,
                        p_party_id,
                        p_limit_curr,
                        p_party_role_code,
                        p_limit_amt);
      
      DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO) IN (SELECT dtl.init_req_id, dtl.REQ_SR_NO FROM SCBT_T_PROD_LIMIT_REQ_LOG LOG, SCBT_T_PROD_LIMIT_REQ_LOG_DTL DTL
        WHERE LOG.req_type_code = 'NEW' AND LOG.req_status_code IN ('CON', 'PEND')
        AND dtl.OBLIGOR_ID = p_cust_id) AND limit_id = p_limit_id;
   ELSE
      DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE (INIT_REQ_ID, REQ_SR_NO) IN (SELECT dtl.init_req_id, dtl.REQ_SR_NO FROM SCBT_T_PROD_LIMIT_REQ_LOG LOG, SCBT_T_PROD_LIMIT_REQ_LOG_DTL DTL
        WHERE LOG.req_type_code = 'NEW' AND LOG.req_status_code IN ('CON', 'PEND')
        AND dtl.OBLIGOR_ID = p_cust_id) AND limit_id = p_limit_id;
   END IF;
      
                
EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_DEL_MOVE_TO_ADHOC;*/

--***************************************************************************************--
PROCEDURE SCBP_TLS_PROD_CONVERT_I2O(p_ret_code        IN OUT VARCHAR2,
                                    p_limit_found     IN BOOLEAN,
                                    p_bank_group_code IN VARCHAR2,
                                    p_cty_code        IN VARCHAR2,
                                    p_inner_Limit_rec IN cNewCustLimit%ROWTYPE) IS
BEGIN
  DECLARE
    V_OUTER_LIMIT_ID  SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
    V_OUTER_LIMIT_CCY SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;

    LMT_UTILIZED EXCEPTION;
    V_NEXT_OUTER_LIMIT_ID SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;

  BEGIN

    v_outer_limit_id := p_inner_Limit_rec.Inner_To_Id;

--* INTRODUCED TO CHECK THE UTILIZATION WHILE DELETING OUTER LIMIT **---

 /*IF p_limit_found = FALSE THEN
     begin
          SELECT limit_id, limit_ccy_utilised_amt into LimitID, N_LIMIT_UTILIZED FROM SCBT_T_PROD_LIMIT_UTIL
           WHERE cty_code = p_cty_code
          AND limit_id = p_inner_Limit_rec.Limit_Id;

            IF N_LIMIT_UTILIZED <> 0 THEN
        
               RAISE LMT_UTILIZED;
        
            END IF;

    EXCEPTION
           WHEN LMT_UTILIZED THEN
              p_ret_code := 'Limit Already Utilized for the ID' || LimitID;
           RETURN;

     END;

 END IF;*/

    WHILE v_outer_limit_id <> ' ' LOOP
      BEGIN
          SELECT t1.LIMIT_CCY_CODE,
                 NVL((SELECT t2.limit_id
                       FROM SCBT_R_CUST_PRODUCT_LIMIT t2
                      WHERE t2.ext_limit_id = t1.inner_to_id
                        AND t2.cust_id = t1.cust_id
                        AND ROWNUM = 1),' ')
            INTO V_OUTER_LIMIT_CCY, V_NEXT_OUTER_LIMIT_ID
            FROM SCBT_R_CUST_PRODUCT_LIMIT t1
           WHERE t1.LIMIT_ID = v_outer_limit_id
          AND t1.BANK_GROUP_CODE = p_bank_group_code
             AND t1.CTY_CODE = p_cty_code;
      EXCEPTION
          WHEN OTHERS THEN
          p_ret_code := 'Converting Product Inner to Outer : outer limit id ' || v_outer_limit_id || ' not found';
          RETURN;
      END;

      /*IF b_init_amt = TRUE THEN
      BEGIN
            SELECT LIMIT_CCY_PEND_INC_AMT,
                   LIMIT_CCY_PEND_DEC_AMT,
                   LIMIT_CCY_UTILISED_AMT
              INTO N_LIMIT_PEND_INC, N_LIMIT_PEND_DEC, N_LIMIT_UTILIZED
              FROM SCBT_T_PROD_LIMIT_UTIL
             WHERE LIMIT_ID = p_inner_Limit_rec.Limit_Id;
        EXCEPTION
          WHEN OTHERS THEN
          p_ret_code := 'Converting Product Inner to Outer : limit id ' || p_inner_Limit_rec.Limit_Id || ' not found';
          RETURN;
      END;
        b_init_amt := FALSE;
      END IF;
     BEGIN
          N_CONV_PEND_INC := Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                p_cty_code,
                                                p_inner_Limit_rec.Limit_Ccy_Code,
                                                NVL(N_LIMIT_PEND_INC, 0),
                                                V_OUTER_LIMIT_CCY,
                                                'N');

          N_CONV_PEND_DEC := Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                p_cty_code,
                                                p_inner_Limit_rec.Limit_Ccy_Code,
                                                NVL(N_LIMIT_PEND_DEC, 0),
                                                V_OUTER_LIMIT_CCY,
                                                'N');
          N_CONV_UTILIZED := Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                p_cty_code,
                                                p_inner_Limit_rec.Limit_Ccy_Code,
                                                NVL(N_LIMIT_UTILIZED, 0),
                                                V_OUTER_LIMIT_CCY,
                                                'N');
     EXCEPTION
         WHEN OTHERS THEN
           p_ret_code := 'Converting Inner to Outer : Exception while getting the exchange rate';
           RETURN;
      END;*/

      DELETE FROM SCBT_T_PROD_LIMIT_MVMT
       WHERE limit_id = V_OUTER_LIMIT_ID
         AND (init_req_id, req_sr_no) IN
             (SELECT init_req_id, req_sr_no
                FROM SCBT_T_PROD_LIMIT_MVMT
               WHERE limit_id = p_inner_Limit_rec.Limit_Id)
                 AND bank_group_code = p_bank_group_code
                 AND cty_code = p_cty_code;
    
             SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                         p_Bank_Group_Code,
                                         p_Cty_Code,
                                         v_outer_limit_id,
                                         V_OUTER_LIMIT_CCY,
                     'PROD');
                                                  
            v_outer_limit_id := v_next_outer_limit_id;
            
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      p_ret_code := 'SCBP_TLS_PROD_CONVERT_I2O :: ' || SUBSTR(SQLERRM, 1, 150);
  END;
  
END SCBP_TLS_PROD_CONVERT_I2O;

--*******************************************************************************--

PROCEDURE SCBP_TLS_PROD_DEL_O (p_ret_code IN OUT VARCHAR2,
                               p_bank_group_code IN VARCHAR2,
                               p_cty_code IN VARCHAR2,
                               p_cust_id  IN VARCHAR2,
                               p_Limit_rec cNewCustLimit%ROWTYPE)

IS

      UTILISED_AMT             SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
      PEND_INC_AMT             SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
      PEND_DEC_AMT             SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
      p_limit_found            BOOLEAN := TRUE;
      LMT_UTILIZED             EXCEPTION;
      LIMITID                  SCBT_T_PROD_LIMIT_UTIL.LIMIT_ID%TYPE;

BEGIN
   BEGIN 
   IF p_limit_found = FALSE THEN
    BEGIN
       SELECT LIMIT_ID, limit_ccy_pend_inc_amt, limit_ccy_pend_dec_amt, 
        LIMIT_CCY_UTILISED_AMT INTO LIMITID, PEND_INC_AMT, PEND_DEC_AMT, UTILISED_AMT 
          FROM SCBT_T_PROD_LIMIT_UTIL
        WHERE bank_group_code = p_bank_group_code 
           AND cty_code = p_cty_code
         AND limit_id = p_Limit_rec.Limit_Id;
    
       IF UTILISED_AMT <> 0 OR  PEND_INC_AMT <> 0 OR PEND_DEC_AMT <> 0 THEN
          RAISE LMT_UTILIZED;
       END IF;
    
       EXCEPTION
    
          WHEN LMT_UTILIZED THEN
             p_ret_code := 'Limit Already Utilized for the ID' || LIMITID;
    
          WHEN OTHERS       THEN
             p_ret_code := SUBSTR(SQLERRM, 1, 150);
    
          RETURN;
    
      END;

   END IF;

   DELETE SCBT_T_PROD_LIMIT_MVMT
    WHERE BANK_GROUP_CODE = p_bank_group_code
      AND limit_id = LIMITID
     AND cty_code = p_cty_code;

   DELETE SCBT_T_PROD_LIMIT_UTIL
    WHERE BANK_GROUP_CODE = p_bank_group_code
      AND limit_id = p_Limit_rec.limit_id
     AND cty_code = p_cty_code;

   RETURN;

EXCEPTION
WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);
END;

END SCBP_TLS_PROD_DEL_O;

--********************************************************************************

/*PROCEDURE SCBP_TLS_CUST_CONVERT_CBR2O (p_ret_code IN OUT VARCHAR2,
                                       p_Bank_Group_Code IN VARCHAR2,
                                       p_Cty_Code IN VARCHAR2,
                                       p_Cust_Limit_Rec IN cOldCustLimit%ROWTYPE)
IS
BEGIN

DECLARE

      CURSOR cb_init_req_cur IS
      SELECT DISTINCT mv.init_req_id, u.limit_ccy_code FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_REQ_LOG rh,
            SCBT_T_PROD_LIMIT_UTIL u, SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd
            WHERE mv.bank_group_code = p_Bank_Group_Code
           AND mv.cty_code = p_Cty_Code
           AND rh.bank_group_code = mv.bank_group_code
           AND rh.cty_code = mv.cty_code 
           AND rd.bank_group_code = mv.bank_group_code
           AND rd.cty_code = mv.cty_code 
            AND mv.init_req_id = rh.init_req_id 
            AND rh.req_type_code = 'NEW' 
            AND rh.req_status_code IN ('PEND','CON') 
            AND mv.limit_id = p_Cust_Limit_Rec.Limit_Id 
            AND u.limit_id = mv.limit_id 
            AND rd.prod_limit_id = u.limit_id;

      CURSOR mb_limits_cur (p_init_req_id IN VARCHAR2) IS
      SELECT DISTINCT mv.limit_id, u.limit_ccy_code FROM SCBT_T_PROD_LIMIT_MVMT mv, SCBT_T_PROD_LIMIT_UTIL u 
       WHERE mv.bank_group_code = p_Bank_Group_Code 
         AND mv.cty_code = p_Cty_Code 
         AND init_req_id = p_init_req_id 
         AND mv.obligor_id = p_Cust_Limit_Rec.main_borrower_id 
         AND mv.limit_id = u.limit_id;

BEGIN
      FOR cb_init_req IN cb_init_req_cur LOOP
        FOR mb_limit IN mb_limits_cur (cb_init_req.init_req_id) LOOP
            
            DELETE FROM SCBT_T_PROD_LIMIT_MVMT 
                  WHERE bank_group_code = p_Bank_Group_Code 
                    AND cty_code = p_Cty_Code 
                    AND limit_id = mb_limit.limit_id 
                    AND init_req_id = cb_init_req.init_req_id;
                    
                    SCBP_TLS_UPDATE_LIMIT_UTIL(p_ret_code,
                                               p_Bank_Group_Code,
                                               p_Cty_Code, 
                                               mb_limit.limit_id,
                                               mb_limit.limit_ccy_code,
                         'PROD');
        END LOOP;
      END LOOP

   RETURN;
EXCEPTION
WHEN OTHERS THEN
     p_ret_code := 'Converting Co-borrower to Outer : ' || SUBSTR(SQLERRM, 1, 150);
END;
END SCBP_TLS_CUST_CONVERT_CBR2O;*/

--******************************************************************

/*PROCEDURE SCBP_TLS_CUST_CONVERT_O2CBR(p_ret_code        IN OUT VARCHAR2,
                                      p_Bank_Group_Code IN VARCHAR2,
                                      p_Cty_Code        IN VARCHAR2,
                                      p_Cust_Limit_Rec  IN cNewCustLimit%ROWTYPE) IS
BEGIN
  DECLARE
  
     -- select matching records of main borrower
    -- select overall record only if an ordinary outer limit is shared
    CURSOR mb_limit_cur IS
      SELECT cpl.*
      FROM
      (  
      SELECT * 
            FROM SCBT_R_CUST_PRODUCT_LIMIT lim
           WHERE lim.bank_group_code = p_Bank_Group_Code
             AND lim.cty_code = p_Cty_Code
             AND lim.cust_id = p_Cust_Limit_Rec.main_borrower_id
             AND lim.limit_id = p_Cust_Limit_Rec.Limit_Share_Id
         )tbl, SCBT_R_CUST_PRODUCT_LIMIT cpl
         WHERE cpl.bank_group_code = tbl.bank_group_code
         AND cpl.cty_code = tbl.cty_code
         AND ((cpl.limit_id = tbl.limit_id) OR (tbl.ext_limit_id = cpl.inner_to_id AND cpl.limit_cat_code='R'))
      UNION
      SELECT *
            FROM SCBT_R_CUST_PRODUCT_LIMIT lim
            WHERE lim.bank_group_code = p_Bank_Group_Code
              AND lim.cty_code = p_Cty_Code
              AND lim.cust_id = p_Cust_Limit_Rec.main_borrower_id
              AND lim.limit_cat_code = 'V';
--              AND p_Cust_Limit_Rec.limit_type_code = '*';

    \*CURSOR req_det_cur IS
      SELECT rd.*
        FROM scbt_t_prod_limit_req_log_dtl rd,
             scbt_t_prod_limit_req_log     rh,
             scbt_t_prod_limit_mvmt        mv
       WHERE mv.bank_group_code = p_Bank_Group_Code
         AND mv.cty_code = p_Cty_Code
         AND mv.limit_id = p_Cust_Limit_Rec.limit_id
       AND rh.bank_group_code = mv.bank_group_code    
       AND rh.cty_code = mv.cty_code     
         AND rh.init_req_id = mv.init_req_id    
         AND rh.req_type_code = 'NEW'    
         AND rh.req_status_code IN ('PEND', 'CON')    
       AND rd.bank_group_code = mv.bank_group_code    
       AND rd.cty_code = mv.cty_code    
         AND rd.init_req_id = mv.init_req_id    
         AND rd.req_sr_no = mv.req_sr_no    
         AND rd.prod_limit_id = p_Cust_Limit_Rec.limit_id; *\     
             
    \*CURSOR all_inner_limit IS
    SELECT LIMIT_ID
      FROM SCBT_R_CUST_PRODUCT_LIMIT inn
     WHERE p_Bank_Group_Code       = inn.bank_group_code
      AND mb_limit.limit_cat_code = 'I'
       AND p_Cty_Code              = inn.cty_code
       AND mb_limit.cust_id        = inn.cust_id
       AND mb_limit.inner_to_id    = inn.ext_limit_id; *\        
    
    v_outer_limit_id       SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE;
    v_outer_limit_ccy_code SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE;
    v_outer_prod_code      SCBT_R_CUST_PRODUCT_LIMIT.limit_product_code%TYPE;
    v_outer_type_code      SCBT_R_CUST_PRODUCT_LIMIT.limit_type_code%TYPE;
    v_offer_flag           VARCHAR2(1);
    v_offer_reason         SCBT_T_PROD_LIMIT_MVMT.offering_reason%TYPE;
    v_outer_limit_cat_code  SCBT_R_CUST_PRODUCT_LIMIT.limit_cat_code%TYPE;
    v_inner_to_id           SCBT_R_CUST_PRODUCT_LIMIT.inner_to_id%TYPE;

  BEGIN

    FOR mb_limit IN mb_limit_cur LOOP
        v_outer_limit_id       := NULL;
        v_outer_limit_ccy_code := NULL;

      \* if inner, then get details of outer limit *\
       IF (mb_limit.limit_cat_code = 'I') THEN
            BEGIN
              SELECT limit_id,
                     limit_product_code,
                     limit_type_code,
                     limit_ccy_code,
                     limit_cat_code,
                     inner_to_id
              INTO v_outer_limit_id,
                     v_outer_prod_code,
                     v_outer_type_code,
                     v_outer_limit_ccy_code,
                     v_outer_limit_cat_code,
                     v_inner_to_id
                FROM SCBT_R_CUST_PRODUCT_LIMIT
               WHERE bank_group_code = p_Bank_Group_Code
                 AND cty_code = p_Cty_Code
                 AND cust_id = mb_limit.cust_id
                 AND ext_limit_id = mb_limit.inner_to_id;
           EXCEPTION
              WHEN OTHERS THEN
              p_ret_code := 'Converting Outer to Co-Borrower : outter limit id ' || mb_limit.inner_to_id || ' not found';
              RETURN;
           END;

      END IF;

        \* check if this request would hit the main borrower's limit *\
          IF (mb_limit.limit_cat_code = 'R') THEN
            \* create movement *\
            BEGIN
                INSERT INTO SCBT_T_PROD_LIMIT_MVMT
                  (BANK_GROUP_CODE,
                   CTY_CODE,
                   LIMIT_ID,
                   LIMIT_TREE_TYPE_CODE,
                   TXN_CCY_CODE,
                   TXN_CCY_AMT,
                   OBLIGOR_ID,
                   INIT_REQ_ID,
                   REQ_SR_NO)
                  (SELECT rd.bank_group_code, rd.cty_code, mb_limit.limit_id, 'PROD',
                         rd.txn_ccy_code, rd.txn_ccy_amt, mb_limit.cust_id, rd.init_req_id,
                          rd.req_sr_no
                     FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd,
                          SCBT_T_PROD_LIMIT_REQ_LOG     rh,
                          SCBT_T_PROD_LIMIT_MVMT        mv
                    WHERE mv.bank_group_code = p_Bank_Group_Code
                     AND mv.cty_code = p_Cty_Code
                     AND mv.limit_id = p_Cust_Limit_Rec.limit_id
                     AND rh.bank_group_code = mv.bank_group_code    
                     AND rh.cty_code = mv.cty_code     
                     AND rh.init_req_id = mv.init_req_id    
                     AND rh.req_type_code = 'NEW'    
                     AND rh.req_status_code IN ('PEND', 'CON')    
                     AND rd.bank_group_code = mv.bank_group_code    
                     AND rd.cty_code = mv.cty_code    
                     AND rd.init_req_id = mv.init_req_id    
                     AND rd.req_sr_no = mv.req_sr_no    
                     AND rd.prod_limit_id = p_Cust_Limit_Rec.limit_id 
                     AND mb_limit.cpty_id IN ('*', NVL(rd.cpty_id, '*'))
                     AND mb_limit.cpty_cty_code IN ('*', NVL(rd.cpty_cty_code, '*'))
                     --AND mb_limit.limit_type_code = rd.limit_type_code
                     AND ( mb_limit.sub_product_type_code='*' OR mb_limit.sub_product_type_code LIKE
                     '%' || NVL(rd.sub_product_type_code, '*') || '%' )
                     AND ((NVL(rd.bill_tenor, 0) BETWEEN mb_limit.from_tenor AND
                         mb_limit.to_tenor))
                     AND ((NVL(rd.total_credit_period, 0) BETWEEN
                         mb_limit.from_validity AND mb_limit.to_validity)));
                EXCEPTION
                  WHEN OTHERS THEN
                    p_ret_code := 'SCBP_TLS_CUST_CONVERT_O2CBR : While converting the Inner' || SQLCODE;
               END;
               v_offer_flag   := 'N';
               v_offer_reason := NULL;
          END IF;

          IF (mb_limit.limit_cat_code <> 'R') THEN
            \* create movement *\
            BEGIN
                INSERT INTO SCBT_T_PROD_LIMIT_MVMT
                  (BANK_GROUP_CODE,
                   CTY_CODE,
                   LIMIT_ID,
                   LIMIT_TREE_TYPE_CODE,
                   TXN_CCY_CODE,
                   TXN_CCY_AMT,
                   OBLIGOR_ID,
                   INIT_REQ_ID,
                   REQ_SR_NO,
                   OFFERING_FLAG,
                   OFFERING_REASON)
                  (SELECT rd.bank_group_code, rd.cty_code, mb_limit.limit_id, 'PROD',
                         rd.txn_ccy_code, rd.txn_ccy_amt, mb_limit.cust_id, rd.init_req_id,
                          rd.req_sr_no,'',''
                     FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd,
                          SCBT_T_PROD_LIMIT_REQ_LOG     rh,
                          SCBT_T_PROD_LIMIT_MVMT        mv
                    WHERE mv.bank_group_code = p_Bank_Group_Code
                     AND mv.cty_code = p_Cty_Code
                     AND mv.limit_id = p_Cust_Limit_Rec.limit_id
                     AND rh.bank_group_code = mv.bank_group_code    
                     AND rh.cty_code = mv.cty_code     
                     AND rh.init_req_id = mv.init_req_id    
                     AND rh.req_type_code = 'NEW'    
                     AND rh.req_status_code IN ('PEND', 'CON')    
                     AND rd.bank_group_code = mv.bank_group_code    
                     AND rd.cty_code = mv.cty_code    
                     AND rd.init_req_id = mv.init_req_id    
                     AND rd.req_sr_no = mv.req_sr_no    
                     AND rd.prod_limit_id = p_Cust_Limit_Rec.limit_id);

               EXCEPTION
               WHEN OTHERS THEN
                   p_ret_code := 'Converting Outer to Co-Borrower : Duplicate entry in Mvmt : Limit ID : '
                            || mb_limit.limit_id;
                   RETURN;
               END;
            END IF;
            -- call Update Util Amt for mb_limit.limit_id, mb_limit.limit_ccy_code;
            SCBP_TLS_UPDATE_LIMIT_UTIL(p_ret_code,
                                       p_Bank_Group_Code,
                                       p_Cty_Code,
                                       mb_limit.limit_id,
                                       mb_limit.limit_ccy_code,
                     'PROD');

            \* if outer exists, create movement for outer as well *\
            WHILE (v_outer_limit_id IS NOT NULL) LOOP
                  BEGIN
                    INSERT INTO SCBT_T_PROD_LIMIT_MVMT
                      (BANK_GROUP_CODE,
                       CTY_CODE,
                       LIMIT_ID,
                       LIMIT_TREE_TYPE_CODE,
                       TXN_CCY_CODE,
                       TXN_CCY_AMT,
                       OBLIGOR_ID,
                       INIT_REQ_ID,
                       REQ_SR_NO,
                       OFFERING_FLAG,
                       OFFERING_REASON)
                      (SELECT rd.bank_group_code, rd.cty_code, v_outer_limit_id, 'PROD',
                             rd.txn_ccy_code, rd.txn_ccy_amt, mb_limit.cust_id, rd.init_req_id,
                              rd.req_sr_no,'',''
                         FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd,
                              SCBT_T_PROD_LIMIT_REQ_LOG     rh,
                              SCBT_T_PROD_LIMIT_MVMT        mv
                        WHERE mv.bank_group_code = p_Bank_Group_Code
                         AND mv.cty_code = p_Cty_Code
                         AND mv.limit_id = p_Cust_Limit_Rec.limit_id
                         AND rh.bank_group_code = mv.bank_group_code    
                         AND rh.cty_code = mv.cty_code     
                         AND rh.init_req_id = mv.init_req_id    
                         AND rh.req_type_code = 'NEW'    
                         AND rh.req_status_code IN ('PEND', 'CON')    
                         AND rd.bank_group_code = mv.bank_group_code    
                         AND rd.cty_code = mv.cty_code    
                         AND rd.init_req_id = mv.init_req_id    
                         AND rd.req_sr_no = mv.req_sr_no    
                         AND rd.prod_limit_id = p_Cust_Limit_Rec.limit_id);
                   EXCEPTION
                   WHEN OTHERS THEN
                       p_ret_code := 'Converting Outer to Co-Borrower : Duplicate entry in Mvmt : Limit ID : '
                                || v_outer_limit_id ;
                       RETURN;
                   END;

                  -- call Update Util Amt for mb_limit.limit_id, mb_limit.limit_ccy_code;
                  SCBP_TLS_UPDATE_LIMIT_UTIL(p_ret_code,
                                             p_Bank_Group_Code,
                                             p_Cty_Code,
                                             v_outer_limit_id,
                                             v_outer_limit_ccy_code,
                       'PROD');                   
                   IF (v_outer_limit_cat_code = 'I') THEN
                        BEGIN
                          SELECT limit_id,
                                 limit_product_code,
                                 limit_type_code,
                                 limit_ccy_code,
                                 limit_cat_code,
                                 inner_to_id
                          INTO v_outer_limit_id,
                                 v_outer_prod_code,
                                 v_outer_type_code,
                                 v_outer_limit_ccy_code,
                                 v_outer_limit_cat_code,
                                 v_inner_to_id
                            FROM SCBT_R_CUST_PRODUCT_LIMIT
                           WHERE bank_group_code = p_Bank_Group_Code
                             AND cty_code = p_Cty_Code
                             AND cust_id = mb_limit.cust_id
                             AND ext_limit_id = v_inner_to_id;
                       EXCEPTION
                          WHEN OTHERS THEN
                          p_ret_code := 'Converting Outer to Co-Borrower : outter limit id ' || mb_limit.inner_to_id || ' not found';
                          RETURN;
                       END;
                  ELSE
                       v_outer_limit_id := NULL;     
            
                  END IF;
               
            END LOOP;
    END LOOP;

    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      p_ret_code := 'SCBP_TLS_CUST_CONVERT_O2CBR :' || SQLCODE;
  END;

END SCBP_TLS_CUST_CONVERT_O2CBR;*/

--************************************************************************************

PROCEDURE SCBP_TLS_PROD_COMP_RESTR(p_ret_code                IN OUT VARCHAR2,  
                                   p_create_restr            IN OUT BOOLEAN,
                                   p_Bank_Group_Code         IN VARCHAR2,    
                                   p_Cty_Code                IN VARCHAR2,    
                                   p_Old_Cust_Limit_Rec      IN cOldCustLimit%ROWTYPE,
                                   p_New_Cust_Limit_Rec      IN cNewCustLimit%ROWTYPE) IS     

BEGIN
   
   IF p_Old_Cust_Limit_Rec.limit_id             = p_New_Cust_Limit_Rec.limit_id            AND
      -- p_Old_Cust_Limit_Rec.init_req_id          = p_New_Cust_Limit_Rec.init_req_id           AND
      --p_Old_Cust_Limit_Rec.req_type_code         = p_New_Cust_Limit_Rec.req_type_code         AND
      --p_Old_Cust_Limit_Rec.req_status_code       = p_New_Cust_Limit_Rec.req_status_code       AND
      --p_Old_Cust_Limit_Rec.req_sr_no             = p_New_Cust_Limit_Rec.req_sr_no             AND
      p_Old_Cust_Limit_Rec.cpty_id               = p_New_Cust_Limit_Rec.cpty_id               AND
      p_Old_Cust_Limit_Rec.cpty_cty_code         = p_New_Cust_Limit_Rec.cpty_cty_code        AND
      p_Old_Cust_Limit_Rec.limit_type_code      = p_New_Cust_Limit_Rec.limit_type_code       AND 
      p_Old_Cust_Limit_Rec.sub_product_type_code = p_New_Cust_Limit_Rec.sub_product_type_code AND
      p_Old_Cust_Limit_Rec.from_tenor            = p_New_Cust_Limit_Rec.from_tenor            AND
      p_Old_Cust_Limit_Rec.to_tenor              = p_New_Cust_Limit_Rec.to_tenor              AND
      --p_Old_Cust_Limit_Rec.total_credit_period   = p_New_Cust_Limit_Rec.total_credit_period   AND
      p_Old_Cust_Limit_Rec.from_validity         = p_New_Cust_Limit_Rec.from_validity         AND
      p_Old_Cust_Limit_Rec.to_validity           = p_New_Cust_Limit_Rec.to_validity           THEN
  
      p_create_restr   := FALSE;
  
  ELSE  
         
      p_create_restr   := TRUE;
  
  END IF; 

END SCBP_TLS_PROD_COMP_RESTR;

--************************************************************************************

PROCEDURE SCBP_TLS_PROD_CREATE_R(p_ret_code        IN OUT VARCHAR2,
                                 p_Bank_Group_Code IN VARCHAR2,
                                 p_Cty_Code        IN VARCHAR2,
                                 p_New_StepId      IN VARCHAR2,
                                 p_Limit_Rec       IN cNewCustLimit%ROWTYPE) IS
BEGIN
    
  INSERT INTO SCBT_T_PROD_LIMIT_UTIL
    (bank_group_code,
     cty_code,
     limit_id,
     limit_tree_type_code,
     limit_ccy_code,
     limit_ccy_pend_inc_amt,
     limit_ccy_pend_dec_amt,
     limit_ccy_utilised_amt,
    limit_ccy_available_amt)
  VALUES
    (p_Bank_Group_Code,
     p_Cty_Code,
     p_Limit_Rec.limit_id,
     'PROD',
     p_Limit_Rec.limit_ccy_code,
     0,
     0,
     0,
    0);

  INSERT INTO SCBT_T_PROD_LIMIT_MVMT
    (BANK_GROUP_CODE,      
    CTY_CODE,             
     LIMIT_ID,             
     INIT_REQ_ID,          
     REQ_SR_NO,            
     TXN_CCY_CODE,         
     TXN_CCY_AMT,          
     LIMIT_TREE_TYPE_CODE, 
     OBLIGOR_ID,           
     OFFERING_FLAG,        
     OFFERING_REASON)      
    SELECT mv.BANK_GROUP_CODE,  
           mv.CTY_CODE,         
           p_Limit_Rec.limit_id,
           mv.INIT_REQ_ID,      
           mv.REQ_SR_NO,        
           mv.TXN_CCY_CODE,     
           mv.TXN_CCY_AMT,      
           'PROD',               
           mv.OBLIGOR_ID,       
           'N',                  
           NULL                       
      FROM SCBT_T_PROD_LIMIT_MVMT   mv,
           SCBT_T_PROD_LIMIT_REQ_LOG     rh,
           SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd
     WHERE mv.limit_id = p_Limit_Rec.inner_to_id
       AND rh.init_req_id = mv.init_req_id
       AND rh.req_type_code = 'NEW'
       AND rh.req_status_code IN ('PEND', 'CON')
       AND mv.init_req_id = rd.init_req_id
       AND mv.req_sr_no = rd.req_sr_no
       AND rd.prod_limit_id = p_Limit_Rec.Inner_To_Id
       AND p_Limit_Rec.cpty_id IN ('*', NVL(rd.cpty_id, '*'))
       AND p_Limit_Rec.cpty_cty_code IN ('*', NVL(rd.cpty_cty_code, '*'))
       AND p_Limit_Rec.limit_type_code = rd.limit_type_code
       AND ( p_Limit_Rec.sub_product_type_code='*' OR p_Limit_Rec.sub_product_type_code LIKE
       '%' || NVL(rd.sub_product_type_code, '*') || '%' )
       AND ((NVL(rd.bill_tenor, 0) BETWEEN p_Limit_Rec.from_tenor AND
           p_Limit_Rec.to_tenor))
       AND ((NVL(rd.total_credit_period, 0) BETWEEN
           p_Limit_Rec.from_validity AND p_Limit_Rec.to_validity));

  IF SQL%rowcount > 0 THEN
     SCBP_TLS_UPDATE_LIMIT_UTIL(p_ret_code,
                                p_bank_group_code,
                                p_cty_code,
                                p_Limit_Rec.limit_id,
                                p_Limit_Rec.limit_ccy_code,
                'PROD');
  END IF;

  RETURN;
  
EXCEPTION
  WHEN OTHERS THEN
    p_ret_code := SUBSTR(SQLERRM, 1, 150);
 
END SCBP_TLS_PROD_CREATE_R;

--********************************************************************************

PROCEDURE SCBP_TLS_PROD_DEL_R(p_ret_code IN OUT VARCHAR2,
                              p_limit_id VARCHAR2)
IS
BEGIN

   DELETE SCBT_T_PROD_LIMIT_MVMT
   WHERE limit_id = p_limit_id;

   DELETE SCBT_T_PROD_LIMIT_UTIL
   WHERE limit_id = p_limit_id;

   RETURN;
EXCEPTION
  WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);
     
END SCBP_TLS_PROD_DEL_R;

--************************************************************--

PROCEDURE SCBP_TLS_PROD_CREATE_O(p_ret_code        IN OUT VARCHAR2,
                                 p_bank_group_code IN VARCHAR2,
                                 p_cty_code        IN VARCHAR2,
                                 p_cust_id         IN VARCHAR2,
                                 p_Limit_rec       cNewCustLimit%ROWTYPE) IS
  BEGIN
            
      INSERT INTO SCBT_T_PROD_LIMIT_UTIL(BANK_GROUP_CODE,
                                           CTY_CODE,
                                           LIMIT_ID,
                                           LIMIT_TREE_TYPE_CODE,
                                      LIMIT_CCY_CODE,
                                           LIMIT_CCY_PEND_INC_AMT,
                                           LIMIT_CCY_PEND_DEC_AMT,
                                     LIMIT_CCY_UTILISED_AMT,
                                           LIMIT_CCY_AVAILABLE_AMT)
                                   VALUES (p_bank_group_code, 
                                           p_cty_code, 
                                           p_Limit_rec.limit_id,
                                           'PROD',
                                           p_Limit_rec.limit_ccy_code,
                                  0,
                                           0,
                                           0,
                                           0);
            
  END SCBP_TLS_PROD_CREATE_O;


--********************************************************************************

PROCEDURE SCBP_TLS_PROD_CONVERT_O2I (p_ret_code IN OUT VARCHAR2,
                                     p_bank_group_code IN  VARCHAR2,
                                     p_cty_code IN  VARCHAR2,
                                     p_inner_Limit_rec IN cNewCustLimit%ROWTYPE)
IS
BEGIN
DECLARE
       V_OUTER_LIMIT_ID                   SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
       V_OUTER_LIMIT_CCY                  SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE;


    V_NEXT_OUTER_LIMIT_ID SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;

BEGIN

    v_outer_limit_id := p_inner_Limit_rec.Inner_To_Id;

    WHILE v_outer_limit_id <> ' ' LOOP
       BEGIN
            SELECT t1.LIMIT_CCY_CODE,
                   NVL((SELECT t2.limit_id
                         FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST t2
                        WHERE t2.ext_limit_id = t1.inner_to_id
                          AND t2.cust_id = t1.cust_id
                          AND t2.step_id = t1.step_id
                          AND ROWNUM = 1),
                       ' ')
              INTO V_OUTER_LIMIT_CCY, V_NEXT_OUTER_LIMIT_ID
              FROM SCBT_R_CUST_PRODUCT_LIMIT_HIST t1
             WHERE t1.LIMIT_ID = v_outer_limit_id
               AND t1.step_id = p_inner_Limit_rec.Step_Id
            AND t1.BANK_GROUP_CODE = p_bank_group_code
            AND t1.cty_code = p_cty_code;
      EXCEPTION
              WHEN OTHERS THEN
                   p_ret_code := 'Converting Prod Outer to Inner : Limit id ' || v_outer_limit_id || ' not found in Hist for step id : ' || p_inner_Limit_rec.Step_Id;
            RETURN;
       END;

       /*IF b_init_amt = TRUE THEN
          BEGIN
             SELECT LIMIT_CCY_PEND_INC_AMT,
                    LIMIT_CCY_PEND_DEC_AMT,
                    LIMIT_CCY_UTILISED_AMT
               INTO N_LIMIT_PEND_INC,N_LIMIT_PEND_DEC, N_LIMIT_UTILIZED
               FROM SCBT_T_PROD_LIMIT_UTIL
              WHERE LIMIT_ID = p_inner_Limit_rec.Limit_Id;

          EXCEPTION

               WHEN OTHERS THEN
                    p_ret_code := 'Converting Prod Outer to Inner : Limit id ' || p_inner_Limit_rec.Limit_Id || ' not found in Util';
              RETURN;
          END;

          b_init_amt := FALSE;

      END IF;

     BEGIN
        N_CONV_PEND_INC := Scbf_Tls_Exch_Rate(p_bank_group_code,
                         p_cty_code,
                         p_inner_Limit_rec.Limit_Ccy_Code,
                         NVL(N_LIMIT_PEND_INC,0),
                         V_OUTER_LIMIT_CCY,
                         'N');

        N_CONV_PEND_DEC := Scbf_Tls_Exch_Rate(p_bank_group_code,
                         p_cty_code,
                         p_inner_Limit_rec.Limit_Ccy_Code,
                         NVL(N_LIMIT_PEND_DEC,0),
                         V_OUTER_LIMIT_CCY,
                         'N');
        N_CONV_UTILIZED := Scbf_Tls_Exch_Rate(p_bank_group_code,
                         p_cty_code,
                         p_inner_Limit_rec.Limit_Ccy_Code,
                         NVL(N_LIMIT_UTILIZED,0),
                          V_OUTER_LIMIT_CCY,
                         'N');
      EXCEPTION
         WHEN OTHERS THEN
           p_ret_code := 'Converting Outer to Inner : Exceptoin while getting the exchange rate';
           RETURN;
      END;*/

    BEGIN
            
/*        INSERT INTO SCBT_T_PROD_LIMIT_MVMT 
          (bank_group_code,
           cty_code,
           limit_id,
           init_req_id,
           req_sr_no,
           txn_ccy_code,
           txn_ccy_amt,
           limit_tree_type_code,
           obligor_id,
           offering_flag,
           offering_reason)
          SELECT m.bank_group_code,
                 m.cty_code,
                 V_OUTER_LIMIT_ID,
                 m.init_req_id,
                 m.req_sr_no,
                 m.txn_ccy_code,
                 m.txn_ccy_amt,
                 m.limit_tree_type_code,
                 m.obligor_id,
                 'N',
                 NULL
      FROM SCBT_T_PROD_LIMIT_MVMT m, SCBT_T_PROD_LIMIT_REQ_LOG l
     WHERE m.init_req_id = l.init_req_id
     AND m.bank_group_code = p_Bank_Group_Code
      AND m.cty_code = p_Cty_Code
      AND l.bank_group_code = m.bank_group_code
      AND l.cty_code = m.cty_code
       AND l.req_type_code = 'NEW'
       AND l.req_status_code IN ('PEND', 'CON')
       AND m.limit_id = p_inner_Limit_rec.Limit_Id;*/
       
        INSERT INTO SCBT_T_PROD_LIMIT_MVMT (BANK_GROUP_CODE,CTY_CODE,LIMIT_ID,TXN_CCY_CODE,
                                            TXN_CCY_AMT,LIMIT_TREE_TYPE_CODE,OBLIGOR_ID,INIT_REQ_ID,REQ_SR_NO)
                                     SELECT m.bank_group_code,m.cty_code,V_OUTER_LIMIT_ID,
                                            m.txn_ccy_code,m.txn_ccy_amt,m.limit_tree_type_code,m.obligor_id,
                                            m.init_req_id, m.req_sr_no
                                       FROM SCBT_T_PROD_LIMIT_MVMT m, SCBT_T_PROD_LIMIT_REQ_LOG r
                                      WHERE m.bank_group_code = p_bank_group_code
                                        AND m.cty_code = p_cty_code
                                        AND limit_id = p_inner_Limit_rec.Limit_Id
                                        AND m.init_req_id = r.init_req_id
                                        AND r.req_type_code = 'NEW'
                                        AND r.req_status_code IN ('CON','PEND')
                                        AND (m.init_req_id, m.req_sr_no) NOT IN (SELECT d.init_req_id, d.req_sr_no
                                                                               FROM SCBT_T_PROD_LIMIT_MVMT d
                                                                              WHERE d.bank_group_code = p_bank_group_code
                                                                                AND d.cty_code        = p_cty_code
                                                                                AND d.limit_id        = V_OUTER_LIMIT_ID);
                                                                                       
       SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                           p_Bank_Group_Code,
                                           p_Cty_Code,
                                           v_outer_limit_id,
                                          V_OUTER_LIMIT_CCY,
                      'PROD');
             
        EXCEPTION
           WHEN OTHERS THEN
           p_ret_code := 'Converting Prod Outer to Inner : Unique key violation in Mvmt. Please check the limit setup';
           RETURN;
        END;

      v_outer_limit_id := v_next_outer_limit_id;

    END LOOP;

EXCEPTION

WHEN OTHERS THEN
      p_ret_code := 'SCBP_TLS_PROD_CONVERT_O2I : ' || SUBSTR(SQLERRM, 1, 150);
END;

END SCBP_TLS_PROD_CONVERT_O2I;

--***************************************************************************************--
FUNCTION SCBF_GET_OFFERING_REASON (p_Bank_Group_Code VARCHAR2,
                                   p_Cty_Code VARCHAR2,
                                   p_init_req_id VARCHAR2, 
                   p_req_sr_no VARCHAR2,
                                   p_Limit_rec cNewCustLimit%ROWTYPE)

RETURN VARCHAR2 IS
BEGIN
DECLARE

   v_total_credit_period       SCBT_T_PROD_LIMIT_REQ_LOG_DTL.total_credit_period%TYPE;
   v_bill_tenor                SCBT_T_PROD_LIMIT_REQ_LOG_DTL.bill_tenor%TYPE;
   v_revolving_lc_type         SCBT_T_PROD_LIMIT_REQ_LOG_DTL.revolving_lc_type%TYPE; 
   v_evergreen_lc_type         SCBT_T_PROD_LIMIT_REQ_LOG_DTL.evergreen_lc_type%TYPE;
   v_offering_reason           VARCHAR2(200) := NULL;
   
BEGIN
          SELECT total_credit_period, bill_tenor, revolving_lc_type, evergreen_lc_type
        INTO v_total_credit_period, v_bill_tenor, v_revolving_lc_type, v_evergreen_lc_type
      FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL 
           WHERE bank_group_code = p_Bank_Group_Code
             AND cty_code = p_Cty_Code
       AND prod_limit_id = p_Limit_rec.limit_id       
             AND init_req_id = p_init_req_id
             AND req_sr_no = p_req_sr_no;

          IF p_Limit_rec.From_Tenor > v_bill_tenor  OR p_Limit_rec.To_Tenor < v_bill_tenor THEN
             
       IF v_offering_reason IS NULL THEN
                v_offering_reason := 'TENR';
             ELSE
               v_offering_reason := v_offering_reason || ',TENR';
             END IF;

          END IF;

          IF p_Limit_rec.From_Validity > v_Total_Credit_Period OR p_Limit_rec.To_Validity < v_Total_Credit_Period THEN
             
       IF v_offering_reason IS NULL THEN
                v_offering_reason := 'VALD';
             ELSE
                v_offering_reason := v_offering_reason || ',VALD';
             END IF;
       
          END IF;
      
      IF (p_Limit_rec.revolving_lc_type <> '*') AND (p_Limit_rec.revolving_lc_type <> v_revolving_lc_type) THEN
          
        IF v_offering_reason IS NULL THEN
                v_offering_reason := 'RVLC';
              ELSE
                v_offering_reason := v_offering_reason || ',RVLC';
              END IF;
       
      END IF;

      IF (p_Limit_rec.evergreen_lc_type <> '*') AND (p_Limit_rec.evergreen_lc_type <> v_evergreen_lc_type) THEN
          
        IF v_offering_reason IS NULL THEN
                v_offering_reason := 'EGLC';
              ELSE
                v_offering_reason := v_offering_reason || ',EGLC';
              END IF;
       
      END IF;
            
 RETURN v_Offering_reason;

EXCEPTION
    WHEN OTHERS THEN
         RETURN NULL;
END;
END SCBF_GET_OFFERING_REASON;

--***************************************************************************************--
PROCEDURE SCBP_UPDATE_OFFERING_REASON(p_ret_code IN OUT VARCHAR2,
                        p_bank_group_code IN VARCHAR2,
                      p_cty_code IN VARCHAR2,
                      p_cust_id  IN VARCHAR2,
                      p_newlimit_rec IN cNewCustLimit%ROWTYPE) IS
                   
  p_off_flag       SCBT_T_PROD_LIMIT_MVMT.offering_flag%TYPE;
  p_off_reason     SCBT_T_PROD_LIMIT_MVMT.offering_reason%TYPE;

  CURSOR off_limit_cur IS
  SELECT rd.init_req_id, rd.req_sr_no
    FROM SCBT_T_PROD_LIMIT_REQ_LOG rh,
         SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd
   WHERE rd.bank_group_code = p_bank_group_code
     AND rd.cty_code = p_cty_Code
     AND rd.prod_limit_id = p_newlimit_rec.Limit_Id
     AND rh.bank_group_code = p_bank_group_code
     AND rh.cty_code = p_cty_Code
     AND rh.init_req_id = rd.init_req_id
     AND rh.req_type_code = 'NEW' 
     AND rh.req_status_code = 'PEND'; 
                       
BEGIN
  
  FOR lmt IN off_limit_cur LOOP
  
      p_off_flag := NULL;
    p_off_reason := NULL;
    
    p_off_reason := SCBF_GET_OFFERING_REASON(p_bank_group_code,
                                 p_cty_code,
                          lmt.init_req_id,
                          lmt.req_sr_no,
                         p_newlimit_rec);
                                    
    IF p_off_reason IS NOT NULL THEN
       
       p_off_flag := 'Y';
       
    END IF;
    
    UPDATE SCBT_T_PROD_LIMIT_MVMT
         SET OFFERING_FLAG   = p_off_flag,
             OFFERING_REASON = p_off_reason
       WHERE BANK_GROUP_CODE = P_BANK_GROUP_CODE
         AND CTY_CODE = P_CTY_CODE
         AND LIMIT_ID = p_newlimit_rec.Limit_Id
       AND INIT_REQ_ID = lmt.init_req_id
       AND REQ_SR_NO = lmt.req_sr_no;
       
  END LOOP;                         
                    
END SCBP_UPDATE_OFFERING_REASON;                    
--***************************************************************************************--

PROCEDURE SCBP_TLS_CHANGE_CCY (p_ret_code IN OUT VARCHAR2,
                               p_bank_group_code VARCHAR2,
                               p_cty_code VARCHAR2,
                               p_limit_id VARCHAR2,
                               p_old_ccy_code VARCHAR2,
                               p_new_ccy_code VARCHAR2)
IS
BEGIN

     UPDATE SCBT_T_PROD_LIMIT_UTIL
     SET
     limit_ccy_code = p_new_ccy_code,

     limit_ccy_pend_inc_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_pend_inc_amt,0),
                                                 p_new_ccy_code,
                                                'N'),
     limit_ccy_pend_dec_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_pend_dec_amt,0),
                                                 p_new_ccy_code,
                                                 'N'),
     limit_ccy_utilised_amt = Scbf_Tls_Exch_Rate(p_bank_group_code,
                                                 p_Cty_Code,
                                                 p_old_ccy_code,
                                                 NVL(limit_ccy_utilised_amt,0),
                                                 p_new_ccy_code,
                                                 'N')
     WHERE limit_id = p_limit_id
     AND cty_code = p_cty_code
     AND bank_group_code = p_bank_group_code;

     RETURN;

EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_TLS_CHANGE_CCY;

--*******************************************************************************--

PROCEDURE SCBP_P_PROCESS_GRP_TNR (p_ret_code IN OUT VARCHAR2,
                                  p_bank_group_code VARCHAR2,
                                  p_cty_code VARCHAR2,
                                  p_cust_id VARCHAR2,
                                  l_prod_limit_id VARCHAR2,
                                  p_tenor VARCHAR2,
                                  p_grp_limit_id VARCHAR2)
IS

p_limit_id      SCBT_T_PROD_LIMIT_MVMT.LIMIT_ID%TYPE;

CURSOR TNR_REQ IS
SELECT D.INIT_REQ_ID, D.REQ_SR_NO, D.BILL_TENOR
  FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL D,
       SCBT_T_PROD_LIMIT_REQ_LOG R
 WHERE D.BANK_GROUP_CODE = p_bank_group_code
   AND D.CTY_CODE = p_cty_code
   AND D.BANK_GROUP_CODE = R.BANK_GROUP_CODE
   AND D.CTY_CODE = R.CTY_CODE
   AND D.INIT_REQ_ID = R.INIT_REQ_ID
   AND R.REQ_STATUS_CODE = 'PEND'
   AND D.PROD_LIMIT_ID = p_limit_id;

l_startpos      INTEGER := 0;
l_endpos        INTEGER;
l_del           VARCHAR2(1) := ',';
l_value         NUMBER := 0; 
l_cnt           INTEGER := 0; 

BEGIN

        LOOP

            BEGIN 

                l_cnt := l_cnt + 1;
                
                IF NVL(INSTR(l_prod_limit_id, l_del, 1, l_cnt),0) != 0 THEN
                        l_endpos := INSTR(l_prod_limit_id, l_del, 1, l_cnt) - l_startpos;
                ELSE
                        l_endpos := LENGTH(l_prod_limit_id) - l_startpos+1; 
                END IF; 
        
                l_startpos := l_startpos + 1; 
                
                l_value := SUBSTR(l_prod_limit_id, l_startpos,l_endpos -1);
        
                IF l_value IS NULL THEN
                   EXIT;
                END IF;        
                

                p_limit_id := l_value;
                           
                FOR req IN TNR_REQ LOOP
                               
                    IF p_tenor < req.bill_tenor THEN
                                  
                       UPDATE SCBT_T_PROD_LIMIT_MVMT
                          SET OFFERING_REASON = OFFERING_REASON || ',TENR',
                              OFFERING_FLAG = 'Y'
                        WHERE LIMIT_ID = l_value
                          AND CTY_CODE = p_cty_code
                          AND BANK_GROUP_CODE = p_bank_group_code
                          AND INIT_REQ_ID = req.init_req_id;
                                     
                    ELSE

                       UPDATE SCBT_T_PROD_LIMIT_MVMT
                          SET OFFERING_REASON = NULL,
                              OFFERING_FLAG = NULL
                        WHERE LIMIT_ID = l_value
                          AND CTY_CODE = p_cty_code
                          AND BANK_GROUP_CODE = p_bank_group_code
                          AND INIT_REQ_ID = req.init_req_id
                          AND OFFERING_REASON = 'TENR';                               
                               
                    END IF;
                               
                END LOOP;
                         
                l_startpos := LENGTH(l_value) + l_startpos;
                
                IF l_value IS NULL THEN
                   EXIT;
                END IF;
                
                
                EXCEPTION
                WHEN OTHERS THEN
                     EXIT;
                END;

      
        END LOOP;

EXCEPTION

WHEN OTHERS THEN
       p_ret_code := SUBSTR(SQLERRM, 1, 150);

END SCBP_P_PROCESS_GRP_TNR;

--*******************************************************************************--

PROCEDURE SCBP_DELETE_PRD_GRP_LIMIT (p_ret_code IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                      p_cty_code VARCHAR2,
                                       p_cust_id VARCHAR2,                   
                                      p_prod_grp_limit_id VARCHAR2,
                                     p_prod_limit_id     VARCHAR2)
IS
BEGIN

   DELETE FROM  SCBT_T_PROD_LIMIT_MVMT
         WHERE  limit_id = p_prod_grp_limit_id
           AND (init_req_id, req_sr_no) IN (SELECT init_req_id, req_sr_no
                                              FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL
                                             WHERE prod_limit_id = p_prod_limit_id)
                                               AND bank_group_code = p_bank_group_code
                                               AND cty_code = p_cty_code;
         
END SCBP_DELETE_PRD_GRP_LIMIT;

--**************************************************************************--

PROCEDURE SCBP_CREATE_PRD_GRP_LIMIT (p_ret_code IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                      p_cty_code VARCHAR2,
                                       p_cust_id VARCHAR2,                   
                                      p_prod_grp_limit_id VARCHAR2,
                                     p_prod_limit_id     VARCHAR2)
IS
     
   BEGIN
   
        /*INSERT INTO SCBT_T_PROD_LIMIT_MVMT (BANK_GROUP_CODE,CTY_CODE,LIMIT_ID,TXN_CCY_CODE,
                     TXN_CCY_AMT,LIMIT_TREE_TYPE_CODE,OBLIGOR_ID,INIT_REQ_ID,REQ_SR_NO)                         
             SELECT p_bank_group_code,p_cty_code,p_prod_grp_limit_id,
                    m.txn_ccy_code,m.txn_ccy_amt,'GPROD',p_Cust_id,m.init_req_id, m.req_sr_no
               FROM SCBT_T_PROD_LIMIT_MVMT m
              WHERE m.bank_group_code = p_bank_group_code
                AND m.cty_code        = p_cty_code
                AND limit_id          = p_prod_limit_id
                AND (init_req_id, req_sr_no) IN (SELECT d.init_req_id, d.req_sr_no
                                                   FROM SCBT_T_PROD_LIMIT_REQ_LOG_DTL d,
                                                        SCBT_T_PROD_LIMIT_REQ_LOG     r,
                                                        SCBT_T_PROD_LIMIT_MVMT n
                                                  WHERE d.obligor_id = p_cust_id
                                                    AND d.cty_code = p_cty_code
                                                    AND d.cty_code = r.cty_code
                                                    AND r.req_type_code = 'NEW'
                                                    AND r.req_status_code IN ('CON','PEND')
                                                    AND d.init_req_id = n.init_req_id
                                                    AND d.req_sr_no   = n.req_sr_no
                                                    AND n.limit_id    =  p_prod_grp_limit_id
                                                    AND d.init_req_id = r.init_req_id);*/

        INSERT INTO SCBT_T_PROD_LIMIT_MVMT (BANK_GROUP_CODE,CTY_CODE,LIMIT_ID,TXN_CCY_CODE,
                                            TXN_CCY_AMT,LIMIT_TREE_TYPE_CODE,OBLIGOR_ID,INIT_REQ_ID,REQ_SR_NO)
                                     SELECT p_bank_group_code,p_cty_code,p_prod_grp_limit_id,
                                            m.txn_ccy_code,m.txn_ccy_amt,'GPROD',p_Cust_id,m.init_req_id, m.req_sr_no
                                       FROM SCBT_T_PROD_LIMIT_MVMT m, SCBT_T_PROD_LIMIT_REQ_LOG r, SCBT_T_PROD_LIMIT_REQ_LOG_DTL d
                                      WHERE m.bank_group_code = p_bank_group_code
                                        AND d.bank_group_code = m.bank_group_code
                                        AND m.cty_code = p_cty_code
                                        AND d.cty_code = m.cty_code
/* JP 08-JAN-2013 MOVEMENT TO BE CONSIDERED ONLY FOR PRODWISE UTILISATION AND m.limit_id = p_prod_limit_id */
                                        AND d.prod_limit_id = p_prod_limit_id
                                        AND m.limit_id = d.prod_limit_id                                        
                                        AND m.init_req_id = r.init_req_id
                                        AND d.init_req_id = m.init_req_id
                                        AND m.req_sr_no   = d.req_sr_no
                                        AND r.req_type_code = 'NEW'
                                        AND r.req_status_code IN ('CON','PEND')
                                        AND (m.init_req_id, m.req_sr_no) NOT IN (SELECT d.init_req_id, d.req_sr_no
                                                                               FROM SCBT_T_PROD_LIMIT_MVMT d
                                                                              WHERE d.bank_group_code = p_bank_group_code
                                                                                AND d.cty_code        = p_cty_code
                                                                                AND d.limit_id        = p_prod_grp_limit_id);
     
  -- END;
   
END SCBP_CREATE_PRD_GRP_LIMIT;

--**************************************************************************--

PROCEDURE SCBP_VAL_PROD_LIMIT (p_ret_code IN OUT VARCHAR2,
                               p_bank_group_code VARCHAR2,
                               p_cty_code VARCHAR2,
                                cust_id VARCHAR2,                   
                               l_prod_limit_id     VARCHAR2,
                               p_prod_limit_id     VARCHAR2,
                               p_action_code       VARCHAR2,
                               p_prod_grp_limit_id VARCHAR2)
IS
--BEGIN

--DECLARE

l_startpos      INTEGER := 0;
l_endpos        INTEGER;
l_del           VARCHAR2(1) := ',';
l_value         NUMBER := 0; 
l_cnt           INTEGER := 0; 

p_startpos      INTEGER := 0;
p_endpos        INTEGER;
p_del           VARCHAR2(1) := ',';
p_value         NUMBER := 0; 
p_found         INTEGER;
p_cnt           INTEGER := 0; 

BEGIN

        LOOP

                BEGIN 

                l_cnt := l_cnt + 1;
                
                IF NVL(INSTR(l_prod_limit_id, l_del, 1, l_cnt),0) != 0 THEN
                        l_endpos := INSTR(l_prod_limit_id, l_del, 1, l_cnt) - l_startpos;
                ELSE
                        l_endpos := LENGTH(l_prod_limit_id) - l_startpos+1; 
                END IF; 
        
                l_startpos := l_startpos + 1; 
                
                l_value := SUBSTR(l_prod_limit_id, l_startpos,l_endpos -1);
        
                IF l_value IS NULL THEN
                   EXIT;
                END IF;        
                
                LOOP
                
                   BEGIN 
                        p_cnt := p_cnt + 1;
                               
                        IF NVL(INSTR(p_prod_limit_id, p_del, 1, p_cnt),0) != 0 THEN
                           p_endpos := INSTR(p_prod_limit_id, p_del, 1, p_cnt) - p_startpos;
                        ELSE
                           p_endpos := LENGTH(p_prod_limit_id) - p_startpos+1; 
                        END IF; 
                        p_startpos := p_startpos + 1; 
                                
                        p_value := SUBSTR(p_prod_limit_id, p_startpos,p_endpos -1);
                              
                        IF l_value != NVL(p_value,0) THEN
                           p_found := 0;
                        ELSE 
                           p_found := 1;
                           p_cnt := 0;
                           p_startpos := 0;
                           EXIT;
                        END IF;
                                
                        IF p_value IS NULL THEN
                           p_cnt := 0;
                           p_startpos := 0;
                        END IF;
                                                                      
                        IF p_value IS NULL THEN
                           p_startpos := 0;
                        ELSE        
                           p_startpos := LENGTH(p_value) + p_startpos;
                        END IF;
                
                        IF (p_value != l_value OR p_value IS NULL) AND p_found = 0 THEN
            
                           IF p_action_code = 'DELETE' THEN
                  
                              SCBP_DELETE_PRD_GRP_LIMIT (p_ret_code, 
                                                          p_bank_group_code,
                                                         p_cty_code,
                                                          cust_id,
                                                          p_prod_grp_limit_id,
                                                         l_value);
                
                           END IF;
                            
                           IF p_action_code = 'CREATE' THEN

                              SCBP_CREATE_PRD_GRP_LIMIT (p_ret_code, 
                                                          p_bank_group_code,
                                                         p_cty_code,
                                                          cust_id,
                                                          p_prod_grp_limit_id,
                                                         l_value);
                               
                           END IF;

                           EXIT;
               
                        END IF;
                                
                                
                        EXCEPTION
                             WHEN OTHERS THEN
                                  p_ret_code := SUBSTR(SQLERRM, 1, 150);
                                  EXIT;
                             END;

                END LOOP;
                                        
        l_startpos := LENGTH(l_value) + l_startpos;
                
                IF l_value IS NULL THEN
                   EXIT;
                END IF;
                                
                EXCEPTION

                WHEN OTHERS THEN
                     EXIT;
                END;
      
        END LOOP;

EXCEPTION

WHEN OTHERS THEN
       p_ret_code := SUBSTR(SQLERRM, 1, 150);
    
END SCBP_VAL_PROD_LIMIT;

--**************************************************************************--

PROCEDURE SCBP_CRE_PROD_LIMIT (p_ret_code IN OUT VARCHAR2,
                               p_bank_group_code VARCHAR2,
                               p_cty_code VARCHAR2,
                                cust_id VARCHAR2,                   
                               l_prod_limit_id     VARCHAR2,
                               l_prod_grp_limit_id VARCHAR2)
IS

l_startpos      INTEGER := 0;
l_endpos        INTEGER;
l_del           VARCHAR2(1) := ',';
l_value         NUMBER := 0; 
l_cnt           INTEGER := 0; 

BEGIN

        LOOP

            BEGIN 

                l_cnt := l_cnt + 1;
                
                IF NVL(INSTR(l_prod_limit_id, l_del, 1, l_cnt),0) != 0 THEN
                        l_endpos := INSTR(l_prod_limit_id, l_del, 1, l_cnt) - l_startpos;
                ELSE
                        l_endpos := LENGTH(l_prod_limit_id) - l_startpos+1; 
                END IF; 
        
                l_startpos := l_startpos + 1; 
                
                l_value := SUBSTR(l_prod_limit_id, l_startpos,l_endpos -1);
        
                IF l_value IS NULL THEN
                   EXIT;
                END IF;        
                

                SCBP_CREATE_PRD_GRP_LIMIT (p_ret_code, 
                                            p_bank_group_code,
                                           p_cty_code,
                                            cust_id,
                                           l_prod_grp_limit_id,
                                           l_value);
                         
                l_startpos := LENGTH(l_value) + l_startpos;
                
                IF l_value IS NULL THEN
                   EXIT;
                END IF;
                
                
                EXCEPTION
                WHEN OTHERS THEN
                     p_ret_code := SUBSTR(SQLERRM, 1, 150);                
                     EXIT;
                END;

      
        END LOOP;

EXCEPTION

WHEN OTHERS THEN
       p_ret_code := SUBSTR(SQLERRM, 1, 150);
    
END SCBP_CRE_PROD_LIMIT;

--**************************************************************************--
--*******************************************************************************--
PROCEDURE SCBP_TLS_PROD_CONVERT_ALL_I2O(p_ret_code        IN OUT VARCHAR2,
                                        p_bank_group_code IN VARCHAR2,
                                        p_cty_code        IN VARCHAR2,
                                        p_inner_Limit_rec IN cOldCustLimit%ROWTYPE) IS

    CURSOR mb_all_inner IS
      SELECT LIMIT_PRODUCT_CODE, CUST_CTY_CODE, CPTY_ID, CUST_ID,
        CPTY_CTY_CODE, LIMIT_ID, LIMIT_TYPE_CODE,  EXT_LIMIT_ID, omnibus_risk,
        NVL((SELECT t2.limit_id FROM SCBT_R_CUST_PRODUCT_LIMIT t2 WHERE t2.ext_limit_id = lim.inner_to_id
        AND t2.cust_id = lim.cust_id AND ROWNUM = 1),' ') AS INNER_TO_ID,
        LIMIT_CAT_CODE, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT,
        -- NVL(lim.limit_share_id,'') AS LIMIT_SHARE_ID,
        STEP_ID, -- NVL(MAIN_BORROWER_ID,' ') AS MAIN_BORROWER_ID, 
        SUB_PRODUCT_TYPE_CODE,
        FROM_TENOR, TO_TENOR, FROM_VALIDITY, TO_VALIDITY, REVOLVING_LC_TYPE, EVERGREEN_LC_TYPE
        FROM SCBT_R_CUST_PRODUCT_LIMIT lim
       WHERE lim.bank_group_code = p_Bank_Group_Code
         AND lim.cty_code        = p_Cty_Code
         AND lim.cust_id         = p_inner_Limit_rec.cust_id
         AND lim.inner_to_id     = p_inner_Limit_rec.limit_id;

p_limit_found BOOLEAN;
lim1                  mb_all_inner%ROWTYPE;
BEGIN
      

   FOR lim IN mb_all_inner LOOP

      IF lim.limit_cat_code = 'I' THEN

         p_limit_found   := FALSE;
         
         /*OPEN cOldCustLimit;
         LOOP 
            UPDATE cOldCustLimit
               SET cOldCustLimit.limit_cat_code = 'O'
             WHERE cOldCustLimit.limit_id = lim.limit_id;
         END LOOP;    
         CLOSE cOldCustLimit;*/
         
         SCBP_TLS_PROD_CONVERT_I2O (p_ret_code,
                             p_limit_found,
                                    p_bank_group_code,
                                    p_cty_code,
                                    lim1);

      END IF;

  END LOOP;

EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);
     
END SCBP_TLS_PROD_CONVERT_ALL_I2O;

FUNCTION SCBP_P_RET_ANY_BCA_LIMIT(p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2, p_pay_method varchar2, p_prod_limit_id varchar2, p_cty_sale varchar2) 
                                     return varchar2 IS 
v_bca_limit_id scbt_r_cust_bca_cond_limit.limit_id%type;                                     
v_count int;
v_cty_of_sale scbt_r_cust_bca_cond_limit.cty_of_sale%type;
v_prod_limit_id scbt_r_cust_bca_cond_limit.product_limit_ids%type;
v_payment_method scbt_r_cust_bca_cond_limit.payment_method%type;
--v_cpty_ids varchar2(1000);
BEGIN
v_bca_limit_id:='';
      for t1 in (select l.payment_method, l.product_limit_ids, l.cty_of_sale, l.limit_id from scbt_r_cust_bca_cond_limit l where l.cust_id = p_cust_id 
      and l.cty_code = p_cty_code and l.bank_group_code = p_bank_group_code
      and l.cpty_cond = 'ANY') loop
        if(t1.payment_method = '*') then
            if(t1.product_limit_ids = '*') then
                    if(t1.cty_of_sale = '*') then
                        v_bca_limit_id:=t1.limit_id;
                    else 
                       for c1 in (select * from table(split(t1.cty_of_sale))) loop
                         if(c1.column_value=p_cty_sale) then 
                          v_bca_limit_id:=t1.limit_id;
                         end if;
                       end loop;
                    end if;
                else 
                --if(p_pay_method in (select * from table(split(t1.product_limit_ids)))) then
                  for c2 in (select * from table(split(t1.product_limit_ids))) loop
                    if(c2.column_value=p_prod_limit_id) then
                      if(t1.cty_of_sale = '*') then
                          v_bca_limit_id:=t1.limit_id;
                      else
                          for c3 in (select * from table(split(t1.product_limit_ids))) loop
                            if(c3.column_value=p_prod_limit_id) then
                              v_bca_limit_id:=t1.limit_id;
                            end if;
                          end loop;
                      end if;
                    end if;
                  end loop;
             end if;
        else 
          for c in (select * from table(split(t1.payment_method))) loop
             if(c.column_value = p_pay_method) then
                 if(t1.product_limit_ids = '*') then
                    if(t1.cty_of_sale = '*') then
                        v_bca_limit_id:=t1.limit_id;
                    else 
                       for c1 in (select * from table(split(t1.cty_of_sale))) loop
                         if(c1.column_value=p_cty_sale) then 
                          v_bca_limit_id:=t1.limit_id;
                         end if;
                       end loop;
                    end if;
                else 
                --if(p_pay_method in (select * from table(split(t1.product_limit_ids)))) then
                  for c2 in (select * from table(split(t1.product_limit_ids))) loop
                    if(c2.column_value=p_prod_limit_id) then
                      if(t1.cty_of_sale = '*') then
                          v_bca_limit_id:=t1.limit_id;
                      else
                          for c3 in (select * from table(split(t1.product_limit_ids))) loop
                            if(c3.column_value=p_prod_limit_id) then
                              v_bca_limit_id:=t1.limit_id;
                            end if;
                          end loop;
                      end if;
                    end if;
                  end loop;
                end if;
              end if;
            end loop;
        end if;
      end loop;
    return v_bca_limit_id; 
end SCBP_P_RET_ANY_BCA_LIMIT;

FUNCTION SCBP_F_CHK_DELETED(p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2,
                                     p_step_id varchar2, v_payment_method varchar2, 
                                     v_cpty_id varchar2, v_cty_sale varchar2, v_prod_limit_ids varchar2) return varchar2 is
v_limit_id scbt_r_cust_bca_cond_limit.limit_id%type;
n_newbcacount INT;
n_oldbcacount INT;
begin
      OPEN cOldBcaLimit(p_bank_group_code,p_cty_code,p_cust_id);
      FETCH cOldBcaLimit BULK COLLECT INTO tOld_BcaStructure;
    
      CLOSE cOldBcaLimit;
    
      OPEN cNewBcaLimit(p_bank_group_code,p_cty_code,p_cust_id,p_step_id);
      FETCH cNewBcaLimit BULK COLLECT INTO tNew_BcaStructure ;
    
      CLOSE cNewBcaLimit;
    
      n_newbcacount:=tNew_BcaStructure.COUNT;
      n_oldbcacount:=tOld_BcaStructure.COUNT;
      
       FOR i IN 1..n_oldbcacount LOOP
           for j in 1..n_newbcacount loop
              if(tNew_BcaStructure(j).limit_id = tOld_BcaStructure(i).limit_id) then
                   if(tNew_BcaStructure(j).CPTY_COND = 'INC') then
                      if(tNew_BcaStructure(j).payment_method='*') then
                        dbms_output.put_line('11');
                        if(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS = '*') then
                                      for t1 in (select * from table(split(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS))) loop
                                        if(tNew_BcaStructure(j).product_limit_ids =  t1.column_value) then
                                           if(tNew_BcaStructure(j).CTY_OF_SALE = '*') then
                                               if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                               else
                                                   for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                      if(t3.column_value = v_cpty_id) then
                                                        v_limit_id := tNew_BcaStructure(j).limit_id;
                                                      end if;
                                                   end loop;
                                                end if;
                                           else
                                               for t2 in (select * from table(split(tNew_BcaStructure(j).CTY_OF_SALE))) loop
                                                   if(t2.column_value = v_cty_sale) then
                                                       if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                                       else
                                                         for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                            if(t3.column_value = v_cpty_id) then
                                                              v_limit_id := tNew_BcaStructure(j).limit_id;
                                                            end if;
                                                         end loop;
                                                       end if;
                                                   end if;
                                               end loop;
                                               
                                           end if;
                                  else
                                      for t1 in (select * from table(split(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS))) loop
                                        if(tNew_BcaStructure(j).product_limit_ids =  t1.column_value) then
                                           if(tNew_BcaStructure(j).CTY_OF_SALE = '*') then
                                               if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                               else
                                                   for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                      if(t3.column_value = v_cpty_id) then
                                                        v_limit_id := tNew_BcaStructure(j).limit_id;
                                                      end if;
                                                   end loop;
                                                end if;
                                           else
                                               for t2 in (select * from table(split(tNew_BcaStructure(j).CTY_OF_SALE))) loop
                                                   if(t2.column_value = v_cty_sale) then
                                                       if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                                       else
                                                         for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                            if(t3.column_value = v_cpty_id) then
                                                              v_limit_id := tNew_BcaStructure(j).limit_id;
                                                            end if;
                                                         end loop;
                                                       end if;
                                                   end if;
                                               end loop;
                                           end if;
                                        end if;
                                      end loop;
                                  
                                end if;
                               end loop;
                          end if; 
                      else
                          for t in (select * from table(split(tNew_BcaStructure(j).payment_method)))  loop
                              if(v_payment_method = t.column_value) then
                              
                                  if(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS = '*') then
                                      for t1 in (select * from table(split(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS))) loop
                                        if(tNew_BcaStructure(j).product_limit_ids =  t1.column_value) then
                                           if(tNew_BcaStructure(j).CTY_OF_SALE = '*') then
                                               if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                               else
                                                   for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                      if(t3.column_value = v_cpty_id) then
                                                        v_limit_id := tNew_BcaStructure(j).limit_id;
                                                      end if;
                                                   end loop;
                                                end if;
                                           else
                                               for t2 in (select * from table(split(tNew_BcaStructure(j).CTY_OF_SALE))) loop
                                                   if(t2.column_value = v_cty_sale) then
                                                       if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                                       else
                                                         for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                            if(t3.column_value = v_cpty_id) then
                                                              v_limit_id := tNew_BcaStructure(j).limit_id;
                                                            end if;
                                                         end loop;
                                                       end if;
                                                   end if;
                                               end loop;
                                               
                                           end if;
                                  else
                                      for t1 in (select * from table(split(tNew_BcaStructure(j).PRODUCT_LIMIT_IDS))) loop
                                        if(tNew_BcaStructure(j).product_limit_ids =  t1.column_value) then
                                           if(tNew_BcaStructure(j).CTY_OF_SALE = '*') then
                                               if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                               else
                                                   for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                      if(t3.column_value = v_cpty_id) then
                                                        v_limit_id := tNew_BcaStructure(j).limit_id;
                                                      end if;
                                                   end loop;
                                                end if;
                                           else
                                               for t2 in (select * from table(split(tNew_BcaStructure(j).CTY_OF_SALE))) loop
                                                   if(t2.column_value = v_cty_sale) then
                                                       if(tNew_BcaStructure(j).CPTY_IDS='*') then
                                                          v_limit_id := tNew_BcaStructure(j).limit_id;
                                                       else
                                                         for t3 in (select * from table(split(tNew_BcaStructure(j).CPTY_IDS))) loop
                                                            if(t3.column_value = v_cpty_id) then
                                                              v_limit_id := tNew_BcaStructure(j).limit_id;
                                                            end if;
                                                         end loop;
                                                       end if;
                                                   end if;
                                               end loop;
                                           end if;
                                        end if;
                                      end loop;
                                  
                                end if;
                               end loop;
                          end if;             
                      
                      
                      
                      end if;
                   end loop;
                   end if;
                   end if;
                   end if;
           end loop;
       end loop;

  
     return v_limit_id;
end SCBP_F_CHK_DELETED;

FUNCTION SCBF_F_RET_ANY_LIMIT_ID(p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2,
                                     p_step_id varchar2, v_payment_method varchar2, 
                                     v_cpty_id varchar2, v_cty_sale varchar2, v_prod_limit_ids varchar2,
                                     v_qualifier varchar2) return varchar2 is
v_limit_id scbt_r_cust_bca_cond_limit.limit_id%type;
v_count int;
p_cty_of_sale varchar2(1000);
p_prod_limit_id varchar2(1000);
p_payment_method varchar2(1000);
v_bca_limit_id scbt_r_cust_bca_cond_limit.limit_id%type;
begin
        v_limit_id:=null;
        v_count:=0;
        /*select count(*) into v_count from scbt_r_cust_bca_cond_limit l where l.cust_id = p_cust_id
        and l.cty_of_sale = v_cty_sale and l.product_limit_ids = v_prod_limit_ids and l.payment_method = v_payment_method
        and l.cpty_cond = 'ANY';*/
      
--       if(v_count>0) then
       
       
       for bca in (select l.cty_of_sale, l.product_limit_ids, l.payment_method
           from scbt_r_cust_bca_cond_limit l where l.cust_id = p_cust_id and l.cpty_cond = 'ANY') loop
           
           for t1 in (select * from table(split(bca.payment_method))) loop
                   p_payment_method := t1.column_value;
                for t2 in (select * from table(split(bca.product_limit_ids))) loop
                   p_prod_limit_id := t2.column_value;
                   for t3 in (select * from table(split(bca.cty_of_sale))) loop
                      p_cty_of_sale := t3.column_value;
                      
                      select count(*) into v_count from scbt_r_cust_bca_cond_limit l where l.cust_id = p_cust_id
                      and decode(l.cty_of_sale,'*',v_cty_sale) = v_cty_sale and 
                      decode(l.product_limit_ids, '*', v_prod_limit_ids) = v_prod_limit_ids 
                      and decode(l.payment_method, '*', v_payment_method) = v_payment_method
                      and l.cpty_cond = 'ANY';
                      
                      if(v_count>0) then
                            select l.limit_id into v_bca_limit_id from scbt_r_cust_bca_cond_limit l where l.cust_id = p_cust_id
                            and decode(l.cty_of_sale,'*',v_cty_sale) = v_cty_sale and 
                            decode(l.product_limit_ids, '*', v_prod_limit_ids) = v_prod_limit_ids 
                            and decode(l.payment_method, '*', v_payment_method) = v_payment_method
                            and l.cpty_cond = 'ANY' and rownum=1;
                  
                            select count(*) into v_count from SCBT_R_CUST_ADH_BCA_COND_MST m
                           where m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit_id
                           and m.party_id = v_cpty_id;
                  
                             if(v_count>0) then
                               select m.limit_id into v_limit_id  from SCBT_R_CUST_ADH_BCA_COND_MST m
                               where m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit_id
                               and m.party_id = v_cpty_id ;
                               
                               if v_qualifier = 'D' then
                                  return v_bca_limit_id;
                               else   
                                  return v_limit_id;
                               end if;
                             end if;
                      end if;
                      
                   end loop;
                end loop;
            end loop;
        end loop;
  --     end if;
      
        if v_qualifier = 'D' then
           return v_bca_limit_id;
        else   
           return v_limit_id;
        end if;
        
end SCBF_F_RET_ANY_LIMIT_ID;


PROCEDURE SCBP_TLS_BCA_CREATE_LIMIT(p_ret_code        IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2,
                                     new_bank_limit cNewbCALimit%rowtype, p_step_id varchar2) is
v_cty_of_sale varchar2(1000);
v_prod_limit_id varchar2(1000);
v_payment_method varchar2(1000);
v_cpty_ids varchar2(1000);
v_dest_limit scbt_r_cust_bca_cond_limit.limit_id%type;
v_bca_limit scbt_r_cust_bca_cond_limit.limit_id%type;
v_count int;
v_tenor scbt_r_cust_bca_cond_limit.tenor%type;
v_LIMIT_CCY_CODE scbt_r_cust_bca_cond_limit.LIMIT_CCY_CODE%type;
v_ret_val varchar2(16);
v_limit_id scbt_r_cust_bca_cond_limit.LIMIT_ID%type;
v_bca_cap_type scbt_r_cust_bca_cond_limit.cap_type%type;
v_limit_id_list varchar2(1000);


v_LIMIT_CCY_ACTIVE_AMT scbt_r_cust_bca_cond_limit.LIMIT_CCY_ACTIVE_AMT%type;
v_adh_any_limit scbt_r_cust_bca_cond_limit.limit_id%type;
v_temp_val varchar2(1000);
begin
     v_limit_id_list:= '';
     v_temp_val:='';
   v_bca_limit:=new_bank_limit.limit_id;
   --SRK - Check whether the cap is for buyer or supplier
   if new_bank_limit.cap_type = 'BC' then
      v_bca_cap_type := 'BCAP';
   else 
      v_bca_cap_type := 'PROD';
   end if;
   
   if new_bank_limit.limit_ccy_code is null then
      SELECT cm.overall_exp_currency 
          INTO v_LIMIT_CCY_CODE
              FROM SCBT_R_PARTY_MST  cm
             WHERE bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code
               AND party_id = p_Cust_Id;  
   else 
        v_LIMIT_CCY_CODE := new_bank_limit.limit_ccy_code;
   end if;
   
         
    if(new_bank_limit.cpty_cond = 'ANY') then
    
          DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE limit_id IN (SELECT limit_id FROM SCBT_R_CUST_ADH_BCA_COND_MST WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
                                   AND cust_id = p_Cust_Id AND bca_limit_id = v_bca_limit) and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
         
         update scbt_t_prod_limit_util set LIMIT_CCY_PEND_INC_AMT = 0, LIMIT_CCY_PEND_DEC_AMT = 0, LIMIT_CCY_UTILISED_AMT = 0 where limit_id IN (SELECT limit_id FROM SCBT_R_CUST_ADH_BCA_COND_MST WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
                                   AND cust_id = p_Cust_Id AND bca_limit_id = v_bca_limit) and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
         
         
         for t1 in (select * from table(split(new_bank_limit.payment_method))) loop
               v_payment_method := t1.column_value;
            for t2 in (select * from table(split(new_bank_limit.product_limit_ids))) loop
               v_prod_limit_id := t2.column_value;
               for t3 in (select * from table(split(new_bank_limit.cty_of_sale))) loop
                  v_cty_of_sale := t3.column_value;
                   for mvmt in (select dtl.init_req_id, dtl.req_sr_no, dtl.limit_tree_type_code, dtl.txn_ccy_code, dtl.txn_ccy_amt, dtl.payment_method, dtl.prod_limit_id, dtl.cty_of_sale, dtl.cpty_id  from scbt_t_prod_limit_req_log log, scbt_t_prod_limit_req_log_dtl dtl
                          where dtl.init_req_id = log.init_req_id and log.cty_code = dtl.cty_code
                          and log.bank_group_code = dtl.bank_group_code and log.req_type_code = 'NEW'  and log.req_status_code in ('PEND','CON')
                          and log.bank_group_code = p_bank_group_code and log.cty_code = p_cty_code
                          and dtl.obligor_id = p_cust_id
                          and nvl(dtl.payment_method,'*') = decode(v_payment_method, '*', dtl.payment_method, v_payment_method)
                          and nvl(dtl.prod_limit_id,'*') = decode(v_prod_limit_id, '*', dtl.prod_limit_id, v_prod_limit_id)
                          and nvl(dtl.cty_of_sale,'*') = decode(v_cty_of_sale, '*', dtl.cty_of_sale, v_cty_of_sale)
                          and dtl.limit_tree_type_code = v_bca_cap_type   AND (dtl.init_req_id, req_sr_no) NOT IN 
                              (SELECT init_req_id, req_sr_no FROM SCBT_T_PROD_LIMIT_MVMT m WHERE m.limit_id IN (
                              SELECT limit_id FROM SCBT_R_CUST_BCA_COND_LIMIT_hst am WHERE bank_group_code = p_bank_group_code AND cty_code = p_cty_code
                              AND cust_id = p_cust_id AND am.CPTY_COND = 'INC' and step_status_code = '02' and step_code <> '06' AND (op_code <> 'D' OR op_code IS NULL))) -- SRK take only the buyer or supplier request based on the setup
                          ) loop
                                --v_ret_val := SCBP_F_CHK_DELETED(p_bank_group_code,p_cty_code,p_cust_id, p_step_id,
                                --                                mvmt.payment_method, mvmt.cpty_id, mvmt.cty_of_sale, mvmt.prod_limit_id);
                                --if(v_ret_val is null) then
                                    
                                   select count(*) into v_count from SCBT_R_CUST_ADH_BCA_COND_MST m where m.bank_group_code = p_bank_group_code
                                   and m.cty_code = p_cty_code and m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit and m.party_id = mvmt.cpty_id;-- SRK check for the cpty id
                                   if(v_count>0) then
                                          select limit_id into v_dest_limit from SCBT_R_CUST_ADH_BCA_COND_MST m where m.bank_group_code = p_bank_group_code
                                          and m.cty_code = p_cty_code and m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit and m.party_id = mvmt.cpty_id; -- SRK check for the cpty id
                                   else
                                          select SCB_C_LIMITID.Nextval into v_dest_limit from dual;
                                          
                                          INSERT INTO SCBT_R_CUST_ADH_BCA_COND_MST (
                                               BANK_GROUP_CODE, CTY_CODE, CUST_ID, 
                                               STEP_ID, LIMIT_ID, BCA_LIMIT_ID, 
                                               TENOR, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, 
                                               RECORD_LOCK_FLAG, PARTY_ID) 
                                            VALUES ( p_bank_group_code, p_cty_code, p_cust_id,
                                                      null, v_dest_limit, v_bca_limit,
                                                      nvl(new_bank_limit.tenor,9999), v_LIMIT_CCY_CODE, nvl(new_bank_limit.limit_ccy_active_amt,999999999999),
                                                      null, mvmt.cpty_id);
                                          
                                           
                                   end if;
                                    
                                   
                                   DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE INIT_REQ_ID = mvmt.init_req_id and req_sr_no = mvmt.req_sr_no and  limit_id = v_dest_limit
                                   AND LIMIT_TREE_TYPE_CODE = mvmt.limit_tree_type_code AND cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
                                
                                   INSERT INTO SCBT_T_PROD_LIMIT_MVMT (
                                               BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, 
                                               INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, 
                                               TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID) 
                                            VALUES ( p_bank_group_code, p_cty_code, v_dest_limit,
                                                mvmt.init_req_id, mvmt.req_sr_no, mvmt.txn_ccy_code,
                                                mvmt.txn_ccy_amt, 'ABCAP', mvmt.cpty_id);
                                   
                                    if(not ((v_temp_val) like ('%'||v_dest_limit||'%')) or (v_temp_val is null)) then
                                           v_temp_val :=v_temp_val||v_dest_limit||',';
                                    end if;
                                         
                                --end if;
                   end loop;
               end loop;
            end loop;
         end loop;
         
         if(length(v_temp_val)>0) then 
              v_temp_val:= substr(v_temp_val, 0, length(v_temp_val)-1);
         end if;
    
         IF v_temp_val is not null then         
         for t in (select * from table(split(v_temp_val))) loop
              SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                             p_Bank_Group_Code,
                             p_Cty_Code,
                             t.column_value,
                             v_LIMIT_CCY_CODE,
                             'ABCAP');
         end loop;
         END IF;
    
    elsif(new_bank_limit.cpty_cond='EXC') then
         
         DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE limit_id = v_bca_limit and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
         
         update scbt_t_prod_limit_util set LIMIT_CCY_PEND_INC_AMT = 0, LIMIT_CCY_PEND_DEC_AMT = 0, LIMIT_CCY_UTILISED_AMT = 0 where limit_id = v_bca_limit and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;


          for mvmt in (SELECT dtl.init_req_id, dtl.req_sr_no, dtl.limit_tree_type_code, dtl.txn_ccy_code, dtl.txn_ccy_amt, dtl.payment_method, dtl.prod_limit_id, 
              dtl.cty_of_sale, dtl.cpty_id FROM SCBT_T_PROD_LIMIT_REQ_LOG LOG, SCBT_T_PROD_LIMIT_REQ_LOG_DTL dtl
                          WHERE dtl.init_req_id = LOG.init_req_id AND LOG.cty_code = dtl.cty_code
                          AND LOG.bank_group_code = dtl.bank_group_code AND LOG.req_type_code = 'NEW' AND LOG.req_status_code IN ('PEND','CON')
                          AND LOG.bank_group_code = p_bank_group_code AND LOG.cty_code = p_cty_code
                          AND dtl.obligor_id = p_cust_id
                          AND dtl.cpty_id NOT IN (SELECT * FROM TABLE(SPLIT(new_bank_limit.cpty_ids)))
						  --AND REGEXP_SUBSTR (','||bca.cpty_ids||',', ','||dtl.cpty_id||',' , 1, 1) = ','||dtl.cpty_id||','
						  AND (nvl(new_bank_limit.payment_method,'*') = '*' OR dtl.payment_method IS NULL OR (REGEXP_SUBSTR (','||new_bank_limit.payment_method||',', ','||dtl.payment_method||',' , 1, 1) = ','||dtl.payment_method||','))
						  AND (nvl(new_bank_limit.cty_of_sale,'*') = '*' OR dtl.cty_of_sale IS NULL OR (REGEXP_SUBSTR (','||new_bank_limit.cty_of_sale||',', ','||dtl.cty_of_sale||',' , 1, 1) = ','||dtl.cty_of_sale||','))
						  AND (nvl(new_bank_limit.product_limit_ids,'*') = '*' OR dtl.prod_limit_id IS NULL OR (REGEXP_SUBSTR (','||new_bank_limit.product_limit_ids||',', ','||dtl.prod_limit_id||',' , 1, 1) = ','||dtl.prod_limit_id||','))
						  AND dtl.limit_tree_type_code = v_bca_cap_type) loop
              
                  DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE INIT_REQ_ID = mvmt.init_req_id and req_sr_no = mvmt.req_sr_no and  limit_id = new_bank_limit.limit_id
                  AND LIMIT_TREE_TYPE_CODE = mvmt.limit_tree_type_code AND cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
              
                  INSERT INTO SCBT_T_PROD_LIMIT_MVMT (
                                       BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, 
                                       INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, 
                                       TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID) 
                                    VALUES ( p_bank_group_code, p_cty_code, new_bank_limit.limit_id,
                                        mvmt.init_req_id, mvmt.req_sr_no, mvmt.txn_ccy_code,
                                        mvmt.txn_ccy_amt, mvmt.limit_tree_type_code, mvmt.cpty_id);
                  if(not ((v_temp_val) like ('%'||new_bank_limit.limit_id||'%')) or (v_temp_val is null)) then
                         v_temp_val :=v_temp_val||new_bank_limit.limit_id||',';
                  end if;
              
              
         end loop;

                                   
         /*for t1 in (select * from table(split(new_bank_limit.payment_method))) loop
               v_payment_method := t1.column_value;
            for t2 in (select * from table(split(new_bank_limit.product_limit_ids))) loop
               v_prod_limit_id := t2.column_value;
               for t3 in (select * from table(split(new_bank_limit.cty_of_sale))) loop
                  v_cty_of_sale := t3.column_value;
                    for t4 in (select * from table(split(new_bank_limit.cpty_ids))) loop
                       v_cpty_ids := t4.column_value;
                       for mvmt in (select dtl.init_req_id, dtl.req_sr_no, dtl.limit_tree_type_code, dtl.txn_ccy_code, dtl.txn_ccy_amt, dtl.payment_method, dtl.prod_limit_id, dtl.cty_of_sale, dtl.cpty_id from scbt_t_prod_limit_req_log log, scbt_t_prod_limit_req_log_dtl dtl
                          where dtl.init_req_id = log.init_req_id and log.cty_code = dtl.cty_code
                          and log.bank_group_code = dtl.bank_group_code and log.req_type_code = 'NEW' and log.req_status_code in ('PEND','CON')
                          and log.bank_group_code = p_bank_group_code and log.cty_code = p_cty_code
                          and dtl.obligor_id = p_cust_id
                          and dtl.cpty_id <> v_cpty_ids
                          and nvl(dtl.payment_method,'*') = decode(v_payment_method, '*', dtl.payment_method, v_payment_method)
                          and nvl(dtl.prod_limit_id,'*') = decode(v_prod_limit_id, '*', dtl.prod_limit_id, v_prod_limit_id)
                          and nvl(dtl.cty_of_sale,'*') = decode(v_cty_of_sale, '*', dtl.cty_of_sale, v_cty_of_sale)
                          and dtl.limit_tree_type_code = v_bca_cap_type
                          ) loop

                                DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE INIT_REQ_ID = mvmt.init_req_id and req_sr_no = mvmt.req_sr_no and  limit_id = new_bank_limit.limit_id
                                AND LIMIT_TREE_TYPE_CODE = mvmt.limit_tree_type_code AND cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
                                
                                INSERT INTO SCBT_T_PROD_LIMIT_MVMT (
                                                     BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, 
                                                     INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, 
                                                     TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID) 
                                                  VALUES ( p_bank_group_code, p_cty_code, new_bank_limit.limit_id,
                                                      mvmt.init_req_id, mvmt.req_sr_no, mvmt.txn_ccy_code,
                                                      mvmt.txn_ccy_amt, mvmt.limit_tree_type_code, v_cpty_ids);
                                if(not ((v_temp_val) like ('%'||new_bank_limit.limit_id||'%')) or (v_temp_val is null)) then
                                       v_temp_val :=v_temp_val||new_bank_limit.limit_id||',';
                                end if;
                       end loop;
                    end loop;
               end loop;
            end loop;
         end loop;*/
         if(length(v_temp_val)>0) then 
              v_temp_val:= substr(v_temp_val, 0, length(v_temp_val)-1);
         end if;
    
         IF v_temp_val is not null then         
         for t in (select * from table(split(v_temp_val))) loop
              SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                             p_Bank_Group_Code,
                             p_Cty_Code,
                             t.column_value,
                             v_LIMIT_CCY_CODE,
                             'BCAP');
         end loop;
         end if;
    else
         DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE limit_id = v_bca_limit and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
         
         update scbt_t_prod_limit_util set LIMIT_CCY_PEND_INC_AMT = 0, LIMIT_CCY_PEND_DEC_AMT = 0, LIMIT_CCY_UTILISED_AMT = 0 where limit_id = v_bca_limit and
                                   cty_code = p_cty_code AND bank_group_code = p_bank_group_code;

        for t1 in (select * from table(split(new_bank_limit.payment_method))) loop
               v_payment_method := t1.column_value;
            for t2 in (select * from table(split(new_bank_limit.product_limit_ids))) loop
               v_prod_limit_id := t2.column_value;
               for t3 in (select * from table(split(new_bank_limit.cty_of_sale))) loop
                  v_cty_of_sale := t3.column_value;
                    for t4 in (select * from table(split(new_bank_limit.cpty_ids))) loop
                       v_cpty_ids := t4.column_value;
                         v_adh_any_limit:= SCBF_F_RET_ANY_LIMIT_ID(p_bank_group_code, p_cty_code,
                                               p_cust_id, p_step_id, v_payment_method, 
                                               v_cpty_ids, v_cty_of_sale, v_prod_limit_id,'C');
  
                        for mvmt in (select dtl.init_req_id, dtl.req_sr_no, dtl.limit_tree_type_code, dtl.txn_ccy_code, dtl.txn_ccy_amt, dtl.payment_method, dtl.prod_limit_id, dtl.cty_of_sale, dtl.cpty_id from scbt_t_prod_limit_req_log log, scbt_t_prod_limit_req_log_dtl dtl
                          where dtl.init_req_id = log.init_req_id and log.cty_code = dtl.cty_code
                          and log.bank_group_code = dtl.bank_group_code and log.req_type_code = 'NEW' and log.req_status_code in ('PEND','CON')
                          and log.bank_group_code = p_bank_group_code and log.cty_code = p_cty_code
                          and dtl.obligor_id = p_cust_id
                          and dtl.cpty_id = v_cpty_ids
                          and nvl(dtl.payment_method,'*') = decode(v_payment_method, '*', dtl.payment_method, v_payment_method)
                          and nvl(dtl.prod_limit_id,'*') = decode(v_prod_limit_id, '*', dtl.prod_limit_id, v_prod_limit_id)
                          and nvl(dtl.cty_of_sale,'*') = decode(v_cty_of_sale, '*', dtl.cty_of_sale, v_cty_of_sale)
                          and dtl.limit_tree_type_code = v_bca_cap_type
                          ) loop
                                     
                               if(v_adh_any_limit is not null) then
                                  if(not ((v_temp_val) like ('%'||v_adh_any_limit||'%')) or (v_temp_val is null)) then
                                         v_temp_val :=v_temp_val||v_adh_any_limit||',';
                                  end if;
                                  DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE INIT_REQ_ID = mvmt.init_req_id and req_sr_no = mvmt.req_sr_no and  limit_id = v_adh_any_limit;
                               end if;

                                DELETE FROM SCBT_T_PROD_LIMIT_MVMT WHERE INIT_REQ_ID = mvmt.init_req_id and req_sr_no = mvmt.req_sr_no and  limit_id = new_bank_limit.limit_id
                                AND LIMIT_TREE_TYPE_CODE = mvmt.limit_tree_type_code AND cty_code = p_cty_code AND bank_group_code = p_bank_group_code;
                            
                              INSERT INTO SCBT_T_PROD_LIMIT_MVMT (
                                                   BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, 
                                                   INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, 
                                                   TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID) 
                                                VALUES ( p_bank_group_code, p_cty_code, new_bank_limit.limit_id,
                                                    mvmt.init_req_id, mvmt.req_sr_no, mvmt.txn_ccy_code,
                                                    mvmt.txn_ccy_amt, mvmt.limit_tree_type_code, v_cpty_ids);
                              if(not ((v_temp_val) like ('%'||new_bank_limit.limit_id||'%')) or (v_temp_val is null)) then
                                     v_temp_val :=v_temp_val||new_bank_limit.limit_id||',';
                              end if;
                       end loop;
                       --delete from SCBT_R_CUST_ADH_BCA_COND_MST m where m.cust_id = p_cust_id and m.party_id = v_cpty_ids and m.cty_code = p_cty_code
                       --and m.bank_group_code = p_bank_group_code;
                       
                    end loop;
               end loop;
            end loop;
         end loop;
         if(length(v_temp_val)>0) then 
              v_temp_val:= substr(v_temp_val, 0, length(v_temp_val)-1);
         end if;
    
         IF v_temp_val is not null then
         for t in (select * from table(split(v_temp_val))) loop
              SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                             p_Bank_Group_Code,
                             p_Cty_Code,
                             t.column_value,
                             v_LIMIT_CCY_CODE,
                             'BCAP');
         end loop;
         end if;
         
    end if;
   
   if(length(v_temp_val)>0) then 
    v_temp_val:= substr(v_temp_val, 0, length(v_temp_val)-1);
    
    end if;
    
    for t in (select * from table(split(v_temp_val))) loop
        dbms_output.put_line('Hi');
    end loop;
    
EXCEPTION

WHEN OTHERS THEN
       p_ret_code := SUBSTR(SQLERRM, 1, 150);
           
     dbms_output.put_line(v_tenor);
END SCBP_TLS_BCA_CREATE_LIMIT;


PROCEDURE SCBP_TLS_BCA_MOVE_LIMIT(p_ret_code        IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2,
                                     old_bank_limit cOldBcaLimit%rowtype) is
v_cty_of_sale varchar2(1000);
v_prod_limit_id varchar2(1000);
v_payment_method varchar2(1000);
v_cpty_ids varchar2(1000);
v_dest_limit scbt_r_cust_bca_cond_limit.limit_id%type;
v_bca_limit scbt_r_cust_bca_cond_limit.limit_id%type;
v_count int;
v_tenor scbt_r_cust_bca_cond_limit.tenor%type;
v_LIMIT_CCY_CODE scbt_r_cust_bca_cond_limit.LIMIT_CCY_CODE%type;
v_LIMIT_CCY_ACTIVE_AMT scbt_r_cust_bca_cond_limit.LIMIT_CCY_ACTIVE_AMT%type;
begin
     FOR T1 IN (select * from table(split(SCBF_F_RET_CUST(old_bank_limit.limit_id, p_bank_group_code, p_cty_code))) ) loop
         for t2 in (select * from table(split(SCBF_F_RET_PAYMENT(old_bank_limit.limit_id, p_bank_group_code, p_cty_code)))) loop
           for t3 in (select * from table(split(SCBF_F_RET_PROD_LIMIT_ID(old_bank_limit.limit_id, p_bank_group_code, p_cty_code)))) loop
                  for t4 in (select * from table(split(SCBF_F_RET_CTY_SALE(old_bank_limit.limit_id, p_bank_group_code, p_cty_code)))) loop
                     v_cpty_ids:=t1.column_value;
                     v_payment_method:=t2.column_value;
                     v_prod_limit_id:=t3.column_value;
                     v_cty_of_sale:=t4.column_value;               

                     v_bca_limit:=SCBP_P_RET_ANY_BCA_LIMIT(p_bank_group_code, p_cty_code, p_cust_id, v_payment_method, v_prod_limit_id, v_cty_of_sale);

                     select l.tenor, l.limit_ccy_code, l.limit_ccy_active_amt
                            into v_tenor, v_LIMIT_CCY_CODE, v_LIMIT_CCY_ACTIVE_AMT 
                            from SCBT_R_CUST_BCA_COND_LIMIT l where l.limit_id = v_bca_limit and l.cust_id = p_cust_id;
                     
                     select count(*) into v_count from SCBT_R_CUST_ADH_BCA_COND_MST m where m.bank_group_code = p_bank_group_code
                     and m.cty_code = p_cty_code and m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit and m.party_id = v_cpty_ids;
                     if(v_count>0) then
                            select limit_id into v_dest_limit from SCBT_R_CUST_ADH_BCA_COND_MST m where m.bank_group_code = p_bank_group_code
                            and m.cty_code = p_cty_code and m.cust_id = p_cust_id and m.bca_limit_id = v_bca_limit and m.party_id = v_cpty_ids;
                     else
                            select SCB_C_LIMITID.Nextval into v_dest_limit from dual;
                            INSERT INTO SCBT_R_CUST_ADH_BCA_COND_MST (
                                 BANK_GROUP_CODE, CTY_CODE, CUST_ID, 
                                 STEP_ID, LIMIT_ID, BCA_LIMIT_ID, 
                                 TENOR, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, 
                                 RECORD_LOCK_FLAG, PARTY_ID) 
                              VALUES ( p_bank_group_code, p_cty_code, p_cust_id,
                                        null, v_dest_limit, v_bca_limit,
                                        v_tenor, v_LIMIT_CCY_CODE, v_LIMIT_CCY_ACTIVE_AMT,
                                        null, v_cpty_ids);
                     end if;
                     
                     
                     
                     for mvmt in (select d.init_req_id, d.req_sr_no,d.bank_group_code,d.cty_code, d.txn_ccy_code, d.txn_ccy_amt, d.obligor_id from scbt_t_prod_limit_req_log_dtl d, scbt_t_prod_limit_req_log log
                               where d.init_req_id = log.init_req_id
                               and d.bank_group_code = log.bank_group_code and d.cty_code = log.cty_code
                               and log.req_type_code = 'NEW'
                               and d.cpty_id = decode(v_cpty_ids,'*',d.cpty_id, v_cpty_ids)
                               and d.payment_method = decode(v_payment_method,'*',d.payment_method, v_payment_method)
                               and d.prod_limit_id = decode(v_prod_limit_id,'*',d.prod_limit_id, v_prod_limit_id)
                               and d.cty_of_sale = decode(v_cty_of_sale,'*',d.cty_of_sale, v_cty_of_sale)
                               and d.obligor_id = p_cust_id
                               ) loop
                         if(v_bca_limit is not null) then
                         INSERT INTO SCBT_T_PROD_LIMIT_MVMT (
                           BANK_GROUP_CODE, CTY_CODE, LIMIT_ID, 
                           INIT_REQ_ID, REQ_SR_NO, TXN_CCY_CODE, 
                           TXN_CCY_AMT, LIMIT_TREE_TYPE_CODE, OBLIGOR_ID) 
                        VALUES ( mvmt.bank_group_code, mvmt.cty_code, v_dest_limit,
                                  mvmt.init_req_id, mvmt.req_sr_no, mvmt.txn_ccy_code,
                                  mvmt.txn_ccy_amt, 'BCAP', mvmt.obligor_id);
                        end if;

                        delete from scbt_t_prod_limit_mvmt m where m.limit_id = old_bank_limit.limit_id
                        and m.init_req_id = mvmt.init_req_id and m.req_sr_no = mvmt.req_sr_no;
                     end loop;
                         
                  end loop;
           end loop; 
             
        end loop;
                  
                  
     end loop;
END SCBP_TLS_BCA_MOVE_LIMIT;

/*PROCEDURE SCBP_TLS_BCA_DEL_LIMIT(p_ret_code        IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     cust_id           VARCHAR2,
                                     old_bank_limit cOldBcaLimit%rowtype) is

begin
     if old_bank_limit.cpty_cond = 'ANY' THEN
        DELETE FROM SCBT_T_PROD_LIMIT_MVMT mvmt 
        where exists (select 1 from SCBT_R_CUST_ADH_BCA_COND_MST mst
                                  where bca_limit_id = old_bank_limit.limit_id and mst.limit_id = mvmt.limit_id);
     else
        if(old_bank_limit.cpty_cond<>'ANY') then
            if(old_bank_limit.cpty_cond = 'INC') then
                   dbms_output.put_line('test');
            end if;
        end if;
        DELETE FROM SCBT_T_PROD_LIMIT_MVMT mvmt where mvmt.limit_id = old_bank_limit.limit_id;
     end if;
     
end SCBP_TLS_BCA_DEL_LIMIT;*/

/*----------------------------------------------------------------------------------------------------------------*/

PROCEDURE SCBP_TLS_BCA_DEL_LIMIT(p_ret_code        IN OUT VARCHAR2,
                                 p_bank_group_code VARCHAR2,
                                 p_cty_code        VARCHAR2,
                                 p_cust_id         VARCHAR2,
                                 old_bank_limit cOldBcaLimit%ROWTYPE, 
                                 p_step_id         VARCHAR2) IS
v_cty_of_sale        VARCHAR2(1000);
v_prod_limit_id      VARCHAR2(1000);
v_payment_method     VARCHAR2(1000);
v_cpty_ids           VARCHAR2(1000);
v_count              INT;
v_ret_val            VARCHAR2(1);

v_tenor SCBT_R_CUST_BCA_COND_LIMIT.tenor%TYPE;
v_limit_id SCBT_R_CUST_BCA_COND_LIMIT.LIMIT_ID%TYPE;
v_bca_limit SCBT_R_CUST_BCA_COND_LIMIT.limit_id%TYPE;
v_dest_limit SCBT_R_CUST_BCA_COND_LIMIT.limit_id%TYPE;
v_adh_any_limit SCBT_R_CUST_BCA_COND_LIMIT.limit_id%TYPE;
v_LIMIT_CCY_CODE SCBT_R_CUST_BCA_COND_LIMIT.LIMIT_CCY_CODE%TYPE;
v_LIMIT_CCY_ACTIVE_AMT SCBT_R_CUST_BCA_COND_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
v_temp_count int;

BEGIN
    
    v_bca_limit:=old_bank_limit.limit_id;
   
    IF(old_bank_limit.cpty_cond = 'INC') THEN
       FOR t1 IN (SELECT * FROM TABLE(SPLIT(old_bank_limit.payment_method))) LOOP
           v_payment_method := t1.COLUMN_VALUE;
         FOR t2 IN (SELECT * FROM TABLE(SPLIT(old_bank_limit.product_limit_ids))) LOOP
             v_prod_limit_id := t2.COLUMN_VALUE;
           FOR t3 IN (SELECT * FROM TABLE(SPLIT(old_bank_limit.cty_of_sale))) LOOP
               v_cty_of_sale := t3.COLUMN_VALUE;
              FOR t4 IN (SELECT * FROM TABLE(SPLIT(old_bank_limit.cpty_ids))) LOOP
                  v_cpty_ids := t4.COLUMN_VALUE;
                  
                  
                  v_adh_any_limit:= Scbf_F_Ret_Any_Limit_Id(p_bank_group_code, 
                                                            p_cty_code,
                                                            p_cust_id, 
                                                            p_step_id, 
                                                            v_payment_method, 
                                                            v_cpty_ids, 
                                                            v_cty_of_sale, 
                                                            v_prod_limit_id,
                                                            'D');
                                     
                  IF (v_adh_any_limit IS NOT NULL) THEN
                  
                    select count(*) into v_temp_count from SCBT_R_CUST_ADH_BCA_COND_MST where bca_limit_id = v_adh_any_limit
                    and party_id = v_cpty_ids;
                    if(v_temp_count=0) then
                    
                        select limit_ccy_code, limit_ccy_active_amt, tenor into 
                              v_LIMIT_CCY_CODE, v_LIMIT_CCY_ACTIVE_AMT, v_tenor from scbt_r_cust_bca_cond_limit where limit_id = v_adh_any_limit;
  
                        SELECT SCB_C_LIMITID.NEXTVAL INTO v_dest_limit FROM dual;
                             
                        INSERT INTO SCBT_R_CUST_ADH_BCA_COND_MST (BANK_GROUP_CODE, CTY_CODE, CUST_ID, 
                                                                  STEP_ID, LIMIT_ID, BCA_LIMIT_ID, 
                                                                  TENOR, LIMIT_CCY_CODE, LIMIT_CCY_ACTIVE_AMT, 
                                                                  RECORD_LOCK_FLAG, PARTY_ID) 
                                                          VALUES (p_bank_group_code, p_cty_code, p_cust_id,
                                                                  NULL, v_dest_limit, v_adh_any_limit,
                                                                  v_tenor, v_LIMIT_CCY_CODE, v_LIMIT_CCY_ACTIVE_AMT,
                                                                  NULL, v_cpty_ids);
                              
                        UPDATE SCBT_T_PROD_LIMIT_MVMT
                           SET LIMIT_ID = v_dest_limit
                         WHERE BANK_GROUP_CODE = p_bank_group_code 
                           AND CTY_CODE = p_cty_code
                           AND limit_id = v_bca_limit;
                     end if;                            
                  END IF;                       
                                    
              END LOOP;                  
              
           END LOOP;
           
         END LOOP;
         
       END LOOP;
       
    END IF;

EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);
     dbms_output.put_line(p_ret_code||p_cust_id||'   limit_id -->  '||old_bank_limit.limit_id);
         
END SCBP_TLS_BCA_DEL_LIMIT;

/*----------------------------------------------------------------------------------------------------------------*/

FUNCTION SCBF_CHECK_BCA_EXISTS_NEW(p_ret_code        IN OUT VARCHAR2,
                                   p_bank_group_code VARCHAR2,
                                   p_cty_code        VARCHAR2,
                                   cust_id           VARCHAR2,
                                   new_bank_limit cNewbCALimit%rowtype,
                                   p_tLimit BcaLimit_tab_type) return varchar2 is
v_ret_val varchar2(2);
v_count int;

BEGIN
     
     v_ret_val:='Y';
     v_count:=p_tLimit.count;
     
     FOR i in 1..v_count LOOP
         
         IF(p_tLimit(i).limit_id = new_bank_limit.limit_id             AND 
            p_tLimit(i).CAP_TYPE = new_bank_limit.CAP_TYPE             AND
            p_tLimit(i).CPTY_COND = new_bank_limit.CPTY_COND           AND
            p_tLimit(i).CPTY_IDS = new_bank_limit.CPTY_IDS             AND
            p_tLimit(i).PAYMENT_METHOD = new_bank_limit.PAYMENT_METHOD AND
            p_tLimit(i).CTY_OF_SALE = new_bank_limit.CTY_OF_SALE       AND
            p_tLimit(i).product_limit_ids = new_bank_limit.product_limit_ids) THEN
             
            v_ret_val:='N';
             
         END IF;
         
     END LOOP;
     
     RETURN v_ret_val;
     
END SCBF_CHECK_BCA_EXISTS_NEW;

/*----------------------------------------------------------------------------------------------------------------*/

function SCBF_CHECK_BCA_EXISTS_OLD(p_ret_code        IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     cust_id           VARCHAR2,
                                     old_bank_limit cOldBcaLimit%rowtype,
                                      p_tLimit BcaLimit_tab_type_new) return varchar2 is
v_ret_val varchar2(2);
v_count int;
begin
     v_ret_val:='Y';
     v_count:=p_tLimit.count;
     
     for i in 1..v_count loop
         if(p_tLimit(i).limit_id = old_bank_limit.limit_id
             and p_tLimit(i).CAP_TYPE = old_bank_limit.CAP_TYPE
             and p_tLimit(i).CPTY_COND = old_bank_limit.CPTY_COND
             and p_tLimit(i).CPTY_IDS = old_bank_limit.CPTY_IDS
             and p_tLimit(i).PAYMENT_METHOD = old_bank_limit.PAYMENT_METHOD
             and p_tLimit(i).CTY_OF_SALE = old_bank_limit.CTY_OF_SALE) then
             v_ret_val:='N';
             end if;
     end loop;
     
     return v_ret_val;
     
end SCBF_CHECK_BCA_EXISTS_OLD;

--*****************************************************************************************--

PROCEDURE Scbp_Tls_Prod_Adjust_Utils(p_ret_code        IN OUT VARCHAR2,
                                     p_bank_group_code VARCHAR2,
                                     p_cty_code        VARCHAR2,
                                     p_cust_id           VARCHAR2,
                                     p_old_step_id     VARCHAR2,
                                     p_new_step_id     VARCHAR2) IS

    n_newcount INT;
    n_oldcount INT;
    n_newbcacount INT;
    n_oldbcacount INT;
    n_newpgfcount INT;
    n_oldpgfcount INT;  
    v_any_count   INT;
    ovl_exp_curr  VARCHAR2(3 BYTE);

BEGIN
DECLARE

  p_limit_found    BOOLEAN;
  old_index        INTEGER;
  v_check_val      varchar2(2);
  v_limit_tree_type  SCBT_T_PROD_LIMIT_MVMT.LIMIT_TREE_TYPE_CODE%TYPE;
  
BEGIN
  p_ret_code := '0000';

  OPEN cOldCustLimit(p_bank_group_code,p_cty_code,p_cust_id);
  FETCH cOldCustLimit BULK COLLECT INTO tOld_Structure;

  CLOSE cOldCustLimit;


  OPEN cNewCustLimit(p_bank_group_code,p_cty_code,p_cust_id,p_new_step_id);
  FETCH cNewCustLimit BULK COLLECT INTO tNew_Structure ;

  CLOSE cNewCustLimit;

  n_newcount:=tNew_Structure.COUNT;
  n_oldcount:=tOld_Structure.COUNT;


  SCBP_ADJUST_PROD_OVERALL_LIMIT(p_bank_group_code,
                                 p_cty_code,p_cust_id,
                                 tNew_Structure,
                                 p_new_step_id,
                                 p_ret_code);

--JP

  OPEN cOldBcaLimit(p_bank_group_code,p_cty_code,p_cust_id);
  FETCH cOldBcaLimit BULK COLLECT INTO tOld_BcaStructure;

  CLOSE cOldBcaLimit;

  OPEN cNewBcaLimit(p_bank_group_code,p_cty_code,p_cust_id,p_new_step_id);
  FETCH cNewBcaLimit BULK COLLECT INTO tNew_BcaStructure ;

  CLOSE cNewBcaLimit;

  n_newbcacount:=tNew_BcaStructure.COUNT;
  n_oldbcacount:=tOld_BcaStructure.COUNT;

--JP

  OPEN cOldPgfLimit(p_bank_group_code,p_cty_code,p_cust_id);
  FETCH cOldPgfLimit BULK COLLECT INTO tOld_PgfStructure;

  CLOSE cOldPgfLimit;

  OPEN cNewPgfLimit(p_bank_group_code,p_cty_code,p_cust_id,p_new_step_id);
  FETCH cNewPgfLimit BULK COLLECT INTO tNew_PgfStructure ;

  CLOSE cNewPgfLimit;

  n_newpgfcount:=tNew_PgfStructure.COUNT;
  n_oldpgfcount:=tOld_PgfStructure.COUNT;

--JP
               

  FOR i IN 1..n_newcount LOOP

       FOR j IN 1..n_oldcount LOOP

          IF tNew_Structure(i).limit_id = tOld_Structure(j).limit_id AND
             tNew_Structure(i).limit_ccy_code <> tOld_Structure(j).limit_ccy_code THEN

             SCBP_TLS_PROD_CHANGE_CCY (p_ret_code, p_bank_group_code,
                                       p_cty_code,tNew_Structure(i).limit_id,
                                       tOld_Structure(j).limit_ccy_code,
                                       tNew_Structure(i).limit_ccy_code);

          END IF;

       END LOOP;

  END LOOP;
  
-- DELETE MVMT HANDLING FOR BUYER/SUPPLIER BCA LIMITS --
  
  FOR i IN 1..n_oldbcacount LOOP

      p_limit_found     := FALSE;
      v_limit_tree_type := 'PROD';      
      
      FOR j IN 1..n_newbcacount LOOP
                    
          IF tNew_BcaStructure(j).limit_id = tOld_BcaStructure(i).limit_id THEN
       
             p_limit_found := TRUE;
            
          END IF;
          
      END LOOP;
      
      IF p_limit_found = FALSE THEN
         
         /* IF "ANY" RECORD IS DELETED ALL THE MVMT HAS TO BE DELETED i.e. MVMT FOR LIMIT ID'S FROM ADH TABLE */
         
         IF tOld_BcaStructure(i).cpty_cond = 'ANY' THEN
            
            DELETE FROM SCBT_T_PROD_LIMIT_MVMT
                  WHERE bank_group_code = p_bank_group_code
                    AND cty_code = p_cty_code
                    AND limit_id IN (SELECT limit_id 
                                       FROM SCBT_R_CUST_ADH_BCA_COND_MST
                                      WHERE bank_group_code = p_bank_group_code
                                        AND cty_code = p_cty_code
                                        AND cust_id = p_cust_id
                                        AND bca_limit_id = tOld_BcaStructure(i).limit_id);
              -- SRK delete util and adhoc limits also
             DELETE FROM SCBT_T_PROD_LIMIT_util
                  WHERE bank_group_code = p_bank_group_code
                    AND cty_code = p_cty_code
                    AND limit_id IN (SELECT limit_id 
                                       FROM SCBT_R_CUST_ADH_BCA_COND_MST
                                      WHERE bank_group_code = p_bank_group_code
                                        AND cty_code = p_cty_code
                                        AND cust_id = p_cust_id
                                        AND bca_limit_id = tOld_BcaStructure(i).limit_id);
                                        
             delete from SCBT_R_CUST_ADH_BCA_COND_MST where bank_group_code = p_bank_group_code
                                        AND cty_code = p_cty_code
                                        AND cust_id = p_cust_id
                                        AND bca_limit_id = tOld_BcaStructure(i).limit_id;
                                        
         END IF;
         
         /* IF "EXC" RECORD IS DELETED ALL THE MVMT HAS TO BE DELETED FOR ITS LIMIT ID */
         
         IF tOld_BcaStructure(i).cpty_cond = 'EXC' THEN
            
            DELETE FROM SCBT_T_PROD_LIMIT_MVMT
                  WHERE bank_group_code = p_bank_group_code
                    AND cty_code = p_cty_code
                    AND limit_id = tOld_BcaStructure(i).limit_id;
                                        
         END IF;
         
         /* IF "INC" RECORD IS DELETED AND THERE'S AN "ANY" RECORD IN MST MATCHING THE "INC" SETUP 
            THEN ITS MVMT HAS TO BE MOVED TO ADH TABLE WITH A NEW LIMIT ID, ELSE, ALL THE MVMT HAS
            TO BE DELETED */
         
         IF tOld_BcaStructure(i).cpty_cond = 'INC' THEN        
            
            v_any_count := 0;
            
            SELECT COUNT(*) INTO v_any_count FROM SCBT_R_CUST_BCA_COND_LIMIT
            WHERE cty_code = p_cty_code AND bank_group_code = p_bank_group_code and cust_id = p_cust_id
            AND cpty_cond = 'ANY';
            
            IF (v_any_count>0) THEN
               
                SCBP_TLS_BCA_DEL_LIMIT(p_ret_code,
                                       p_bank_group_code,
                                       p_cty_code,
                                       p_cust_id,
                                       tOld_BcaStructure(i),
                                       p_new_step_id);
                 DELETE FROM SCBT_T_PROD_LIMIT_MVMT
                     WHERE bank_group_code = p_bank_group_code
                       AND cty_code = p_cty_code
                       AND limit_id = tOld_BcaStructure(i).limit_id;
                  -- SRK
                  FOR k IN 1..n_newbcacount LOOP
                       if (tNew_BcaStructure(k).cpty_cond = 'ANY') then
                           v_check_val := SCBF_CHECK_BCA_EXISTS_NEW(p_ret_code,
                                                      p_bank_group_code,
                                                      p_cty_code,
                                                      p_cust_id,
                                                      tNew_BcaStructure(k),
                                                      tOld_BcaStructure);
                            IF (v_check_val='N') THEN
                                 SCBP_TLS_BCA_CREATE_LIMIT(p_ret_code,
                                         p_bank_group_code,
                                         p_cty_code,
                                         p_cust_id,
                                         tNew_BcaStructure(k), 
                                         p_new_step_id);
                             end if;
                        end if;
                    end loop;
                  -- SRK
                                            
            ELSE
                
               DELETE FROM SCBT_T_PROD_LIMIT_MVMT
                     WHERE bank_group_code = p_bank_group_code
                       AND cty_code = p_cty_code
                       AND limit_id = tOld_BcaStructure(i).limit_id;
                       
            END IF;
                                        
         END IF;
         
         IF tOld_BcaStructure(i).cap_type = 'BC' THEN
         
            v_limit_tree_type := 'BCAP';
            
         END IF;
         
         --SRK
         /*SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                     p_Bank_Group_Code,
                                     p_Cty_Code,
                                     tOld_BcaStructure(i).limit_id,
                                     tOld_BcaStructure(i).limit_ccy_code,
                                     v_limit_tree_type); */                                             
                  
      END IF;
      
  END LOOP;
  
-- CURRENCY CHANGE HANDLING FOR BUYER/SUPPLIER BCA LIMITS --

  FOR i IN 1..n_newbcacount LOOP

      FOR j IN 1..n_oldbcacount LOOP

          IF tNew_BcaStructure(i).limit_id  = tOld_BcaStructure(j).limit_id AND
             tNew_BcaStructure(i).cpty_cond <> 'ANY' AND          
             tNew_BcaStructure(i).limit_ccy_code <> tOld_BcaStructure(j).limit_ccy_code AND
             tNew_BcaStructure(i).limit_ccy_code IS NOT NULL THEN
       
             SCBP_TLS_PROD_CHANGE_CCY (p_ret_code,
                                       p_bank_group_code,
                                       p_cty_code,
                                       tNew_BcaStructure(i).limit_id,
                                       tOld_BcaStructure(j).limit_ccy_code,
                                       tNew_BcaStructure(i).limit_ccy_code);
            
          END IF;
          
          IF  tNew_BcaStructure(i).limit_id = tOld_BcaStructure(j).limit_id AND
              tNew_BcaStructure(i).cpty_cond = 'ANY' AND
              tNew_BcaStructure(i).limit_ccy_code IS NOT NULL AND
             (tNew_BcaStructure(i).limit_ccy_code <> tOld_BcaStructure(j).limit_ccy_code OR
              tNew_BcaStructure(i).limit_ccy_active_amt <> tOld_BcaStructure(j).limit_ccy_active_amt) THEN             
              
              SCBP_BCA_AMT_CCY_CHANGE (p_ret_code,
                                       p_bank_group_code,
                                       p_cty_code,
                                       tNew_BcaStructure(i).limit_id,
                                       tNew_BcaStructure(i).limit_ccy_active_amt,
                                       tOld_BcaStructure(j).limit_ccy_code,
                                       tNew_BcaStructure(i).limit_ccy_code,
                                       p_cust_id);
                         
          END IF;
             
      END LOOP;

  END LOOP;


  --  BUYER / SUPPLIER LIMIT RESTRUCTURING [DELETE PROCESS] START --
  
 /* FOR j IN 1..n_oldabscount LOOP
  
        p_limit_found := FALSE;
    
    FOR i IN 1..n_newabscount LOOP
    
        IF tNew_AbsStructure(i).appr_buyer_supplier_limit_id = tOld_AbsStructure(j).appr_buyer_supplier_limit_id THEN
           
           p_limit_found := TRUE;

               EXIT;
          
      END IF; 
      
    END LOOP;
    
    IF p_limit_found <> TRUE THEN
       
       IF(tOld_AbsStructure(j).limit_ccy_code IS NULL) THEN
            SELECT OVERALL_EXP_CURRENCY INTO v_limit_ccy FROM SCBT_R_PARTY_MST WHERE party_id = cust_id AND cty_code = p_cty_code AND ROWNUM=1;
       ELSE
            v_limit_ccy :=tOld_AbsStructure(j).limit_ccy_code;
       END IF;
       SCBP_DEL_MOVE_TO_ADHOC(p_ret_code,
                                     p_bank_group_code,
                                     p_cty_code,
                   p_ret_value,
                   cust_id,
                                     tOld_AbsStructure(j).party_id,
                                     tOld_AbsStructure(j).party_role,                  
                   tOld_AbsStructure(j).appr_buyer_supplier_limit_id,
                   v_limit_ccy,
                   tOld_AbsStructure(j).limit_ccy_active_amt);
    END IF;
    
  END LOOP;    

--  BUYER / SUPPLIER LIMIT RESTRUCTURING [DELETE PROCESS] END --

--  BUYER / SUPPLIER LIMIT RESTRUCTURING [CREATE PROCESS] START --
  
  FOR i IN 1..n_newabscount LOOP

        p_limit_found := FALSE;
    
        FOR j IN 1..n_oldabscount LOOP

          IF tNew_AbsStructure(i).appr_buyer_supplier_limit_id = tOld_AbsStructure(j).appr_buyer_supplier_limit_id THEN
         
       p_limit_found := TRUE;
                            
        END IF;

        END LOOP;
    
    IF p_limit_found <> TRUE THEN
        IF(tNew_AbsStructure(i).limit_ccy_code IS NULL) THEN
            SELECT OVERALL_EXP_CURRENCY INTO v_limit_ccy FROM SCBT_R_PARTY_MST WHERE party_id = cust_id AND cty_code = p_cty_code AND ROWNUM=1;
       ELSE
            v_limit_ccy :=tNew_AbsStructure(i).limit_ccy_code;
       END IF;
       SCBP_CREATE_BUYER_SUPP_MVMT(p_ret_code,
                            p_bank_group_code,
                    p_cty_code,
                    cust_id,
                      tNew_AbsStructure(i).appr_buyer_supplier_limit_id,
                      tNew_AbsStructure(i).party_role,
                      tNew_AbsStructure(i).party_id);
        SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                    p_Bank_Group_Code,
                                    p_Cty_Code,
                                    tNew_AbsStructure(i).appr_buyer_supplier_limit_id,
                                    v_limit_ccy,
                  'BSLI');
    END IF;
  END LOOP;*/
  
  --  BUYER / SUPPLIER LIMIT RESTRUCTURING [CREATE PROCESS] END --

  -- PRODUCT GROUP FACILITY RESTRUCTURING START --

  FOR i IN 1..n_newpgfcount LOOP

       FOR j IN 1..n_oldpgfcount LOOP

          IF tNew_PgfStructure(i).facility_grp_id = tOld_PgfStructure(j).facility_grp_id AND
             NVL(tNew_PgfStructure(i).limit_amt_ccy,' ') <> tOld_PgfStructure(j).limit_amt_ccy AND
             tNew_PgfStructure(i).group_type = 'AMT' THEN
       
             IF tNew_PgfStructure(i).limit_amt_ccy IS NOT NULL THEN

                SCBP_TLS_CHANGE_CCY (p_ret_code,
                                     p_bank_group_code,
                                     p_cty_code,
                                     tNew_PgfStructure(i).facility_grp_id,
                                     tOld_PgfStructure(j).limit_amt_ccy,
                                     tNew_PgfStructure(i).limit_amt_ccy);
                                       
             END IF;                                       

          END IF;

       END LOOP;

  END LOOP;

 
    FOR i IN 1..n_oldbcacount LOOP
       v_check_val:= SCBF_CHECK_BCA_EXISTS_OLD(p_ret_code,p_bank_group_code,p_cty_code,p_cust_id,
                                                 tOld_BcaStructure(i),tNew_BcaStructure);
       if(v_check_val='Y') then
             dbms_output.put_line('prod adjust');
       end if;
    
    END LOOP;

  FOR i IN 1..n_oldpgfcount LOOP

      p_limit_found := FALSE;
    
      FOR j IN 1..n_newpgfcount LOOP

          IF tNew_PgfStructure(j).facility_grp_id = tOld_PgfStructure(i).facility_grp_id THEN
           
             p_limit_found := TRUE;

             EXIT;
          
          END IF;

      END LOOP;
    
      IF p_limit_found <> TRUE THEN
    
         DELETE FROM SCBT_T_PROD_LIMIT_MVMT
               WHERE limit_id = tOld_PgfStructure(i).facility_grp_id
                 AND bank_group_code = p_bank_group_code
                 AND cty_code = p_cty_code;
        
         SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                     p_Bank_Group_Code,
                                     p_Cty_Code,                                     
                                     tOld_PgfStructure(i).facility_grp_id,
                                     tOld_PgfStructure(i).limit_amt_ccy,
                                     'GPROD');   
    
      END IF;                     

  END LOOP;
    
  ovl_exp_curr := scbf_get_exp_ccy(p_bank_group_code, p_cty_code, p_cust_id);
  
  FOR i IN 1..n_newpgfcount LOOP

      p_limit_found := FALSE;
    
      FOR j IN 1..n_oldpgfcount LOOP

          IF tNew_PgfStructure(i).facility_grp_id = tOld_PgfStructure(j).facility_grp_id THEN

             p_limit_found := TRUE;
       
             EXIT;
       
          END IF;

      END LOOP;
     
      IF p_limit_found <> TRUE THEN
         
         SCBP_CRE_PROD_LIMIT (p_ret_code,
                               p_bank_group_code,
                              p_cty_code,
                               p_cust_id,
                              tNew_PgfStructure(i).prod_limit_ids,
                              tNew_PgfStructure(i).facility_grp_id);
                  
         SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                     p_Bank_Group_Code,
                                     p_Cty_Code,
                                     tNew_PgfStructure(i).facility_grp_id,
                                     NVL(tNew_PgfStructure(i).limit_amt_ccy,ovl_exp_curr),
                                     'GPROD');                  
                  
      END IF;
     
  END LOOP;

  FOR j IN 1..n_oldpgfcount LOOP

      FOR i IN 1..n_newpgfcount LOOP

          IF tNew_PgfStructure(i).facility_grp_id = tOld_PgfStructure(j).facility_grp_id AND
             tNew_PgfStructure(i).prod_limit_ids <> tOld_PgfStructure(j).prod_limit_ids THEN
             --tNew_PgfStructure(i).prod_limit_ids <> tOld_PgfStructure(j).prod_limit_ids AND
             --tNew_PgfStructure(i).group_type = 'AMT' THEN

             FOR C1 IN (SELECT * FROM TABLE(SPLIT(tOld_PgfStructure(j).prod_limit_ids))) LOOP

                 p_limit_found := FALSE;
                 
                 FOR C2 IN (SELECT * FROM TABLE(SPLIT(tNew_PgfStructure(i).prod_limit_ids))) LOOP
                     
                     IF C1.COLUMN_VALUE = C2.COLUMN_VALUE THEN
                        
                        p_limit_found := TRUE;
                        
                        EXIT;
                          
                     END IF;
                     
                 END LOOP;
                 
                 IF p_limit_found = FALSE THEN
                 
                    SCBP_DELETE_PRD_GRP_LIMIT (p_ret_code, 
                                               p_bank_group_code,
                                               p_cty_code,
                                               p_cust_id,
                                               tOld_PgfStructure(j).facility_grp_id,
                                               C1.COLUMN_VALUE);                   
                 END IF;
                            
             END LOOP;
             
             /*SCBP_VAL_PROD_LIMIT (p_ret_code,
                                   p_bank_group_code,
                                  p_cty_code,
                                   p_cust_id,
                                   tOld_PgfStructure(j).prod_limit_ids,
                                  tNew_PgfStructure(i).prod_limit_ids,
                                  'DELETE',
                                  tOld_PgfStructure(j).facility_grp_id);*/

             SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                         p_Bank_Group_Code,
                                         p_Cty_Code,
                                         tOld_PgfStructure(j).facility_grp_id,
                                         NVL(tOld_PgfStructure(j).limit_amt_ccy,ovl_exp_curr),
                                         'GPROD');                  
                  
          END IF;

       END LOOP;
     
  END LOOP;

  FOR i IN 1..n_newpgfcount LOOP

      FOR j IN 1..n_oldpgfcount LOOP

          IF tNew_PgfStructure(i).facility_grp_id = tOld_PgfStructure(j).facility_grp_id AND
             tNew_PgfStructure(i).prod_limit_ids <> tOld_PgfStructure(j).prod_limit_ids THEN
             --tNew_PgfStructure(i).prod_limit_ids <> tOld_PgfStructure(j).prod_limit_ids AND
             --tNew_PgfStructure(i).group_type = 'AMT' THEN
             
             FOR C1 IN (SELECT * FROM TABLE(SPLIT(tNew_PgfStructure(i).prod_limit_ids))) LOOP

                 p_limit_found := FALSE;
                 
                 FOR C2 IN (SELECT * FROM TABLE(SPLIT(tOld_PgfStructure(j).prod_limit_ids))) LOOP
                     
                     IF C1.COLUMN_VALUE = C2.COLUMN_VALUE THEN
                        
                        p_limit_found := TRUE;
                        
                        EXIT;
                          
                     END IF;
                     
                 END LOOP;
                 
                 IF p_limit_found = FALSE THEN
                 
                    SCBP_CREATE_PRD_GRP_LIMIT (p_ret_code, 
                                               p_bank_group_code,
                                               p_cty_code,
                                               p_cust_id,
                                               tNew_PgfStructure(i).facility_grp_id,
                                               c1.column_value);

                 END IF;
                            
             END LOOP;
             
             /*SCBP_VAL_PROD_LIMIT (p_ret_code,
                                   p_bank_group_code,
                                  p_cty_code,
                                   p_cust_id,                  
                                   tNew_PgfStructure(i).prod_limit_ids,
                                  tOld_PgfStructure(j).prod_limit_ids,
                                  'CREATE',
                                  tNew_PgfStructure(i).facility_grp_id);*/
                  
                SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                            p_Bank_Group_Code,
                                            p_Cty_Code,
                                            tNew_PgfStructure(i).facility_grp_id,
                                            NVL(tNew_PgfStructure(i).limit_amt_ccy,ovl_exp_curr),
                                            'GPROD');
                      
          END IF;

       END LOOP;
     
  END LOOP;
    
  FOR i IN 1..n_newpgfcount LOOP

      FOR j IN 1..n_oldpgfcount LOOP

          IF tNew_PgfStructure(i).facility_grp_id = tOld_PgfStructure(j).facility_grp_id AND
             tNew_PgfStructure(i).prod_limit_ids <> tOld_PgfStructure(j).prod_limit_ids AND
             tNew_PgfStructure(i).tenor_value <> tOld_PgfStructure(j).tenor_value AND
             tNew_PgfStructure(i).group_type = 'TNR' THEN
             
             SCBP_P_PROCESS_GRP_TNR(p_ret_code,
                                    p_bank_group_code,
                                    p_cty_code,
                                    p_cust_id,
                                    tNew_PgfStructure(i).prod_limit_ids,
                                     tNew_PgfStructure(i).tenor_value,
                                    tNew_PgfStructure(i).facility_grp_id);
                                    
          END IF;

       END LOOP;
     
  END LOOP;
  
  -- PRODUCT GROUP FACILITY RESTRUCTURING END   --   
  
  FOR j IN 1..n_oldcount LOOP
       p_limit_found := FALSE;
       FOR i IN 1..n_newcount LOOP
          IF tNew_Structure(i).limit_id = tOld_Structure(j).limit_id THEN
                 p_limit_found := TRUE;
              EXIT;
            END IF;
       END LOOP;

       IF p_limit_found =  FALSE  THEN
    
          /*IF tOld_Structure(j).main_borrower_id <> ' ' THEN
             SCBP_TLS_CUST_CONVERT_CBR2O(p_ret_code,
                                         p_Bank_Group_Code,
                                         p_Cty_Code,
                                         tOld_Structure(j));
          END IF;*/
       IF tOld_Structure(j).limit_cat_code =  'I'  THEN
             SCBP_TLS_PROD_CONVERT_ALL_I2O (p_ret_code,
                                            p_bank_group_code,
                                            p_cty_code,
                                            tOld_Structure(j));
        
            SCBP_TLS_PROD_CONVERT_I2O     (p_ret_code,
                                            TRUE,
                                            p_bank_group_code,
                                            p_cty_code,
                                            tOld_Structure(j));
                                                       
             SCBP_TLS_PROD_DEL_O           (p_ret_code,
                                            p_bank_group_code,
                                            p_cty_code,
                                            p_cust_id,
                                            tOld_Structure(j));
         END IF;
    
          IF tOld_Structure(j).limit_cat_code =  'O'  THEN
    
             SCBP_TLS_PROD_CONVERT_ALL_I2O (p_ret_code,
                                            p_bank_group_code,
                                            p_cty_code,
                                            tOld_Structure(j));
        
             SCBP_TLS_PROD_DEL_O           (p_ret_code,
                                            p_bank_group_code,
                                            p_cty_code,
                                            p_cust_id,
                                            tOld_Structure(j));
    
        END IF;
               
          IF tOld_Structure(j).limit_cat_code =  'R' OR tOld_Structure(j).limit_cat_code =  'CR'  THEN
               
             SCBP_TLS_PROD_DEL_R(p_ret_code,
                                            tOld_Structure(j).limit_id);
                                             
          END IF;
       END IF;

  END LOOP;


  FOR i IN 1..n_newcount LOOP
       p_limit_found := FALSE;
       
       FOR j IN 1..n_oldcount LOOP
           IF tNew_Structure(i).limit_id = tOld_Structure(j).limit_id THEN
                old_index := j;
                p_limit_found := TRUE;
                EXIT;
           END IF;
       END LOOP;
           
       IF (p_limit_found <> TRUE) THEN 
          IF tNew_Structure(i).limit_cat_code =  'I'  THEN
        
             SCBP_TLS_PROD_CREATE_O    (p_ret_code,
                                        p_bank_group_code,
                                        p_cty_code,
                                        p_cust_id,
                                        tNew_Structure(i));

             /*SCBP_TLS_CUST_CONVERT_O2CBR(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tNew_Structure(i)); */
        
           SCBP_TLS_PROD_CONVERT_O2I (p_ret_code,
                                        p_bank_group_code,
                                        p_cty_code, 
                                        tNew_Structure(i));
        
          END IF;
        
          IF tNew_Structure(i).limit_cat_code =  'O'  THEN
        
             SCBP_TLS_PROD_CREATE_O    (p_ret_code,
                                        p_bank_group_code,
                                        p_cty_code,
                                        p_cust_id,
                                        tNew_Structure(i));
        
             /*SCBP_TLS_CUST_CONVERT_O2CBR(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tNew_Structure(i)); */
          END IF;
            
          IF tNew_Structure(i).limit_cat_code =  'R' OR tNew_Structure(i).limit_cat_code =  'CR'  THEN
        
             SCBP_TLS_PROD_CREATE_R    (p_ret_code,
                                        p_Bank_Group_Code,
                                        p_cty_code,
                                        p_New_Step_Id,
                                        tNew_Structure(i));
        
          END IF;
       ELSE 
          IF tNew_Structure(i).limit_cat_code <> tOld_Structure(old_index).limit_cat_code THEN
               
              IF (tNew_Structure(i).limit_cat_code = 'O') THEN
                
                   SCBP_TLS_PROD_CONVERT_I2O (p_ret_code,
                                              TRUE,
                                              p_bank_group_code,
                                              p_cty_code,
                                              tOld_Structure(old_index));
               
              END IF;               
                
              IF (tNew_Structure(i).limit_cat_code = 'I') THEN
                
                  SCBP_TLS_PROD_CONVERT_O2I (p_ret_code,
                                             p_bank_group_code,
                                             p_cty_code, 
                                             tNew_Structure(i));
                                               
              END IF;  
          END IF;    
             
          IF (tNew_Structure(i).limit_cat_code = 'I') THEN
              IF  tNew_Structure(i).limit_cat_code = tOld_Structure(old_index).limit_cat_code AND
                  tNew_Structure(i).inner_to_id <> tOld_Structure(old_index).inner_to_id  THEN
                      
                  SCBP_TLS_PROD_CONVERT_I2O (p_ret_code,
                                             TRUE,
                                             p_bank_group_code,
                                             p_cty_code,
                                             tOld_Structure(old_index));
                    
                  SCBP_TLS_PROD_CONVERT_O2I (p_ret_code,
                                             p_bank_group_code,
                                             p_cty_code, 
                                             tNew_Structure(i));
                                           
              END IF;
          END IF;
          
          /*IF (tOld_Structure(old_index).main_borrower_id = ' ' AND tNew_Structure(i).main_borrower_id <> ' ') THEN
                      
                  SCBP_TLS_CUST_CONVERT_O2CBR(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tNew_Structure(i)); 
             
          END IF;
          
          IF (tOld_Structure(old_index).main_borrower_id <> ' ' AND tNew_Structure(i).main_borrower_id = ' ') THEN
                      
                  SCBP_TLS_CUST_CONVERT_CBR2O(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tOld_Structure(old_index)); 
             
          END IF;
                  
          IF (tOld_Structure(old_index).main_borrower_id <> ' ' AND tNew_Structure(i).main_borrower_id <> ' ') AND
             (tOld_Structure(old_index).main_borrower_id <> tNew_Structure(i).main_borrower_id) THEN
                      
                  SCBP_TLS_CUST_CONVERT_CBR2O(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tOld_Structure(old_index)); 
             
                  SCBP_TLS_CUST_CONVERT_O2CBR(p_ret_code,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tNew_Structure(i)); 
          END IF;
          
        IF (tOld_Structure(old_index).limit_cat_code = 'R' AND tNew_Structure(i).limit_cat_code = 'R') THEN 
 
                  SCBP_TLS_PROD_COMP_RESTR   (p_ret_code,
                                              p_create_restr,
                                              p_Bank_Group_Code,
                                              p_Cty_Code,
                                              tOld_Structure(old_index),
                                              tNew_Structure(i));
             
                  IF p_create_restr = TRUE THEN                                     
       
                NULL;
      
               END IF;
          END IF;*/
       
       END IF;
       
  END LOOP;

 FOR i IN 1..n_newbcacount LOOP
     
     v_check_val := SCBF_CHECK_BCA_EXISTS_NEW(p_ret_code,
                                              p_bank_group_code,
                                              p_cty_code,
                                              p_cust_id,
                                              tNew_BcaStructure(i),
                                              tOld_BcaStructure);
     IF (v_check_val='Y') THEN
         
         SCBP_TLS_BCA_CREATE_LIMIT(p_ret_code,
                                   p_bank_group_code,
                                   p_cty_code,
                                   p_cust_id,
                                   tNew_BcaStructure(i), 
                                   p_new_step_id);
          
          if (tNew_BcaStructure(i).cpty_cond = 'INC') then
              FOR k IN 1..n_newbcacount LOOP
                   if (tNew_BcaStructure(k).cpty_cond = 'ANY') then
                       v_check_val := SCBF_CHECK_BCA_EXISTS_NEW(p_ret_code,
                                                  p_bank_group_code,
                                                  p_cty_code,
                                                  p_cust_id,
                                                  tNew_BcaStructure(k),
                                                  tOld_BcaStructure);
                        IF (v_check_val='N') THEN
                             SCBP_TLS_BCA_CREATE_LIMIT(p_ret_code,
                                     p_bank_group_code,
                                     p_cty_code,
                                     p_cust_id,
                                     tNew_BcaStructure(k), 
                                     p_new_step_id);
                         end if;
                    end if;
                end loop;
            end if;
                                   
     END IF;
     
 END LOOP;

 FOR i IN 1..n_newcount LOOP
      
     IF tNew_Structure(i).limit_cat_code <> 'V' THEN
    
        SCBP_UPDATE_OFFERING_REASON(p_ret_code,
                                     p_bank_group_code,
                                    p_cty_code,
                                    p_cust_id,
                                    tNew_Structure(i));
                    
     END IF;
                     
 END LOOP;
  
EXCEPTION

WHEN OTHERS THEN
     p_ret_code := SUBSTR(SQLERRM, 1, 150);
END;

END Scbp_Tls_Prod_Adjust_Utils;

--*************************************************************************************

PROCEDURE SCBP_TLS_Prod_ccyRevalProcess(p_ret_code        IN OUT VARCHAR2,
                                       p_bank_group_code VARCHAR2,
                                        p_cty_code        VARCHAR2,
                                        p_business_date   DATE,
                                        p_step_id         VARCHAR2) IS
BEGIN
  DECLARE
    update_timestamp DATE;
    prod_row_count   NUMBER;
    coll_row_count   NUMBER;
    v_facility_grp_id_count NUMBER;
    v_facility_grp_id  SCBT_R_CUST_FACILITY_GRP.FACILITY_GRP_ID%TYPE;
    v_facility_grp_ccy_code SCBT_R_CUST_FACILITY_GRP.LIMIT_AMT_CCY%TYPE;
    v_limit_amtexc_flag VARCHAR2(1);
    v_cust_id        SCBT_R_PARTY_MST.PARTY_ID%TYPE;
    v_active_amt     SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE;
    v_prod_util_amount SCBT_T_PROD_LIMIT_UTIL.LIMIT_CCY_UTILISED_AMT%TYPE;
    -- lim_amt          SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_active_amt%TYPE;
    v_limitAcctArray  parse.VARCHAR2_TABLE;
    v_ntokens  INTEGER;
    v_link_acc_no SCBT_T_CUST_ACC_SMRY_MST.ACC_NO%TYPE;
    v_link_acc_ccy SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_CODE%TYPE;
    v_link_anticipated_amt SCBT_T_CUST_ACC_SMRY_MST.ACC_CCY_ANTICIPATED_AMT%TYPE;
    v_od_cash_balance SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
    v_temp_od_cash_balance SCBT_T_PROD_LIMIT_REQ_LOG_DTL.TXN_CCY_AMT%TYPE;
    v_prod_limit_req_log_seq SCBT_T_PROD_LIMIT_REQ_LOG.REC_ID%TYPE;
    v_prod_limit_req_log_dtl_seq SCBT_T_PROD_LIMIT_REQ_LOG_DTL.INIT_REQ_ID%TYPE;
    v_deal_id SCBT_T_DEAL_REGISTER_HDR_MST.DEAL_ID%TYPE;
    v_tbu_code SCBT_T_DEAL_REGISTER_HDR_MST.BU_CODE%TYPE;
    v_risk_Sharing_Pct SCBT_R_CUST_RISK_SHARING_MST.RISK_PARTICIPATION_PCT%TYPE;
   
    TYPE type_ext_limit_id IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.EXT_LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE type_inner_to_id  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID %TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_cat_code IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CAT_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_ccy_active_amt IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_ccy_code IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_id IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_product_code IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE INDEX BY PLS_INTEGER;
    TYPE type_limit_type_code IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_TYPE_CODE%TYPE INDEX BY PLS_INTEGER;
  
    list_ext_limit_id type_ext_limit_id;
    list_inner_to_id type_inner_to_id;
    list_limit_cat_code type_limit_cat_code;
    list_limit_ccy_active_amt type_limit_ccy_active_amt;
    list_limit_ccy_code type_limit_ccy_code;
    list_limit_id type_limit_id;
    list_limit_product_code type_limit_product_code;
    list_limit_type_code type_limit_type_code;
    


    CURSOR prod_util_cur IS
    SELECT * FROM SCBT_T_PROD_LIMIT_UTIL utl WHERE LIMIT_ID IN (
        SELECT DISTINCT u.limit_id FROM
        SCBT_T_PROD_LIMIT_UTIL u, SCBT_T_PROD_LIMIT_REQ_LOG rh, SCBT_T_PROD_LIMIT_MVMT mv
        WHERE u.bank_group_code = p_bank_group_code
  AND u.cty_code = p_cty_code
  AND mv.limit_id = u.limit_id
  AND mv.txn_ccy_code <> u.limit_ccy_code
  AND mv.init_req_id = rh.init_req_id
  AND rh.req_type_code = 'NEW'
  AND rh.req_status_code IN ('PEND','CON'));

-- OVERALL LIMIT CURSOR --

  CURSOR ovl_cur IS
  SELECT S.cust_id, s.limit_id, s.LIMIT_CCY_CODE, s.LIMIT_CCY_ACTIVE_AMT
    FROM SCBT_R_CUST_PRODUCT_LIMIT S, SCBT_T_PROD_LIMIT_UTIL U
   WHERE S.BANK_GROUP_CODE = p_bank_group_code
     AND U.BANK_GROUP_CODE = S.BANK_GROUP_CODE
     AND S.CTY_CODE		     = p_cty_code
     AND U.CTY_CODE		     = S.CTY_CODE
     AND S.LIMIT_CAT_CODE  = 'V'
     AND S.LIMIT_ID        = U.LIMIT_ID
     AND U.LIMIT_CCY_UTILISED_AMT <> '0';

-- OUTER LIMIT CURSOR --

  CURSOR out_cur IS
  SELECT S.LIMIT_CCY_ACTIVE_AMT, S.LIMIT_CCY_CODE
    FROM SCBT_R_CUST_PRODUCT_LIMIT S
   WHERE S.BANK_GROUP_CODE = p_bank_group_code
     AND S.CTY_CODE        = p_cty_code
     AND S.CUST_ID         = v_cust_id
     AND S.LIMIT_CAT_CODE  = 'O';

-- LIMIT ID FOR OD FACILITY
  CURSOR od_out_cur IS
  SELECT S.CUST_ID, S.LIMIT_ID, S.LIMIT_CCY_ACTIVE_AMT
         , S.LIMIT_CCY_CODE, S.LIMIT_PRODUCT_CODE, S.OVERDRAFT_FACILITY_ACCNO
         , S.LIMIT_TYPE_CODE, NVL(S.CO_BORROWER_ID,'*') AS CO_BORROWER_ID, S.LIMIT_CAT_CODE
    FROM SCBT_R_CUST_PRODUCT_LIMIT S
   WHERE S.BANK_GROUP_CODE = p_bank_group_code
     AND S.CTY_CODE        = p_cty_code
     --and s.cust_id in ('800007245')
     AND LIMIT_PRODUCT_CODE IN ('OD','ODID');


--Coll util method is enabled on 07-Jan-2013
    CURSOR coll_util_cur IS
    SELECT * FROM scbt_t_coll_limit_util utl1 WHERE LIMIT_ID IN (
        SELECT DISTINCT u.limit_id FROM
        scbt_t_coll_limit_util u, scbt_t_coll_limit_req_log rh, scbt_t_coll_limit_mvmt mv
        WHERE u.bank_group_code = p_bank_group_code
  AND u.cty_code = p_cty_code
  AND mv.limit_id = u.limit_id
  AND mv.txn_ccy_code <> u.limit_ccy_code
  AND mv.init_req_id = rh.init_req_id
  AND rh.req_type_code = 'NEW'
  AND rh.req_status_code IN ('PEND','CON'));

    coll_util_amt scbt_t_coll_limit_util.limit_ccy_utilised_amt%TYPE;
    coll_pend_inc_amt scbt_t_coll_limit_util.limit_ccy_pend_inc_amt%TYPE;
    coll_pend_dec_amt scbt_t_coll_limit_util.limit_ccy_pend_dec_amt%TYPE;


    -- nRecCount INT;

  BEGIN

    p_ret_code := '0000';
    v_limit_amtexc_flag := 'N';
    -- step 1 Check if all fx rates are available for Product Limits
    SELECT COUNT(1)
      INTO prod_row_count
      FROM (SELECT DISTINCT rd.txn_ccy_code AS ccy_code
              FROM SCBT_T_PROD_LIMIT_REQ_LOG rh, SCBT_T_PROD_LIMIT_REQ_LOG_DTL rd
             WHERE rh.bank_group_code = p_bank_group_code
               AND rh.CTY_CODE = p_cty_code
               AND rh.REQ_TYPE_CODE = 'NEW'
               AND rh.REQ_STATUS_CODE IN ('PEND', 'CON')
               AND rd.init_req_id = rh.init_req_id
               AND rd.txn_ccy_code IS NOT NULL
            UNION
            SELECT DISTINCT limit_ccy_code
              FROM SCBT_T_PROD_LIMIT_UTIL
             WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code
               AND LIMIT_CCY_CODE IS NOT NULL
            MINUS
            SELECT DISTINCT fx_ccy_code
              FROM SCBT_R_LIMIT_FX_MAINT_MST
             WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code
            MINUS
            SELECT ccy_code
              FROM SCBT_R_CTY_MST
             WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code);

    IF prod_row_count > 0 THEN
       p_ret_code := '0001';
       GOTO end_procedure;
    END IF;

     --This statement enabled on 07-JAN-2013
     -- step 2 Check if all fx rates are available for Collateral Limits
    SELECT COUNT(1)
      INTO coll_row_count
      FROM (SELECT DISTINCT rd.txn_ccy_code AS ccy_code
              FROM scbt_t_coll_limit_req_log rh, scbt_t_coll_limit_req_log_dtl rd
             WHERE rh.bank_group_code = p_bank_group_code
               --AND rh.TBU_CTY_CODE = p_cty_code --Commented on 07-JAN-2013
               AND rh.CTY_CODE = p_cty_code
               AND rh.REQ_TYPE_CODE = 'NEW'
               AND rh.REQ_STATUS_CODE IN ('PEND', 'CON')
               AND rd.init_req_id = rh.init_req_id
               AND rd.txn_ccy_code IS NOT NULL
            UNION
            SELECT DISTINCT limit_ccy_code
     FROM scbt_t_coll_limit_util
            WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code
            MINUS
            SELECT DISTINCT fx_ccy_code
              FROM scbt_r_limit_fx_maint_mst
             WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code
            MINUS
            SELECT ccy_code
              FROM scbt_r_cty_mst
             WHERE bank_group_code = p_bank_group_code
               AND CTY_CODE = p_cty_code);

    IF coll_row_count > 0 THEN
      p_ret_code := '0001';
      GOTO end_procedure;
    END IF;


    -- step 3 Check if any rates have changed since last refresh for Product Limits
    SELECT COUNT(1)
      INTO prod_row_count
      FROM (SELECT a.fx_ccy_code, a.multiplying_factor
              FROM SCBT_R_LIMIT_FX_RATE_MST a, SCBT_R_LIMIT_FX_MAINT_MST b
             WHERE a.bank_group_code = p_bank_group_code
               AND a.cty_code = p_cty_code
               AND b.bank_group_code = a.bank_group_code
               AND b.cty_code = a.cty_code
               AND b.fx_ccy_code = a.fx_ccy_code
            MINUS
            SELECT a.fx_ccy_code, a.multiplying_factor
                  FROM SCBT_R_LIMIT_FX_MAINT_MST a, SCBT_R_LIMIT_FX_RATE_MST b
             WHERE a.bank_group_code = p_bank_group_code
               AND a.cty_code = p_cty_code
               AND b.bank_group_code = a.bank_group_code
               AND b.cty_code = a.cty_code
               AND b.fx_ccy_code = a.fx_ccy_code);

    IF prod_row_count = 0 THEN
      -- no rate change since last refresh
      -- insert any new rates available and proceed to Collateral limits
      INSERT INTO SCBT_R_LIMIT_FX_RATE_MST
        (bank_group_code,
         cty_code,
         fx_ccy_code,
         fx_ccy_decimal_no,
         base_ccy_code,
         base_ccy_decimal_no,
         rate,
         multiplying_factor,
         ccy_units,
         refresh_date,
         step_id,
         upd_timestamp)
        SELECT fxm.BANK_GROUP_CODE,
               fxm.CTY_CODE,
               fxm.FX_CCY_CODE,
               (SELECT gcm.CCY_PARITY
                  FROM SCBT_R_GLOBAL_CCY_MST gcm
                 WHERE gcm.CCY_CODE = fxm.FX_CCY_CODE) FX_CCY_DEC_NO,
               fxm.BASE_CCY_CODE,
               (SELECT gcm.CCY_PARITY
                  FROM SCBT_R_GLOBAL_CCY_MST gcm
                 WHERE gcm.CCY_CODE = fxm.BASE_CCY_CODE) BASE_CCY_DEC_NO,
               fxm.rate,
               fxm.MULTIPLYING_FACTOR,
               ccy_units,
               p_business_date,
               p_step_id,
               SYSDATE
          FROM SCBT_R_LIMIT_FX_MAINT_MST fxm
         WHERE fxm.BANK_GROUP_CODE = p_bank_group_code
           AND fxm.CTY_CODE = p_cty_code
           AND fxm.fx_ccy_code NOT IN
               (SELECT fx_ccy_code
                  FROM SCBT_R_LIMIT_FX_RATE_MST
                 WHERE bank_group_code = p_bank_group_code
                   AND cty_code = p_cty_code);
    END IF;

    -- step 4 Check if any rates have changed since last refresh for Collateral Limits
/*    SELECT COUNT(1)
      INTO coll_row_count
      FROM (SELECT a.fx_ccy_code, a.multiplying_factor
              FROM scbt_r_limit_fx_rate_mst a, scbt_r_limit_fx_maint_mst b
             WHERE a.bank_group_code = p_bank_group_code
               AND a.cty_code = p_cty_code
               AND b.bank_group_code = a.bank_group_code
               AND b.cty_code = a.cty_code
               AND b.fx_ccy_code = a.fx_ccy_code
            MINUS
            SELECT a.fx_ccy_code, a.multiplying_factor
              FROM scbt_r_limit_fx_maint_mst a, scbt_r_limit_fx_rate_mst b
             WHERE a.bank_group_code = p_bank_group_code
               AND a.cty_code = p_cty_code
               AND b.bank_group_code = a.bank_group_code
               AND b.cty_code = a.cty_code
               AND b.fx_ccy_code = a.fx_ccy_code);

*/
   --Modified on 07-JAN-2013 
    IF coll_row_count = 0 THEN
      -- IF prod_row_count = 0 THEN
      -- no rate change since last refresh
      -- insert any new rates available and return successfully
      INSERT INTO SCBT_R_LIMIT_FX_RATE_MST
        (bank_group_code,
         cty_code,
         fx_ccy_code,
         fx_ccy_decimal_no,
         base_ccy_code,
         base_ccy_decimal_no,
         rate,
         multiplying_factor,
         ccy_units,
         refresh_date,
         step_id,
         upd_timestamp)
        SELECT fxm.BANK_GROUP_CODE,
               fxm.CTY_CODE,
               fxm.FX_CCY_CODE,
               (SELECT gcm.CCY_PARITY
                  FROM SCBT_R_GLOBAL_CCY_MST gcm
                 WHERE gcm.CCY_CODE = fxm.FX_CCY_CODE) FX_CCY_DEC_NO,
               fxm.BASE_CCY_CODE,
               (SELECT gcm.CCY_PARITY
                  FROM SCBT_R_GLOBAL_CCY_MST gcm
                 WHERE gcm.CCY_CODE = fxm.BASE_CCY_CODE) BASE_CCY_DEC_NO,
               fxm.rate,
               fxm.MULTIPLYING_FACTOR,
               ccy_units,
               p_business_date,
               p_step_id,
               SYSDATE
          FROM SCBT_R_LIMIT_FX_MAINT_MST fxm
         WHERE fxm.BANK_GROUP_CODE = p_bank_group_code
           AND fxm.CTY_CODE = p_cty_code
           AND fxm.fx_ccy_code NOT IN
               (SELECT fx_ccy_code
                  FROM SCBT_R_LIMIT_FX_RATE_MST
                 WHERE bank_group_code = p_bank_group_code
                   AND cty_code = p_cty_code);

      p_ret_code := '0000';
      --NULL;
     -- GOTO end_procedure;
    END IF;

    -- step 5 Backup existing values
    update_timestamp := SYSDATE;

    BEGIN
    INSERT INTO SCBT_R_LIMIT_FX_RATE_HIST
      (bank_group_code,
       base_ccy_code,
       base_ccy_decimal_no,
       ccy_units,
       cty_code,
       fx_ccy_code,
       fx_ccy_decimal_no,
       rate,
       multiplying_factor,
       record_lock_flag,
       refresh_date,
       step_id,
       upd_timestamp)
      SELECT bank_group_code,
             base_ccy_code,
             base_ccy_decimal_no,
             ccy_units,
             cty_code,
             fx_ccy_code,
             fx_ccy_decimal_no,
             rate,
             multiplying_factor,
             record_lock_flag,
             refresh_date,
             step_id,
             update_timestamp
        FROM SCBT_R_LIMIT_FX_RATE_MST
       WHERE bank_group_code = p_bank_group_code
         AND cty_code = p_cty_code;
    EXCEPTION WHEN OTHERS THEN
     NULL;
    END;
    -- step 6 Get new rates

    DELETE FROM SCBT_R_LIMIT_FX_RATE_MST
     WHERE bank_group_code = p_bank_group_code
       AND cty_code = p_cty_code;

    INSERT INTO SCBT_R_LIMIT_FX_RATE_MST
      (bank_group_code,
       cty_code,
       fx_ccy_code,
       fx_ccy_decimal_no,
       base_ccy_code,
       base_ccy_decimal_no,
       rate,
       multiplying_factor,
       ccy_units,
       refresh_date,
       step_id,
       upd_timestamp)
      SELECT fxm.BANK_GROUP_CODE,
             fxm.CTY_CODE,
             fxm.FX_CCY_CODE,
             (SELECT gcm.CCY_PARITY
                FROM SCBT_R_GLOBAL_CCY_MST gcm
               WHERE gcm.CCY_CODE = fxm.FX_CCY_CODE) FX_CCY_DEC_NO,
             fxm.BASE_CCY_CODE,
             (SELECT gcm.CCY_PARITY
                FROM SCBT_R_GLOBAL_CCY_MST gcm
               WHERE gcm.CCY_CODE = fxm.BASE_CCY_CODE) BASE_CCY_DEC_NO,
             fxm.rate,
             fxm.MULTIPLYING_FACTOR,
             ccy_units,
             p_business_date,
             p_step_id,
             SYSDATE
        FROM SCBT_R_LIMIT_FX_MAINT_MST fxm
       WHERE fxm.BANK_GROUP_CODE = p_bank_group_code
         AND fxm.CTY_CODE = p_cty_code;

    -- step 7 Apply new rates

    FOR utl IN prod_util_cur


    LOOP

            SCBP_TLS_UPDATE_LIMIT_UTIL(p_ret_code,
                                            p_bank_group_code,
                                            p_cty_code, utl.limit_id,
                                            utl.limit_ccy_code,
                      'PROD');


    END LOOP;

        BEGIN
    FOR ovl IN ovl_cur LOOP

        v_cust_id      := ovl.cust_id;
        v_active_amt   := 0;


        FOR out IN out_cur LOOP

            IF out.LIMIT_CCY_CODE <> ovl.limit_ccy_code THEN

               v_active_amt  := v_active_amt+ NVL(SCBF_TLS_EXCH_RATE(p_bank_Group_Code,        -- BANK GROUP CODE
        		                                                         p_cty_Code,               -- COUNTRY CODE
        	                                                           out.limit_ccy_code,       -- FROM CURR CODE
                                                                     out.limit_ccy_active_amt, -- FROM AMOUNT
        	                                                           ovl.limit_ccy_code,       -- TO CURR CODE
                                                                     'N'),0);                  -- ROUNG FLAG

            ELSE

               v_active_amt  := v_active_amt + out.limit_ccy_active_amt;

            END IF;

        END LOOP;



        IF v_active_amt <> ovl.limit_ccy_active_amt THEN

           UPDATE SCBT_R_CUST_PRODUCT_LIMIT
              SET LIMIT_CCY_ACTIVE_AMT = v_active_amt
            WHERE BANK_GROUP_CODE      = p_bank_group_code
              AND CTY_CODE             = p_cty_code
              AND CUST_ID              = ovl.cust_id
              AND LIMIT_CAT_CODE       = 'V';

        END IF;

    END LOOP;
        EXCEPTION WHEN OTHERS THEN
          NULL;
        END;

-- To calculate limit active amount for OD -START
    FOR od_out IN od_out_cur LOOP

      v_prod_util_amount   :=0;
      v_od_cash_balance    :=0;
      v_limit_amtexc_flag    :='N';
      v_risk_Sharing_Pct     :=(100);
      
     BEGIN
      --To calculate CUST PRODUCT LIMIT ID
      BEGIN
            IF od_out.CO_BORROWER_ID <> '*' THEN
                 SELECT NVL(LIMIT_CCY_UTILISED_AMT,0) INTO v_prod_util_amount
                 FROM SCBT_T_PROD_LIMIT_UTIL
                 WHERE BANK_GROUP_CODE = p_bank_group_code
                 AND CTY_CODE = p_cty_code					
                 AND limit_id = od_out.limit_id;
            ELSE        
                 v_prod_util_amount := SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT (
                                    p_bank_group_code
                                    , p_cty_code
                                    , od_out.cust_id
                                    , od_out.limit_id
                                    , od_out.limit_ccy_code
                                    , od_out.limit_product_code);
            END IF;
      EXCEPTION WHEN OTHERS THEN
        v_limit_amtexc_flag  := 'Y';
        v_prod_util_amount   := 0;
      END;
      
      IF od_out.overdraft_facility_accno IS NOT NULL THEN
         --Converting formula into TABLE
         parse.delimstring_to_table(od_out.overdraft_facility_accno, v_limitAcctArray, v_ntokens, ',');
         v_temp_od_cash_balance   := 0;

         FOR odAccountVar in 1..v_ntokens LOOP
             v_link_acc_ccy := substr(v_limitAcctArray(odAccountVar), 0,3);
             v_link_acc_no := substr(v_limitAcctArray(odAccountVar), 5, length(v_limitAcctArray(odAccountVar)));

             BEGIN
                 SELECT A.ACC_CCY_ANTICIPATED_AMT into v_link_anticipated_amt 
                 FROM SCBT_T_CUST_ACC_SMRY_MST A, SCBT_R_CUST_ACCT_MAINTENANCE C
                 WHERE A.BANK_GROUP_CODE = C.BANK_GROUP_CODE AND A.CTY_CODE = C.CTY_CODE
                 AND A.CUST_ID = C.CUST_ID AND A.ACC_NO = C.ACC_NO AND A.ACC_CCY_CODE = C.ACC_CCY_CODE
                 AND A.BANK_GROUP_CODE = p_bank_group_code
                 AND A.CTY_CODE = p_cty_code
                 AND A.ACC_NO = v_link_acc_no
                 AND A.ACC_CCY_CODE = v_link_acc_ccy
                 AND A.CUST_ID = od_out.cust_id
                 AND C.CUST_CO_BORROWER_ID = DECODE(od_out.CO_BORROWER_ID,'*',od_out.cust_id,od_out.CO_BORROWER_ID);
  
               IF od_out.limit_ccy_code <> v_link_acc_ccy THEN
                  v_temp_od_cash_balance := v_temp_od_cash_balance + NVL(SCBF_TLS_EXCH_RATE(
                                                                       p_bank_Group_Code,        -- BANK GROUP CODE
          		                                                         p_cty_Code,               -- COUNTRY CODE
          	                                                           v_link_acc_ccy,       -- FROM CURR CODE
                                                                       v_link_anticipated_amt, -- FROM AMOUNT
          	                                                           od_out.limit_ccy_code,       -- TO CURR CODE
                                                                       'N'),0);
               ELSE
                  v_temp_od_cash_balance  := v_temp_od_cash_balance + v_link_anticipated_amt;
               END IF;

             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;  
         END LOOP;

         --To compare prod util amount with OD facility cash balance
         IF v_temp_od_cash_balance != 0 OR v_prod_util_amount !=0 THEN
               --IF available cash balance is zero then consider prod util amount as negative value
             IF v_temp_od_cash_balance > 0 THEN
               v_od_cash_balance := v_prod_util_amount * -1;
             ELSIF abs(v_temp_od_cash_balance) != v_prod_util_amount THEN
               IF v_limit_amtexc_flag = 'Y' AND v_prod_util_amount = 0 THEN
                v_prod_util_amount := abs(v_temp_od_cash_balance);
               END IF; 
               v_od_cash_balance := abs(v_temp_od_cash_balance) - v_prod_util_amount;
             END IF;

        if v_od_cash_balance <> 0 then
          -- Added by Kishore (1324077) for OD Syndication  handling (JIRA ID :COCOA-994)
          v_risk_Sharing_Pct := (SCBF_GET_SCB_RISK_SHARING_PCT (p_bank_Group_Code , p_cty_Code , od_out.cust_id, od_out.limit_id ));
            v_od_cash_balance :=v_od_cash_balance*(v_risk_Sharing_Pct /100);
             --To get rec id
             BEGIN
               select SCBS_C_RECID.NEXTVAL into V_PROD_LIMIT_REQ_LOG_SEQ from DUAL;
             EXCEPTION WHEN OTHERS THEN
               v_prod_limit_req_log_seq := NULL;
             END;

             --To get deal id, bu code from DEAL_REGISTER HDR MST table for limit id
             BEGIN
               select DEAL_ID, BU_CODE into v_deal_id, v_tbu_code from SCBT_T_DEAL_REGISTER_HDR_MST
                  WHERE BANK_GROUP_CODE=p_bank_Group_Code
                  AND CTY_CODE=p_cty_Code
                  AND CUST_ID= od_out.cust_id
                  AND PROD_LIMIT_ID=od_out.limit_id;
             EXCEPTION WHEN OTHERS THEN
               v_deal_id := NULL;
               v_tbu_code := NULL;
             END;

             --To insert data INTO SCBT_T_PROD_LIMIT_REQ_LOG table
             BEGIN
               INSERT INTO SCBT_T_PROD_LIMIT_REQ_LOG
                (
                  BANK_GROUP_CODE,
                  CTY_CODE,
                  REC_ID,
                 -- REQ_ID,
                  BUS_EVENT_REF_NO,
                  INIT_REQ_ID,
                  REQ_STATUS_CODE,
                  SYS_CODE,
                  USER_ID,
                  REQ_TYPE_CODE,
                  FORCE_POST_FLAG,
                  REQ_TIMESTAMP,
                  LOG_STATUS_CODE,
                  TBU_CODE,
                  BUSINESS_DATE
                )
                values
                (
                  p_bank_Group_Code
                  , p_cty_Code
                  , v_prod_limit_req_log_seq
                  --, NULL
                  , v_prod_limit_req_log_seq
                  , v_prod_limit_req_log_seq
                  , 'CON'
                  , 'COCO'
                  , 'SYSTEM'
                  , 'NEW'
                  , 'Y'
                  , SYSDATE
                  , 'PROC'
                  , v_tbu_code
                  , p_business_date
                );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;


              --To insert data INTO SCBT_T_PROD_LIMIT_REQ_LOG_DTL table
              BEGIN
                INSERT INTO SCBT_T_PROD_LIMIT_REQ_LOG_DTL
                (
                  BANK_GROUP_CODE,
                  CTY_CODE,
                  INIT_REQ_ID,
                  REQ_SR_NO,
                  REQ_ID,
                  DEAL_ID,
                  STEP_ID,
                  LIMIT_PRODUCT_CODE,
                  LIMIT_TYPE_CODE,
                  TXN_CCY_CODE,
                  TXN_CCY_AMT,
                  OBLIGOR_ID,
                  CPTY_ID,
                  CPTY_CTY_CODE,
                  OBLIGOR_CTY_CODE,
                  CPTY_ROLE_CODE,
                  LIMIT_TREE_TYPE_CODE,
                  PROD_LIMIT_ID,
                  COLL_LIMIT_ID,
                  TOTAL_CREDIT_PERIOD,
                  BILL_TENOR,
                  SUB_PRODUCT_TYPE_CODE,
                  MANUAL_OFFERING_FLAG,
                  MANUAL_OFFERING_REASON,
                  REVOLVING_LC_TYPE,
                  EVERGREEN_LC_TYPE,
                  CO_BORROWER_ID,
                  TXN_REF_ID,
                  TP_REF_NO,
                  MATURITY_DATE,
                  TXN_REC_ID,
                  PAYMENT_METHOD,
                  CTY_OF_SALE,
                  BOOKING_BRANCH,
                  SYN_TXN_CCY_AMT,
                  ISS_BOOKING_BRANCH
                )
                VALUES
                (
                  p_bank_Group_Code
                  , p_cty_Code
                  , v_prod_limit_req_log_seq
                  , 1
                  , NULL
                  , v_deal_id
                  , 'REVAL'
                  , od_out.limit_product_code
                  , od_out.limit_type_code
                  , od_out.limit_ccy_code
                  , v_od_cash_balance
                  , od_out.cust_id
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , 'PROD'
                  , od_out.limit_id
                  , NULL
                  , 0
                  , 0
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , od_out.co_borrower_id
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , NULL
                  , v_od_cash_balance
                  , NULL
                );

              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;

      --To insert data into LIMIT MOVEMENT table
      --START

        SELECT EXT_LIMIT_ID, INNER_TO_ID, LIMIT_CAT_CODE
        			, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_CODE, LIMIT_ID
              BULK COLLECT INTO
                list_ext_limit_id, list_inner_to_id, list_limit_cat_code
                , list_limit_ccy_active_amt, list_limit_ccy_code, list_limit_id
        FROM (
        SELECT  EXT_LIMIT_ID, INNER_TO_ID, LIMIT_CAT_CODE
        			, LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_CODE, LIMIT_ID
        			 FROM SCBT_R_CUST_PRODUCT_LIMIT
        			      WHERE BANK_GROUP_CODE = p_bank_Group_Code
        			      AND CTY_CODE = p_cty_Code
                    AND CUST_ID = od_out.cust_id
        			      AND limit_cat_code ='V'
        UNION
        SELECT  EXT_LIMIT_ID, INNER_TO_ID, LIMIT_CAT_CODE
        			,LIMIT_CCY_ACTIVE_AMT, LIMIT_CCY_CODE, LIMIT_ID
        			 FROM SCBT_R_CUST_PRODUCT_LIMIT
        			      START WITH limit_id = od_out.limit_id
        			      CONNECT BY NOCYCLE PRIOR  inner_to_id=ext_limit_id
        			      AND BANK_GROUP_CODE = p_bank_Group_Code
        			      AND CTY_CODE = p_cty_Code
                    AND CUST_ID = od_out.cust_id
        			      AND limit_cat_code in ('I','O', 'CI')
            );
      --END IF;

      --To insert data on PROD LIMIT MOVEMENT table
      FOR intLimitRow IN 1..list_limit_id.COUNT LOOP

        INSERT INTO SCBT_T_PROD_LIMIT_MVMT
          (
            BANK_GROUP_CODE
            , CTY_CODE
            , LIMIT_ID
            , INIT_REQ_ID
            , REQ_SR_NO
            , TXN_CCY_CODE
            , TXN_CCY_AMT
            , LIMIT_TREE_TYPE_CODE
            , OBLIGOR_ID
            , OFFERING_FLAG
            , OFFERING_REASON)
         VALUES (
             p_bank_Group_Code
             , p_cty_code
             , list_limit_id(intLimitRow)
             , v_prod_limit_req_log_seq
             , 1
             , od_out.limit_ccy_code
             , v_od_cash_balance --list_limit_ccy_active_amt(intLimitRow)
             , 'PROD'
             , od_out.cust_id
             , 'N'
             , NULL
           );
           
           
           --19-FEB-2013 --To insert facility group in SCBT_T_PROD_LIMIT_MVMT and SCBP_TLS_UPDATE_LIMIT_UTIL
           --START
           v_facility_grp_id_count := 0;
           BEGIN
              SELECT COUNT(1) INTO v_facility_grp_id_count 
                 FROM SCBT_R_CUST_FACILITY_GRP 
               WHERE BANK_GROUP_CODE= p_bank_group_code AND CTY_CODE = p_cty_code
                 AND CUST_ID = od_out.cust_id 
                 AND GROUP_TYPE='AMT'
                 AND od_out.limit_id IN (SELECT * FROM TABLE(SPLIT(PROD_LIMIT_IDS))); 
           
           EXCEPTION WHEN OTHERS THEN
              v_facility_grp_id_count := 0;
           END; 
           
           IF v_facility_grp_id_count > 0 THEN

             v_facility_grp_id := NULL;
             v_facility_grp_ccy_code := NULL;
             BEGIN
                SELECT FACILITY_GRP_ID, LIMIT_AMT_CCY
                  INTO v_facility_grp_id, v_facility_grp_ccy_code 
                   FROM SCBT_R_CUST_FACILITY_GRP 
                 WHERE BANK_GROUP_CODE= p_bank_group_code AND CTY_CODE = p_cty_code
                   AND CUST_ID = od_out.cust_id 
                   AND GROUP_TYPE='AMT'
                   AND od_out.limit_id IN (SELECT * FROM TABLE(SPLIT(PROD_LIMIT_IDS))); 
             
             EXCEPTION WHEN OTHERS THEN
                v_facility_grp_id := NULL;
                v_facility_grp_ccy_code := NULL;
             END;              
           
             BEGIN
                --To insert Group data in SCBT_T_PROD_LIMIT_MVMT
                INSERT INTO SCBT_T_PROD_LIMIT_MVMT
                  (
                    BANK_GROUP_CODE
                    , CTY_CODE
                    , LIMIT_ID
                    , INIT_REQ_ID
                    , REQ_SR_NO
                    , TXN_CCY_CODE
                    , TXN_CCY_AMT
                    , LIMIT_TREE_TYPE_CODE
                    , OBLIGOR_ID
                    , OFFERING_FLAG
                    , OFFERING_REASON)
                 VALUES (
                     p_bank_Group_Code
                     , p_cty_code
                     , v_facility_grp_id
                     , v_prod_limit_req_log_seq
                     , 1
                     , od_out.limit_ccy_code
                     , v_od_cash_balance --list_limit_ccy_active_amt(intLimitRow)
                     , 'GPROD'
                     , od_out.cust_id
                     , 'N'
                     , NULL
                   );                
                   
                --To insert data in SCBP_TLS_UPDATE_LIMIT_UTIL
                SCBP_TLS_UPDATE_LIMIT_UTIL(
                  p_ret_code
                  , p_bank_group_code
                  , p_cty_code
                  , v_facility_grp_id
                  , v_facility_grp_ccy_code
                  , 'GPROD');
             
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;  
           
           
           END IF;
                      
           --19-FEB-2013 --To insert facility group in SCBT_T_PROD_LIMIT_MVMT and SCBP_TLS_UPDATE_LIMIT_UTIL
           --END
           

           --To update Limit Utilization
           SCBP_TLS_UPDATE_LIMIT_UTIL(
                p_ret_code
                , p_bank_group_code
                , p_cty_code
                , list_limit_id(intLimitRow)
                , list_limit_ccy_code(intLimitRow)
                , 'PROD');

        --END
      END LOOP;             
              
         END IF;
      END IF;
    END IF;

    EXCEPTION WHEN OTHERS THEN
     NULL;
     END;
    END LOOP;
-- To calculate limit active amount for OD -END


/* Coll util method is enabled on 07-Jan-2013 and Scbk_P_Coll_Tls */
    FOR utl1 IN coll_util_cur
       LOOP
       
          Scbk_P_Coll_Tls.SCBP_TLS_UPDATE_LIMIT_UTIL(
                               p_ret_code,
                               p_bank_group_code,
                               p_cty_code, 
                               utl1.LIMIT_TREE_TYPE_CODE,
                               utl1.limit_id,
                               utl1.limit_ccy_code
                               );
/*
          SCBP_TLS_UPDATE_COLL_LIMIT_UTIL(p_ret_code,
                                          p_bank_group_code,
                                          p_cty_code, utl1.limit_id,
                                          utl1.limit_ccy_code)
*/                                          
                                          
       END LOOP;

  COMMIT;

    <<end_procedure>>

    RETURN;

  EXCEPTION

    WHEN OTHERS THEN
      ROLLBACK;
      DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
      p_ret_code := SUBSTR(SQLERRM, 1, 150);

  END;

END SCBP_TLS_Prod_ccyRevalProcess;

--***********************************************************--

PROCEDURE SCBP_ADJUST_ABS_LIMIT (p_ret_code IN OUT VARCHAR2,
                                 p_bank_group_code VARCHAR2,
                                 p_cty_code VARCHAR2,
                                 p_cust_id VARCHAR2,
                                 p_ccy_code VARCHAR2) IS

CURSOR bca_limit IS
SELECT limit_id, limit_ccy_code
  FROM SCBT_R_CUST_BCA_COND_LIMIT
 WHERE bank_group_code = p_bank_group_code
   AND cty_code = p_cty_code
   AND limit_ccy_code <> p_ccy_code   
   AND cust_id  = p_cust_id
   AND limit_ccy_active_amt = '999999999999'
   AND cpty_cond <> 'ANY';
   
CURSOR bca_adhoc IS
SELECT a.limit_id, a.limit_ccy_code
  FROM SCBT_R_CUST_BCA_COND_LIMIT m,
       SCBT_R_CUST_ADH_BCA_COND_MST a
 WHERE m.bank_group_code = p_bank_group_code
   AND m.cty_code = p_cty_code
   AND m.limit_ccy_code <> p_ccy_code   
   AND m.cust_id  = p_cust_id
   AND m.limit_ccy_active_amt = '999999999999'
   AND m.cpty_cond = 'ANY'   
   AND m.bank_group_code = a.bank_group_code
   AND m.cty_code = a.cty_code
   AND m.limit_id = a.bca_limit_id;
     
BEGIN

   FOR lmt IN bca_limit LOOP

       UPDATE SCBT_R_CUST_BCA_COND_LIMIT
          SET limit_ccy_code  = p_ccy_code
        WHERE bank_group_code = p_bank_group_code
          AND cty_code        = p_cty_code
          AND cust_id         = p_cust_id
          AND limit_id        = lmt.limit_id;
        
       UPDATE SCBT_T_PROD_LIMIT_UTIL
          SET limit_ccy_code  = p_ccy_code
        WHERE bank_group_code = p_bank_group_code
          AND cty_code        = p_cty_code
          AND limit_id        = lmt.limit_id;  
         
       SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                   p_Bank_Group_Code,
                                   p_Cty_Code,
                                   lmt.limit_id,
                                   p_ccy_code,
                                   'BCAP');
                   
   END LOOP;
   
   FOR lmt IN bca_adhoc LOOP

       UPDATE SCBT_R_CUST_ADH_BCA_COND_MST
          SET limit_ccy_code  = p_ccy_code
        WHERE bank_group_code = p_bank_group_code
          AND cty_code        = p_cty_code
          AND cust_id         = p_cust_id
          AND limit_id        = lmt.limit_id;
         
       UPDATE SCBT_T_PROD_LIMIT_UTIL
          SET limit_ccy_code  = p_ccy_code
        WHERE bank_group_code = p_bank_group_code
          AND cty_code        = p_cty_code
          AND limit_id        = lmt.limit_id;  
         
       SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                   p_Bank_Group_Code,
                                   p_Cty_Code,
                                   lmt.limit_id,
                                   p_ccy_code,
                                   'BCAP');
                   
   END LOOP;
   
EXCEPTION

WHEN OTHERS THEN
     NULL;

END SCBP_ADJUST_ABS_LIMIT;

--***********************************************************--

PROCEDURE SCBP_ADJUST_PGF_LIMIT (p_ret_code IN OUT VARCHAR2,
                                 p_bank_group_code VARCHAR2,
                                 p_cty_code VARCHAR2,
                                 p_cust_id VARCHAR2,
                                 p_ccy_code VARCHAR2) IS

CURSOR pgf_setup_limit IS
SELECT facility_grp_id, limit_amt_ccy
  FROM SCBT_R_CUST_FACILITY_GRP
 WHERE bank_group_code = p_bank_group_code
   AND cty_code        = p_cty_code
   AND cust_id         = p_cust_id
   AND limit_amt_ccy <> p_ccy_code
   AND group_type = 'AMT';

BEGIN

   FOR lmt IN pgf_setup_limit LOOP

        UPDATE SCBT_R_CUST_FACILITY_GRP
           SET limit_amt_ccy  = p_ccy_code
         WHERE bank_group_code = p_bank_group_code
           AND cty_code        = p_cty_code
           AND cust_id         = p_cust_id
           AND facility_grp_id = lmt.facility_grp_id;
         
        UPDATE SCBT_T_PROD_LIMIT_UTIL
           SET limit_ccy_code = p_ccy_code
         WHERE bank_group_code = p_bank_group_code
           AND cty_code        = p_cty_code
           AND limit_id = lmt.facility_grp_id;  
         
        SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                    p_Bank_Group_Code,
                                    p_Cty_Code,
                                    lmt.facility_grp_id,
                                    p_ccy_code,
                                    'GPROD');
                   
   END LOOP;
   
EXCEPTION

WHEN OTHERS THEN
     NULL;

END SCBP_ADJUST_PGF_LIMIT;

--***********************************************************--
-- THIS PROCEDURE WILL REVALUATE ALL THE LIMITS UNDER THE CUSTOMER WITH THE NEW OVERALL EXPOSURE CURRENCY --

PROCEDURE SCBP_TLS_update_overall_ccy(p_ret_code        IN OUT VARCHAR2,
                                      p_bank_group_code VARCHAR2,
                                      p_cty_code        VARCHAR2,
                                      p_Cust_Id           VARCHAR2,
                                      p_ccy_code        VARCHAR2) IS
                    

BEGIN

DECLARE

ov_Old_Ccy             SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE;
ov_limit_id            SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE;
ov_limit_amt           SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_active_amt%TYPE;

BEGIN
   BEGIN
       p_ret_code := '0000';

      SELECT limit_id, limit_ccy_code INTO ov_limit_id, ov_Old_Ccy
        FROM SCBT_R_CUST_PRODUCT_LIMIT
       WHERE bank_group_code = p_Bank_Group_Code
         AND cty_code = p_Cty_Code
         AND cust_id = p_Cust_Id
         AND limit_cat_code = 'V';
  
   EXCEPTION
  
       WHEN NO_DATA_FOUND THEN
            NULL;
        RETURN;
        
       WHEN OTHERS THEN
               DBMS_OUTPUT.PUT_LINE('ERROR ' || SUBSTR(SQLERRM, 1, 150));
               p_ret_code := SUBSTR(SQLERRM, 1, 150);
  
            RETURN;
   END;     

  IF ov_Old_Ccy <> p_ccy_code THEN
     
     SELECT NVL(SUM(Scbf_Tls_Exch_Rate(p_Bank_Group_Code, p_Cty_Code, limit_ccy_code, limit_ccy_active_amt,
                       p_ccy_code, 'N')),0)
          INTO ov_limit_amt
          FROM SCBT_R_CUST_PRODUCT_LIMIT
         WHERE bank_group_code = p_Bank_Group_Code
           AND cty_code = p_Cty_Code
           AND cust_id = p_Cust_ID
           AND limit_cat_code = 'O';
   
       BEGIN 
            
        UPDATE SCBT_R_CUST_PRODUCT_LIMIT
               SET limit_ccy_code = p_ccy_code,
                    limit_ccy_active_amt = ov_limit_amt
             WHERE bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code
               AND cust_id  = p_Cust_ID
               AND limit_id = ov_limit_id;
                   
            UPDATE SCBT_T_PROD_LIMIT_UTIL 
           SET limit_ccy_code = p_ccy_code 
             WHERE bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code
               AND limit_id = ov_limit_id; 
    
    
             SCBP_TLS_UPDATE_LIMIT_UTIL (p_ret_code,
                                         p_Bank_Group_Code,
                                         p_Cty_Code,
                                         ov_limit_id,
                                         p_ccy_code,
                       'PROD');
                     
    
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                     NULL;
           
          END;
       
  END IF;

-- THIS PROCEDURE WILL REVALUATE CURRENCY FOR BOTH SETUP & ADHOC BUYER SUPPLIER LIMITS --

  SCBP_ADJUST_ABS_LIMIT (p_ret_code,
                         p_bank_group_code,
                         p_cty_code,
                         p_cust_id,
                         p_ccy_code);        

/*-- THIS PROCEDURE WILL REVALUATE CURRENCY FOR ALL SETUP LIMITS UNDER PRODUCT GROUP FACILITY --

  SCBP_ADJUST_PGF_LIMIT(p_ret_code,
                        p_bank_group_code,
                        p_cty_code,
                        p_cust_id,
                        p_ccy_code);                                                                               */

-- THIS PROCEDURE WILL REVALUATE CURRENCY FOR ALL SETUP & ADHOC LIMITS UNDER COLLATERAL PACKAGE --

  Scbk_P_Coll_Tls.Scbp_Tls_Coll_Adjust_limit(p_ret_code,
                                             p_bank_group_code,
                                             p_cty_code,
                                             p_cust_id,
                                             p_ccy_code);
                                             

EXCEPTION

WHEN OTHERS THEN
     NULL;
END;

END SCBP_TLS_update_overall_ccy;

--***********************************************************--
PROCEDURE SCBP_UPDATE_OVERALL_LIMIT(p_Bank_Group_Code IN VARCHAR2,
                                    p_Cty_Code IN VARCHAR2,
                                    p_init_req_id IN VARCHAR2,
                                    p_ret_code IN OUT VARCHAR2)

AS BEGIN
DECLARE
        ov_Limit_Ccy SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_code%TYPE;
        v_Limit_id SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE;
        ov_limit_amt SCBT_R_CUST_PRODUCT_LIMIT.limit_ccy_active_amt%TYPE;

   CURSOR cust_cur IS
   SELECT DISTINCT mvmt.obligor_id 
     FROM SCBT_T_PROD_LIMIT_MVMT mvmt, 
          SCBT_R_CUST_PRODUCT_LIMIT cust 
    WHERE mvmt.bank_group_code = cust.bank_group_code
      AND mvmt.cty_code = cust.cty_code
      AND cust.bank_group_code = p_Bank_Group_Code
      AND cust.cty_code = p_Cty_Code
      AND mvmt.init_req_id = p_init_req_id
      AND mvmt.limit_tree_type_code = 'PROD'
      AND mvmt.limit_id = cust.limit_id
      AND cust.revolving_flag = 'N';


   BEGIN
        
        FOR cust IN cust_cur LOOP

            SELECT limit_ccy_code, limit_id 
              INTO ov_Limit_Ccy, v_limit_id  
              FROM SCBT_R_CUST_PRODUCT_LIMIT 
             WHERE bank_group_code = p_Bank_Group_code
               AND cty_code = p_Cty_Code 
               AND cust_id = cust.obligor_id 
               AND limit_cat_code = 'V';

            SELECT SUM(AMT) INTO ov_limit_amt FROM 
            (
            SELECT NVL(SUM(Scbf_Tls_Exch_Rate(p_Bank_Group_Code, p_Cty_Code, limit_ccy_code, limit_ccy_active_amt,
                   ov_Limit_Ccy, 'N')),0) AS AMT
              FROM SCBT_R_CUST_PRODUCT_LIMIT
             WHERE bank_group_code = p_Bank_Group_Code 
               AND cty_code = p_Cty_Code 
               AND cust_id = cust.obligor_id 
               AND limit_cat_code = 'O'
            HAVING SUM(Scbf_Tls_Exch_Rate(p_Bank_Group_Code, p_Cty_Code, limit_ccy_code, limit_ccy_active_amt,
                   ov_Limit_Ccy, 'N')) > 0
            );

            UPDATE SCBT_R_CUST_PRODUCT_LIMIT 
               SET limit_ccy_active_amt = ov_limit_amt 
             WHERE limit_id = v_limit_id
               AND bank_group_code = p_Bank_Group_Code
               AND cty_code = p_Cty_Code;

        END LOOP;

END;

END SCBP_UPDATE_OVERALL_LIMIT;

--*****************************************************************---

--*****************************************************************************


function SCBF_GET_SCB_RISK_SHARING_PCT (p_BankGroupCode varchar2, p_CtyCode varchar2,P_CustId varchar2,p_LimitId varchar2 )
RETURN number IS
BEGIN
declare
   l_riskSharingPct SCBT_R_CUST_RISK_SHARING_MST.RISK_PARTICIPATION_PCT%TYPE:=100;  
  BEGIN
     select (SELECT R.RISK_PARTICIPATION_PCT FROM SCBT_R_CUST_RISK_SHARING_MST R WHERE  
	   P.BANK_GROUP_CODE = R.BANK_GROUP_CODE(+) and P.CTY_CODE= R.CTY_CODE(+) and P.CUST_ID = R.CUST_ID(+)
	   AND P.SYNDICATION_ID = R.SYNDICATION_ID(+) AND R.BANK_ID = '800000000')  into l_riskSharingPct
	  FROM SCBT_R_CUST_PRODUCT_LIMIT P,	  SCBT_R_CUST_SYNDICATION_MST S  
	 where P.BANK_GROUP_CODE =p_BankGroupCode
	   AND p.cty_code =p_CtyCode
	  AND p.bank_group_code = s.bank_group_code
	   AND p.cty_code= s.cty_code
	   AND p.cust_id = s.cust_id
	   and P.SYNDICATION_ID = S.SYNDICATION_ID
	   and P.CUST_ID = P_CustId
	   and P.LIMIT_ID =p_LimitId
     and S.SCB_ROLE = 'AG';
     if l_riskSharingPct is null
        then return (100);
     else
        return L_RISKSHARINGPCT;
     END IF;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN
     return (100);
END;
END SCBF_GET_SCB_RISK_SHARING_PCT;

--*************************************************************

END Scbk_P_Prod_Tls;
/
