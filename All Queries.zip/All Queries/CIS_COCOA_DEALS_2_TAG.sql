GET_COCOA_DEAL_ID_FOR_CIS_REF (deal summary)
==============================
SELECT DISTINCT dmr.CUST_ID AS COCOA_CUST_ID, dmr.DEAL_ID AS COCOA_DEAL_ID,SIP_DEAL_REF_NO,
				dmr.DEAL_DESC, (Scbf_C_Get_Code_Desc(dmr.BANK_GROUP_CODE,dmr.CTY_CODE,'*','EN','CD019',dmr.BUSINESS_TYPE,1)) 
				AS BUSINESS_TYPE,dmr.REMARKS
				FROM SCBT_T_DEAL_REGISTER_HDR_MST dmr,scbt_t_sip_deal_smry_mst tm 
				WHERE dmr.BANK_GROUP_CODE = tm.BANK_GROUP_CODE AND dmr.CTY_CODE = tm.CTY_CODE AND
				tm.DEAL_ID like dmr.DEAL_ID ||'%' 
				AND dmr.CUST_ID = tm.CUST_ID
				AND upper(deal_status_code)<>'DCL'
				AND dmr.BANK_GROUP_CODE = 'SCB' AND dmr.CTY_CODE = 'HK' and upper(SIP_DEAL_REF_NO) like upper(TIC-311(4)) ORDER BY dmr.DEAL_ID DESC 
				