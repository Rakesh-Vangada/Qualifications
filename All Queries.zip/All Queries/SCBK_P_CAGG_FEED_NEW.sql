CREATE OR REPLACE PACKAGE COCOOWNER.SCBK_P_CAGG_FEED IS
     PROCEDURE SCBP_P_COLL_AGGREGATOR_FEED(bankGroupCode IN VARCHAR2,ctyCode IN VARCHAR2,custId IN VARCHAR2,runningSeq IN OUT NUMBER);
     PROCEDURE SCBP_P_UNLINKED_COLL_AGGR_FEED(bankGroupCode IN VARCHAR2,ctyCode IN VARCHAR2,custId IN VARCHAR2,runningSeq IN OUT NUMBER);
     PROCEDURE SCBP_P_BBTL_COLL_AGGR_FEED(bankGroupCode IN VARCHAR2,ctyCode IN VARCHAR2,custId IN VARCHAR2, coBorrowerId IN VARCHAR2,limitId VARCHAR2, txnRecId IN VARCHAR2, runningSeq IN OUT NUMBER);
     PROCEDURE SCBP_P_BBTL_COLL_AGGR_FEED_EXT(bankGroupCode IN VARCHAR2,ctyCode IN VARCHAR2,custId IN VARCHAR2, coBorrowerId IN VARCHAR2,limitId VARCHAR2, txnRecId IN VARCHAR2, runningSeq IN OUT NUMBER);
     FUNCTION scbf_get_sci_limit_id (v_bank_grp_code IN VARCHAR2,v_cty_code IN VARCHAR2,v_cust_id IN VARCHAR2, v_limit_id IN VARCHAR2, v_cust_leid IN VARCHAR2) RETURN VARCHAR2;

END SCBK_P_CAGG_FEED; 
/
CREATE OR REPLACE PACKAGE BODY COCOOWNER.SCBK_P_CAGG_FEED IS

/*
*  --COCOACR_31012013 - Added delete statement suggest by Sudheer/Palani
*  --COCO_31052013 - In case of �dummy inner� limit the limit id of parent limits to be captured in CAGG file
* -- COCOACR_31052013 Added for main borrower and co borrower sep
* -- CAGG_US_ENH_30082013 Added for SEP_BB_CERT_FLG US enhancements
* --COCOACR_12SEP2013 Changes done by Anbu suggest by Sudheer for Currency conversion if the limit and exp ccy is different
* -- COCOACR_24SEP2013 Function Added by Kishore on 24th SEPT 2013
*/
 v_txn_rec_id SCBT_T_TXN_MST.TXN_REC_ID%TYPE;


 PROCEDURE SCBP_P_COLL_AGGREGATOR_FEED(bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    runningSeq    IN OUT NOCOPY NUMBER) IS
  TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelIDType IS TABLE OF SCBT_T_PARCEL_MST.parcel_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelExpiryDateType IS TABLE OF SCBT_T_PARCEL_MST.EXPIRY_DATE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelEffDateType IS TABLE OF SCBT_T_PARCEL_MST.FIRST_COLLATERAL_DATE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelStorageLocType IS TABLE OF SCBT_T_PARCEL_MST.STORAGE_CTY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCMVCcyCodeType IS TABLE OF SCBT_T_PARCEL_MST. CMV_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCMVCcyAmtType IS TABLE OF SCBT_T_PARCEL_MST.Cmv_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE TxnRefIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.txn_ref_id%TYPE INDEX BY PLS_INTEGER;
  TYPE TxnCcyCodeType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.Txn_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
  TYPE TxnRecIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.txn_rec_id%TYPE INDEX BY PLS_INTEGER;
  TYPE CommodityIDType IS TABLE OF scbt_r_commodity_mst.commodity_id%TYPE INDEX BY PLS_INTEGER;
  TYPE CollCovPercType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.COVERAGE_PCT%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitCcyList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitProdCodeType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitActiveAmtList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_ACTIVE_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitInnerToIdList   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE outerLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE INDEX BY PLS_INTEGER;
  --TYPE extLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.ext_limit_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyCodeType IS TABLE OF SCBT_T_PARCEL_MST. GCV_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyAmtType IS TABLE OF SCBT_T_PARCEL_MST.GCv_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCollStatusCodeType IS TABLE OF SCBT_T_PARCEL_MST.CR_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelRecJ158CodeType IS TABLE OF SCBT_T_PARCEL_MST.RECJ158_CODE%TYPE INDEX BY PLS_INTEGER;
  custExpCcy        SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  bussDate          SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
  dealId            SCBT_T_DEAL_HIST.DEAL_ID%TYPE;
  recordID          SCBT_T_IPS_CAGG_FEED_MST.REC_ID%TYPE;
  commodityType     SCBT_R_COMMODITY_MST.Commodity_Type_Code%TYPE;
  commodityCat      SCBT_R_COMMODITY_MST.Commodity_Cat_Code%TYPE;
  txnRefIDList      TxnRefIDType;
  txnParentRecIDMstList      TxnRecIDType;
  txnParentRefIDMstList TxnRefIDType;
  txnParentCcyCodeMstList TxnCcyCodeType;
  txnRecIDList      TxnRecIDType;
  collateralIDList  CollateralIDType;
  parcelIDList      ParcelIDType;
  bussDateAsString  VARCHAR2(10);
  collateralId      scbt_t_collateral_register_mst.collateral_id%TYPE;
  collCat           scbt_t_collateral_register_mst.collateral_category%TYPE;
  collStatusCode    scbt_t_collateral_register_mst.collateral_status_code%TYPE;
  collReceivableCcy scbt_t_collateral_register_mst.receivable_ccy_code%TYPE;
  collReceivableAmt scbt_t_collateral_register_mst.receivable_ccy_amt%TYPE;
  securityType      SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubType   SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  commodityIDList   CommodityIDType;
  collateralApp     SCBT_T_IPS_CAGG_FEED_MST.Collateral_Approach%TYPE;
  prodCode          SCBT_T_TXN_HST.PRODUCT_CODE%TYPE;
  tpRefID           SCBT_T_TXN_HST.TP_REF_ID%TYPE;
  maturityDate      ParcelExpiryDateType;
  effectiveDate     ParcelEffDateType;
  collStorageLoc    ParcelStorageLocType;
  bookingLoc        SCBT_T_DEAL_MST.CTY_CODE%TYPE;
  cmvCcyCode        ParcelCMVCcyCodeType;
  ccyCodeForCMV     VARCHAR2(3);
  custLEID          SCBT_R_PARTY_MST.Party_Id%TYPE;
  tpSystemCode      Scbt_t_Txn_mst.TP_SYSTEM_CODE%TYPE;
  txnStepCode       scbt_t_txn_mst.txn_step_code%TYPE;
  collCovPerc       CollCovPercType;
  cmvCcyAmt         ParcelCMVCcyAmtType;
 -- actualCMVAmount   Scbt_t_Txn_Cr_Linkage_Mst.COVERAGE_PCT%TYPE;
  actualCMVAmount number(17,3);
  cashMarginCcyCode Scbt_t_Txn_mst.Cash_Margin_Ccy_Code%TYPE;
  cashMarginCcyAmt  Scbt_t_Txn_mst.Cash_Margin_Ccy_amt%TYPE;
  totalAccBalAmt  scbt_t_cust_acc_smry_mst.acc_ccy_anticipated_amt%TYPE;
  totalRemCashAmt SCBT_T_IPS_CAGG_FEED_MST.Cmv_Ccy_Amt%TYPE;
  totalCHSfallAmt SCBT_T_IPS_CAGG_FEED_MST.Cmv_Ccy_Amt%TYPE;
  limitCcyCode    LimitCcyList;
  outerLimitCcyCode    LimitCcyList;
  limitActiveAmt  LimitActiveAmtList;
  apportionedAmt SCBT_T_IPS_CAGG_FEED_MST.Cmv_Ccy_Amt%TYPE;
  totalLimitAmt SCBT_T_IPS_CAGG_FEED_MST.Cmv_Ccy_Amt%TYPE;
  inner_to      SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE;
  lookupLimitId SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;
  ext_limit_ID  SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  appLimitIdList LimitIDList;
  temp_ext_limit_ID SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  sciLimitIdList   LimitIDList;
  sciLimitProdCodeList LimitProdCodeType;
  cmvEffDate       DATE;
  cmvMatDate       DATE;
  innerToIdList     LimitInnerToIdList;
  outerLimitIdList outerLimitIdType;
  initAccountBalance number;
  remainingAccountBalance number;
  totalTopUpByFacility number;
  tempRecId             SCBT_T_IPS_CAGG_FEED_MST.Rec_Id%TYPE;
  security_id       SCBT_T_IPS_SCI_LMT_APPR_SEC.LAS_SEC_ID%TYPE;
  --extLimitIdList          extLimitIdType;
  --innerToIdListForSCI     LimitInnerToIdList;
  is_valid_data     boolean;
  custom_error_mesg SCBT_T_IPS_CAGG_FEED_MST_ERR.ERROR_MESSAGE%type;
  securityTypeParam      SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubTypeParam   SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  cashMarginSeq          NUMBER;
  tempCollateralId       SCBT_T_IPS_CAGG_FEED_MST.COLLATERAL_ID%TYPE;
  tempParcelId           SCBT_T_IPS_CAGG_FEED_MST.Parcel_Id%type;
  is_parcel_exist_for_txn boolean;
  tempEffectiveDate       SCBT_T_PARCEL_MST.FIRST_COLLATERAL_DATE%TYPE;
  tempStorageLoc          SCBT_T_PARCEL_MST.STORAGE_CTY_CODE%TYPE;
  tempCollType            SCBT_T_COLLATERAL_REGISTER_MST.COLLATERAL_CATEGORY%TYPE;
  contingentProduct NUMBER;
  contingentCollAmtType SCBT_R_PARAM_DATA.PARAM_DATA_01%TYPE;
  contingentCollCCYType         SCBT_R_PARAM_DATA.PARAM_DATA_02%TYPE;
  gcvCcyCode        ParcelGCVCcyCodeType;
  gcvCcyAmt         ParcelGCVCcyAmtType;
  securitySubTypeDescParam varchar2(100);
  tempGcvCcyCode scbt_t_collateral_register_mst.total_gcv_ccy_code%Type;
  tempGcvCcyAmt scbt_t_collateral_register_mst.TOTAL_GCV_CCY_AMT%Type;
  exceptnSecSubType NUMBER;
  txnMaturityDate SCBT_T_TXN_MST.MATURITY_DATE%TYPE;
  --temp_parent_limit_id    SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  totalCmvAmtForContingent SCBT_T_PARCEL_MST.Cmv_Ccy_Amt%TYPE;
  isTxnLinkExist NUMBER;
  collStatusCodeParcelList         ParcelCollStatusCodeType;
  isCTAExpired scbt_r_param_data.param_data_01%TYPE;
  isExpiredColl NUMBER;
  isLCPriceBasis scbt_t_collateral_register_mst.IS_LC_PRICE_BASIS%Type;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_is_syndicate_coll         NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  v_max_syndicated_amt_ccy    SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT_CCY%TYPE;
  v_max_syndicated_amt        SCBT_T_TXN_HST.MAX_SYNDICATED_TXN_AMT%TYPE;
  bbtl_prod_limit_id          SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE;
  bbtl_deal_step_id           SCBT_T_TXN_MST.LATEST_DEAL_STEP_ID%TYPE;
  v_txn_outstanding_amt       SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_faclty_outstanding_amt    SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_bbtl_cmv_amt              SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_txn_ccy_code              SCBT_T_TXN_MST.TXN_CCY_CODE%TYPE;
  v_cash_record_required      VARCHAR2(3);
  v_topup_amount              NUMBER(17,3);
  v_topup_amount_generated    VARCHAR2(1);
  v_exposure_amt              NUMBER(17,3);

  full_cashMarginCcyCode Scbt_t_Txn_mst.Cash_Margin_Ccy_Code%TYPE;
  full_cashMarginCcyAmt  Scbt_t_Txn_mst.Cash_Margin_Ccy_amt%TYPE;

  topup_cashMarginCcyCode Scbt_t_Txn_mst.Cash_Margin_Ccy_Code%TYPE;
  topup_cashMarginCcyAmt  Scbt_t_Txn_mst.Cash_Margin_Ccy_amt%TYPE;
  ParcelRecJ158CodeList  ParcelRecJ158CodeType;
  v_usd_cmv_amt               SCBT_T_IPS_CAGG_FEED_MST.USD_CMV_AMT%TYPE;

    -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin

  fsvPctCust            SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctDefault         SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctBbc             SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPct                SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvValue              NUMBER;
  fsvOverrideFlag       SCBT_T_IPS_CAGG_FEED_MST.Fsv_Override_Flag%TYPE;

  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

  -- adding cagg changes for FSD_BAU_Enhancements_Release_II_2013 - OBU V 0.2 Final.doc docx begin

  prodLimitId Scbt_t_Txn_mst.Prod_Limit_Id%TYPE;
  bookingLocFromLimit SCBT_R_CUST_PRODUCT_LIMIT.CTY_CODE%TYPE;

  -- adding cagg changes for FSD_BAU_Enhancements_Release_II_2013 - OBU V 0.2 Final.doc docx end

  BEGIN


  BEGIN
       delete from SCBT_T_IPS_CAGG_FEED_MST where BANK_GROUP_CODE= bankGroupCode
         and CTY_CODE=ctyCode and CUST_ID=custId;
  EXCEPTION WHEN OTHERS THEN
     COMMIT;
     NULL;
  END;


   -- Customer Exposure Currency
   BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;


   totalRemCashAmt := 0;
   inner_to := ' ';

    -- Business Date
    BEGIN
             SELECT BUSINESS_DATE INTO bussDate FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode;
    EXCEPTION
             WHEN NO_DATA_FOUND THEN
             NULL;
    END;

    v_topup_amount_generated := 'Y';

    -- LEID of Customer
    BEGIN
        SELECT EXT_SYSTEM_ID INTO custLEID FROM SCBT_R_PARTY_EXT_ID WHERE party_id=custId AND EXT_SYSTEM_CODE='SC';
          EXCEPTION
            WHEN OTHERS THEN
              custLEID :='';
    END;

    v_cash_record_required := Scbf_C_Get_Param_Data('CA04',
                                                     '01',
                                                     bankGroupCode,
                                                     ctyCode,
                                                     '*',
                                                     '*',
                                                     'CAGGCASH',
                                                     '',
                                                     '',
                                                     '',
                                                     '',
                                                     '',
                                                     '',
                                                     '',
                                                     '',
                                                     '');
    -- All Transations of the customer
    BEGIN
      SELECT distinct txn_rec_ID, TXN_REF_ID, TXN_CCY_CODE BULK COLLECT INTO txnParentRecIDMstList, txnParentRefIDMstList, txnParentCcyCodeMstList FROM scbt_t_txn_mst
         WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND CUST_ID = custId
           and (NVL(TXN_CCY_NET_AMT,0) - NVL(TXN_CCY_UTIL_AMT,0)) > 0
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
           AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
              WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
           AND PROD_LIMIT_ID not in (SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
             WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE=ctyCode AND CUST_ID = custId
             AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                 WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                 AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'));
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;;
    EXCEPTION
       WHEN NO_DATA_FOUND THEN
          NULL;
    END;

    -- Record ID Generation

    bussDateAsString := TO_CHAR(bussDate, 'DDMMYYYY');
    recordID := 'CO' || bussDateAsString;

    --To construct RECORD ID
    BEGIN
        SELECT MAX(REC_ID) INTO tempRecId FROM SCBT_T_IPS_CAGG_FEED_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND BUSINESS_DATE=bussDate;
               --AND CUST_ID = custId;
        runningSeq := to_number(substr(tempRecId, 11, length(tempRecId)));
    EXCEPTION
        WHEN OTHERS THEN
        runningSeq := 0;
    END;


    IF runningSeq IS NULL THEN
       runningSeq :=0;
    END IF;
   -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
   --To construct COLLATERAL ID FOR CASH RECORDS AT TRANSACTION LEVEL
   BEGIN
      SELECT MAX(to_number(substr(COLLATERAL_ID, 1, 14))) INTO cashMarginSeq FROM SCBT_T_IPS_CAGG_FEED_MST
         WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         --AND BUSINESS_DATE=bussDate;
         --AND CUST_ID = custId;
         and COLLATERAL_ID LIKE '%CC';
         EXCEPTION
            WHEN OTHERS THEN
            cashMarginSeq := 0;
   END;

   IF cashMarginSeq IS NULL THEN
       cashMarginSeq :=0;
   END IF;
    -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END


      -- To calculate initial account balance
   initAccountBalance := Scbk_P_Cocoa_Cdb.SCBF_C_GET_ACCT_BALANCE (bankGroupCode, ctyCode, custId, custExpCcy, 'N');
   remainingAccountBalance := initAccountBalance;





   -- Get the number of transactions for the customer
     FOR intTxnRow IN 1..txnParentRecIDMstList.COUNT LOOP

          BEGIN
               SELECT distinct REFID, RECID BULK COLLECT INTO txnRefIDList,txnRecIDList FROM (
                SELECT TXN_REF_ID "REFID",TXN_REC_ID "RECID", NVL(COVERAGE_PCT,0) "COLLCOVPER", CUST_ID "CUSTOMERID",COLLATERAL_ID "COLLATERALID"
                  FROM Scbt_t_Txn_Cr_Linkage_Mst
                 WHERE BANK_GROUP_CODE = bankGroupCode
                   AND CTY_CODE = ctyCode
                   AND CUST_ID = custId
                   AND txn_rec_id = txnParentRecIDMstList(intTxnRow));
          EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                   NULL;
          END;

          --To calculate 100% Cash Margin
          isTxnLinkExist := 0;



          FOR i IN 1..txnRecIDList.COUNT LOOP

              -- Fetch the Deal ID for the Collateral
              BEGIN
                cashMarginCcyAmt :=  0;
                isTxnLinkExist := 1;

                --SELECT DEAL_ID,PRODUCT_CODE,TP_REF_ID,TP_SYSTEM_CODE,TXN_STEP_CODE, nvl(CASH_MARGIN_CCY_CODE, custExpCcy)
                --changes done to retrieve prod_limit_id also for getting booking location from customer limit setup
                SELECT DEAL_ID,PROD_LIMIT_ID,PRODUCT_CODE,TP_REF_ID,TP_SYSTEM_CODE,TXN_STEP_CODE, nvl(CASH_MARGIN_CCY_CODE, custExpCcy)
                /*,(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))*/
                , (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
                , MATURITY_DATE
                  INTO dealId,prodLimitId,prodCode,tpRefID,tpSystemCode,txnStepCode,cashMarginCcyCode,cashMarginCcyAmt, txnMaturityDate
                FROM SCBT_T_TXN_MST
                  WHERE BANK_GROUP_CODE = bankGroupCode
                  AND CTY_CODE = ctyCode
                  AND CUST_ID = custId
                  AND TXN_REC_ID = txnRecIDList(i)
                  --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                  AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                  --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                  --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                   AND PROD_LIMIT_ID not in (
                     SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                       WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE=ctyCode
                       AND CUST_ID=custId AND LIMIT_TYPE_CODE in (
                         select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                            WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                            AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                  ;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                   NULL;
              END;

              --To add TOP-UP amount with Cash Margin for LTV related changes

                BEGIN
               SELECT  COLLATERALID, COLLCOVPER BULK COLLECT INTO collateralIDList, collCovPerc FROM (
                SELECT TXN_REF_ID "REFID",TXN_REC_ID "RECID", NVL(COVERAGE_PCT,0) "COLLCOVPER", CUST_ID "CUSTOMERID",COLLATERAL_ID "COLLATERALID"
                  FROM Scbt_t_Txn_Cr_Linkage_Mst
                 WHERE BANK_GROUP_CODE = bankGroupCode
                   AND CTY_CODE = ctyCode
                   AND CUST_ID = custId
                   AND txn_rec_id = txnRecIDList(i));
               EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                   NULL;
               END;

              FOR k IN 1..collateralIDList.COUNT LOOP
              ---****************************---
              ---********PHYSICAL LEVEL******---
              ---****************************---



              -- Fetch Booking Location

              BEGIN
                   SELECT CTY_CODE INTO bookingLoc FROM SCBT_T_DEAL_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND DEAL_ID = dealId;
              EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                    bookingLoc := null;
              END;

              --changes done to retrieve booking location from customer limit setup
              BEGIN
                   SELECT BOOKING_LOCATION INTO bookingLocFromLimit from SCBT_R_CUST_PRODUCT_LIMIT WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND LIMIT_ID = prodLimitId;
              EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                     bookingLocFromLimit := bookingLoc;
              END;


              -- Fetch the Collateral Categort and Status Code for the Collateral
              BEGIN
               actualCMVAmount := 0;
               tempGcvCcyAmt := 0;
               tempGcvCcyCode := ' ';

               SELECT collateral_category, collateral_status_code,receivable_ccy_code,NVL(receivable_ccy_amt,0)
               , TOTAL_GCV_CCY_CODE
               , NVL(TOTAL_GCV_CCY_AMT, 0)
               INTO collCat,collStatusCode,collReceivableCcy,collReceivableAmt
               , tempGcvCcyCode
               , tempGcvCcyAmt
               FROM scbt_t_collateral_register_mst
               WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND collateral_id = collateralIDList(k)
               AND COLLATERAL_CATEGORY != 'REL';
              EXCEPTION
                   WHEN OTHERS THEN
                     collCat:=NULL;
                     collStatusCode := NULL;
                     collReceivableCcy := NULL;
                     collReceivableAmt := NULL;
                   NULL;
              END;


             BEGIN
                  SELECT COMMODITY_ID,PARCEL_ID,EXPIRY_DATE,FIRST_COLLATERAL_DATE,STORAGE_CTY_CODE, nvl(CMV_CCY_CODE,custExpCcy), NVL(CMV_CCY_AMT,0)
                  , GCV_CCY_CODE, NVL(GCV_CCY_AMT,0), CR_STATUS_CODE, RECJ158_CODE
                  BULK COLLECT INTO commodityIDList,parcelIDList,maturityDate,effectiveDate,collStorageLoc,cmvCcyCode, cmvCcyAmt
                  , gcvCcyCode, gcvCcyAmt, collStatusCodeParcelList, ParcelRecJ158CodeList
                         FROM SCBT_T_PARCEL_MST
                         WHERE BANK_GROUP_CODE = bankGroupCode
                         AND COLLATERAL_ID = collateralIDList(k)
                         AND PARCEL_TYPE_CODE != 'MST'
                         AND COLLATERAL_TYPE_CODE NOT IN (
                                      SELECT NVL(PARAM_KEY_01, ' ') FROM SCBT_R_PARAM_DATA
                                        WHERE PARAM_ID='CA03'
                                          AND  PARAM_DATA_01='N'
                         );
             EXCEPTION
                 WHEN OTHERS THEN
                 NULL;
             END;


             --To calculate total cmvccy amount for contingent collateral
             totalCmvAmtForContingent := 0;

             BEGIN
               IF collCat = 'CON' THEN
                SELECT sum(NVL(CMV_CCY_AMT,0)) INTO totalCmvAmtForContingent
                           FROM SCBT_T_PARCEL_MST
                           WHERE BANK_GROUP_CODE = bankGroupCode
                           AND COLLATERAL_ID = collateralIDList(k)
                           AND PARCEL_TYPE_CODE != 'MST'
                           AND COLLATERAL_TYPE_CODE NOT IN (
                                        SELECT NVL(PARAM_KEY_01, ' ') FROM SCBT_R_PARAM_DATA
                                          WHERE PARAM_ID='CA03'
                                            AND  PARAM_DATA_01='N'
                           );

               END IF;
             EXCEPTION
                WHEN OTHERS THEN
                 totalCmvAmtForContingent := 0;
             END;


             -- Loop Through all parcels' commodity IDs

              FOR j IN 1..commodityIDList.COUNT LOOP

              -- For Physical Collateral
              --Changes made for Contigent Collateral
              IF (collCat = 'PHY' OR collCat = 'RCV' OR collCat='CON') THEN
                  BEGIN
                     SELECT COMMODITY_TYPE_CODE,COMMODITY_CAT_CODE INTO commodityType,commodityCat
                           FROM SCBT_R_COMMODITY_MST WHERE BANK_GROUP_CODE = bankGroupCode  AND COMMODITY_ID = commodityIDList(j);
                     EXCEPTION
                         WHEN OTHERS THEN
                           NULL;
                 END;
                 collateralApp := 'T';
              END IF;

             ccyCodeForCMV := cmvCcyCode(j);

              -- SCI Limit ID
              BEGIN
                  SELECT PROD_LIMIT_ID INTO lookupLimitId
                     FROM SCBT_T_TXN_MST
                  WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custID
                     AND TXN_REC_ID = txnRecIDList(i)
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                     AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                       WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                     AND PROD_LIMIT_ID not in (
                       SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                         WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE=ctyCode
                          AND CUST_ID=custId AND LIMIT_TYPE_CODE in (
                           select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                             WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                             AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'));
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
              EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
              END;

              -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,lookupLimitId,custLEID);
               /*          BEGIN
                             SELECT ext_limit_id, inner_to_id
                             BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                             FROM SCBT_R_CUST_PRODUCT_LIMIT
                             START WITH limit_id = lookupLimitId
                             CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id   --ext_limit_id=inner_to_id
                             AND BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE = ctyCode
                             AND CUST_ID = custId
                             order by level asc;
                         EXCEPTION
                             WHEN OTHERS THEN
                             NULL;
                         END;
                         --To report parent id if SCI LIMIT ID is not there
                         temp_parent_limit_id := null;
                         temp_ext_limit_id := null;
                         FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP
                            BEGIN
                               SELECT LAS_LMT_ID into temp_ext_limit_id
                               FROM (
                                  select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                  WHERE A.LAS_LE_ID=custLEID
                                     and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                     --28-NOV-2012
                                     --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                 ) where rownum=1;
                                   exit;
                                EXCEPTION WHEN OTHERS THEN
                                   BEGIN
                                       SELECT LAS_LMT_ID into temp_ext_limit_id
                                       FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                            WHERE A.LAS_LE_ID=custLEID
                                            and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                            --28-NOV-2012
                                            --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                            ) where rownum=1;
                                       exit;
                                   EXCEPTION  WHEN OTHERS THEN
                                      temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                                      NULL;
                                   END;
                       END;
                         END LOOP;
*/

              BEGIN
                   tempEffectiveDate := effectiveDate(j);
                   tempStorageLoc := collStorageLoc(j);
                    -- Coverage Amount Calculation based on Coverage Percentage
                    actualCMVAmount :=0;

                    IF (collCat = 'PHY' ) THEN
                       actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(collCovPerc(k)/100)) * Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,cmvCcyAmt(j))));
                   -- END IF;

                    ELSIF (collCat = 'RCV' ) THEN
                      --Changes made on receivable collateral 22-AUG-2012
                      -- Changes from coll reveivable amount at scbt_t_collateral_register_mst
                      -- to gcvCcyAmt at SCBT_T_PARCEL_MST table
                      actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(collCovPerc(k)/100)) * Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,gcvCcyAmt(j))));  --collReceivableAmt
                      --ccyCodeForCMV := collReceivableCcy;
                      ccyCodeForCMV := gcvCcyCode(j);
                      -- Fetch the effective date and storage loc for the Collateral
                      BEGIN
                           SELECT ISSUE_DATE, CTY_CODE  INTO tempEffectiveDate, tempStorageLoc FROM scbt_t_collateral_register_mst WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND collateral_id = collateralIDList(k);
                           EXCEPTION
                           WHEN NO_DATA_FOUND THEN
                                NULL;
                                tempEffectiveDate := null;
                                tempStorageLoc := null;
                           END;

                    ELSIF (collCat = 'CON' ) THEN
                       actualCMVAmount := 0;
                       contingentCollAmtType := Scbf_C_Get_Param_Data('CA02',
                                                                   '01',
                                                                   bankGroupCode,
                                                                    '*',
                                                                   '*',
                                                                   '*',
                                                                   'CON',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*');
                       contingentCollCCYType := Scbf_C_Get_Param_Data('CA02',
                                                                   '02',
                                                                   bankGroupCode,
                                                                    '*',
                                                                   '*',
                                                                   '*',
                                                                   'CON',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   '*');
                       if (contingentCollAmtType = 'CMV') then
                          actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(collCovPerc(k)/100)) * Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,cmvCcyAmt(j))));
                       elsif (contingentCollAmtType = 'GCV') then
                            /*
                             actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,(collCovPerc(k)/100)) * Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,cmvCcyAmt(j))));
                                                     */
                                                     --custExpCcy,tempGcvCcyAmt)));
                             actualCMVAmount := tempGcvCcyAmt * cmvCcyAmt(j)/ totalCmvAmtForContingent;
                             actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                     custExpCcy,actualCMVAmount);

                                                     --custExpCcy,gcvCcyAmt(j))));
                             ccyCodeForCMV := tempGcvCcyCode;
                             --ccyCodeForCMV := gcvCcyCode(j);
                       end if;
                    END IF;

               EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                END;

                if tpSystemCode = 'DTP' then
                    tpSystemCode := 'IMEX';
                elsif tpSystemCode = 'OTP' then
                    tpSystemCode := 'OAF';
                elsif tpSystemCode = 'ACBS' then
                    tpSystemCode := 'ACB';
                elsif tpSystemCode IS NULL then
                    tpSystemCode := 'IMEX';
                end if;

               --QC 870 Security Type and Security Sub Type should match with SCI securityType and Security Sub Type START
                securityTypeParam := null;
                securitySubTypeParam := null;
                tempCollType := collCat;


                if (collCat = 'CON') then
                    tempCollType := 'PHY';
                end if;

                securityTypeParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                   '01',
                                                                   bankGroupCode,
                                                                   '*',
                                                                   '*',
                                                                   '*',
                                                                   NVL(tempCollType,''),
                                                                   NVL(commodityType,''),
                                                                   NVL(commodityCat,''),
                                                                   NVL(collStatusCodeParcelList(j), ''), --NVL(collStatusCode,''),
                                                                   '',
                                                                   '',
                                                                   '',
                                                                   '',
                                                                   '',
                                                                   '');

                 securitySubTypeParam :=   Scbf_C_Get_Param_Data('CA01',
                                                                       '02',
                                                                       bankGroupCode,
                                                                       '*',
                                                                       '*',
                                                                       '*',
                                                                       NVL(tempCollType,''),
                                                                       NVL(commodityType,''),
                                                                       NVL(commodityCat,''),
                                                                       NVL(collStatusCodeParcelList(j), ''), --NVL(collStatusCode,''),
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '');

                securitySubTypeDescParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                       '03',
                                                                       bankGroupCode,
                                                                       '*',
                                                                       '*',
                                                                       '*',
                                                                       NVL(tempCollType,''),
                                                                       NVL(commodityType,''),
                                                                       NVL(commodityCat,''),
                                                                       NVL(collStatusCodeParcelList(j), ''), --NVL(collStatusCode,''),
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '');


                if(collCat = 'RCV' ) then
                   securityTypeParam := 'AB';
                   /*02-NOV-2012 Changes for RECJ158_CODE for receivable collateral*/
                   --securitySubTypeParam := 'AB104';
                   securitySubTypeParam := nvl(ParcelRecJ158CodeList(j), '');
                   securitySubTypeDescParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                       '03',
                                                                       bankGroupCode,
                                                                       '*',
                                                                       '*',
                                                                       '*',
                                                                       'RECV',
                                                                       securitySubTypeParam,
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '');

                    securitySubTypeDescParam := nvl(securitySubTypeDescParam, 'RECEIVABLE');
                end if;

              -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;


                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := actualCMVAmount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := actualCMVAmount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := actualCMVAmount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end


                -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
                -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
                security_id :=null;
                securityType := null;
                securitySubType := null;

                BEGIN
                   select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                     into security_id, securityType, securitySubType
                     FROM (
                         select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                         from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                            WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                                AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                AND UPDATE_STATUS_IND <> 'D'
                     ) where rownum=1;
                   EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                       security_id :=null;
                       securityType := null;
                       securitySubType :=null;
                END;
                -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE END

                --Condition added for Contingent Collateral
                    BEGIN
                    SELECT COUNT(1) INTO contingentProduct
                      from scbt_r_param_data where BANK_GROUP_CODE ='SCB'
                      and param_id='CA03'
                      and param_key_02 = 'CON'
                      and param_data_01 = prodCode;
                      --  FROM SCBT_R_CAGG_FILTER_CRITERIA
                     --   WHERE FILTER_VALUE = prodCode
                          --  AND FILTER_TYPE='CONTINGENT';
                    EXCEPTION
                             WHEN NO_DATA_FOUND THEN
                             contingentProduct := 0;
                    END;

                    exceptnSecSubType := 0;

                    --EXCEPTIONAL SECURITY SUB TYPE
                    BEGIN
                       select count(CODE_VALUE_1)
                            INTO exceptnSecSubType
                       from SCBT_R_MAP_INFO A
                            WHERE MAP_ID='CAGG_EXCPTN_LIST'
                               AND CODE_VALUE_1 = securitySubTypeParam;
                       EXCEPTION
                            WHEN OTHERS THEN
                              exceptnSecSubType := 0;
                    END;

                -- Insert into Master Table for Physical Collateral - Parcel Level

                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(ccyCodeForCMV = 'USD') THEN
                         v_usd_cmv_amt := actualCMVAmount;
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , ccyCodeForCMV
                                                , NVL(actualCMVAmount,0)
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END
                    BEGIN
                       runningSeq := runningSeq + 1;
                       custom_error_mesg := NULL;
                       is_valid_data := true;
                      if ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) then
                        is_valid_data := false;
                        custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
                      end if;
                      if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                          is_valid_data := false;
        	       	        custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                      elsif ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) then
                          is_valid_data := false;
                               custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                      end if;
                      if (  (upper(securityTypeParam) !=  upper(securityType) or upper(securitySubTypeParam) != upper(securitySubType))) then
                        is_valid_data := false;
                        custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
                      end if;
                       if (collateralIDList(k) IS NULL OR length(collateralIDList(k))<1 ) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'COLLATERAL ID is empty.';
                       end if;
                       if (parcelIDList(j) IS NULL OR length(parcelIDList(j))<1 ) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'PARCEL ID is empty.';
                       end if;
                       if (tempEffectiveDate IS NULL OR length(tempEffectiveDate)<1 ) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'Effective Date is empty.';
                       end if;
                       if (tempStorageLoc IS NULL OR length(tempStorageLoc)<1 ) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'Storage Location is empty.';
                       end if;
                       if (actualCMVAmount is null or actualCMVAmount <= 0) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
                       end if;
                       if (collCat='CON' and contingentProduct <=0 ) then
                           is_valid_data := false;
                           custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                       end if;

                       if (is_valid_data) then
                           --New condition if PARCEL LEVEL RECORDS EXSIST FOR TRANSACTION THEN CASH MARGIN RECORDS WILL BE CALCULATED 09-09-2011
                           --is_parcel_exist_for_txn := true;
                     -- if(nvl(actualCMVAmount,0) != 0) then
                           INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                              BANK_GROUP_CODE
                              , CTY_CODE
                              , CUST_ID
                              , DEAL_ID
                              , COLLATERAL_ID
                              , PARCEL_ID
                              , REC_ID
                              , BUSINESS_DATE
                              , SECURITY_VALUATION_DATE
                              , SOURCE_SYSTEM_CODE
                              , SECURITY_TYPE
                              , SECURITY_SUBTYPE
                              , COLLATERAL_APPROACH
                              , PRODUCT_CODE
                              , IS_SECURITY_PERFECTED
                              , MATURITY_DATE
                              , EFFECTIVE_DATE
                              , SECURITY_PERFECTION_DATE
                              , STORAGE_CTY_CODE
                              , BOOKING_LOC_CTY_CODE
                              , CMV_CCY_CODE
                              , CMV_CCY_AMT
                              , TP_REF_ID
                              , SCI_LEID
                              , TP_SYSTEM_CODE
                              , TXN_REF_ID
                              , SCI_LIMIT_ID
                              , SECURITY_ID
                              , CAGG_CATURED_TYPE
                              , USD_CMV_AMT
                              , FSV_PCT
                              , FSV_VALUE
                              , FSV_OVERRIDE_FLAG)
                            VALUES(
                              bankGroupCode
                              , ctyCode
                              , custId
                              , dealId
                              , collateralIDList(k)
                              , parcelIDList(j)
                              , recordID || LPAD(runningSeq,8,'0')
                              , bussDate
                              , bussDate
                              , 'CCA'
                              , securityType
                              , securitySubType
                              , 'T'
                              , prodCode
                              , 'Y'
                              , txnMaturityDate  --maturityDate(j)
                              , tempEffectiveDate
                              , tempEffectiveDate
                              , NVL(tempStorageLoc,bookingLocFromLimit)
                              , bookingLocFromLimit --changes for obu
                              , ccyCodeForCMV
                              , actualCMVAmount
                              , tpRefID
                              , custLEID
                              , tpSystemCode
                              , txnRefIDList(i)
                              , temp_ext_limit_id
                              , security_id
                              , 'CAGG_PHYSICAL'
                              , v_usd_cmv_amt
                              , fsvPct
                              , fsvValue
                              , fsvOverrideFlag
                           );
                       ELSE
                           --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                           IF ( actualCMVAmount is null or actualCMVAmount <=0) THEN
                                 GOTO SKIP_TXN_LOOP;
                           END IF;

                           INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR (
                               BANK_GROUP_CODE
                              , CTY_CODE
                              , CUST_ID
                              , DEAL_ID
                              , COLLATERAL_ID
                              , PARCEL_ID
                              , REC_ID
                              , BUSINESS_DATE
                              , SECURITY_VALUATION_DATE
                              , SOURCE_SYSTEM_CODE
                              , SECURITY_TYPE
                              , SECURITY_SUBTYPE
                              , COLLATERAL_APPROACH
                              , PRODUCT_CODE
                              , IS_SECURITY_PERFECTED
                              , MATURITY_DATE
                              , EFFECTIVE_DATE
                              , SECURITY_PERFECTION_DATE
                              , STORAGE_CTY_CODE
                              , BOOKING_LOC_CTY_CODE
                              , CMV_CCY_CODE
                              , CMV_CCY_AMT
                              , TP_REF_ID
                              , SCI_LEID
                              , TP_SYSTEM_CODE
                              , TXN_REF_ID
                              , SCI_LIMIT_ID
                              , SECURITY_ID
                              , ERROR_MESSAGE
                              , Securitysubtypedesc
                              , CAGG_CATURED_TYPE
                              , USD_CMV_AMT
                              , FSV_PCT
                              , FSV_VALUE
                              , FSV_OVERRIDE_FLAG)
                           VALUES(
                              bankGroupCode
                              , ctyCode
                              , custId
                              , dealId
                              , collateralIDList(k)
                              , parcelIDList(j)
                              , recordID || LPAD(runningSeq,8,'0')
                              , bussDate
                              , bussDate
                              , 'CCA'
                              , nvl(securityTypeParam, securityType)  --securityType
                              , nvl(securitySubTypeParam, securitySubType)  --securitySubType
                              , 'T'
                              , prodCode
                              , 'Y'
                              , txnMaturityDate  --maturityDate(j)
                              , tempEffectiveDate
                              , tempEffectiveDate
                              , tempStorageLoc
                              , bookingLocFromLimit
                              , ccyCodeForCMV
                              , actualCMVAmount
                              , tpRefID
                              , custLEID
                              , tpSystemCode
                              , txnRefIDList(i)
                              , temp_ext_limit_id
                              , security_id
                              , custom_error_mesg
                              , securitySubTypeDescParam
                              , 'CAGG_PHYSICAL_ERR'
                              , v_usd_cmv_amt
                              , fsvPct
                              , fsvValue
                              , fsvOverrideFlag);
                              <<SKIP_TXN_LOOP>>
                                  NULL;
                         --  END IF;
                           END IF;
                          EXCEPTION
                           WHEN OTHERS THEN
                           dbms_output.put_line(recordID|| '**956PHYSICAL**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                           NULL;
                         END;
                    END LOOP;
              END LOOP;


              ---****************************---
              ---********CASH MARGIN*********---
              ---****************************---

              IF (v_cash_record_required = 'Y' AND cashMarginCcyAmt IS NOT NULL AND cashMarginCcyAmt>0) THEN

                  BEGIN
                      SELECT effective_date,maturity_date INTO cmvEffDate,cmvMatDate
                      FROM scbt_t_txn_mst
                      WHERE bank_group_code = bankGroupCode
                      AND cty_code = ctyCode
                      AND txn_rec_id = txnRecIDList(i);

                  EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                  END;
                  --for excess cash
                  --To Calculate remaining account balance

                  /*BELOW STATEMENT IS ADDED AS REQUESTED BY SUDHEER ON 24-SEP-2012*/
                  IF (remainingAccountBalance < Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,cashMarginCcyCode,NVL(cashMarginCcyAmt,0),custExpCcy,'N')) THEN
                     cashMarginCcyAmt:= Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,custExpCcy,NVL(remainingAccountBalance,0),cashMarginCcyCode,'N');
                     remainingAccountBalance := 0;
                  END IF;


                  --SCI Validation for cash margin records - START
                BEGIN
                    SELECT PROD_LIMIT_ID INTO lookupLimitId
                       FROM SCBT_T_TXN_MST
                    WHERE BANK_GROUP_CODE = bankGroupCode
                       AND CTY_CODE = ctyCode
                       AND CUST_ID = custID
                       AND TXN_REC_ID = txnRecIDList(i);
                EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                END;


                --IMEX will be a system code if tp system code as DTP
                if tpSystemCode = 'DTP' then
                    tpSystemCode := 'IMEX';
                elsif tpSystemCode = 'OTP' then
                    tpSystemCode := 'OAF';
                elsif tpSystemCode = 'ACBS' then
                    tpSystemCode := 'ACB';
                elsif tpSystemCode IS NULL then
                    tpSystemCode := 'IMEX';
                end if;

                -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,lookupLimitId,custLEID);
           /*
                BEGIN
                     SELECT ext_limit_id, inner_to_id
                           BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                           START WITH limit_id = lookupLimitId
                           CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id  --ext_limit_id=inner_to_id
                           AND BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE = ctyCode
                           AND CUST_ID = custId
                           order by level desc;
                     EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                     END;

                     --To report parent id if SCI LIMIT ID is not there
                     temp_parent_limit_id := null;
                     temp_ext_limit_id := null;
                     FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP

                         BEGIN
                             SELECT LAS_LMT_ID into temp_ext_limit_id
                                 FROM (
                                    select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                     WHERE A.LAS_LE_ID=custLEID
                                     and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                     --28-NOV-2012
                                     --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                  ) where rownum=1;
                             exit;

                             EXCEPTION WHEN OTHERS THEN
                               BEGIN
                                  SELECT LAS_LMT_ID into temp_ext_limit_id
                                    FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                    WHERE A.LAS_LE_ID=custLEID
                                    and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                    --28-NOV-2012
                                    --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                  ) where rownum=1;

                                  exit;
                                EXCEPTION  WHEN OTHERS THEN
                                   temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                                   NULL;
                                END;
                             END;
                       END LOOP;
*/

                  --For QC 870 Security type and Security Sub Type as CS202 -START
                  securityTypeParam := null;
                  securitySubTypeParam := null;
                  securityTypeParam :=  Scbf_C_Get_Param_Data('CA01',
                                                          '01',
                                                           bankGroupCode,
                                                           '*',
                                                           '*',
                                                           '*',
                                                           'CASH',
                                                           'CASH',
                                                           '*',
                                                           '*',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '');


                 securitySubTypeParam :=   Scbf_C_Get_Param_Data('CA01',
                                                               '02',
                                                               bankGroupCode,
                                                               '*',
                                                               '*',
                                                               '*',
                                                               'CASH',
                                                               'CASH',
                                                               '*',
                                                               '*',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '');

                         securitySubTypeDescParam :=  'CASH';

              -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;


                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := cashMarginCcyAmt;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := cashMarginCcyAmt * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := cashMarginCcyAmt;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end


                  --For QC 870 Security type and Security Sub Type as CS202 -END

                  -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
                  security_id :=null;
                  securityType := null;
                  securitySubType := null;


                  BEGIN
                     select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                       into security_id, securityType, securitySubType
                       FROM (
                           select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                           from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                              WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                                  AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                  AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                  AND UPDATE_STATUS_IND <> 'D'
                       ) where rownum=1;
                     EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                         security_id :=null;
                         securityType := null;
                         securitySubType :=null;
                  END;
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE END

                  --SCI Validation for cash margin records - END

                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(cashMarginCcyCode = 'USD') THEN
                         v_usd_cmv_amt := cashMarginCcyAmt;
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , cashMarginCcyCode
                                                , NVL(cashMarginCcyAmt,0)
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


                  exceptnSecSubType := 0;
                  --EXCEPTIONAL SECURITY SUB TYPE
                  BEGIN
                     select count(CODE_VALUE_1)
                        INTO exceptnSecSubType
                        from SCBT_R_MAP_INFO A
                      WHERE MAP_ID='CAGG_EXCPTN_LIST'
                          AND CODE_VALUE_1 = securitySubTypeParam;
                  EXCEPTION
                      WHEN OTHERS THEN
                         exceptnSecSubType := 0;
                  END;

                  --For QC 870 Security type and Security Sub Type as CS202 -END
                  -- Insert into Master Table for Physical Collateral and Receivable collateral - Cash Margin
                   BEGIN
                       runningSeq := runningSeq + 1;
                       is_valid_data := true;
                       custom_error_mesg := null;
                    custom_error_mesg := null;
                    if ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) then
                      is_valid_data := false;

                      custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
                    end if;
                    if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                        is_valid_data := false;
          	       	    custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                    elsif ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) then
                        is_valid_data := false;
                             custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                    end if;
                    if (  (upper(securityTypeParam) !=  upper(securityType) or upper(securitySubTypeParam) != upper(securitySubType))) then
                        is_valid_data := false;
                        custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
                    end if;
                    if (cmvEffDate IS NULL OR length(cmvEffDate)<1 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Effective Date is empty.';
                    end if;
                    if (cashMarginCcyAmt is null or cashMarginCcyAmt <=0) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
                    end if;
                    if (collCat='CON' and contingentProduct <=0 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                    end if;
                    --New condition if PARCEL LEVEL RECORDS EXSIST FOR TRANSACTION THEN CASH MARGIN RECORDS WILL BE CALCULATED 09-09-2011
                    --if ( is_valid_data and is_parcel_exist_for_txn ) then

                    -- ** TO CAPTURE CASH MARGIN RECORDS**--
                    if ( is_valid_data ) then
                       -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
                        --To construct Collateral Id and Parcel Id
                        cashMarginSeq := cashMarginSeq+1;
                        tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                        tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                        -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                        --if(nvl(cashMarginCcyAmt,0) != 0) then
                        INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                               BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , REC_ID
                               , COLLATERAL_ID --QC 870
                               , PARCEL_ID     --QC 870
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , recordID || LPAD(runningSeq,8,'0')
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , securityType
                               , securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate --mvMatDate
                               , cmvEffDate
                               , cmvEffDate
                               , NVL(tempStorageLoc,bookingLocFromLimit) --'' -- COCOA-1056
                               , bookingLocFromLimit
                               , cashMarginCcyCode --cashMarginCcyCode
                               , cashMarginCcyAmt --cashMarginCcyAmt
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnRefIDList(i)
                               , temp_ext_limit_id
                               , security_id
                               , 'CAGG_LINKED_CASH_MARGIN'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                       -- end if;
                    ELSE
                          --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                          IF ( cashMarginCcyAmt is null or cashMarginCcyAmt <=0) THEN
                               GOTO SKIP_TXN_LOOP;
                          END IF;

                         -- if(nvl(cashMarginCcyAmt,0) != 0 and custom_error_mesg != 'Current Market Value is empty or ZERO.') then
                            -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
                            -- To construct Collateral Id and Parcel Id
                            cashMarginSeq := cashMarginSeq+1;
                            tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                            tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                            -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                            INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR(
                                BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , COLLATERAL_ID
                               , PARCEL_ID
                               , REC_ID
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , ERROR_MESSAGE
                               , Securitysubtypedesc
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , recordID || LPAD(runningSeq,8,'0')
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , NVL(securityTypeParam, securityType)  --securityType
                               , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate --cmvMatDate
                               , cmvEffDate
                               , cmvEffDate
                               , bookingLoc
                               , bookingLocFromLimit
                               , cashMarginCcyCode --cashMarginCcyCode
                               , cashMarginCcyAmt --cashMarginCcyAmt
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnRefIDList(i)
                               , temp_ext_limit_id
                               , security_id
                               , custom_error_mesg
                               , securitySubTypeDescParam
                               , 'CAGG_LINKED_CASH_MARGIN_ERR'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                          <<SKIP_TXN_LOOP>>
                             NULL;
                           --  end if;
                        END IF;
                        EXCEPTION
                           WHEN OTHERS THEN
                           dbms_output.put_line(recordID|| '**1337-CASH MARGIN**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                           NULL;
                         END;

                         is_parcel_exist_for_txn := false;
                 END IF;

              END LOOP;

              IF (v_cash_record_required = 'Y') THEN

                --To calculate 100% Cash margin
                IF isTxnLinkExist = 0 THEN

                  ---****************************---
                  ---********100%CASH MARGIN*********---
                  ---****************************---
                  -- Fetch the Deal ID for the Collateral
                  BEGIN
                    full_cashMarginCcyAmt :=  0;
                    SELECT DEAL_ID,PRODUCT_CODE,TP_REF_ID,TP_SYSTEM_CODE,TXN_STEP_CODE,nvl(CASH_MARGIN_CCY_CODE, custExpCcy)
                    /*,(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))*/
, (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
                    , MATURITY_DATE
                       , effective_date,maturity_date, PROD_LIMIT_ID
                    INTO dealId,prodCode,tpRefID,tpSystemCode,txnStepCode,full_cashMarginCcyCode,full_cashMarginCcyAmt, txnMaturityDate
                       , cmvEffDate, cmvMatDate, lookupLimitId
                    FROM SCBT_T_TXN_MST
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND TXN_REC_ID = txnParentRecIDMstList(intTxnRow)
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                    AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                    AND PROD_LIMIT_ID not in (
                      SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                        WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE=ctyCode
                        AND CUST_ID=custId AND LIMIT_TYPE_CODE in (
                           select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                             WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                             AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'));
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                  EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       NULL;
                  END;


                  /*BELOW STATEMENT IS ADDED AS REQUESTED BY SUDHEER ON 24-SEP-2012*/
                  IF (remainingAccountBalance < Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N')) THEN
                     full_cashMarginCcyAmt:= Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,custExpCcy,NVL(remainingAccountBalance,0),cashMarginCcyCode,'N');
                     remainingAccountBalance := 0;
                  END IF;


                 -- Fetch Booking Location
                 BEGIN
                    SELECT CTY_CODE INTO bookingLoc FROM SCBT_T_DEAL_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND DEAL_ID = dealId;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      bookingLoc := null;
                 END;

                 --changes done to retrieve booking location from customer limit setup
                 BEGIN
                   SELECT BOOKING_LOCATION INTO bookingLocFromLimit from SCBT_R_CUST_PRODUCT_LIMIT WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND LIMIT_ID = prodLimitId;
                 EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                     bookingLocFromLimit := bookingLoc; --defaulting to booking location from deal
                 END;

                 --IMEX will be a system code if tp system code as DTP
                if tpSystemCode = 'DTP' then
                    tpSystemCode := 'IMEX';
                elsif tpSystemCode = 'OTP' then
                    tpSystemCode := 'OAF';
                elsif tpSystemCode = 'ACBS' then
                    tpSystemCode := 'ACB';
                elsif tpSystemCode IS NULL then
                    tpSystemCode := 'IMEX';
                end if;

               -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,lookupLimitId,custLEID);
  /*
                 BEGIN
                     SELECT ext_limit_id, inner_to_id
                           BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                           START WITH limit_id = lookupLimitId
                           CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id  --ext_limit_id=inner_to_id
                           AND BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE = ctyCode
                           AND CUST_ID = custId
                           order by level desc;
                     EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                     END;

                     --To report parent id if SCI LIMIT ID is not there
                     temp_parent_limit_id := null;
                     temp_ext_limit_id := null;
                     FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP

                         BEGIN
                             SELECT LAS_LMT_ID into temp_ext_limit_id
                                 FROM (
                                    select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                     WHERE A.LAS_LE_ID=custLEID
                                     and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                     --28-NOV-2012
                                     --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                  ) where rownum=1;
                             exit;

                             EXCEPTION WHEN OTHERS THEN
                               BEGIN
                                  SELECT LAS_LMT_ID into temp_ext_limit_id
                                    FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                    WHERE A.LAS_LE_ID=custLEID
                                    and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                    --28-NOV-2012
                                    --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                  ) where rownum=1;

                                  exit;
                                EXCEPTION  WHEN OTHERS THEN
                                   temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                                   NULL;
                                END;
                             END;
                       END LOOP;
*/

                  --For QC 870 Security type and Security Sub Type as CS202 -START
                  securityTypeParam := null;
                  securitySubTypeParam := null;
                  securityTypeParam :=  Scbf_C_Get_Param_Data('CA01',
                                                          '01',
                                                           bankGroupCode,
                                                           '*',
                                                           '*',
                                                           '*',
                                                           'CASH',
                                                           'CASH',
                                                           '*',
                                                           '*',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '');


                 securitySubTypeParam :=   Scbf_C_Get_Param_Data('CA01',
                                                               '02',
                                                               bankGroupCode,
                                                               '*',
                                                               '*',
                                                               '*',
                                                               'CASH',
                                                               'CASH',
                                                               '*',
                                                               '*',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '');

                         securitySubTypeDescParam :=  'CASH';

                 -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;


                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N');
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N') * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N');
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

                  --For QC 870 Security type and Security Sub Type as CS202 -END

                  -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
                  security_id :=null;
                  securityType := null;
                  securitySubType := null;

                  BEGIN
                     select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                       into security_id, securityType, securitySubType
                       FROM (
                           select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                           from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                              WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                                  AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                  AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                  AND UPDATE_STATUS_IND <> 'D'
                       ) where rownum=1;
                     EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                         security_id :=null;
                         securityType := null;
                         securitySubType :=null;
                  END;
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE END

                  --SCI Validation for cash margin records - END

                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(custExpCcy = 'USD') THEN
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N');
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , custExpCcy
                                                , Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N')
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


                  exceptnSecSubType := 0;
                  --EXCEPTIONAL SECURITY SUB TYPE
                  BEGIN
                     select count(CODE_VALUE_1)
                        INTO exceptnSecSubType
                        from SCBT_R_MAP_INFO A
                      WHERE MAP_ID='CAGG_EXCPTN_LIST'
                          AND CODE_VALUE_1 = securitySubTypeParam;
                  EXCEPTION
                      WHEN OTHERS THEN
                         exceptnSecSubType := 0;
                  END;


                  -- Insert into Master Table for Physical Collateral and Receivable collateral - Cash Margin
                   BEGIN
                       runningSeq := runningSeq + 1;
                       is_valid_data := true;
                       custom_error_mesg := null;
                    custom_error_mesg := null;
                    if ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) then
                      is_valid_data := false;
                      custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
                    end if;
                    if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                        is_valid_data := false;
          	       	    custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                    elsif ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) then
                        is_valid_data := false;
                             custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                    end if;
                    if (  (upper(securityTypeParam) !=  upper(securityType) or upper(securitySubTypeParam) != upper(securitySubType))) then
                      is_valid_data := false;
                      custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
                    end if;
                    if (cmvEffDate IS NULL OR length(cmvEffDate)<1 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Effective Date is empty.';
                    end if;
                    if (full_cashMarginCcyAmt is null or full_cashMarginCcyAmt <=0) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
                    end if;
                    if (collCat='CON' and contingentProduct <=0 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                    end if;


                    --New condition if PARCEL LEVEL RECORDS EXSIST FOR TRANSACTION THEN CASH MARGIN RECORDS WILL BE CALCULATED 09-09-2011
                    --if ( is_valid_data and is_parcel_exist_for_txn ) then

                    --**TO CAPTURE 100% CASH MARGIN**--
                    if ( is_valid_data ) then
                       -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
                        --To construct Collateral Id and Parcel Id
                        cashMarginSeq := cashMarginSeq+1;
                        tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                        tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                        -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                        --if(nvl(cashMarginCcyAmt,0) != 0) then
                        INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                               BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , REC_ID
                               , COLLATERAL_ID --QC 870
                               , PARCEL_ID     --QC 870
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , recordID || LPAD(runningSeq,8,'0')
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , securityType
                               , securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate --mvMatDate
                               , cmvEffDate
                               , cmvEffDate
                               , NVL(tempStorageLoc,bookingLocFromLimit) --''-- COCOA-1056
                               , bookingLocFromLimit
                               , custExpCcy --cashMarginCcyCode
                               , Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N') --remainingAccountBalance --cashMarginCcyAmt
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnParentRefIDMstList(intTxnRow)
                               , temp_ext_limit_id
                               , security_id
                               , 'CAGG_UNLINKED_CASH_MARGIN'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                       -- end if;
                    ELSE
                           --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                        IF ( (full_cashMarginCcyAmt is null or full_cashMarginCcyAmt <=0) ) THEN
                               GOTO SKIP_TXN_LOOP;
                           END IF;

                         -- if(nvl(cashMarginCcyAmt,0) != 0 and custom_error_mesg != 'Current Market Value is empty or ZERO.') then
                            -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
                            -- To construct Collateral Id and Parcel Id
                            cashMarginSeq := cashMarginSeq+1;
                            tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                            tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                            -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                            INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR(
                                BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , COLLATERAL_ID
                               , PARCEL_ID
                               , REC_ID
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , ERROR_MESSAGE
                               , Securitysubtypedesc
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , recordID || LPAD(runningSeq,8,'0')
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , NVL(securityTypeParam, securityType)  --securityType
                               , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate --cmvMatDate
                               , cmvEffDate
                               , cmvEffDate
                               , bookingLoc
                               , bookingLocFromLimit
                               , custExpCcy  --cashMarginCcyCode
                               , Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,full_cashMarginCcyCode,NVL(full_cashMarginCcyAmt,0),custExpCcy,'N') --remainingAccountBalance --cashMarginCcyAmt
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnParentRefIDMstList(intTxnRow)
                               , temp_ext_limit_id
                               , security_id
                               , custom_error_mesg
                               , securitySubTypeDescParam
                               , 'CAGG_UNLINKED_CASH_MARGIN_ERR'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                          <<SKIP_TXN_LOOP>>
                             NULL;
                           --  end if;
                        END IF;
                        EXCEPTION
                           WHEN OTHERS THEN
                           dbms_output.put_line(recordID|| '**1727-100% CASH MARGIN**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                           NULL;
                         END;

                END IF;

                --- CAPTURING TOPUP RECORDS at TRANSACTION LEVEL START ---
                  BEGIN
                    topup_cashMarginCcyAmt :=  0;
                    SELECT DEAL_ID,PRODUCT_CODE,TP_REF_ID,TP_SYSTEM_CODE,TXN_STEP_CODE,nvl(CASH_MARGIN_CCY_CODE, custExpCcy)
                    /*,(NVL(CASH_MARGIN_CCY_AMT,0) - NVL(CM_CCY_RELEASE_AMT,0))*/
, (CASE WHEN NVL(CASH_MARGIN_ADJ,'MINUS') <>'PLUS' THEN
((NVL(CASH_MARGIN_ORIGN_AMT,0) - NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0))
ELSE ((NVL(CASH_MARGIN_ORIGN_AMT,0) + NVL(CASH_MARGIN_ADJ_AMT,0)) - NVL(CM_CCY_RELEASE_AMT,0)) END)
                    , MATURITY_DATE
                       , effective_date,maturity_date, PROD_LIMIT_ID
                    INTO dealId,prodCode,tpRefID,tpSystemCode,txnStepCode,topup_cashMarginCcyCode,topup_cashMarginCcyAmt, txnMaturityDate
                       , cmvEffDate, cmvMatDate, lookupLimitId
                    FROM SCBT_T_TXN_MST
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND TXN_REC_ID = txnParentRecIDMstList(intTxnRow)
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                    AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                    AND PROD_LIMIT_ID not in (select LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                       where BANK_GROUP_CODE= bankGroupCode and CTY_CODE=ctyCode
                         and LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                                AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE')
                    );
                    --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                  EXCEPTION
                       WHEN NO_DATA_FOUND THEN
                       NULL;
                  END;


                 -- Fetch Booking Location
                 BEGIN
                    SELECT CTY_CODE INTO bookingLoc FROM SCBT_T_DEAL_MST WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND DEAL_ID = dealId;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                      bookingLoc := null;
                 END;

                 --changes done to retrieve booking location from customer limit setup
                 BEGIN
                   SELECT BOOKING_LOCATION INTO bookingLocFromLimit from SCBT_R_CUST_PRODUCT_LIMIT WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND LIMIT_ID = prodLimitId;
                 EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                     bookingLocFromLimit := bookingLoc;
                 END;

                --TO calculate TOPUP AMOUNT at TRANSACTION LEVEL
                v_topup_amount := 0;
                v_topup_amount := Scbk_P_Cocoa_Cdb.SCBF_GET_TOPUP_AMT_BY_LEVEL (
                                                   bankGroupCode
                                                   , ctyCode
                                                   , custId
                                                   , txnParentRefIDMstList(intTxnRow)
                                                   , txnParentRecIDMstList(intTxnRow)
                                                   , txnParentCcyCodeMstList(intTxnRow)
                                                   , ''
                                                   , ''
                                                   , ''
                                                   , 'T');

                IF v_topup_amount IS NOT NULL and v_topup_amount > 0 THEN
                   --IMEX will be a system code if tp system code as DTP
                  if tpSystemCode = 'DTP' then
                      tpSystemCode := 'IMEX';
                  elsif tpSystemCode = 'OTP' then
                      tpSystemCode := 'OAF';
                  elsif tpSystemCode = 'ACBS' then
                      tpSystemCode := 'ACB';
                  elsif tpSystemCode IS NULL then
                      tpSystemCode := 'IMEX';
                  end if;

              -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,lookupLimitId,custLEID);
    /*
                 BEGIN
                     SELECT ext_limit_id, inner_to_id
                           BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                           FROM SCBT_R_CUST_PRODUCT_LIMIT
                           START WITH limit_id = lookupLimitId
                           CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id  --ext_limit_id=inner_to_id
                           AND BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE = ctyCode
                           AND CUST_ID = custId
                           order by level desc;
                     EXCEPTION
                          WHEN OTHERS THEN
                          NULL;
                     END;

                     --To report parent id if SCI LIMIT ID is not there
                     temp_parent_limit_id := null;
                     temp_ext_limit_id:= null;
                     FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP

                         BEGIN
                             SELECT LAS_LMT_ID into temp_ext_limit_id
                                 FROM (
                                    select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                     WHERE A.LAS_LE_ID=custLEID
                                     and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                     --28-NOV-2012
                                     --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                  ) where rownum=1;
                             exit;

                             EXCEPTION WHEN OTHERS THEN
                               BEGIN
                                  SELECT LAS_LMT_ID into temp_ext_limit_id
                                    FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                    WHERE A.LAS_LE_ID=custLEID
                                    and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                    28-NOV-2012
                                    --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                  ) where rownum=1;

                                  exit;
                                EXCEPTION  WHEN OTHERS THEN
                                   temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                                   NULL;
                                END;
                             END;
                       END LOOP;

*/
                  --For QC 870 Security type and Security Sub Type as CS202 -START
                  securityTypeParam := null;
                  securitySubTypeParam := null;
                  securityTypeParam :=  Scbf_C_Get_Param_Data('CA01',
                                                          '01',
                                                           bankGroupCode,
                                                           '*',
                                                           '*',
                                                           '*',
                                                           'CASH',
                                                           'CASH',
                                                           '*',
                                                           '*',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '',
                                                           '');


                 securitySubTypeParam :=   Scbf_C_Get_Param_Data('CA01',
                                                               '02',
                                                               bankGroupCode,
                                                               '*',
                                                               '*',
                                                               '*',
                                                               'CASH',
                                                               'CASH',
                                                               '*',
                                                               '*',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '',
                                                               '');

                         securitySubTypeDescParam :=  'CASH';

                -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;


                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := v_topup_amount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;


                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := v_topup_amount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := v_topup_amount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

                  --For QC 870 Security type and Security Sub Type as CS202 -END

                  -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
                  security_id :=null;
                  securityType := null;
                  securitySubType := null;

                  BEGIN
                     select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                       into security_id, securityType, securitySubType
                       FROM (
                           select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                           from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                              WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                                  AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                  AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                  AND UPDATE_STATUS_IND <> 'D'
                       ) where rownum=1;
                     EXCEPTION
                         WHEN OTHERS THEN
                         NULL;
                         security_id :=null;
                         securityType := null;
                         securitySubType :=null;
                  END;
                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE END

                  --SCI Validation for cash margin records - END

                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(custExpCcy = 'USD') THEN
                         v_usd_cmv_amt := v_topup_amount;
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , custExpCcy
                                                , NVL(v_topup_amount,0)
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


                  exceptnSecSubType := 0;
                  --EXCEPTIONAL SECURITY SUB TYPE
                  BEGIN
                     select count(CODE_VALUE_1)
                        INTO exceptnSecSubType
                        from SCBT_R_MAP_INFO A
                      WHERE MAP_ID='CAGG_EXCPTN_LIST'
                          AND CODE_VALUE_1 = securitySubTypeParam;
                  EXCEPTION
                      WHEN OTHERS THEN
                         exceptnSecSubType := 0;
                  END;


                  -- Insert into Master Table for Physical Collateral and Receivable collateral - Cash Margin
                   BEGIN
                       runningSeq := runningSeq + 1;
                       is_valid_data := true;
                       custom_error_mesg := null;
                    if ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) then
                      is_valid_data := false;

                      custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
                    end if;
                    if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                        is_valid_data := false;
          	       	    custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                    elsif ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) then
                        is_valid_data := false;
                             custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                    end if;
                    if (  (upper(securityTypeParam) !=  upper(securityType) or upper(securitySubTypeParam) != upper(securitySubType))) then
                      is_valid_data := false;
                      custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
                    end if;
                    if (cmvEffDate IS NULL OR length(cmvEffDate)<1 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Effective Date is empty.';
                    end if;
                    if (v_topup_amount is null or v_topup_amount <=0) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'TOPUP AMOUNT for TRANSACTION is empty or ZERO.';
                    end if;
                    if (collCat='CON' and contingentProduct <=0 ) then
                         is_valid_data := false;
                         custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                    end if;


                    --New condition if PARCEL LEVEL RECORDS EXSIST FOR TRANSACTION THEN CASH MARGIN RECORDS WILL BE CALCULATED 09-09-2011
                    --if ( is_valid_data and is_parcel_exist_for_txn ) then

                    --*** INSERT TOPUP RECORDS at TRANSACTION LEVEL **--
                    if ( is_valid_data ) then
                       -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --START
                        --To construct Collateral Id and Parcel Id
                        cashMarginSeq := cashMarginSeq+1;
                        tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                        tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                        -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                        --if(nvl(cashMarginCcyAmt,0) != 0) then
                        INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                               BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , REC_ID
                               , COLLATERAL_ID --QC 870
                               , PARCEL_ID     --QC 870
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , recordID || LPAD(runningSeq,8,'0')
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , securityType
                               , securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate --mvMatDate
                               , cmvEffDate
                               , cmvEffDate
                               , NVL(tempStorageLoc,bookingLocFromLimit) --''-- COCOA-1056
                               , bookingLocFromLimit
                               , custExpCcy --cashMarginCcyCode
                               , v_topup_amount --cashMarginCcyAmt
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnParentRefIDMstList(intTxnRow)
                               , temp_ext_limit_id
                               , security_id
                               , 'CAGG_TOPUP_TXN_LEVEL'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                       -- end if;
                    ELSE
                            --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                        IF ( (v_topup_amount is null or v_topup_amount <=0) ) THEN
                                GOTO SKIP_TXN_LOOP;
                            END IF;
                            cashMarginSeq := cashMarginSeq+1;
                            tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                            tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                            -- For  QC 870 Collateral Id and Parcel Id for Cash Margin --END
                            INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR(
                                BANK_GROUP_CODE
                               , CTY_CODE
                               , CUST_ID
                               , DEAL_ID
                               , COLLATERAL_ID
                               , PARCEL_ID
                               , REC_ID
                               , BUSINESS_DATE
                               , SECURITY_VALUATION_DATE
                               , SOURCE_SYSTEM_CODE
                               , SECURITY_TYPE
                               , SECURITY_SUBTYPE
                               , COLLATERAL_APPROACH
                               , PRODUCT_CODE
                               , IS_SECURITY_PERFECTED
                               , MATURITY_DATE
                               , EFFECTIVE_DATE
                               , SECURITY_PERFECTION_DATE
                               , STORAGE_CTY_CODE
                               , BOOKING_LOC_CTY_CODE
                               , CMV_CCY_CODE
                               , CMV_CCY_AMT
                               , TP_REF_ID
                               , SCI_LEID
                               , TP_SYSTEM_CODE
                               , TXN_REF_ID
                               , SCI_LIMIT_ID
                               , SECURITY_ID
                               , ERROR_MESSAGE
                               , Securitysubtypedesc
                               , CAGG_CATURED_TYPE
                               , USD_CMV_AMT
                               , FSV_PCT
                               , FSV_VALUE
                               , FSV_OVERRIDE_FLAG)
                             VALUES(
                               bankGroupCode
                               , ctyCode
                               , custId
                               , dealId
                               , tempCollateralId --QC 870
                               , tempParcelId --QC 870
                               , recordID || LPAD(runningSeq,8,'0')
                               , bussDate
                               , bussDate
                               , 'CCA'
                               , NVL(securityTypeParam, securityType)  --securityType
                               , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                               , 'T'
                               , prodCode
                               , 'Y'
                               , txnMaturityDate
                               , cmvEffDate
                               , cmvEffDate
                               , bookingLoc
                               , bookingLocFromLimit
                               , custExpCcy
                               , v_topup_amount
                               , tpRefID
                               , custLEID
                               , tpSystemCode
                               , txnParentRefIDMstList(intTxnRow)
                               , temp_ext_limit_id
                               , security_id
                               , custom_error_mesg
                               , securitySubTypeDescParam
                               , 'CAGG_TOPUP_TXN_LEVEL_ERR'
                               , v_usd_cmv_amt
                               , fsvPct
                               , fsvValue
                               , fsvOverrideFlag);
                          <<SKIP_TXN_LOOP>>
                             NULL;
                           --  end if;
                        END IF;
                        EXCEPTION
                           WHEN OTHERS THEN
                           dbms_output.put_line(recordID|| '**2118INSERT TOPUP RECORDS at TRANSACTION LEVEL**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                           NULL;
                         END;

                 END IF;
                --- topup records at transaction level end---

             END IF;

      END LOOP;


     IF v_cash_record_required = 'Y' THEN
       ---*** EXCESS CASH / SURPLESS CASH FOR THE CUSTOMER ***---
             -- TOPUP TRANSACTION AT CUSTOMER LEVEL ** START--

             --To select OUTER LIMIT ID and LIMIT_ID
             BEGIN
/*
                    SELECT ext_limit_id, PROD.limit_id,Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,UTIL.LIMIT_CCY_CODE,NVL(UTIL.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N')
                      , LIMIT_PRODUCT_CODE
                      BULK COLLECT INTO sciLimitIdList,outerLimitIdList, limitActiveAmt, sciLimitProdCodeList
                       FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,SCBT_T_PROD_LIMIT_UTIL UTIL
                       WHERE PROD.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND PROD.CTY_CODE = UTIL.CTY_CODE
                          AND PROD.LIMIT_ID = UTIL.LIMIT_ID
                          AND PROD.BANK_GROUP_CODE = bankGroupCode
                          AND PROD.CTY_CODE = ctyCode
                          AND PROD.limit_cat_code ='O'
                          AND PROD.cust_id = custId;
*/
/* COMMENTED ABOVE STATEMENT TO CONSIDER LIMIT_CAT_CODE AS 'I' if transaction is happend
   on 07-FEB-2013
*/

    SELECT DISTINCT EXT_LIMIT_ID, LIMIT_ID, LIMIT_ACTIVE_AMOUNT, LIMIT_PRODUCT_CODE
         BULK COLLECT INTO sciLimitIdList,outerLimitIdList, limitActiveAmt, sciLimitProdCodeList
         FROM (
            SELECT ext_limit_id, PROD.limit_id,Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,UTIL.LIMIT_CCY_CODE,NVL(UTIL.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N') as limit_active_amount
                   , LIMIT_PRODUCT_CODE, LIMIT_TYPE_CODE
              FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,SCBT_T_PROD_LIMIT_UTIL UTIL
                       WHERE PROD.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND PROD.CTY_CODE = UTIL.CTY_CODE
                          AND PROD.LIMIT_ID = UTIL.LIMIT_ID
                          AND PROD.BANK_GROUP_CODE = bankGroupCode
                          AND PROD.CTY_CODE = ctyCode
                          AND PROD.limit_cat_code ='O'
                          AND PROD.cust_id = custId
              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                 AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                      UNION
                           SELECT p.ext_limit_id,p.limit_id
                           , Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,U.LIMIT_CCY_CODE,NVL(U.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N') as limit_active_amount
                           ,limit_product_code, limit_type_code
                                FROM scbt_t_collateral_register_mst c,scbt_r_cust_product_limit p,scbt_t_deal_register_hdr_mst r
                                ,SCBT_T_PROD_LIMIT_UTIL u
                                WHERE BUSINESS_TYPE = 'FLC' AND limit_cat_code in ('CI','I') -- COCOA-1055
                                  AND R.prod_limit_id = p.limit_id AND p.cust_id = r.cust_id AND p.cust_id = c.cust_id AND c.deal_id = r.deal_id
                                  AND collateral_category <> 'REL' AND total_cmv_ccy_amt>0
                                  AND C.bank_group_code = p.bank_group_code
                                  AND C.bank_group_code = r.bank_group_code
                                  AND C.cty_code = p.cty_code
                                  AND C.cty_code = r.cty_code
                                  AND P.bank_group_code = bankGroupCode
                                  AND P.CTY_CODE = ctyCode
                                  AND P.CUST_ID=custId
                                  AND P.BANK_GROUP_CODE = U.BANK_GROUP_CODE
                                  AND P.CTY_CODE = U.CTY_CODE
                                  AND P.LIMIT_ID = U.LIMIT_ID
                                  AND P.LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                              )
                              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                              WHERE LIMIT_TYPE_CODE NOT in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                                     AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;;
              EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                           NULL;
              END;

             v_topup_amount := 0;
             v_topup_amount := Scbk_P_Cocoa_Cdb.SCBF_GET_TOPUP_AMT_BY_LEVEL (
                                                           bankGroupCode
                                                           , ctyCode
                                                           , custId
                                                           , ''
                                                           , ''
                                                           , ''
                                                           , ''
                                                           , ''
                                                           , custExpCcy
                                                           , 'C');

         -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := v_topup_amount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := v_topup_amount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := v_topup_amount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end


               FOR outerLimitIndex IN 1..sciLimitIdList.COUNT LOOP

                  --totalTopUpByFacility := 0;

                --To select INNER_TO_ID


                  --INNER_TO_ID START
                  BEGIN
                    SELECT sum(Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,UTIL.LIMIT_CCY_CODE,NVL(UTIL.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N') )
                        INTO apportionedAmt
                       FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,SCBT_T_PROD_LIMIT_UTIL UTIL
                       WHERE PROD.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND PROD.CTY_CODE = UTIL.CTY_CODE
                          AND PROD.LIMIT_ID = UTIL.LIMIT_ID
                          AND PROD.BANK_GROUP_CODE = bankGroupCode
                          AND PROD.CTY_CODE = ctyCode
/* COMMENTED ABOVE STATEMENT TO CONSIDER LIMIT_CAT_CODE AS 'I' if transaction is happend
   on 07-FEB-2013
*/
                          --AND PROD.limit_cat_code ='O'
                          AND PROD.cust_id = custId
                          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                          AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                          WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                           AND LIMIT_TYPE_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                             WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                           AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                      --(Exposure for Outer limit/Total Exposure for all outer) * Topup at customer level
                      BEGIN
                         v_topup_amount := (limitActiveAmt(outerLimitIndex) / apportionedAmt) * v_topup_amount;
                      EXCEPTION WHEN OTHERS THEN
                         v_topup_amount := 0;
                      END;
                  EXCEPTION
                        WHEN OTHERS THEN
                            v_topup_amount:= 0;
                  END;

             -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := v_topup_amount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := v_topup_amount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := v_topup_amount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

                  security_id := null;
                  securityType :=  Scbf_C_Get_Param_Data('CA01',
                                                      '01',
                                                       bankGroupCode,
                                                       '*',
                                                       '*',
                                                       '*',
                                                       'CASH',
                                                       'CASH',
                                                       '*',
                                                       '*',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '',
                                                       '');

                  securitySubType :=   Scbf_C_Get_Param_Data('CA01',
                                                       '02',
                                                        bankGroupCode,
                                                        '*',
                                                        '*',
                                                        '*',
                                                        'CASH',
                                                        'CASH',
                                                        '*',
                                                        '*',
                                                        '',
                                                        '',
                                                        '',
                                                        '',
                                                        '',
                                                        '');
                  securitySubTypeDescParam :=  'CASH';


                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(custExpCcy = 'USD') THEN
                         v_usd_cmv_amt := v_topup_amount;
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , custExpCcy
                                                , NVL(v_topup_amount,0)
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


                  exceptnSecSubType := 0;
               --EXCEPTIONAL SECURITY SUB TYPE
               BEGIN
                  select count(CODE_VALUE_1)
                       INTO exceptnSecSubType
                  from SCBT_R_MAP_INFO A
                       WHERE MAP_ID='CAGG_EXCPTN_LIST'
                       AND CODE_VALUE_1 = securitySubTypeParam;
               EXCEPTION
                    WHEN OTHERS THEN
                     exceptnSecSubType := 0;
               END;

               BEGIN
                 runningSeq := runningSeq + 1;
                 temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,sciLimitIdList(outerLimitIndex),custLEID);
                 is_valid_data := true;
                 -- if ( actualCMVAmount is null or actualCMVAmount <=0) then
                 if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                        is_valid_data := false;
          	       	    custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                 end if;
                 if( v_topup_amount is null or v_topup_amount <=0) then
                    is_valid_data := false;
                    custom_error_mesg :=  custom_error_mesg ||'TOPUP AMOUNT AT FACILITY level Value is empty or ZERO.';
                 elsif (collCat = 'CON' and contingentProduct  <=0) then
                    is_valid_data := false;
                    custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                 end if;

                 --**TO CAPTURE TOPUP TRANSACTION AT CUSTOMER LEVEL**--
                 if ( is_valid_data  ) then
                        INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                                        BANK_GROUP_CODE
                                      , CTY_CODE
                                      , CUST_ID
                                      , SCI_LIMIT_ID
                                      , COLLATERAL_ID
                                      , DEAL_ID
                                      , PARCEL_ID
                                      , REC_ID
                                      , BUSINESS_DATE
                                      , SECURITY_VALUATION_DATE
                                      , SOURCE_SYSTEM_CODE
                                      , SECURITY_TYPE
                                      , SECURITY_SUBTYPE
                                      , COLLATERAL_APPROACH
                                      , PRODUCT_CODE
                                      , IS_SECURITY_PERFECTED
                                      , MATURITY_DATE
                                      , EFFECTIVE_DATE
                                      , STORAGE_CTY_CODE
                                      , BOOKING_LOC_CTY_CODE
                                      , CMV_CCY_CODE
                                      , CMV_CCY_AMT
                                      , TP_REF_ID
                                      , SCI_LEID
                                      , TP_SYSTEM_CODE
                                      , TXN_REF_ID
                                      , SECURITY_ID
                                      , CAGG_CATURED_TYPE
                                      , USD_CMV_AMT
                                      , FSV_PCT
                                      , FSV_VALUE
                                      , FSV_OVERRIDE_FLAG)
                                     VALUES(
                                        bankGroupCode
                                        , ctyCode
                                        , custId
                                        , temp_ext_limit_id--sciLimitIdList(outerLimitIndex)
                                        , ''
                                        , ''
                                        , ''
                                        , recordID || LPAD(runningSeq,8,'0')
                                        , bussDate
                                        , bussDate
                                        , 'CCA'
                                        , securityType
                                        , securitySubType
                                        , 'F'
                                        , prodCode
                                        , 'Y'
                                        , ''
                                        , ''
                                        , NVL(tempStorageLoc,bookingLocFromLimit) --''-- COCOA-1056
                                        , bookingLocFromLimit
                                        , custExpCcy
                                        , v_topup_amount
                                        , ''
                                        , custLEID
                                        , ''
                                        , ctyCode   -- obu chngs for records other than transactionlevel, txn refid to be stamped with ctycode
                                        , security_id
                                        , 'CAGG_TOPUP_CUST_LEVEL'
                                        , v_usd_cmv_amt
                                        , fsvPct
                                        , fsvValue
                                        , fsvOverrideFlag);
                               ELSE
                                   IF ( (v_topup_amount is null or v_topup_amount <=0)) THEN
                                          GOTO SKIP_TXN_LOOP;
                                       END IF;

                                INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR(
                                      BANK_GROUP_CODE
                                      , CTY_CODE
                                      , CUST_ID
                                      , SCI_LIMIT_ID
                                      , COLLATERAL_ID
                                      , DEAL_ID
                                      , PARCEL_ID
                                      , REC_ID
                                      , BUSINESS_DATE
                                      , SECURITY_VALUATION_DATE
                                      , SOURCE_SYSTEM_CODE
                                      , SECURITY_TYPE
                                      , SECURITY_SUBTYPE
                                      , COLLATERAL_APPROACH
                                      , PRODUCT_CODE
                                      , IS_SECURITY_PERFECTED
                                      , MATURITY_DATE
                                      , EFFECTIVE_DATE
                                      , STORAGE_CTY_CODE
                                      , BOOKING_LOC_CTY_CODE
                                      , CMV_CCY_CODE
                                      , CMV_CCY_AMT
                                      , TP_REF_ID
                                      , SCI_LEID
                                      , TP_SYSTEM_CODE
                                      , TXN_REF_ID
                                      , SECURITY_ID
                                      , ERROR_MESSAGE
                                      , SECURITYSUBTYPEDESC
                                      , CAGG_CATURED_TYPE
                                      , USD_CMV_AMT
                                      , FSV_PCT
                                      , FSV_VALUE
                                      , FSV_OVERRIDE_FLAG)
                                   VALUES(
                                      bankGroupCode
                                      , ctyCode
                                      , custId
                                      , temp_ext_limit_id--sciLimitIdList(outerLimitIndex)
                                      , ''
                                      , ''
                                      , ''
                                      , recordID || LPAD(runningSeq,8,'0')
                                      , bussDate
                                      , bussDate
                                      , 'CCA'
                                      , NVL( securityTypeParam, securityType)
                                      , NVL( securitySubTypeParam, securitySubType)
                                      , 'F'
                                      , prodCode
                                      , 'Y'
                                      , ''
                                      , ''
                                      , bookingLoc --''
                                      , bookingLocFromLimit
                                      , custExpCcy
                                      , v_topup_amount
                                      , ''
                                      , custLEID
                                      , ''
                                      , ctyCode  -- obu chngs for records other than transactionlevel, txn refid to be stamped with ctycode
                                      , security_id
                                      , custom_error_mesg
                                      , securitySubTypeDescParam
                                      , 'CAGG_TOPUP_CUST_LEVEL_ERR'
                                      , v_usd_cmv_amt
                                      , fsvPct
                                      , fsvValue
                                      , fsvOverrideFlag);
                                  <<SKIP_TXN_LOOP>>
                                     NULL;
                                END IF;
                             EXCEPTION
                               WHEN OTHERS THEN
                               dbms_output.put_line(recordID|| '**2800TOPUP TRANSACTION AT FACILITY LEVEL**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                               NULL;
                              END;

                     END LOOP;

             -- TOPUP TRANSACTION AT CUSTOMER LEVEL ** END--


             -- TOPUP TRANSACTION AT FACILITY LEVEL ** START --

                          --To select OUTER LIMIT ID and LIMIT_ID
             BEGIN
/*
                    SELECT ext_limit_id, PROD.limit_id,Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,UTIL.LIMIT_CCY_CODE,NVL(UTIL.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N')
                      , LIMIT_PRODUCT_CODE
                      BULK COLLECT INTO sciLimitIdList,outerLimitIdList, limitActiveAmt, sciLimitProdCodeList
                       FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,SCBT_T_PROD_LIMIT_UTIL UTIL
                       WHERE PROD.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND PROD.CTY_CODE = UTIL.CTY_CODE
                          AND PROD.LIMIT_ID = UTIL.LIMIT_ID
                          AND PROD.BANK_GROUP_CODE = bankGroupCode
                          AND PROD.CTY_CODE = ctyCode
                          AND PROD.limit_cat_code ='O'
                          AND PROD.cust_id = custId;
*/
/* COMMENTED ABOVE STATEMENT TO CONSIDER LIMIT_CAT_CODE AS 'I' if transaction is happend
   on 07-FEB-2013
*/

    SELECT DISTINCT EXT_LIMIT_ID, LIMIT_ID, LIMIT_ACTIVE_AMOUNT, LIMIT_PRODUCT_CODE
         BULK COLLECT INTO sciLimitIdList,outerLimitIdList, limitActiveAmt, sciLimitProdCodeList
         FROM (
            SELECT ext_limit_id, PROD.limit_id,Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,UTIL.LIMIT_CCY_CODE,NVL(UTIL.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N') as limit_active_amount
                   , LIMIT_PRODUCT_CODE, LIMIT_TYPE_CODE
              FROM SCBT_R_CUST_PRODUCT_LIMIT PROD,SCBT_T_PROD_LIMIT_UTIL UTIL
                       WHERE PROD.BANK_GROUP_CODE = UTIL.BANK_GROUP_CODE AND PROD.CTY_CODE = UTIL.CTY_CODE
                          AND PROD.LIMIT_ID = UTIL.LIMIT_ID
                          AND PROD.BANK_GROUP_CODE = bankGroupCode
                          AND PROD.CTY_CODE = ctyCode
                          AND PROD.limit_cat_code ='O'
                          AND PROD.cust_id = custId
              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                 AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                      UNION
                           SELECT p.ext_limit_id,p.limit_id
                           , Scbf_Fetch_Exch_Rate(bankGroupCode,ctyCode,U.LIMIT_CCY_CODE,NVL(U.LIMIT_CCY_UTILISED_AMT,0),custExpCcy,'N') as limit_active_amount
                           ,limit_product_code, LIMIT_TYPE_CODE
                                FROM scbt_t_collateral_register_mst c,scbt_r_cust_product_limit p,scbt_t_deal_register_hdr_mst r
                                ,SCBT_T_PROD_LIMIT_UTIL u
                                WHERE BUSINESS_TYPE = 'FLC' AND limit_cat_code in ('CI','I') -- COCOA-1055
                                  AND R.prod_limit_id = p.limit_id AND p.cust_id = r.cust_id AND p.cust_id = c.cust_id AND c.deal_id = r.deal_id
                                  AND collateral_category <> 'REL' AND total_cmv_ccy_amt>0
                                  AND C.bank_group_code = p.bank_group_code
                                  AND C.bank_group_code = r.bank_group_code
                                  AND C.cty_code = p.cty_code
                                  AND C.cty_code = r.cty_code
                                  AND P.bank_group_code = bankGroupCode
                                  AND P.CTY_CODE = ctyCode
                                  AND P.CUST_ID=custId
                                  AND P.BANK_GROUP_CODE = U.BANK_GROUP_CODE
                                  AND P.CTY_CODE = U.CTY_CODE
                                  AND P.LIMIT_ID = U.LIMIT_ID
                                  AND P.LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                              )
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                     WHERE LIMIT_TYPE_CODE NOT in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                       AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;

              EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                           NULL;
              END;

             FOR outerLimitIndex IN 1..sciLimitIdList.COUNT LOOP

                SELECT LIMIT_ID, LIMIT_CCY_CODE BULK COLLECT INTO innerToIdList, limitCCyCode
                  FROM SCBT_R_CUST_PRODUCT_LIMIT
                  START WITH ext_limit_id=sciLimitIdList(outerLimitIndex)
                  CONNECT BY NOCYCLE PRIOR  ext_limit_id = inner_to_id
                     AND BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custID
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                     AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                       WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                     AND LIMIT_TYPE_CODE NOT in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                        WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                        AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;

                 FOR innerLimitIndex IN 1..innerToIdList.COUNT LOOP

                    BEGIN
                           v_topup_amount := Scbk_P_Cocoa_Cdb.SCBF_GET_TOPUP_AMT_BY_LEVEL (
                                                                 bankGroupCode
                                                                 , ctyCode
                                                                 , custId
                                                                 , ''
                                                                 , ''
                                                                 , ''
                                                                 , innerToIdList(innerLimitIndex)
                                                                 , limitCcyCode(innerLimitIndex)
                                                                 , custExpCcy
                                                                 , 'F');
                    EXCEPTION
                       WHEN OTHERS THEN
                         v_topup_amount := 0;
                    END;

                 -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                BEGIN
                   SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                     WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND COLL_LOCATION_CODE= ctycode
                     AND CUST_ID = custId
                     AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || lookupLimitId || ',', 1, 1 ) =( ',' || lookupLimitId || ',')
                     AND J158_CODE = securitySubTypeParam;
                EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctCust is NULL) THEN
                    fsvValue        := v_topup_amount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                 -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                 IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctCust <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctCust;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := v_topup_amount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := v_topup_amount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

                    securityType :=  Scbf_C_Get_Param_Data('CA01',
                                                            '01',
                                                             bankGroupCode,
                                                             '*',
                                                             '*',
                                                             '*',
                                                             'CASH',
                                                             'CASH',
                                                             '*',
                                                             '*',
                                                             '',
                                                             '',
                                                             '',
                                                             '',
                                                             '',
                                                             '');


                    securitySubType :=   Scbf_C_Get_Param_Data('CA01',
                                                             '02',
                                                              bankGroupCode,
                                                              '*',
                                                              '*',
                                                              '*',
                                                              'CASH',
                                                              'CASH',
                                                              '*',
                                                              '*',
                                                              '',
                                                              '',
                                                              '',
                                                              '',
                                                              '',
                                                              '');
                    securitySubTypeDescParam :=  'CASH';

                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                    v_usd_cmv_amt := 0;
                    BEGIN
                      IF(custExpCcy = 'USD') THEN
                         v_usd_cmv_amt := v_topup_amount;
                      ELSE
                         v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , custExpCcy
                                                , NVL(v_topup_amount,0)
                                              , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


                    BEGIN

                     runningSeq := runningSeq + 1;
                     custom_error_mesg := NULL;
                     is_valid_data := true;
                       if( v_topup_amount is NOT null AND v_topup_amount >0) then
                          custom_error_mesg := 'TOPUP AMOUNT AT FACILITY level Value is empty or ZERO.';
                          --is_valid_data := false;
                         -- custom_error_mesg :=  custom_error_mesg ||'TOPUP AMOUNT AT FACILITY level Value is empty or ZERO.';
                      -- end if;

-- JP 27-NOV START

                     BEGIN
                      SELECT LAS_LMT_ID into temp_ext_limit_id
                       FROM (
                          select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                          WHERE A.LAS_LE_ID=custLEID
                             and A.LAS_LMT_ID=sciLimitIdList(outerLimitIndex)
                         ) where rownum=1;
                           exit;
                        EXCEPTION WHEN OTHERS THEN
                              temp_ext_limit_id := nvl(temp_ext_limit_id, sciLimitIdList(outerLimitIndex));
                              is_valid_data := false;
                              custom_error_mesg := 'Security ID or Security Type or Security Sub Type is missing in SCI';
                         END;

-- JP 27-NOV END

                            /* JP 27-NOV - CHANGE AS PER NOV MID-MONTH END RESULTS
                               POPULATE TEMPORARY COLLATERAL  ID
                               SCI LIMIT ID TO BE POPULATED WITH SCI LIMIT ID */

                       cashMarginSeq := cashMarginSeq+1;
                       tempCollateralId := LPAD(cashMarginSeq,14,'0')||'CC';
                       tempParcelId := LPAD(cashMarginSeq,14,'0')||'PC';
                       IF ( is_valid_data  ) THEN

                            INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                                            BANK_GROUP_CODE
                                          , CTY_CODE
                                          , CUST_ID
                                          , SCI_LIMIT_ID
                                          , COLLATERAL_ID
                                          , DEAL_ID
                                          , PARCEL_ID
                                          , REC_ID
                                          , BUSINESS_DATE
                                          , SECURITY_VALUATION_DATE
                                          , SOURCE_SYSTEM_CODE
                                          , SECURITY_TYPE
                                          , SECURITY_SUBTYPE
                                          , COLLATERAL_APPROACH
                                          , PRODUCT_CODE
                                          , IS_SECURITY_PERFECTED
                                          , MATURITY_DATE
                                          , EFFECTIVE_DATE
                                          , STORAGE_CTY_CODE
                                          , BOOKING_LOC_CTY_CODE
                                          , CMV_CCY_CODE
                                          , CMV_CCY_AMT
                                          , TP_REF_ID
                                          , SCI_LEID
                                          , TP_SYSTEM_CODE
                                          , TXN_REF_ID
                                          , SECURITY_ID
                                          , CAGG_CATURED_TYPE
                                          , USD_CMV_AMT
                                          , FSV_PCT
                                          , FSV_VALUE
                                          , FSV_OVERRIDE_FLAG)
                                         VALUES(
                                            bankGroupCode
                                            , ctyCode
                                            , custId
                                            , temp_ext_limit_ID
                                            , tempCollateralId
                                            , ''
                                            , tempParcelId
                                            , recordID || LPAD(runningSeq,8,'0')
                                            , bussDate
                                            , bussDate
                                            , 'CCA'
                                            , securityType
                                            , securitySubType
                                            , 'F'
                                            , ''
                                            , 'Y'
                                            , ''
                                            , ''
                                            , ctyCode --''
                                            , ctyCode
                                            , custExpCcy
                                            , v_topup_amount
                                            , ''
                                            , custLEID
                                            , ''
                                            , ctyCode  -- obu chngs for records other than transactionlevel, txn refid to be stamped with ctycode
                                            , ''
                                            , 'CAGG_TOPUP_FACILITY_LEVEL'
                                            , v_usd_cmv_amt
                                            , fsvPct
                                            , fsvValue
                                            , fsvOverrideFlag);
                                   ELSE
                                         --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                                       IF ( (v_topup_amount is null or v_topup_amount <=0)) THEN
                                           GOTO SKIP_TXN_LOOP;
                                       END IF;

                                    INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR(
                                          BANK_GROUP_CODE
                                          , CTY_CODE
                                          , CUST_ID
                                          , SCI_LIMIT_ID
                                          , COLLATERAL_ID
                                          , DEAL_ID
                                          , PARCEL_ID
                                          , REC_ID
                                          , BUSINESS_DATE
                                          , SECURITY_VALUATION_DATE
                                          , SOURCE_SYSTEM_CODE
                                          , SECURITY_TYPE
                                          , SECURITY_SUBTYPE
                                          , COLLATERAL_APPROACH
                                          , PRODUCT_CODE
                                          , IS_SECURITY_PERFECTED
                                          , MATURITY_DATE
                                          , EFFECTIVE_DATE
                                          , STORAGE_CTY_CODE
                                          , BOOKING_LOC_CTY_CODE
                                          , CMV_CCY_CODE
                                          , CMV_CCY_AMT
                                          , TP_REF_ID
                                          , SCI_LEID
                                          , TP_SYSTEM_CODE
                                          , TXN_REF_ID
                                          , SECURITY_ID
                                          , ERROR_MESSAGE
                                          , SECURITYSUBTYPEDESC
                                          , CAGG_CATURED_TYPE
                                          , USD_CMV_AMT
                                          , FSV_PCT
                                          , FSV_VALUE
                                          , FSV_OVERRIDE_FLAG)
                                       VALUES(
                                          bankGroupCode
                                          , ctyCode
                                          , custId
                                          , temp_ext_limit_ID
                                          , tempCollateralId
                                          , ''
                                          , tempParcelId
                                          , recordID || LPAD(runningSeq,8,'0')
                                          , bussDate
                                          , bussDate
                                          , 'CCA'
                                          , NVL( securityTypeParam, securityType)
                                          , NVL( securitySubTypeParam, securitySubType)
                                          , 'F'
                                          , ''
                                          , 'Y'
                                          , ''
                                          , ''
                                          , ctyCode --''
                                          , ctyCode
                                          , custExpCcy
                                          , v_topup_amount
                                          , ''
                                          , custLEID
                                          , ''
                                          , ctyCode  -- obu chngs for records other than transactionlevel, txn refid to be stamped with ctycode
                                          , ''
                                          , custom_error_mesg
                                          , securitySubTypeDescParam
                                          , 'CAGG_TOPUP_FACILITY_LEVEL_ERR'
                                          , v_usd_cmv_amt
                                          , fsvPct
                                          , fsvValue
                                          , fsvOverrideFlag);
                                      <<SKIP_TXN_LOOP>>
                                         NULL;
                                    END IF;
                                  END IF;
                                 EXCEPTION
                                   WHEN OTHERS THEN
                                   dbms_output.put_line(recordID|| '**3025TOPUP TRANSACTION AT FACILITY LEVEL**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                                   NULL;
                                  END;
                 END LOOP;
               END LOOP;

              --**TO CAPTURE TOPUP TRANSACTION AT FACILITY LEVEL**--

             -- TOPUP TRANSACTION AT FACILITY LEVEL ** END --
             END IF;
             SCBP_P_UNLINKED_COLL_AGGR_FEED(bankGroupCode, ctyCode, custId, runningSeq);
             --COLLATERALS FOR INDIA BASED DP TRANSACTIONS
           --  IF ctyCode in ('GB') THEN
             --   v_txn_rec_id := NULL;
              --  SCBP_P_BBTL_COLL_AGGR_FEED(bankGroupCode, ctyCode, custId, null, null, null, runningSeq);
            -- END IF;


            -- IF ctyCode in ('IN') THEN
              --  v_txn_rec_id := NULL;
              --  SCBP_P_BBTL_COLL_AGGR_FEED(bankGroupCode, ctyCode, custId, null, null, null, runningSeq);
             -- ELSE
             --   v_txn_rec_id := NULL;
                SCBP_P_BBTL_COLL_AGGR_FEED_EXT(bankGroupCode, ctyCode, custId, null, null, null, runningSeq);
            -- END IF;
             --COCOACR_31012013
              IF ctyCode='CN' THEN
                  delete from scbt_t_ips_cagg_feed_mst where bank_group_code = bankGroupCode
                  and cty_code = ctyCode and cust_id = custId and
                  sci_limit_id in (select ext_limit_id from scbt_r_cust_product_limit
                  where bank_group_code = bankGroupCode and cty_code = ctyCode
                  and cust_id = custId
                  and limit_type_code = 'CAT2');
              END IF;

    COMMIT;

  END SCBP_P_COLL_AGGREGATOR_FEED;

PROCEDURE SCBP_P_UNLINKED_COLL_AGGR_FEED(bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    runningSeq    IN OUT NOCOPY NUMBER) IS
  TYPE CollateralIDType IS TABLE OF Scbt_t_Txn_Cr_Linkage_Mst.collateral_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelIDType IS TABLE OF SCBT_T_PARCEL_MST.parcel_id%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelExpiryDateType IS TABLE OF SCBT_T_PARCEL_MST.EXPIRY_DATE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelEffDateType IS TABLE OF SCBT_T_PARCEL_MST.FIRST_COLLATERAL_DATE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelStorageLocType IS TABLE OF SCBT_T_PARCEL_MST.STORAGE_CTY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCMVCcyCodeType IS TABLE OF SCBT_T_PARCEL_MST. CMV_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCMVCcyAmtType IS TABLE OF SCBT_T_PARCEL_MST.Cmv_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyCodeType IS TABLE OF SCBT_T_PARCEL_MST. GCV_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelGCVCcyAmtType IS TABLE OF SCBT_T_PARCEL_MST.GCV_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE CommodityIDType IS TABLE OF scbt_r_commodity_mst.commodity_id%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitInnerToIdList   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE dealIdList IS TABLE OF SCBT_T_DEAL_REGISTER_HDR_MST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE collCatList IS TABLE OF SCBT_T_COLLATERAL_REGISTER_MST.COLLATERAL_CATEGORY%TYPE INDEX BY PLS_INTEGER;
  TYPE collStatusCodeList IS TABLE OF SCBT_T_COLLATERAL_REGISTER_MST.COLLATERAL_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE collReceivableCcyList IS TABLE OF SCBT_T_COLLATERAL_REGISTER_MST.RECEIVABLE_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE collReceivableAmtList IS TABLE OF SCBT_T_COLLATERAL_REGISTER_MST.RECEIVABLE_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitIDList IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE INDEX BY PLS_INTEGER;
  TYPE outerLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.limit_id%TYPE INDEX BY PLS_INTEGER;
  TYPE LimitProductType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_PRODUCT_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE collEffectiveDateList IS TABLE OF SCBT_T_COLLATERAL_REGISTER_MST.ISSUE_DATE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelTypeCodeType IS TABLE OF SCBT_T_PARCEL_MST.parcel_type_code%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelCollStatusCodeType IS TABLE OF SCBT_T_PARCEL_MST.CR_STATUS_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE ParcelRecJ158CodeType IS TABLE OF SCBT_T_PARCEL_MST.RECJ158_CODE%TYPE INDEX BY PLS_INTEGER;

  custExpCcy                SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  bussDate                  SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
  recordID                  SCBT_T_IPS_CAGG_FEED_MST.REC_ID%TYPE;
  commodityType             SCBT_R_COMMODITY_MST.Commodity_Type_Code%TYPE;
  commodityCat              SCBT_R_COMMODITY_MST.Commodity_Cat_Code%TYPE;
  securityType              SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubType           SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  custLEID                  SCBT_R_PARTY_MST.Party_Id%TYPE;
  actualCMVAmount           NUMBER;
  bussDateAsString      VARCHAR2(10);
  ccyCodeForCMV             VARCHAR2(3);
  tempRecId             SCBT_T_IPS_CAGG_FEED_MST.Rec_Id%TYPE;
  collateralIDList          CollateralIDType;
  parcelIDList              ParcelIDType;
  commodityIDList           CommodityIDType;
  maturityDate              ParcelExpiryDateType;
  effectiveDate             ParcelEffDateType;
  collStorageLoc            ParcelStorageLocType;
  cmvCcyCode                ParcelCMVCcyCodeType;
  parcelTypeCode        ParcelTypeCodeType;
  cmvCcyAmt                 ParcelCMVCcyAmtType;
  gcvCcyCode                ParcelGCVCcyCodeType;
  gcvCcyAmt                 ParcelGCVCcyAmtType;

  innerToIdList             LimitInnerToIdList;
  unlinkDealIdList          dealIdList;
  unlinkCollCatList         collCatList;
  unlinkCollStatusCode      collStatusCodeList;
  unlinkCollReceivableCcy      collReceivableCcyList;
  unlinkCollReceivableAmt      collReceivableAmtList;
  sciLimitIdList   LimitIDList;
  outerLimitIdList outerLimitIdType;
  limitProdctList LimitProductType;
  prodCode          SCBT_R_CUST_PRODUCT_LIMIT.Limit_Product_Code%TYPE;
  security_id       SCBT_T_IPS_SCI_LMT_APPR_SEC.LAS_SEC_ID%TYPE;
  is_valid_data     boolean;
  custom_error_mesg SCBT_T_IPS_CAGG_FEED_MST_ERR.ERROR_MESSAGE%type;
  securityTypeParam      SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubTypeParam   SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  tempEffectiveDAte      SCBT_T_COLLATERAL_REGISTER_MST.Issue_Date%type;
  unlinkCollEffectiveDate      collEffectiveDateList;
  contingentProduct NUMBER;
  securitySubTypeDescParam varchar2(100);
  exceptnSecSubType NUMBER;
  collStatusCodeParcelList         ParcelCollStatusCodeType;
  ParcelRecJ158CodeList         ParcelRecJ158CodeType;
  v_usd_cmv_amt              SCBT_T_IPS_CAGG_FEED_MST.USD_CMV_AMT%TYPE;

  --Changes to report parent limit id if SCI LIMIT ID's is not there
  --TYPE extLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.ext_limit_id%TYPE INDEX BY PLS_INTEGER;
  --TYPE LimitInnerToIdList   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE prodLimitIdType IS TABLE OF SCBT_T_DEAL_REGISTER_HDR_MST.PROD_LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  --extLimitIdList          extLimitIdType;
  --innerToIdListForSCI     LimitInnerToIdList;
  prodLimitIdList              prodLimitIdType;

  temp_ext_limit_ID SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  --temp_parent_limit_id    SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  lookupLimitId SCBT_R_CUST_PRODUCT_LIMIT.Limit_Id%TYPE;


  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin

  fsvPctCust            SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctDefault         SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctBbc             SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPct                SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvValue              NUMBER;
  fsvOverrideFlag       SCBT_T_IPS_CAGG_FEED_MST.Fsv_Override_Flag%TYPE;
  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

  BEGIN

   -- Customer Exposure Currency
   BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;


    -- Business Date
    BEGIN
        SELECT BUSINESS_DATE INTO bussDate FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        NULL;
    END;



    -- Record ID Generation
    bussDateAsString := TO_CHAR(bussDate, 'DDMMYYYY');
    recordID := 'CO' || bussDateAsString;

    --To construct RECORD ID
    BEGIN
        SELECT MAX(REC_ID) INTO tempRecId FROM SCBT_T_IPS_CAGG_FEED_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND BUSINESS_DATE=bussDate;
               --AND CUST_ID = custId;
        runningSeq := to_number(substr(tempRecId, 11, length(tempRecId)));
    EXCEPTION
        WHEN OTHERS THEN
        runningSeq := 0;
    END;


    IF runningSeq IS NULL THEN
       runningSeq :=0;
    END IF;

    ---To generate Unlinked Collaterals

    -- LEID of Customer
    BEGIN
       SELECT EXT_SYSTEM_ID INTO custLEID FROM SCBT_R_PARTY_EXT_ID WHERE party_id=custId AND EXT_SYSTEM_CODE='SC';
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
           custLEID :='';
    END;


/*
    --To select OUTER LIMIT ID and LIMIT_ID
    select ext_limit_id, limit_id, limit_product_code BULK COLLECT INTO sciLimitIdList, outerLimitIdList, limitProdctList
           from SCBT_R_CUST_PRODUCT_LIMIT
         WHERE BANK_GROUP_CODE = bankGroupCode
           AND CTY_CODE = ctyCode
           AND CUST_ID = custID
           AND LIMIT_CAT_CODE='O'
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
           AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
           WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END;
           ;
*/
/* COMMENTED ABOVE STATEMENT TO CONSIDER LIMIT_CAT_CODE AS 'I' if transaction is happend
   on 07-FEB-2013
*/

    SELECT DISTINCT EXT_LIMIT_ID, LIMIT_ID, LIMIT_PRODUCT_CODE
         BULK COLLECT INTO sciLimitIdList, outerLimitIdList, limitProdctList
         FROM (
            select ext_limit_id, limit_id, limit_product_code, LIMIT_TYPE_CODE from SCBT_R_CUST_PRODUCT_LIMIT
              WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode AND CUST_ID = custId AND LIMIT_CAT_CODE='O'
              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                 AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                      UNION
                           SELECT p.ext_limit_id,p.limit_id,limit_product_code, LIMIT_TYPE_CODE
                                FROM scbt_t_collateral_register_mst c,scbt_r_cust_product_limit p,scbt_t_deal_register_hdr_mst r
                                WHERE BUSINESS_TYPE = 'FLC' AND limit_cat_code in ('CI','I') -- COCOA-1055
                                  AND R.prod_limit_id = p.limit_id AND p.cust_id = r.cust_id AND p.cust_id = c.cust_id AND c.deal_id = r.deal_id
                                  AND collateral_category <> 'REL' AND total_cmv_ccy_amt>0
                                  AND C.bank_group_code = p.bank_group_code
                                  AND C.bank_group_code = r.bank_group_code
                                  AND C.cty_code = p.cty_code
                                  AND C.cty_code = r.cty_code
                                  AND P.bank_group_code = bankGroupCode
                                  AND P.CTY_CODE = ctyCode
                                  AND P.CUST_ID=custId
                                  AND P.LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                              )
                              --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                              WHERE LIMIT_TYPE_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                                     WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                              AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
    --OUTER LIMIT_ID START

    ---****************************---
    ---*******UNLINKED LEVEL*******---
    ---****************************---

    FOR limitIndex IN 1..sciLimitIdList.COUNT LOOP


        --To select INNER_TO_ID
        SELECT LIMIT_ID BULK COLLECT INTO innerToIdList
            FROM SCBT_R_CUST_PRODUCT_LIMIT
            START WITH ext_limit_id=sciLimitIdList(limitIndex)
--        CONNECT BY NOCYCLE PRIOR  inner_to_id=ext_limit_id   --ext_limit_id = inner_to_id
          /* CHANGE TO BE TESTED FOR CN PROD ISSUE */
          /*28-NOV-2012*/
        CONNECT BY NOCYCLE PRIOR  inner_to_id=ext_limit_id --ext_limit_id = inner_to_id
            AND BANK_GROUP_CODE = bankGroupCode
            AND CTY_CODE = ctyCode
            AND CUST_ID = custID
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
            AND LIMIT_PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
               WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
            AND LIMIT_TYPE_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
               WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
               AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE');
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;

            prodCode := limitProdctList(limitIndex);

            BEGIN
                SELECT COUNT(1) INTO contingentProduct
                 from scbt_r_param_data where BANK_GROUP_CODE ='SCB'
                      and param_id='CA03'
                      and param_key_02 = 'CON'
                      and param_data_01 = prodCode;

                --   FROM SCBT_R_CAGG_FILTER_CRITERIA
                 --   WHERE FILTER_VALUE = prodCode
                 --   AND FILTER_TYPE='CONTINGENT';
           EXCEPTION
                WHEN NO_DATA_FOUND THEN
                contingentProduct := 0;
           END;

        --INNER_TO_ID START
        FOR innerLimitIndex IN 1..innerToIdList.COUNT LOOP


            --To select deal for the limitss
             BEGIN --unlinkDealId, unlinkCustId, unlinkProdLimitId

                 IF innerLimitIndex = 1 THEN
                     SELECT DEAL_ID, PROD_LIMIT_ID  BULK COLLECT INTO unlinkDealIdList, prodLimitIdList
                       FROM SCBT_T_DEAL_REGISTER_HDR_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                          AND CTY_CODE = ctyCode
                          AND CUST_ID = custId
                          AND PROD_LIMIT_ID in (innerToIdList(innerLimitIndex), outerLimitIdList(limitIndex));
                 ELSE
                     SELECT DEAL_ID, PROD_LIMIT_ID  BULK COLLECT INTO unlinkDealIdList, prodLimitIdList
                         FROM SCBT_T_DEAL_REGISTER_HDR_MST
                         WHERE BANK_GROUP_CODE = bankGroupCode
                            AND CTY_CODE = ctyCode
                            AND CUST_ID = custId
                            AND PROD_LIMIT_ID = innerToIdList(innerLimitIndex);
                 END IF;
                EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                   NULL;
             END;

             --DEAL_ID START
             FOR dealIndex IN 1..unlinkDealIdList.COUNT LOOP

                --To select collateral details
                SELECT COLLATERAL_ID, COLLATERAL_CATEGORY, COLLATERAL_STATUS_CODE,
                       RECEIVABLE_CCY_CODE, NVL(RECEIVABLE_CCY_AMT, 0)
                       , ISSUE_DATE
                       , nvl(TOTAL_GCV_CCY_AMT, 0)
                       , TOTAL_GCV_CCY_CODE
                      BULK COLLECT INTO collateralIDList, unlinkCollCatList, unlinkCollStatusCode,
                        unlinkCollReceivableCcy,  unlinkCollReceivableAmt
                       , unlinkCollEffectiveDate
                       , gcvCcyAmt
                       , gcvCcyCode
                    FROM  SCBT_T_COLLATERAL_REGISTER_MST
                        WHERE BANK_GROUP_CODE = bankGroupCode
                         AND CTY_CODE = ctyCode
                         AND COLLATERAL_CATEGORY != 'REL'
                         AND DEAL_ID = unlinkDealIdList(dealIndex);


                    lookupLimitId := prodLimitIdList(dealIndex);
                    --COLLATERAL_ID START
                    FOR collIndex IN 1..collateralIDList.COUNT LOOP

                        BEGIN

                             SELECT COMMODITY_ID, PARCEL_ID, EXPIRY_DATE, FIRST_COLLATERAL_DATE,
                                    STORAGE_CTY_CODE, CMV_CCY_CODE, NVL(CMV_CCY_AMT,0)
                                    , PARCEL_TYPE_CODE
                                    , CR_STATUS_CODE
                                    --, GCV_CCY_CODE, NVL(GCV_CCY_AMT,0)
                                    , RECJ158_CODE
                                BULK COLLECT INTO commodityIDList, parcelIDList, maturityDate,
                                    effectiveDate, collStorageLoc, cmvCcyCode, cmvCcyAmt
                                    , parcelTypeCode
                                    , collStatusCodeParcelList
                                    --, gcvCcyCode, gcvCcyAmt
                                    , ParcelRecJ158CodeList
                                FROM SCBT_T_PARCEL_MST WHERE BANK_GROUP_CODE = bankGroupCode
                                    AND COLLATERAL_ID = collateralIDList(collIndex)
                                    AND PARCEL_TYPE_CODE != 'MST'
                                    --AND NVL(NET_COMMODITY_QNTY,0) >= NVL(UTILISED_QNTY,0)
                                    AND (NVL(NET_COMMODITY_QNTY,0) - NVL(UTILISED_QNTY,0))>0
                                    AND COLLATERAL_TYPE_CODE NOT IN  (
                                      SELECT NVL(PARAM_KEY_01, ' ') FROM SCBT_R_PARAM_DATA
                                        WHERE PARAM_ID='CA03'
                                          AND  PARAM_DATA_01='N'
                                    );
                        EXCEPTION
                            WHEN OTHERS THEN
                            NULL;
                        END;

                        --COMMODITY LIST START
                        FOR commodityIndex IN 1..commodityIDList.COUNT LOOP
                               BEGIN
                                   SELECT COMMODITY_TYPE_CODE,COMMODITY_CAT_CODE INTO commodityType,commodityCat
                                          FROM SCBT_R_COMMODITY_MST WHERE BANK_GROUP_CODE = bankGroupCode  AND COMMODITY_ID = commodityIDList(commodityIndex);
                                 EXCEPTION
                                     WHEN OTHERS THEN
                                     NULL;
                                END;

                              --Calculation part is START
                              BEGIN

                                  tempEffectiveDate := effectiveDate(commodityIndex);

                                  actualCMVAmount := 0;
                                   -- Coverage Amount Calculation based on Coverage Percentage
                                  IF (unlinkCollCatList(collIndex) = 'PHY' ) THEN
                                      actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy, 1) * Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,cmvCcyAmt(commodityIndex))));
                                      ccyCodeForCMV := cmvCcyCode(commodityIndex);
                                  ELSIF (unlinkCollCatList(collIndex) = 'RCV' ) THEN
                                      actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy, 1) * Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,unlinkCollReceivableAmt(collIndex))));
                                      ccyCodeForCMV := unlinkCollReceivableCcy(collIndex);
                                      tempEffectiveDate := unlinkCollEffectiveDate(collIndex);
                                  ELSIF (unlinkCollCatList(collIndex) = 'CON' ) THEN
                                      actualCMVAmount := Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,(Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy, 1) * Scbf_Round_Amount(bankGroupCode,
                                                       custExpCcy,gcvCcyAmt(collIndex))));
                                      ccyCodeForCMV := gcvCcyCode(collIndex);
                                  END IF;


                                  --QC 870 Security Type and Security Sub Type should match with SCI securityType and Security Sub Type START
                                  securityTypeParam := null;
                                  securitySubTypeParam := null;
                                  securitySubTypeDescParam := null;
                                  securityTypeParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                                     '01',
                                                                                     bankGroupCode,
                                                                                     '*',
                                                                                     '*',
                                                                                     '*',
                                                                                     NVL(unlinkCollCatList(collIndex),''),
                                                                                     NVL(commodityType,''),
                                                                                     NVL(commodityCat,''),
                                                                                     NVL(collStatusCodeParcelList(commodityIndex), ''), --NVL(unlinkCollStatusCode(collIndex),''),
                                                                                     '',
                                                                                     '',
                                                                                     '',
                                                                                     '',
                                                                                     '',
                                                                                     '');

                                   securitySubTypeParam :=   Scbf_C_Get_Param_Data('CA01',
                                                                                         '02',
                                                                                         bankGroupCode,
                                                                                         '*',
                                                                                         '*',
                                                                                         '*',
                                                                                         NVL(unlinkCollCatList(collIndex),''),
                                                                                         NVL(commodityType,''),
                                                                                         NVL(commodityCat,''),
                                                                                         NVL(collStatusCodeParcelList(commodityIndex), ''), --NVL(unlinkCollStatusCode(collIndex),''),
                                                                                         '',
                                                                                         '',
                                                                                         '',
                                                                                         '',
                                                                                         '',
                                                                                         '');

                                    securitySubTypeDescParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                       '03',
                                                                       bankGroupCode,
                                                                       '*',
                                                                       '*',
                                                                       '*',
                                                                       NVL(unlinkCollCatList(collIndex),''),
                                                                       NVL(commodityType,''),
                                                                       NVL(commodityCat,''),
                                                                       NVL(collStatusCodeParcelList(commodityIndex), ''), --NVL(unlinkCollStatusCode(collIndex),''),
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '');


                                  IF (unlinkCollCatList(collIndex) = 'RCV' ) THEN
                                     securityTypeParam := 'AB';
                                     /*02-NOV-2012 Changes for RECJ158_CODE for receivable collateral*/
                                     securitySubTypeParam := nvl(ParcelRecJ158CodeList(commodityIndex), '');
                                     --securitySubTypeParam :='AB104';

                                     securitySubTypeDescParam :=  Scbf_C_Get_Param_Data('CA01',
                                                                       '03',
                                                                       bankGroupCode,
                                                                       '*',
                                                                       '*',
                                                                       '*',
                                                                       'RECV',
                                                                       securitySubTypeParam, --'Receivables Assigned - Specific Inv',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '',
                                                                       '');

                                      securitySubTypeDescParam := NVL(securitySubTypeDescParam, 'RECEIVABLE');
                                  END IF;

                                  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                                    fsvOverrideFlag := 'N';
                                    fsvPctCust      := null;
                                    fsvPctDefault   := null;
                                    fsvPctBbc       := null;
                                    fsvPct          := null;
                                    fsvValue        := null;

                                    BEGIN
                                     SELECT FSV_PCT INTO fsvPctCust FROM SCBT_R_CUST_PROD_FSV_MST
                                       WHERE BANK_GROUP_CODE=bankgroupcode
                                       AND CTY_CODE = ctycode
                                       AND COLL_LOCATION_CODE= ctycode
                                       AND CUST_ID = custId
                                       AND REGEXP_SUBSTR ( ',' || PROD_LIMIT_IDS|| ',' , ',' || innerToIdList(innerLimitIndex)  || ',', 1, 1 ) =( ',' || innerToIdList(innerLimitIndex) || ',')
                                       AND J158_CODE = securitySubTypeParam;
                                    EXCEPTION
                                          WHEN NO_DATA_FOUND THEN
                                                NULL;
                                     END;


                                     BEGIN
                                          SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                                          WHERE BANK_GROUP_CODE=bankgroupcode
                                          AND J158_CTY_CODE = ctycode
                                          AND J158_CODE = securitySubTypeParam;
                                     EXCEPTION
                                          WHEN NO_DATA_FOUND THEN
                                                NULL;
                                     END;

                                     -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                                     IF(fsvPctCust is NULL) THEN
                                        fsvValue        := actualCMVAmount;
                                     END IF;

                                     -- always defaulting fsv pct from maintenance if available
                                     IF(fsvPctDefault IS NOT NULL) THEN
                                        fsvPct := fsvPctDefault;
                                     END IF;

                                     -- check whether overridden in customer maintenance and this case is applicable for non bbc transactions
                                     IF(fsvPctCust IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                                       IF(fsvPctCust <> fsvPctDefault) THEN
                                          fsvOverrideFlag := 'Y';
                                          fsvPct := fsvPctCust;
                                       END IF;
                                     END IF;

                                     IF(fsvPct IS NOT NULL) THEN
                                     BEGIN
                                       fsvValue := actualCMVAmount * fsvPct / 100;
                                     EXCEPTION
                                       WHEN OTHERS THEN
                                        fsvValue := actualCMVAmount;
                                     END;
                                     END IF;
                                  -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end
                                  -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
                                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
                                  security_id :=null;
                                  securityType := null;
                                  securitySubType := null;
                                  exceptnSecSubType := 0;


                                  /*
                                  --Below old code has been commented to report parent limit id if sci limit id's is not there.


                                  BEGIN
                                    select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                                    into security_id, securityType, securitySubType
                                    FROM (
                                         select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                                         from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                         WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=sciLimitIdList(limitIndex)
                                         AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                         AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                         ) where rownum=1;
                                  EXCEPTION
                                     WHEN OTHERS THEN
                                     NULL;
                                  END;
                                  */

---START
 -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,lookupLimitId,custLEID);
              /*
                        BEGIN
                             SELECT ext_limit_id, inner_to_id
                             BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                             FROM SCBT_R_CUST_PRODUCT_LIMIT
                             START WITH limit_id = lookupLimitId
                             CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id   --ext_limit_id=inner_to_id
                             AND BANK_GROUP_CODE = bankGroupCode
                             AND CTY_CODE = ctyCode
                             AND CUST_ID = custId
                             order by level asc;
                         EXCEPTION
                             WHEN OTHERS THEN
                             NULL;
                         END;


 --To report parent id if SCI LIMIT ID is not there
                         temp_parent_limit_id := null;
                         temp_ext_limit_id := null;
                         FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP

                            BEGIN
                               SELECT LAS_LMT_ID into temp_ext_limit_id
                               FROM (
                                  select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                  WHERE A.LAS_LE_ID=custLEID
                                     and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                    --28-NOV-2012
                                     --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                 ) where rownum=1;
                                   exit;

                                EXCEPTION WHEN OTHERS THEN
                                   BEGIN
                                       SELECT LAS_LMT_ID into temp_ext_limit_id
                                       FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                            WHERE A.LAS_LE_ID=custLEID
                                            and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                            --28-NOV-2012
                                            --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                                            ) where rownum=1;
                                       exit;
                                   EXCEPTION  WHEN OTHERS THEN
                                      temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                                      NULL;
                                   END;
                            END;


                         END LOOP;
     */
                BEGIN
                   select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                     into security_id, securityType, securitySubType
                     FROM (
                         select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                         from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                            WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                                AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                                AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                                AND UPDATE_STATUS_IND <> 'D'
                     ) where rownum=1;
                   EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                       security_id :=null;
                       securityType := null;
                       securitySubType :=null;
                END;
---END
                                  -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
                                  v_usd_cmv_amt := 0;
                                  BEGIN
                                    IF(ccyCodeForCMV = 'USD') THEN
                                       v_usd_cmv_amt := actualCMVAmount;
                                    ELSE
                                       v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                                            bankGroupCode
                                                            , ctyCode
                                                            , ccyCodeForCMV
                                                              , NVL(actualCMVAmount,0)
                                                            , 'USD','N');
                                    END IF;
                                  EXCEPTION WHEN OTHERS THEN
                                     v_usd_cmv_amt := 0;
                                  END;
                                  -- To calculate USD_CMV_AMT 25-FEB-2013 -- END



                                  --EXCEPTIONAL SECURITY SUB TYPE
                                  BEGIN
                                    select count(CODE_VALUE_1)
                                           INTO exceptnSecSubType
                                         from SCBT_R_MAP_INFO A
                                         WHERE MAP_ID='CAGG_EXCPTN_LIST'
                                           AND CODE_VALUE_1 = securitySubTypeParam;
                                  EXCEPTION
                                     WHEN OTHERS THEN
                                        exceptnSecSubType := 0;
                                  END;
                                  -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE END

                                  --QC 870 Security Type and Security Sub Type should match with SCI securityType and Security Sub Type END

                                  is_valid_data :=true;
                                  runningSeq := runningSeq + 1;
                                  custom_error_mesg := NULL;
                                  -- Exception handling
                                  if ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) then
                                    is_valid_data := false;

                                    custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
                                  end if;
                                  if ( sciLimitIdList(limitIndex) is null  or length(sciLimitIdList(limitIndex)) < 1 ) then
                                      is_valid_data := false;
                                           custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                                  elsif ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) then
                                      is_valid_data := false;
                                           custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
                                  end if;

                                  if (  (upper(securityTypeParam) !=  upper(securityType) or upper(securitySubTypeParam) != upper(securitySubType))) then
                                      is_valid_data := false;

                                    custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
                                  end if;
                                  if (tempEffectiveDate IS NULL OR length(tempEffectiveDate)<1 ) then
                                    is_valid_data := false;

                                    custom_error_mesg :=  custom_error_mesg ||'Effective Date is empty.';
                                  --elsif (collStorageLoc(commodityIndex) IS NULL OR length(collStorageLoc(commodityIndex))<1 ) then
                                  end if;
                                  if ( ctyCode IS NULL OR length(ctyCode)<1 ) then
                                    is_valid_data := false;

                                    custom_error_mesg :=  custom_error_mesg ||'Storage Location is empty.';
                                  end if;
                                  if (collateralIDList(collIndex) is null or length(collateralIDList(collIndex)) <1 ) then
                                    is_valid_data :=false;

                                    custom_error_mesg :=  custom_error_mesg ||'Collateral ID is empty.';
                                  end if;
                                  if (parcelIDList(commodityIndex) is null or length(parcelIDList(commodityIndex)) <1 ) then
                                    is_valid_data :=false;

                                    custom_error_mesg :=  custom_error_mesg ||'Parcel ID is empty.';
                                  end if;
                                  if ( actualCMVAmount is null or actualCMVAmount <=0) then
                                    is_valid_data := false;

                                    custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
                                  end if;
                                  if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                                     is_valid_data := false;
        	       	                   custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
                                  end if;
                                  if (parcelTypeCode(commodityIndex)='CON' and contingentProduct <=0) then
                                        is_valid_data := false;

                                        custom_error_mesg :=  custom_error_mesg ||'Product code should be LCORS, LCORU, LCBBS, LCBBU and LCRC for Contingent Collateral.';
                                  end if;

                                  if ( is_valid_data ) then
                                       INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                                            BANK_GROUP_CODE
                                            , CTY_CODE
                                            , CUST_ID
                                            , COLLATERAL_ID
                                            , DEAL_ID
                                            , PARCEL_ID
                                            , REC_ID
                                            , BUSINESS_DATE
                                            , SECURITY_VALUATION_DATE
                                            , SOURCE_SYSTEM_CODE
                                            , SECURITY_TYPE
                                            , SECURITY_SUBTYPE
                                            , COLLATERAL_APPROACH
                                            , PRODUCT_CODE
                                            , IS_SECURITY_PERFECTED
                                            , MATURITY_DATE
                                            , EFFECTIVE_DATE
                                            , SECURITY_PERFECTION_DATE
                                            , STORAGE_CTY_CODE
                                            , BOOKING_LOC_CTY_CODE
                                            , CMV_CCY_CODE
                                            , CMV_CCY_AMT
                                            --, TP_REF_ID
                                            , SCI_LEID
                                            , TP_SYSTEM_CODE
                                            , TXN_REF_ID
                                            , SCI_LIMIT_ID
                                            , SECURITY_ID
                                            , CAGG_CATURED_TYPE
                                            , USD_CMV_AMT
                                            , FSV_PCT
                                            , FSV_VALUE
                                            , FSV_OVERRIDE_FLAG)
                                        VALUES(
                                            bankGroupCode
                                            , ctyCode
                                            , custId
                                            , collateralIDList(collIndex)
                                            , unlinkDealIdList(dealIndex)
                                            , parcelIDList(commodityIndex)
                                            , recordID || LPAD(runningSeq,8,'0')
                                            , bussDate
                                            , bussDate
                                            , 'CCA'
                                            , securityType
                                            , securitySubType
                                            , 'F'
                                            , prodCode
                                            , 'Y'
                                            , maturityDate(commodityIndex)
                                            , effectiveDate(commodityIndex)
                                            , effectiveDate(commodityIndex)
                                            , NVL(collStorageLoc(commodityIndex),ctyCode) -- sujeesh
                                            , ctyCode
                                            , ccyCodeForCMV
                                            , actualCMVAmount
                                            --, tpRefID
                                            , custLEID
                                            ,'SCI'
                                            , ctyCode -- putting cty code instead of txn ref id for booking location changes
                                            , temp_ext_limit_id--sciLimitIdList(limitIndex)
                                            , security_id
                                            , 'CAGG_UNLINKED_COLL'
                                            , v_usd_cmv_amt
                                            , fsvPct
                                            , fsvValue
                                            , fsvOverrideFlag);
                                  else
                                       --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                                         IF ( (actualCMVAmount is null or actualCMVAmount <=0)) THEN
                                            GOTO SKIP_TXN_LOOP;
                                         END IF;

                                         INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR (
                                            BANK_GROUP_CODE
                                            , CTY_CODE
                                            , CUST_ID
                                            , COLLATERAL_ID
                                            , DEAL_ID
                                            , PARCEL_ID
                                            , REC_ID
                                            , BUSINESS_DATE
                                            , SECURITY_VALUATION_DATE
                                            , SOURCE_SYSTEM_CODE
                                            , SECURITY_TYPE
                                            , SECURITY_SUBTYPE
                                            , COLLATERAL_APPROACH
                                            , PRODUCT_CODE
                                            , IS_SECURITY_PERFECTED
                                            , MATURITY_DATE
                                            , EFFECTIVE_DATE
                                            , SECURITY_PERFECTION_DATE
                                            , STORAGE_CTY_CODE
                                            , BOOKING_LOC_CTY_CODE
                                            , CMV_CCY_CODE
                                            , CMV_CCY_AMT
                                            --, TP_REF_ID
                                            , SCI_LEID
                                            , TP_SYSTEM_CODE
                                            , TXN_REF_ID
                                            , SCI_LIMIT_ID
                                            , SECURITY_ID
                                            , ERROR_MESSAGE
                                            , securitySubTypeDesc
                                            , CAGG_CATURED_TYPE
                                            , USD_CMV_AMT
                                            , FSV_PCT
                                            , FSV_VALUE
                                            , FSV_OVERRIDE_FLAG)
                                        VALUES(
                                            bankGroupCode
                                            , ctyCode
                                            , custId
                                            , collateralIDList(collIndex)
                                            , unlinkDealIdList(dealIndex)
                                            , parcelIDList(commodityIndex)
                                            , recordID || LPAD(runningSeq,8,'0')
                                            , bussDate
                                            , bussDate
                                            , 'CCA'
                                            , NVL(securityTypeParam, securityType)  --securityType
                                            , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                                            , 'F'
                                            , prodCode
                                            , 'Y'
                                            , maturityDate(commodityIndex)
                                            , effectiveDate(commodityIndex)
                                            , effectiveDate(commodityIndex)
                                            , collStorageLoc(commodityIndex)
                                            , ctyCode
                                            , ccyCodeForCMV
                                            , actualCMVAmount
                                            --, tpRefID
                                            , custLEID
                                            , 'SCI'
                                            , ctyCode -- putting cty code instead of txn ref id for booking location changes
                                            , temp_ext_limit_id  --sciLimitIdList(limitIndex)
                                            , security_id
                                            , custom_error_mesg
                                            , securitySubTypeDescParam
                                            , 'CAGG_UNLINKED_COLL_ERR'
                                            , v_usd_cmv_amt
                                            , fsvPct
                                            , fsvValue
                                            , fsvOverrideFlag);
                                        <<SKIP_TXN_LOOP>>
                                            NULL;
                                      end if;

                                         commit;
                             EXCEPTION
                                 WHEN OTHERS THEN
                                  --dbms_output.put_line(recordID|| '**UNLINKED**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                                    NULL;
                             END;
                             --Calculation part is END
                        END LOOP;
                        --COMMODITY LIST END

                    END LOOP;
                    --COLLATERAL_ID END

                END LOOP;
                --DEAL_ID END

               END LOOP;
               --INNER_TO_ID END



          END LOOP;
          --OUTER LIMIT_ID END
          ---********** New Logic from outer to inner END


    COMMIT;

  END SCBP_P_UNLINKED_COLL_AGGR_FEED;


  PROCEDURE SCBP_P_BBTL_COLL_AGGR_FEED(bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    coBorrowerId  IN VARCHAR2,
                                    limitId       IN VARCHAR2,
                                    txnRecId      IN VARCHAR2,
                                    runningSeq    IN OUT NOCOPY NUMBER) IS

  TYPE txnProdLimitIdType IS TABLE OF SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE txnProdCodeType IS TABLE OF SCBT_T_TXN_MST.PRODUCT_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE txnCcyCodeType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
  TYPE txnCcyAmtType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE txnCcyUtilAmtType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Util_Amt%TYPE INDEX BY PLS_INTEGER;
  TYPE txnShortFallType IS TABLE OF SCBT_T_TXN_MST.Shortfall_Offset_Type%TYPE INDEX BY PLS_INTEGER;
  --TYPE extLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.ext_limit_id%TYPE INDEX BY PLS_INTEGER;
  --TYPE LimitInnerToIdList   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE INDEX BY PLS_INTEGER;
  --temp_parent_limit_id    SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  temp_ext_limit_ID SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  TYPE txnStepCodeType IS TABLE OF SCBT_T_TXN_MST.TXN_STEP_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE txnRecIdType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE txnRefIdType IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE tpRefIdType  IS TABLE OF SCBT_T_TXN_MST.TP_REF_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE tpSysCdType  IS TABLE OF SCBT_T_TXN_MST.TP_SYSTEM_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE dealIdType   IS TABLE OF SCBT_T_TXN_MST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;


  custExpCcy                SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  bussDate                  SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
  recordID                  SCBT_T_IPS_CAGG_FEED_MST.REC_ID%TYPE;
  securityType              SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubType           SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  custLEID                  SCBT_R_PARTY_MST.Party_Id%TYPE;
  actualCMVAmount           NUMBER;
  bussDateAsString      VARCHAR2(10);
  tempRecId             SCBT_T_IPS_CAGG_FEED_MST.Rec_Id%TYPE;

  prodCode          SCBT_R_CUST_PRODUCT_LIMIT.Limit_Product_Code%TYPE;
  security_id       SCBT_T_IPS_SCI_LMT_APPR_SEC.LAS_SEC_ID%TYPE;
  is_valid_data     boolean;
  custom_error_mesg SCBT_T_IPS_CAGG_FEED_MST_ERR.ERROR_MESSAGE%type;
  securityTypeParam      SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubTypeParam   SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;

  contingentProduct NUMBER;
  securitySubTypeDescParam varchar2(100);
  exceptnSecSubType NUMBER;
  isCTAExpired scbt_r_param_data.param_data_01%TYPE;
  isExpiredColl NUMBER;
  v_co_borrower_id SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;


  --For Borrowing Base UK 
  shortfall_offset_type SCBT_T_TXN_MST.SHORTFALL_OFFSET_TYPE%TYPE;
  bbtl_certificate_id SCBT_R_BBC_DTLS_MST.BBC_ID%TYPE;
  bbtl_certificate_date SCBT_R_BBC_DTLS_MST.CERTIFICATE_DATE%TYPE;
  bbtl_extended_expiry_date SCBT_R_BBC_DTLS_MST.EXTENDED_EXPIRY_DATE%TYPE;
  bbtl_security_type_param VARCHAR2(10);
  bbtl_security_sub_type_param SCBT_R_BBC_GENERAL_DTLS_MST.BBC_J158_CODE%TYPE;
  bbtl_appl_dp_ccy_code SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_CODE%TYPE;
  bbtl_appl_dp_ccy_amt SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_AMT%TYPE;
  bbtl_facility_group_id SCBT_R_BBC_GENERAL_DTLS_MST.FACILITY_GROUP_ID%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_is_syndicate_coll         NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  --bbtl_deal_step_id           SCBT_T_TXN_MST.LATEST_DEAL_STEP_ID%TYPE;
  v_txn_outstanding_amt       SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_faclty_outstanding_amt    SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  txnProdLimitIdList          txnProdLimitIdType;
  txnStepCodeList              txnStepCodeType;
  txnProdCodeList             txnProdCodeType;
  txnCcyCodeList              txnCcyCodeType;
  txnCcyAmtList               txnCcyAmtType;
  txnCcyUtilAmtList           txnCcyUtilAmtType;
  txnShortFallList            txnShortFallType;
  --extLimitIdList              extLimitIdType;
  --innerToIdListForSCI         LimitInnerToIdList;
  v_prev_prod_limit_id        SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE;
  txnRecIdList                txnRecIdType;
  txnRefIdList                txnRefIdType;
  tpRefIdList                 tpRefIdType;
  tpSysCodeList               tpSysCdType;
  dealIdList                  dealIdType;
  v_tp_sys_code               SCBT_T_TXN_MST.TP_SYSTEM_CODE%TYPE;
  V_COUNT                     NUMBER;
  bbc_run_seq                 NUMBER;
  v_usd_cmv_amt               SCBT_T_IPS_CAGG_FEED_MST.USD_CMV_AMT%TYPE;

  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin

  fsvPctCust            SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctDefault         SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctBbc             SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPct                SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvValue              NUMBER;
  fsvOverrideFlag       SCBT_T_IPS_CAGG_FEED_MST.Fsv_Override_Flag%TYPE;
  extended_expiry_date SCBT_R_BBC_DTLS_MST.EXTENDED_EXPIRY_DATE%TYPE;
  grace_period SCBT_R_BBC_DTLS_MST.GRACE_PERIOD%TYPE;
  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

  BEGIN

   -- Customer Exposure Currency
   BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;


    -- Business Date
    BEGIN
        SELECT BUSINESS_DATE INTO bussDate FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    -- LEID of Customer
    BEGIN
       SELECT EXT_SYSTEM_ID INTO custLEID FROM SCBT_R_PARTY_EXT_ID WHERE party_id=custId AND EXT_SYSTEM_CODE='SC';
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
           custLEID :='';
    END;

    -- Record ID Generation
    bussDateAsString := TO_CHAR(bussDate, 'DDMMYYYY');
    recordID := 'CO' || bussDateAsString;
    bbc_run_seq := 0;

    --To construct RECORD ID
    BEGIN
        SELECT MAX(REC_ID) INTO tempRecId FROM SCBT_T_IPS_CAGG_FEED_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND BUSINESS_DATE=bussDate;
               --AND CUST_ID = custId;
        runningSeq := to_number(substr(tempRecId, 11, length(tempRecId)));
    EXCEPTION
        WHEN OTHERS THEN
        runningSeq := 0;
    END;


    IF runningSeq IS NULL THEN
       runningSeq :=0;
    END IF;

    ---To generate Facility level Collaterals

     /* changed TXN_CCY_AMT to TXN_CCY_NET_AMT on 25-SEP-2012 */
/*
    BEGIN
       SELECT PROD_LIMIT_ID, PRODUCT_CODE, TXN_CCY_CODE, nvl(TXN_CCY_NET_AMT, 0), nvl(TXN_CCY_UTIL_AMT, 0), nvl(SHORTFALL_OFFSET_TYPE, ' ')
          , TXN_STEP_CODE
          BULK COLLECT INTO
              txnProdLimitIdList, txnProdCodeList, txnCcyCodeList, txnCcyAmtList, txnCcyUtilAmtList, txnShortFallList
          , txnStepCodeList
         FROM SCBT_T_TXN_MST
       where BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND CUST_ID = custId
         AND SHORTFALL_OFFSET_TYPE = 'CBB'
         ORDER BY PROD_LIMIT_ID;
    EXCEPTION
       WHEN OTHERS THEN
         NULL;
    END;
*/

/* CONSIDER only UTILISED LIMIT FOR OUTER LIMIT IDs
 for FACILITY OUTSTANDING AMOUNT
*/
    IF coBorrowerId IS NULL THEN

        BEGIN
         /* changed TXN_CCY_AMT to TXN_CCY_NET_AMT on 25-SEP-2012 */
           SELECT PROD_LIMIT_ID, PRODUCT_CODE, TXN_CCY_CODE, nvl(TXN_CCY_NET_AMT, 0), nvl(TXN_CCY_UTIL_AMT, 0), nvl(SHORTFALL_OFFSET_TYPE, ' ')
              , TXN_STEP_CODE, TXN_REC_ID, TXN_REF_ID, TP_REF_ID, TP_SYSTEM_CODE, DEAL_ID
              BULK COLLECT INTO
                  txnProdLimitIdList, txnProdCodeList, txnCcyCodeList, txnCcyAmtList, txnCcyUtilAmtList, txnShortFallList
              , txnStepCodeList,  txnRecIdList, txnRefIdList, tpRefIdList, tpSysCodeList, dealIdList
             FROM SCBT_T_TXN_MST
           where BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND CUST_ID = custId
             AND SHORTFALL_OFFSET_TYPE = 'CBB'
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
             AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
             WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
             AND PROD_LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
                 WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
                  AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                   WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                 AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
             ORDER BY PROD_LIMIT_ID;
        EXCEPTION
           WHEN OTHERS THEN
             NULL;
        END;

        BEGIN
           SELECT
           sum (CUST_EXP_UTIL) INTO v_faclty_outstanding_amt
           from (
            SELECT DISTINCT limit_id, LIMIT_CCY_CODE,
             Scbf_Tls_Exch_Rate(
                PL.BANK_GROUP_CODE
                , PL.CTY_CODE
                , LIMIT_CCY_CODE
                , NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                   TM.BANK_GROUP_CODE
                   , TM.CTY_CODE
                   , TM.CUST_ID
                   , TM.PROD_LIMIT_ID
                   , PL.LIMIT_CCY_CODE
                   , TM.PRODUCT_CODE)
                   , 0)
                   , custExpCcy
                   , 'Y'
                 )  AS CUST_EXP_UTIL

           FROM SCBT_T_PROD_LIMIT_UTIL PL
             , SCBT_T_TXN_MST TM
        WHERE PL.BANK_GROUP_CODE = TM.BANK_GROUP_CODE
          AND PL.CTY_CODE=TM.CTY_CODE
          AND TM.SHORTFALL_OFFSET_TYPE = 'CBB'
          AND PL.LIMIT_ID = TM.PROD_LIMIT_ID
          AND PL.BANK_GROUP_CODE = bankGroupCode
          AND PL.CTY_CODE = ctyCode
          AND TM.CUST_ID = custId
          AND PROD_LIMIT_ID NOT IN (
                 SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND CO_BORROWER_ID IS NOT NULL
                )
          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                  AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
           AND PROD_LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
               WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
                AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                 WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
               AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
           --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
          );
        EXCEPTION
           WHEN OTHERS THEN
             v_faclty_outstanding_amt := 0;
        END;
    ELSE

        BEGIN
         /* changed TXN_CCY_AMT to TXN_CCY_NET_AMT on 25-SEP-2012 */
           SELECT PROD_LIMIT_ID, PRODUCT_CODE, TXN_CCY_CODE, nvl(TXN_CCY_NET_AMT, 0), nvl(TXN_CCY_UTIL_AMT, 0), nvl(SHORTFALL_OFFSET_TYPE, ' ')
              , TXN_STEP_CODE, TXN_REC_ID, TXN_REF_ID, TP_REF_ID, TP_SYSTEM_CODE, DEAL_ID
              BULK COLLECT INTO
                  txnProdLimitIdList, txnProdCodeList, txnCcyCodeList, txnCcyAmtList, txnCcyUtilAmtList, txnShortFallList
              , txnStepCodeList, txnRecIdList, txnRefIdList, tpRefIdList, tpSysCodeList, dealIdList
             FROM SCBT_T_TXN_MST
           where BANK_GROUP_CODE = bankGroupCode
             AND CTY_CODE = ctyCode
             AND CUST_ID = custId
             AND SHORTFALL_OFFSET_TYPE = 'CBB'
             AND PROD_LIMIT_ID = limitId
             AND TXN_REC_ID = txnRecId
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
             AND PRODUCT_CODE not in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
             WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
             AND PROD_LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
                 WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
                  AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                   WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                   AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
             ORDER BY PROD_LIMIT_ID;
        EXCEPTION
           WHEN OTHERS THEN
             NULL;
        END;

        BEGIN
           SELECT
           sum (CUST_EXP_UTIL) INTO v_faclty_outstanding_amt
           from (
            SELECT DISTINCT limit_id, LIMIT_CCY_CODE,
             Scbf_Tls_Exch_Rate(
                PL.BANK_GROUP_CODE
                , PL.CTY_CODE
                , LIMIT_CCY_CODE
                , NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                   TM.BANK_GROUP_CODE
                   , TM.CTY_CODE
                   , TM.CUST_ID
                   , TM.PROD_LIMIT_ID
                   , PL.LIMIT_CCY_CODE
                   , TM.PRODUCT_CODE)
                   , 0)
                   , custExpCcy
                   , 'Y'
                 )  AS CUST_EXP_UTIL
           FROM SCBT_T_PROD_LIMIT_UTIL PL
             , SCBT_T_TXN_MST TM
        WHERE PL.BANK_GROUP_CODE = TM.BANK_GROUP_CODE
          AND PL.CTY_CODE=TM.CTY_CODE
          AND TM.SHORTFALL_OFFSET_TYPE = 'CBB'
          AND PL.LIMIT_ID = TM.PROD_LIMIT_ID
          AND PL.BANK_GROUP_CODE = bankGroupCode
          AND PL.CTY_CODE = ctyCode
          AND TM.CUST_ID = custId
          AND limit_id IN (
             SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND CO_BORROWER_ID = coBorrowerId
            )
          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
          AND limit_id NOT IN (
             SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND LIMIT_PRODUCT_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
            )
          --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
             AND LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
                 WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
                  AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                   WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                   AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;

          );
        EXCEPTION
           WHEN OTHERS THEN
             v_faclty_outstanding_amt := 0;
        END;
    END IF;



    IF txnProdLimitIdList IS NOT NULL THEN

      FOR txnLimitIDIndex IN 1..txnProdLimitIdList.COUNT LOOP


           IF txnStepCodeList(txnLimitIDIndex) IS NOT NULL and txnStepCodeList(txnLimitIDIndex) = 'ODT' THEN
              --For OD Transaction
              v_txn_outstanding_amt :=0;
              IF v_prev_prod_limit_id IS NULL OR v_prev_prod_limit_id != txnProdLimitIdList(txnLimitIDIndex) THEN
                 v_prev_prod_limit_id := txnProdLimitIdList(txnLimitIDIndex);
                 BEGIN
                    SELECT  Scbf_Tls_Exch_Rate(
                               BANK_GROUP_CODE
                               , CTY_CODE
                               , LIMIT_CCY_CODE
                               , NVL(LIMIT_CCY_UTILISED_AMT,0)
                               , custExpCcy
                               , 'Y')
                           INTO  v_txn_outstanding_amt
                       from SCBT_T_PROD_LIMIT_UTIL
                       where BANK_GROUP_CODE = bankGroupCode
                          AND CTY_CODE = ctyCode
                          AND LIMIT_ID =  txnProdLimitIdList(txnLimitIDIndex);
                 EXCEPTION WHEN OTHERS THEN
                   v_txn_outstanding_amt :=0;
                 END;
                ELSE
                 v_txn_outstanding_amt := 0;
              END IF;

           ELSE
             --To calculate Outstanding Amount
             v_txn_outstanding_amt :=
                     Scbf_Tls_Exch_Rate(
                         bankGroupCode
                         , ctyCode
                         , txnCcyCodeList(txnLimitIDIndex)
                         , txnCcyAmtList(txnLimitIDIndex) - txnCcyUtilAmtList(txnLimitIDIndex)
                         , custExpCcy
                         , 'Y');
          END IF;
          --OUTER LIMIT_ID START

          ---****************************---
          ---*******BBTL LEVEL*******---
          ---****************************---

         --To get co_borrower_id
          BEGIN
              SELECT CO_BORROWER_ID INTO v_co_borrower_id FROM SCBT_R_CUST_PRODUCT_LIMIT
                     WHERE BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID=custId
                     AND LIMIT_ID=txnProdLimitIdList(txnLimitIDIndex)
                     AND SHORTFALL_OFFSET='CBB';
                     --AND CUST_ID = custId;
          EXCEPTION
              WHEN OTHERS THEN
              v_co_borrower_id := NULL;
          END;


         IF v_co_borrower_id IS NOT NULL  AND (v_txn_rec_id IS NULL OR v_txn_rec_id != txnRecIdList(txnLimitIDIndex)) THEN
            v_txn_rec_id := txnRecIdList(txnLimitIDIndex);
            SCBP_P_BBTL_COLL_AGGR_FEED(bankGroupCode, ctyCode, custId, v_co_borrower_id, txnProdLimitIdList(txnLimitIDIndex), v_txn_rec_id, runningSeq);
            GOTO SKIP_CO_BORROWER_TXN_LOOP;
         END IF;

         IF v_txn_outstanding_amt > 0 THEN

         --To get BBTL CERTIFICATE ID START
               bbtl_certificate_id := null;
               bbtl_facility_group_id := null;
               IF txnShortFallList(txnLimitIDIndex) IS NOT NULL AND txnShortFallList(txnLimitIDIndex) in ('CBB', 'GBB') THEN
                 BEGIN
                   SELECT bbc_id, 'CF', bbc_j158_code, facility_group_id
                      INTO bbtl_certificate_id, bbtl_security_type_param
                        , bbtl_security_sub_type_param, bbtl_facility_group_id
                       from SCBT_R_BBC_GENERAL_DTLS_MST
                      WHERE BANK_GROUP_CODE = bankGroupCode
                         AND CTY_CODE = ctyCode
                         AND CUST_ID = custId
                         AND CO_BORROWER_ID = nvl(v_co_borrower_id, '*')
                         AND FACILITY_GROUP_ID= decode(FACILITY_GROUP_ID, '*', '*', txnProdLimitIdList(txnLimitIDIndex))
                         AND STRUCTURE_CODE = decode(txnShortFallList(txnLimitIDIndex), 'CBB','CL', 'GBB', 'GL', ' ');
                 EXCEPTION
                     WHEN OTHERS THEN
                       bbtl_certificate_id := null;
                       bbtl_facility_group_id := null;
                       bbtl_security_type_param := null;
                       bbtl_security_sub_type_param := null;
                 END;

                 --To get BBTL CERTIFICATE DATE START
                  -- adding maturity date to US as that of GB as suggested by sudheer
                 IF bbtl_certificate_id is not null THEN
                   BEGIN
                     SELECT certificate_date,extended_expiry_date,grace_period
                            --, decode(ctyCode, 'IN', extended_expiry_date , 'GB', (extended_expiry_date+grace_period),'US', (extended_expiry_date+grace_period))
                          INTO bbtl_certificate_date
                            , extended_expiry_date
                            , grace_period
                          from SCBT_R_BBC_DTLS_MST
                         WHERE BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE = ctyCode
                           AND BBC_ID = bbtl_certificate_id
                           AND ACTIVE_BBC_FLAG  = 'Y';
                   EXCEPTION
                      WHEN OTHERS THEN
                        bbtl_certificate_date := null;
                        bbtl_extended_expiry_date := null;
                        grace_period := null;
                        --bbtl_appl_dp_ccy_amt := null;
                        bbtl_facility_group_id := null;
                   END;

                   IF ctyCode = 'IN' THEN
                     bbtl_extended_expiry_date := extended_expiry_date;
                   ELSE
                     bbtl_extended_expiry_date := extended_expiry_date+grace_period;
                   END IF;

                   --Calculating CMV value for GBB START
                   -----
                   -----
                   -----
                   BEGIN
                      SELECT COUNT(1) into v_is_syndicate_coll
                          FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                             WHERE map_id = 'TXNISSUVAL'
                             AND code_value_1 = 'CONT_PROD'
                             AND m.code_value_2 = p.limit_product_code
                             AND p.cust_id = custId
                             AND p.limit_id = txnProdLimitIdList(txnLimitIDIndex)
                             AND p.bank_group_code = bankGroupCode
                             AND p.cty_code = ctyCode;
                   EXCEPTION
                        WHEN OTHERS THEN
                        v_is_syndicate_coll := 0;
                   END;

                   IF v_is_syndicate_coll > 0 THEN
                      v_product_type := 'CON';
                   ELSE
                      v_product_type := 'ASS';
                   END IF;

                   BEGIN
                      select PARAM_DATA_07 INTO v_syndicate_data
                         FROM SCBT_R_PARAM_DATA
                         WHERE param_id = 'TP10'
                          AND PARAM_KEY_01 = (
                           select DISTINCT SCB_ROLE
                             FROM SCBT_T_TXN_HST
                             WHERE BANK_GROUP_CODE=bankGroupCode
                               AND CTY_CODE=ctyCode
                               AND CUST_ID=custId
                               --AND DEAL_STEP_ID= bbtl_deal_step_id
                               AND PROD_LIMIT_ID=txnProdLimitIdList(txnLimitIDIndex)
                         ) and PARAM_KEY_02 = v_product_type;
                   EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                   END;


                   --For BBTL UK 

                   --  IF txnScbRoleList(txnLimitIDIndex) IS NULL THEN
                        BEGIN
                             select
                                SCB_SHARE_CMV_CCY_CODE --TOTAL_CMV_CCY_CODE
                                , Scbf_Tls_Exch_Rate(
                                     bbcMst.BANK_GROUP_CODE
                                          , bbcMst.CTY_CODE           -- COUNTRY CODE
                                     , SCB_SHARE_CMV_CCY_CODE --TOTAL_CMV_CCY_CODE
                                     , NVL(SCB_SHARE_CMV_CCY_AMT,0) --TOTAL_CMV_CCY_AMT
                                           -- , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_CODE, TOTAL_CMV_CCY_CODE)         -- FROM CURR CODE
                                         -- , decode(nvl(v_syndicate_data, 'BCA'), 'BCA',APPL_DP_CCY_AMT, TOTAL_CMV_CCY_AMT)            -- FROM AMOUNT
                                            , custExpCcy            -- TO CURR CODE
                                          , 'Y')
                                 INTO bbtl_appl_dp_ccy_code
                                  , bbtl_appl_dp_ccy_amt
                              FROM SCBT_R_BBC_DTLS_MST bbcMst,
                                   SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                              where bbcMst.BANK_GROUP_CODE=bankgroupcode
                                   AND bbcMst.CTY_CODE=ctycode
                                   AND bbcMst.Active_Bbc_Flag= 'Y'
                                   AND bbcGen.Bank_Group_Code = bankgroupcode
                                   AND bbcGen.Cty_Code = ctycode
                                   AND bbcGen.Cust_Id = custid
                                   AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                                   AND CO_BORROWER_ID = nvl(v_co_borrower_id, '*')
                                   AND bbcGen.Facility_Group_Id = nvl(bbtl_facility_group_id, '*');
                        EXCEPTION
                             WHEN OTHERS THEN
                               bbtl_appl_dp_ccy_code := '';
                               bbtl_appl_dp_ccy_amt := 0;
                        END;
                  END IF;
                 --To get BBTL CERTIFICATE DATE END

               END IF;
               --To get BBTL CERTIFICATE ID END

              prodCode := txnProdCodeList(txnLimitIDIndex);

              BEGIN
                SELECT COUNT(1) INTO contingentProduct
                  from scbt_r_param_data where BANK_GROUP_CODE ='SCB'
                       and param_id='CA03'
                       and param_key_02 = 'CON'
                       and param_data_01 = prodCode;
                      --   FROM SCBT_R_CAGG_FILTER_CRITERIA
                       --   WHERE FILTER_VALUE = prodCode
                       --   AND FILTER_TYPE='CONTINGENT';
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   contingentProduct := 0;
              END;


              BEGIN
                 actualCMVAmount := NVL(v_txn_outstanding_amt,0) * NVL(bbtl_appl_dp_ccy_amt,0) / NVL(v_faclty_outstanding_amt,0);
              EXCEPTION
                WHEN OTHERS THEN
                  actualCMVAmount := 0;
              END;


              --QC 870 Security Type and Security Sub Type should match with SCI securityType and Security Sub Type START
              securityTypeParam := null;
              securitySubTypeParam := null;
              securitySubTypeDescParam := null;
              securityTypeParam :=  bbtl_security_type_param;
              securitySubTypeParam := bbtl_security_sub_type_param;
              securitySubTypeDescParam :=  null;

              -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
              -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
              security_id :=null;
              securityType := null;
              securitySubType := null;
              exceptnSecSubType := 0;


                -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;


                 BEGIN
                      SELECT FSV_PCT INTO fsvPctBbc FROM SCBT_T_BBC_COLLATERAL_DTLS_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND CUST_ID = custId
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = securitySubTypeParam;
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctBbc is NULL) THEN
                    fsvValue        := actualCMVAmount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                  -- check whether overridden in bbc module and this case is applicable for bbc transactions
                 IF(fsvPctBbc IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctBbc <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctBbc;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := actualCMVAmount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := actualCMVAmount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

--Added logic to find the Parent limit id if the security is not found for the INNER LIMIT ID --START

            -- Changes done by Kishore on 24th SEPT 2013
              temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,txnProdLimitIdList(txnLimitIDIndex),custLEID);
       /*
              BEGIN
                 SELECT ext_limit_id, inner_to_id
                     BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                   FROM SCBT_R_CUST_PRODUCT_LIMIT
                     START WITH limit_id = txnProdLimitIdList(txnLimitIDIndex) --v_prod_limit_id
                     CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id  --ext_limit_id=inner_to_id
                     AND BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId
                     order by level desc;
              EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
              END;


              --To report parent id if SCI LIMIT ID is not there
              temp_parent_limit_id := null;
              temp_ext_limit_id:= null;
              FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP
                  BEGIN
                     SELECT LAS_LMT_ID into temp_ext_limit_id
                         FROM (
                            select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                              WHERE A.LAS_LE_ID=custLEID
                              and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                              --28-NOV-2012
                              --and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                         ) where rownum=1;
                     exit;

                  EXCEPTION WHEN OTHERS THEN
                      BEGIN
                         SELECT LAS_LMT_ID into temp_ext_limit_id
                            FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                WHERE A.LAS_LE_ID=custLEID
                                and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                                --28-NOV-2012
                                --and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                            ) where rownum=1;
                         exit;
                      EXCEPTION  WHEN OTHERS THEN
                           temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                           NULL;
                      END;
                  END;
              END LOOP;
*/
              BEGIN
                 select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                   into security_id, securityType, securitySubType
                     FROM (
                       select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                         from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                            WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                              AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                              AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                              AND UPDATE_STATUS_IND <> 'D'
                     ) where rownum=1;
              EXCEPTION
                 WHEN OTHERS THEN
                       NULL;
                       security_id :=null;
                       securityType := null;
                       securitySubType :=null;
              END;

              -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
              v_usd_cmv_amt := 0;
              BEGIN
                IF(custExpCcy = 'USD') THEN
                  v_usd_cmv_amt := actualCMVAmount;
                ELSE
                  v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                      bankGroupCode
                                      , ctyCode
                                      , custExpCcy
                                        , NVL(actualCMVAmount,0)
                                      , 'USD','N');
                      END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
                    END;
                    -- To calculate USD_CMV_AMT 25-FEB-2013 -- END


--Added logic to find the Parent limit id if the security is not found for the INNER LIMIT ID --END

              --EXCEPTIONAL SECURITY SUB TYPE
              BEGIN
                 select count(CODE_VALUE_1)
                     INTO exceptnSecSubType
                   from SCBT_R_MAP_INFO A
                     WHERE MAP_ID='CAGG_EXCPTN_LIST'
                   AND CODE_VALUE_1 = securitySubTypeParam;
              EXCEPTION
                WHEN OTHERS THEN
                  exceptnSecSubType := 0;
                END;

              --START
              isCTAExpired :=  Scbf_C_Get_Param_Data('TP11',
                                    '01',
                                    bankGroupCode,
                                    '*',
                                    '*',
                                    '*',
                                    ctyCode,
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '');

            isExpiredColl := 0;
            IF ( isCTAExpired IS NOT NULL and isCTAExpired = 'Y'
                 AND bbtl_certificate_date IS NOT NULL
                 AND bbtl_certificate_date <=  trunc(sysdate) ) THEN
               isExpiredColl := 1;
            END IF;


            BEGIN
              is_valid_data :=true;
              runningSeq := runningSeq + 1;
              custom_error_mesg := NULL;
               
              -- Exception handling
              IF ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
              END IF;
              if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                 is_valid_data := false;
        	       custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
              END IF;            
              IF ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
              END IF;


              IF ( (upper(securityType) !=  upper(securityTypeParam) or upper(securitySubType) != upper(securitySubTypeParam))) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
              END IF;

              IF ( ctyCode IS NULL OR length(ctyCode)<1 ) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Storage Location is empty.';
              END IF;

              IF ( actualCMVAmount is null or actualCMVAmount <=0) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
              END IF;

              --UK CTA changes
              IF (isExpiredColl IS NOT NULL and isExpiredColl =1) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Collateral to be reported only for unexpired collaterals';
              END IF;

              SELECT COUNT(*) INTO V_COUNT
                FROM SCBT_R_MAP_INFO
               WHERE BANK_GROUP_CODE = bankGroupCode
                 AND MAP_ID          = 'CAGGSYS'
                 AND CODE_VALUE_1    = tpSysCodeList(txnLimitIDIndex);

              IF v_count > 0 THEN

                 SELECT CODE_VALUE_2 INTO v_tp_sys_code
                   FROM SCBT_R_MAP_INFO
                  WHERE BANK_GROUP_CODE = bankGroupCode
                    AND MAP_ID          = 'CAGGSYS'
                    AND CODE_VALUE_1    = tpSysCodeList(txnLimitIDIndex);

              ELSE

                  v_tp_sys_code  := tpSysCodeList(txnLimitIDIndex);

              END IF;

              bbc_run_seq        := bbc_run_seq + 1;

              /* SUMMARY OF CHANGES REFERRING TO INDIA OCTOBER PRODUCTION REPORTING
                 DEAL ID TO BE POPULATED INSTAED OF BBC ID
                 PARCEL ID TO BE MADE WITH RUNNING SEQ I.E. CUST ID || SEQ || PC
                 COLLATERAL APPROACH TO BE MADE TRANSACTIONAL INSTEAD OF FACILITY
                 TP REF ID TO BE POPULATED
                 TP SYSTEM CODE MANIPULATION MADE TO READ FROM MAP_INFO TABLE */

              IF ( is_valid_data ) THEN
                 INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                            BANK_GROUP_CODE
                           , CTY_CODE
                           , CUST_ID
                           , COLLATERAL_ID
                           , DEAL_ID
                           , PARCEL_ID
                           , REC_ID
                           , BUSINESS_DATE
                           , SECURITY_VALUATION_DATE
                           , SOURCE_SYSTEM_CODE
                           , SECURITY_TYPE
                           , SECURITY_SUBTYPE
                           , COLLATERAL_APPROACH
                           , PRODUCT_CODE
                           , IS_SECURITY_PERFECTED
                           , MATURITY_DATE
                           , EFFECTIVE_DATE
                           , SECURITY_PERFECTION_DATE
                           , STORAGE_CTY_CODE
                           , BOOKING_LOC_CTY_CODE
                           , CMV_CCY_CODE
                           , CMV_CCY_AMT
                           , TP_REF_ID
                           , SCI_LEID
                           , TP_SYSTEM_CODE
                           , SCI_LIMIT_ID
                           , SECURITY_ID
                           , TXN_REF_ID
                           , CAGG_CATURED_TYPE
                           , USD_CMV_AMT
                           , FSV_PCT
                           , FSV_VALUE
                           , FSV_OVERRIDE_FLAG)
                       VALUES(
                           bankGroupCode
                           , ctyCode
                           , custId
                           , bbtl_certificate_id
                           , dealIdList(txnLimitIDIndex)
                           , CONCAT(CONCAT(custId, bbc_run_seq), 'PC')
                           , recordID || LPAD(runningSeq,8,'0')
                           , bussDate
                           , bussDate
                           , 'CCA'
                           , securityType
                           , securitySubType
                           , 'T'
                           , prodCode
                           , 'Y'
                           , bbtl_extended_expiry_date
                           , bbtl_certificate_date
                           , bbtl_certificate_date
                           , ctyCode --collStorageLoc(commodityIndex)
                           , ctyCode
                           , custExpCcy --ccyCodeForCMV
                           , actualCMVAmount
                           , tpRefIdList(txnLimitIDIndex)
                           , custLEID
                           , v_tp_sys_code
                           , temp_ext_limit_id --txnProdCodeList(txnLimitIDIndex)
                           , security_id
                           , txnRefIdList(txnLimitIDIndex)
                           , 'CAGG_BBTL_COLL'
                           , v_usd_cmv_amt
                           , fsvPct
                           , fsvValue
                           , fsvOverrideFlag);
                       ELSE
                         --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                         IF ( (actualCMVAmount is null or actualCMVAmount <=0) ) THEN
                            GOTO SKIP_TXN_LOOP;
                         END IF;

                         INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR (
                              BANK_GROUP_CODE
                              , CTY_CODE
                              , CUST_ID
                              , COLLATERAL_ID
                              , DEAL_ID
                              , PARCEL_ID
                              , REC_ID
                              , BUSINESS_DATE
                              , SECURITY_VALUATION_DATE
                              , SOURCE_SYSTEM_CODE
                              , SECURITY_TYPE
                              , SECURITY_SUBTYPE
                              , COLLATERAL_APPROACH
                              , PRODUCT_CODE
                              , IS_SECURITY_PERFECTED
                              , MATURITY_DATE
                              , EFFECTIVE_DATE
                              , SECURITY_PERFECTION_DATE
                              , STORAGE_CTY_CODE
                              , BOOKING_LOC_CTY_CODE
                              , CMV_CCY_CODE
                              , CMV_CCY_AMT
                              , TP_REF_ID
                              , SCI_LEID
                              , TP_SYSTEM_CODE
                              , SCI_LIMIT_ID
                              , SECURITY_ID
                              , ERROR_MESSAGE
                              , securitySubTypeDesc
                              , TXN_REF_ID
                              , CAGG_CATURED_TYPE
                              , USD_CMV_AMT
                              , FSV_PCT
                              , FSV_VALUE
                              , FSV_OVERRIDE_FLAG)
                          VALUES(
                              bankGroupCode
                              , ctyCode
                              , custId
                              , bbtl_certificate_id
                              , dealIdList(txnLimitIDIndex)
                              , CONCAT(CONCAT(custId, bbc_run_seq), 'PC')
                              , recordID || LPAD(runningSeq,8,'0')
                              , bussDate
                              , bussDate
                              , 'CCA'
                              , NVL(securityTypeParam, securityType)  --securityType
                              , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                              , 'T'
                              , prodCode
                              , 'Y'
                              , bbtl_extended_expiry_date
                              , bbtl_certificate_date
                              , bbtl_certificate_date
                              , ctyCode
                              , ctyCode
                              , custExpCcy --ccyCodeForCMV
                              , actualCMVAmount
                              , tpRefIdList(txnLimitIDIndex)
                              , custLEID
                              , v_tp_sys_code
                              , temp_ext_limit_id --txnProdCodeList(txnLimitIDIndex)
                              , security_id
                              , custom_error_mesg
                              , securitySubTypeDescParam
                              , txnRefIdList(txnLimitIDIndex)
                              , 'CAGG_BBTL_COLL_ERR'
                              , v_usd_cmv_amt
                              , fsvPct
                              , fsvValue
                              , fsvOverrideFlag);
                           <<SKIP_TXN_LOOP>>
                              NULL;
                       END IF;

                         --commit;
                    EXCEPTION
                       WHEN OTHERS THEN
                      --dbms_output.put_line(recordID|| '**UNLINKED**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                         NULL;
                    END;
                   --Calculation part is END
              END IF;
              <<SKIP_CO_BORROWER_TXN_LOOP>>
                  NULL;
      END LOOP;

    END IF;

    COMMIT;

  END SCBP_P_BBTL_COLL_AGGR_FEED;



PROCEDURE SCBP_P_BBTL_COLL_AGGR_FEED_EXT(bankGroupCode IN VARCHAR2,
                                    ctyCode       IN VARCHAR2,
                                    custId        IN VARCHAR2,
                                    coBorrowerId  IN VARCHAR2,
                                    limitId       IN VARCHAR2,
                                    txnRecId      IN VARCHAR2,
                                    runningSeq    IN OUT NOCOPY NUMBER) IS

  --TYPE txnProdLimitIdType IS TABLE OF SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE txnProdCodeType IS TABLE OF SCBT_T_TXN_MST.PRODUCT_CODE%TYPE INDEX BY PLS_INTEGER;
  --TYPE txnCcyCodeType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Code%TYPE INDEX BY PLS_INTEGER;
  --TYPE txnCcyAmtType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Amt%TYPE INDEX BY PLS_INTEGER;
  --TYPE txnCcyUtilAmtType IS TABLE OF SCBT_T_TXN_MST.Txn_Ccy_Util_Amt%TYPE INDEX BY PLS_INTEGER;
  --TYPE txnShortFallType IS TABLE OF SCBT_T_TXN_MST.Shortfall_Offset_Type%TYPE INDEX BY PLS_INTEGER;
  --TYPE extLimitIdType IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.ext_limit_id%TYPE INDEX BY PLS_INTEGER;
  --TYPE LimitInnerToIdList   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.INNER_TO_ID%TYPE INDEX BY PLS_INTEGER;
  --temp_parent_limit_id    SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  temp_ext_limit_ID SCBT_R_CUST_PRODUCT_LIMIT.Ext_Limit_Id%TYPE;
  TYPE txnStepCodeType IS TABLE OF SCBT_T_TXN_MST.TXN_STEP_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE txnRecIdType IS TABLE OF SCBT_T_TXN_MST.TXN_REC_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE txnRefIdType IS TABLE OF SCBT_T_TXN_MST.TXN_REF_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE tpRefIdType  IS TABLE OF SCBT_T_TXN_MST.TP_REF_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE tpSysCdType  IS TABLE OF SCBT_T_TXN_MST.TP_SYSTEM_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE dealIdType   IS TABLE OF SCBT_T_TXN_MST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;


  custExpCcy                SCBT_R_PARTY_MST.OVERALL_EXP_CURRENCY%TYPE;
  bussDate                  SCBT_S_DAILY_PARAM.BUSINESS_DATE%TYPE;
  recordID                  SCBT_T_IPS_CAGG_FEED_MST.REC_ID%TYPE;
  securityType              SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubType           SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;
  custLEID                  SCBT_R_PARTY_MST.Party_Id%TYPE;
  actualCMVAmount           NUMBER;
  v_usd_cmv_amt               SCBT_T_IPS_CAGG_FEED_MST.USD_CMV_AMT%TYPE;

  applScbSharePct       NUMBER;

  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin

  fsvPctCust            SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctDefault         SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPctBbc             SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvPct                SCBT_T_IPS_CAGG_FEED_MST.Fsv_Pct%TYPE;
  fsvValue              NUMBER;
  fsvOverrideFlag       SCBT_T_IPS_CAGG_FEED_MST.Fsv_Override_Flag%TYPE;

  -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

  bussDateAsString      VARCHAR2(10);
  tempRecId             SCBT_T_IPS_CAGG_FEED_MST.Rec_Id%TYPE;

  prodCode          SCBT_R_CUST_PRODUCT_LIMIT.Limit_Product_Code%TYPE;
  security_id       SCBT_T_IPS_SCI_LMT_APPR_SEC.LAS_SEC_ID%TYPE;
  is_valid_data     boolean;
  custom_error_mesg SCBT_T_IPS_CAGG_FEED_MST_ERR.ERROR_MESSAGE%type;
  securityTypeParam      SCBT_T_IPS_CAGG_FEED_MST.Security_Type%TYPE;
  securitySubTypeParam   SCBT_T_IPS_CAGG_FEED_MST.Security_Subtype%TYPE;

  contingentProduct NUMBER;
  securitySubTypeDescParam varchar2(100);
  exceptnSecSubType NUMBER;
  isCTAExpired scbt_r_param_data.param_data_01%TYPE;
  isExpiredColl NUMBER;
  v_co_borrower_id SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE;
  v_sep_bb_cert_flag SCBT_R_CUST_LIMIT_MST.SEP_BB_CERT_FLAG%TYPE;

  --For Borrowing Base UK 
  shortfall_offset_type SCBT_T_TXN_MST.SHORTFALL_OFFSET_TYPE%TYPE;
  bbtl_certificate_id SCBT_R_BBC_DTLS_MST.BBC_ID%TYPE;
  bbtl_certificate_date SCBT_R_BBC_DTLS_MST.CERTIFICATE_DATE%TYPE;
  bbtl_extended_expiry_date SCBT_R_BBC_DTLS_MST.EXTENDED_EXPIRY_DATE%TYPE;
  bbtl_security_type_param VARCHAR2(10);
  bbtl_security_sub_type_param SCBT_R_BBC_GENERAL_DTLS_MST.BBC_J158_CODE%TYPE;
  extended_expiry_date SCBT_R_BBC_DTLS_MST.EXTENDED_EXPIRY_DATE%TYPE;
  grace_period SCBT_R_BBC_DTLS_MST.GRACE_PERIOD%TYPE;
  bbtl_appl_dp_ccy_code SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_CODE%TYPE;
  bbtl_appl_dp_ccy_amt SCBT_R_BBC_DTLS_MST.APPL_DP_CCY_AMT%TYPE;
  bbtl_facility_group_id SCBT_R_BBC_GENERAL_DTLS_MST.FACILITY_GROUP_ID%TYPE;
  v_prod_limit_id             SCBT_R_CUST_FACILITY_GRP.PROD_LIMIT_IDS%TYPE;
  v_is_syndicate_coll         NUMBER;
  v_syndicate_data            SCBT_R_PARAM_DATA.Param_Data_04%TYPE;
  v_product_type              SCBT_R_PARAM_DATA.PARAM_KEY_02%TYPE;
  --bbtl_deal_step_id         SCBT_T_TXN_MST.LATEST_DEAL_STEP_ID%TYPE;
  v_txn_outstanding_amt       SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_faclty_outstanding_amt    SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
   v_outstanding_amt           SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_main_borrwer_outstanding_amt SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_co_borrwer_outstanding_amt  SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;
  v_co_borrwer_outstnd_amt_new  SCBT_T_TXN_MST.TXN_CCY_AMT%TYPE;-- COCOA-1050
  --txnProdLimitIdList          txnProdLimitIdType;
  txnStepCodeList              txnStepCodeType;
  txnProdCodeList             txnProdCodeType;
  --txnCcyCodeList              txnCcyCodeType;
  --txnCcyAmtList               txnCcyAmtType;
  --txnCcyUtilAmtList           txnCcyUtilAmtType;
  --txnShortFallList            txnShortFallType;
  --extLimitIdList              extLimitIdType;
  --innerToIdListForSCI         LimitInnerToIdList;
  v_prev_prod_limit_id        SCBT_T_TXN_MST.PROD_LIMIT_ID%TYPE;
  txnRecIdList                txnRecIdType;
  txnRefIdList                txnRefIdType;
  tpRefIdList                 tpRefIdType;
  tpSysCodeList               tpSysCdType;
  dealIdList                  dealIdType;
  v_tp_sys_code               SCBT_T_TXN_MST.TP_SYSTEM_CODE%TYPE;
  V_COUNT                     NUMBER;
  bbc_run_seq                 NUMBER;
  ccyCodeForCMV               VARCHAR2(3);

  --COCOACR_12SEP2013
 TYPE LimitCcyCodeType   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
 TYPE TempLimitCcyCodeType   IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
 limitCcyCodeList LimitCcyCodeType;
 tempLimitCcyCodeList TempLimitCcyCodeType;

  --BBC COLLATERAL CHANGES -18-JAN-2013
  TYPE bbcCollJ158Type    IS TABLE OF SCBT_T_BBC_COLLATERAL_DTLS_MST.J158_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE bbcCollCmvCcyType  IS TABLE OF SCBT_T_BBC_COLLATERAL_DTLS_MST.CMV_CCY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE bbcCollCmvAmtType  IS TABLE OF SCBT_T_BBC_COLLATERAL_DTLS_MST.CMV_CCY_AMT%TYPE INDEX BY PLS_INTEGER;
  TYPE facilityLimitIdType  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.LIMIT_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE coborrowerIdType  IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.CO_BORROWER_ID%TYPE INDEX BY PLS_INTEGER;
  bbcCollJ158List    bbcCollJ158Type;
  bbcCollCmvCcyList  bbcCollCmvCcyType;
  bbcCollCmvAmtList  bbcCollCmvAmtType;
  facilityLimitIdList facilityLimitIdType;
  tempLimitIdList facilityLimitIdType;
  tempCoBorrowerIdList facilityLimitIdType;
  coborrowerIdList    coborrowerIdType;

  BEGIN

   -- Customer Exposure Currency
   BEGIN
      SELECT OVERALL_EXP_CURRENCY
        INTO custExpCcy
        FROM SCBT_R_PARTY_MST
       WHERE BANK_GROUP_CODE = bankGroupCode
         AND CTY_CODE = ctyCode
         AND PARTY_ID = custId;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        custExpCcy := 'SGD';
    END;


    -- Business Date
    BEGIN
        SELECT BUSINESS_DATE INTO bussDate FROM SCBT_S_DAILY_PARAM WHERE BANK_GROUP_CODE = bankGroupCode AND CTY_CODE = ctyCode;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        NULL;
    END;

    -- LEID of Customer
    BEGIN
       SELECT EXT_SYSTEM_ID INTO custLEID FROM SCBT_R_PARTY_EXT_ID WHERE party_id=custId AND EXT_SYSTEM_CODE='SC';
       EXCEPTION
          WHEN NO_DATA_FOUND THEN
           custLEID :='';
    END;

    -- Record ID Generation
    bussDateAsString := TO_CHAR(bussDate, 'DDMMYYYY');
    recordID := 'CO' || bussDateAsString;
    bbc_run_seq := 0;

    --To construct RECORD ID
    BEGIN
        SELECT MAX(REC_ID) INTO tempRecId FROM SCBT_T_IPS_CAGG_FEED_MST
               WHERE BANK_GROUP_CODE = bankGroupCode
               AND CTY_CODE = ctyCode
               AND BUSINESS_DATE=bussDate;
               --AND CUST_ID = custId;
        runningSeq := to_number(substr(tempRecId, 11, length(tempRecId)));
    EXCEPTION
        WHEN OTHERS THEN
        runningSeq := 0;
    END;


    IF runningSeq IS NULL THEN
       runningSeq :=0;
    END IF;

    SELECT LIMIT_ID,LIMIT_PRODUCT_CODE,CO_BORROWER_ID
    ,LIMIT_CCY_CODE --COCOACR_12SEP2013
    BULK COLLECT INTO facilityLimitIdList,txnProdCodeList,coborrowerIdList
    ,limitCcyCodeList --COCOACR_12SEP2013
    FROM SCBT_R_CUST_PRODUCT_LIMIT
                   WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND CUST_ID = custId
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
                     AND limit_id NOT IN (
                      SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                      WHERE BANK_GROUP_CODE = bankGroupCode
                      AND CTY_CODE = ctyCode
                      AND CUST_ID = custId
                      AND LIMIT_PRODUCT_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                          WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
                      )
                  --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
                  --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
                  AND LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
                  WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
                  AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                  WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
                  AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
                   --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                  AND SHORTFALL_OFFSET IN ('CBB','GBB');

       --to calculate total outstanding for mainborrower limits only
       SELECT LIMIT_ID
       ,LIMIT_CCY_CODE --COCOACR_12SEP2013
       BULK COLLECT INTO tempLimitIdList
       ,tempLimitCcyCodeList --COCOACR_12SEP2013
       FROM SCBT_R_CUST_PRODUCT_LIMIT
                   WHERE BANK_GROUP_CODE=bankgroupcode
                     AND CTY_CODE = ctycode
                     AND CUST_ID = custId
                     AND CO_BORROWER_ID IS NULL
                     --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
             AND limit_id NOT IN (
             SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND LIMIT_PRODUCT_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
            )
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
            AND LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
            AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
            WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
            AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
                     AND SHORTFALL_OFFSET IN ('CBB','GBB');
         v_main_borrwer_outstanding_amt :=0;
       FOR tempLimitIdIndex IN 1..tempLimitIdList.COUNT LOOP
       BEGIN
              v_main_borrwer_outstanding_amt := v_main_borrwer_outstanding_amt
                                          +   Scbf_Tls_Exch_Rate(    --COCOACR_12SEP2013
                                          bankGroupCode
                                          , ctyCode
                                          , tempLimitCcyCodeList(tempLimitIdIndex)
                                          ,NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                                                                   bankGroupCode
                                                                   , ctyCode
                                                                   , custId
                                                                   , tempLimitIdList(tempLimitIdIndex)
                                                                   , custExpCcy
                                                                   , null)
                                                                   , 0)
                                           , custExpCcy
                                           , 'Y')  ;
       EXCEPTION WHEN OTHERS THEN
         v_main_borrwer_outstanding_amt :=0;
       END;
       END LOOP;

       -- CAGG_US_ENH_30082013
       
         v_co_borrwer_outstanding_amt :=0;       
         v_co_borrwer_outstnd_amt_new := 0;  -- COCOA-1050
       FOR coborrowerIdIndex IN 1..coborrowerIdList.COUNT LOOP
       BEGIN
             SELECT
               sum (NVL(CUST_EXP_UTIL,0)) INTO v_co_borrwer_outstnd_amt_new -- COCOA-1050
               from (
                SELECT DISTINCT limit_id, LIMIT_CCY_CODE,
                 Scbf_Tls_Exch_Rate(
                    PL.BANK_GROUP_CODE
                    , PL.CTY_CODE
                    , LIMIT_CCY_CODE
                    , NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                       TM.BANK_GROUP_CODE
                       , TM.CTY_CODE
                       , TM.CUST_ID
                       , TM.PROD_LIMIT_ID
                       , PL.LIMIT_CCY_CODE
                       , TM.PRODUCT_CODE)
                       , 0)
                       , custExpCcy
                       , 'Y'
                     )  AS CUST_EXP_UTIL
               FROM SCBT_T_PROD_LIMIT_UTIL PL
                 , SCBT_T_TXN_MST TM
            WHERE PL.BANK_GROUP_CODE = TM.BANK_GROUP_CODE
              AND PL.CTY_CODE=TM.CTY_CODE
              AND TM.SHORTFALL_OFFSET_TYPE IN('CBB','GBB')
              AND PL.LIMIT_ID = TM.PROD_LIMIT_ID
              AND PL.BANK_GROUP_CODE = bankGroupCode
              AND PL.CTY_CODE = ctyCode
              AND TM.CUST_ID = custId
              AND limit_id = facilityLimitIdList(coborrowerIdIndex)              
              AND limit_id IN (
                 SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND CO_BORROWER_ID = coborrowerIdList(coborrowerIdIndex)
                    AND SHORTFALL_OFFSET IN('CBB','GBB')
                )
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
             AND limit_id NOT IN (
             SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND LIMIT_PRODUCT_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
            )
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
            AND LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
            AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
            WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
            AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
            ); 
                                               
       v_co_borrwer_outstanding_amt := v_co_borrwer_outstanding_amt+NVL(v_co_borrwer_outstnd_amt_new,0);-- COCOA-1050                                            
       EXCEPTION WHEN OTHERS THEN
         v_co_borrwer_outstnd_amt_new :=0; -- COCOA-1050
       END;                         
       END LOOP;        
                            
           v_sep_bb_cert_flag := 'Y';

            -- To get separate BB certificate flag ----
            BEGIN
              select sep_bb_cert_flag INTO v_sep_bb_cert_flag from SCBT_R_CUST_LIMIT_MST CL
              where CL.BANK_GROUP_CODE = bankGroupCode
              AND CL.CTY_CODE = ctyCode
              AND CL.CUST_ID = custId;
           EXCEPTION
           WHEN NO_DATA_FOUND THEN
               v_sep_bb_cert_flag := 'Y';
           END;

          -- CAGG_US_ENH_30082013 ends


       -- To get the total outstanding amt for all the facilities for that customer
       v_faclty_outstanding_amt :=0;

      FOR facilityLimitIndex IN 1..facilityLimitIdList.COUNT LOOP

       IF coborrowerIdList(facilityLimitIndex) IS NULL THEN
           v_faclty_outstanding_amt := v_main_borrwer_outstanding_amt;
       ELSE
           BEGIN
               SELECT
               sum (NVL(CUST_EXP_UTIL,0)) INTO v_faclty_outstanding_amt
               from (
                SELECT DISTINCT limit_id, LIMIT_CCY_CODE,
                 Scbf_Tls_Exch_Rate(
                    PL.BANK_GROUP_CODE
                    , PL.CTY_CODE
                    , LIMIT_CCY_CODE
                    , NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                       TM.BANK_GROUP_CODE
                       , TM.CTY_CODE
                       , TM.CUST_ID
                       , TM.PROD_LIMIT_ID
                       , PL.LIMIT_CCY_CODE
                       , TM.PRODUCT_CODE)
                       , 0)
                       , custExpCcy
                       , 'Y'
                     )  AS CUST_EXP_UTIL
               FROM SCBT_T_PROD_LIMIT_UTIL PL
                 , SCBT_T_TXN_MST TM
            WHERE PL.BANK_GROUP_CODE = TM.BANK_GROUP_CODE
              AND PL.CTY_CODE=TM.CTY_CODE
              AND TM.SHORTFALL_OFFSET_TYPE IN('CBB','GBB')
              AND PL.LIMIT_ID = TM.PROD_LIMIT_ID
              AND PL.BANK_GROUP_CODE = bankGroupCode
              AND PL.CTY_CODE = ctyCode
              AND TM.CUST_ID = custId
              AND limit_id IN (
                 SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                    WHERE BANK_GROUP_CODE = bankGroupCode
                    AND CTY_CODE = ctyCode
                    AND CUST_ID = custId
                    AND CO_BORROWER_ID = coborrowerIdList(facilityLimitIndex)
                    AND SHORTFALL_OFFSET IN('CBB','GBB')
                )
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' START
             AND limit_id NOT IN (
             SELECT LIMIT_ID from SCBT_R_CUST_PRODUCT_LIMIT
                WHERE BANK_GROUP_CODE = bankGroupCode
                AND CTY_CODE = ctyCode
                AND CUST_ID = custId
                AND LIMIT_PRODUCT_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
                    WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05' AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDPROD')
            )
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'INPUT FINANCE' PRODUCT '15-JAN-2013' END
            --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' START
            AND LIMIT_ID not in (SELECT LIMIT_ID FROM SCBT_R_CUST_PRODUCT_LIMIT
            WHERE BANK_GROUP_CODE= bankGroupCode and CTY_CODE = ctyCode
            AND CUST_ID = custId AND LIMIT_TYPE_CODE in (select PARAM_DATA_01 from SCBT_R_PARAM_DATA
            WHERE BANK_GROUP_CODE=bankGroupCode AND PARAM_ID='CA05'
            AND CTY_CODE in (ctyCode, '*') AND PARAM_KEY_01='CAGGINVALIDLIMITTYPECODE'))
             --ADDED BELOW CONDITION TO AVOID TO CAPTURE 'CAT2 AS LIMIT TYPE CODE' '13-FEB-2013' END;
            );
            EXCEPTION
               WHEN OTHERS THEN
                 v_faclty_outstanding_amt := 0;
            END;
       END IF;

         -- CAGG_US_ENH_30082013
         -- If separate bb flag is 'N' then main borrower certificate amt is inclusive of coborrower amt associated ---
         IF v_sep_bb_cert_flag = 'N' THEN
            v_faclty_outstanding_amt := NVL(v_main_borrwer_outstanding_amt,0) + NVL(v_co_borrwer_outstanding_amt,0);
         END IF;
         -- CAGG_US_ENH_30082013 ends

             ----------calculating outstanding for that limit

                BEGIN
                        IF txnProdCodeList(facilityLimitIndex) IS NOT NULL and txnProdCodeList(facilityLimitIndex) = 'ODT' THEN
                            --For OD Transaction
                            v_txn_outstanding_amt :=0;
                            IF v_prev_prod_limit_id IS NULL OR v_prev_prod_limit_id != facilityLimitIdList(facilityLimitIndex) THEN
                               v_prev_prod_limit_id := facilityLimitIdList(facilityLimitIndex);
                               BEGIN
                                  SELECT  Scbf_Tls_Exch_Rate(
                                             BANK_GROUP_CODE
                                             , CTY_CODE
                                             , LIMIT_CCY_CODE
                                             , LIMIT_CCY_UTILISED_AMT
                                             , custExpCcy
                                             , 'Y')
                                         INTO  v_txn_outstanding_amt
                                     from SCBT_T_PROD_LIMIT_UTIL
                                     where BANK_GROUP_CODE = bankGroupCode
                                        AND CTY_CODE = ctyCode
                                        AND LIMIT_ID =  facilityLimitIdList(facilityLimitIndex);
                               EXCEPTION WHEN OTHERS THEN
                                 v_txn_outstanding_amt :=0;
                               END;
                              ELSE
                               v_txn_outstanding_amt := 0;
                            END IF;

                         ELSE
                           --To calculate Outstanding Amount
                          -- changes done to capture outstanding only for that limit
                           BEGIN --COCOACR_12SEP2013
                           v_txn_outstanding_amt :=       Scbf_Tls_Exch_Rate(
                                                          bankGroupCode
                                                          , ctyCode
                                                          , limitCcyCodeList(facilityLimitIndex)
                                                          ,NVL(SCBK_P_COCOA_CDB.SCBF_GET_PROD_UTIL_AMOUNT(
                                                                  bankGroupCode
                                                                  , ctyCode
                                                                  , custId
                                                                  , facilityLimitIdList(facilityLimitIndex)
                                                                  , custExpCcy
                                                                  , null)
                                                                  ,0)
                                                           , custExpCcy
                                                           , 'Y');
                            EXCEPTION WHEN OTHERS THEN
                                 v_txn_outstanding_amt :=0;
                            END;

                    END IF;
                    END;




         --To get BBTL CERTIFICATE ID START
               bbtl_certificate_id := null;
               bbtl_facility_group_id := null;
                 BEGIN
                   SELECT facility_group_id
                      INTO bbtl_facility_group_id
                       from SCBT_R_BBC_GENERAL_DTLS_MST
                      WHERE BANK_GROUP_CODE = bankGroupCode
                         AND CTY_CODE = ctyCode
                         AND CUST_ID = custId
                         AND CO_BORROWER_ID = nvl(coborrowerIdList(facilityLimitIndex), '*')
                         AND FACILITY_GROUP_ID = decode(FACILITY_GROUP_ID, '*', '*', facilityLimitIdList(facilityLimitIndex))
                         AND STRUCTURE_CODE IN ('CL','GL');
                 EXCEPTION
                     WHEN OTHERS THEN
                       bbtl_facility_group_id := null;
                 END;

                 ----COLLATERALS FOR INDIA BASED DP TRANSACTIONS
                 -- Retreiving distinct bbc_id, being same for multiple J158 codes
                 -- Based on the flag getting the bbc_id for displaying either separate bbc certificates or one certificate
                 -- CAGG_US_ENH_30082013
                 IF (v_sep_bb_cert_flag IS NULL OR v_sep_bb_cert_flag = 'Y' ) THEN
                  BEGIN
                     SELECT DISTINCT bbc_id INTO bbtl_certificate_id FROM SCBT_R_BBC_GENERAL_DTLS_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                         AND CTY_CODE = ctyCode
                         AND CUST_ID = custId
                         AND CO_BORROWER_ID = nvl(coborrowerIdList(facilityLimitIndex),'*');
                 EXCEPTION
                     WHEN OTHERS THEN
                       bbtl_certificate_id := null;
                 END;
                 END IF;

                  IF v_sep_bb_cert_flag = 'N' THEN
                  BEGIN
                     SELECT DISTINCT bbc_id INTO bbtl_certificate_id FROM SCBT_R_BBC_GENERAL_DTLS_MST
                       WHERE BANK_GROUP_CODE = bankGroupCode
                         AND CTY_CODE = ctyCode
                         AND CUST_ID = custId
                         AND CO_BORROWER_ID = '*';
                 EXCEPTION
                     WHEN OTHERS THEN
                       bbtl_certificate_id := null;
                 END;
                 END IF;

                 -- CAGG_US_ENH_30082013 changes ends

                 --To get BBTL CERTIFICATE DATE START
                  -- adding maturity date to US as that of GB as suggested by sudheer


                 IF bbtl_certificate_id is not null THEN
                   BEGIN
                     SELECT certificate_date,extended_expiry_date,grace_period
                           -- , decode(ctyCode, 'IN', extended_expiry_date , 'GB', (extended_expiry_date+grace_period),'US', (extended_expiry_date+grace_period))
                          INTO bbtl_certificate_date
                            , extended_expiry_date
                            , grace_period
                          from SCBT_R_BBC_DTLS_MST
                         WHERE BANK_GROUP_CODE = bankGroupCode
                           AND CTY_CODE = ctyCode
                           AND BBC_ID = bbtl_certificate_id
                           AND ACTIVE_BBC_FLAG  = 'Y';
                   EXCEPTION
                      WHEN OTHERS THEN
                        bbtl_certificate_date := null;
                        extended_expiry_date := null;
                        grace_period   := null;
                   END;

                   IF ctyCode = 'IN' THEN
                     bbtl_extended_expiry_date := extended_expiry_date;
                   ELSE
                     bbtl_extended_expiry_date := extended_expiry_date+grace_period;
                   END IF;


                   --Calculating CMV value for GBB START

                   BEGIN
                      SELECT COUNT(1) into v_is_syndicate_coll
                          FROM SCBT_R_MAP_INFO m, SCBT_R_CUST_PRODUCT_LIMIT p
                             WHERE map_id = 'TXNISSUVAL'
                             AND code_value_1 = 'CONT_PROD'
                             AND m.code_value_2 = p.limit_product_code
                             AND p.cust_id = custId
                             AND p.limit_id = facilityLimitIdList(facilityLimitIndex)
                             AND p.bank_group_code = bankGroupCode
                             AND p.cty_code = ctyCode;
                   EXCEPTION
                        WHEN OTHERS THEN
                        v_is_syndicate_coll := 0;
                   END;

                   IF v_is_syndicate_coll > 0 THEN
                      v_product_type := 'CON';
                   ELSE
                      v_product_type := 'ASS';
                   END IF;

                   BEGIN
                      select PARAM_DATA_07 INTO v_syndicate_data
                         FROM SCBT_R_PARAM_DATA
                         WHERE param_id = 'TP10'
                          AND PARAM_KEY_01 = (
                           select DISTINCT SCB_ROLE
                             FROM SCBT_T_TXN_HST
                             WHERE BANK_GROUP_CODE=bankGroupCode
                               AND CTY_CODE=ctyCode
                               AND CUST_ID=custId
                               AND PROD_LIMIT_ID=facilityLimitIdList(facilityLimitIndex)
                         ) and PARAM_KEY_02 = v_product_type;
                   EXCEPTION
                       WHEN OTHERS THEN
                       NULL;
                   END;

                  --For BBTL UK 

                        BEGIN
                             select
                                SCB_SHARE_CMV_CCY_CODE --TOTAL_CMV_CCY_CODE
                                /*, Scbf_Tls_Exch_Rate(
                                     bbcMst.BANK_GROUP_CODE
                                          , bbcMst.CTY_CODE           -- COUNTRY CODE
                                     , SCB_SHARE_CMV_CCY_CODE --TOTAL_CMV_CCY_CODE
                                     , SCB_SHARE_CMV_CCY_AMT --TOTAL_CMV_CCY_AMT
                                          , custExpCcy            -- TO CURR CODE
                                          , 'Y')*/
                                 INTO bbtl_appl_dp_ccy_code
                                --  , bbtl_appl_dp_ccy_amt
                              FROM SCBT_R_BBC_DTLS_MST bbcMst,
                                   SCBT_R_BBC_GENERAL_DTLS_MST bbcGen
                              where bbcMst.BANK_GROUP_CODE=bankgroupcode
                                   AND bbcMst.CTY_CODE=ctycode
                                   AND bbcMst.Active_Bbc_Flag= 'Y'
                                   AND bbcGen.Bank_Group_Code = bankgroupcode
                                   AND bbcGen.Cty_Code = ctycode
                                   AND bbcGen.Cust_Id = custid
                                   AND bbcGen.Bbc_Id = bbcMst.Bbc_Id
                                   AND CO_BORROWER_ID = nvl(coborrowerIdList(facilityLimitIndex), '*')
                                   AND bbcGen.Facility_Group_Id = nvl(bbtl_facility_group_id, '*');
                        EXCEPTION
                             WHEN OTHERS THEN
                               bbtl_appl_dp_ccy_code := '';
                               bbtl_appl_dp_ccy_amt := 0;
                        END;
                  END IF;
                 --To get BBTL CERTIFICATE DATE END

            BEGIN
              SELECT J158_CODE, CMV_CCY_CODE, CMV_CCY_AMT
                 BULK COLLECT INTO bbcCollJ158List, bbcCollCmvCcyList, bbcCollCmvAmtList
              FROM SCBT_T_BBC_COLLATERAL_DTLS_MST
              WHERE BANK_GROUP_CODE=bankgroupcode
                AND CTY_CODE = ctycode
                AND CUST_ID = custId
                AND BBC_ID = bbtl_certificate_id
                and J158_CTY_CODE = ctycode;

              FOR bbcJ158Index IN 1..bbcCollJ158List.COUNT LOOP

                prodCode := txnProdCodeList(facilityLimitIndex);

              BEGIN
                SELECT COUNT(1) INTO contingentProduct
                  from scbt_r_param_data where BANK_GROUP_CODE ='SCB'
                       and param_id='CA03'
                       and param_key_02 = 'CON'
                       and param_data_01 = prodCode;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   contingentProduct := 0;
              END;

              --COLLATERALS FOR INDIA BASED DP TRANSACTIONS
              --CMV_CCY_AMT from SCBT_T_COLLATERAL_REGISTER_MST
              BEGIN
                 bbtl_appl_dp_ccy_amt := Scbf_Tls_Exch_Rate(
                                         bankGroupCode
                                         , ctyCode
                                         , bbcCollCmvCcyList(bbcJ158Index)
                                         , bbcCollCmvAmtList(bbcJ158Index)
                                         , custExpCcy
                                         , 'Y');
              EXCEPTION
                WHEN OTHERS THEN
                  bbtl_appl_dp_ccy_amt := 0;
              END;
             -- END IF;

             -- COCOACR_31052013
             IF ctyCode ='IN' THEN

             BEGIN
                   SELECT APPL_SCB_SHARE_PCT into applScbSharePct from SCBT_R_BBC_GENERAL_DTLS_MST
                   WHERE BANK_GROUP_CODE=bankGroupCode
                   AND CTY_CODE=ctyCode
                   AND BBC_ID=bbtl_certificate_id;

             EXCEPTION
             WHEN OTHERS THEN
                  applScbSharePct := 0;
             END;

               if applScbSharePct <>0 THEN
               bbtl_appl_dp_ccy_amt := NVL(bbtl_appl_dp_ccy_amt,0) * (applScbSharePct/100);
               END IF;

             END IF;
             -- END COCOACR_31052013

              BEGIN
                 actualCMVAmount := NVL(v_txn_outstanding_amt,0) * NVL(bbtl_appl_dp_ccy_amt,0) / NVL(v_faclty_outstanding_amt,0);
              EXCEPTION
                WHEN OTHERS THEN
                  actualCMVAmount := 0;
              END;

              --QC 870 Security Type and Security Sub Type should match with SCI securityType and Security Sub Type START

              BEGIN
                  bbtl_security_type_param := SUBSTR(bbcCollJ158List(bbcJ158Index), 1, 2);
              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;

              -- adding cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx begin
                fsvOverrideFlag := 'N';
                fsvPctCust      := null;
                fsvPctDefault   := null;
                fsvPctBbc       := null;
                fsvPct          := null;
                fsvValue        := null;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctBbc FROM SCBT_T_BBC_COLLATERAL_DTLS_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND CUST_ID = custId
                      AND BBC_ID = bbtl_certificate_id
                      AND J158_CODE = bbcCollJ158List(bbcJ158Index);
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 BEGIN
                      SELECT FSV_PCT INTO fsvPctDefault FROM SCBT_R_J158_MAINTENANCE_MST
                      WHERE BANK_GROUP_CODE=bankgroupcode
                      AND J158_CTY_CODE = ctycode
                      AND J158_CODE = bbcCollJ158List(bbcJ158Index);
                 EXCEPTION
                      WHEN NO_DATA_FOUND THEN
                            NULL;
                 END;

                 -- when there is no setup, fsv% will be empty,override flag will be N, fsvvalue defaults to cmv amt,
                 IF(fsvPctBbc is NULL) THEN
                    fsvValue        := actualCMVAmount;
                 END IF;

                 -- always defaulting fsv pct from maintenance if available
                 IF(fsvPctDefault IS NOT NULL) THEN
                    fsvPct := fsvPctDefault;
                 END IF;

                  -- check whether overridden in bbc module and this case is applicable for bbc transactions
                 IF(fsvPctBbc IS NOT NULL AND fsvPctDefault IS NOT NULL) THEN
                   IF(fsvPctBbc <> fsvPctDefault) THEN
                      fsvOverrideFlag := 'Y';
                      fsvPct := fsvPctBbc;
                   END IF;
                 END IF;

                 IF(fsvPct IS NOT NULL) THEN
                 BEGIN
                   fsvValue := actualCMVAmount * fsvPct / 100;
                 EXCEPTION
                   WHEN OTHERS THEN
                    fsvValue := actualCMVAmount;
                 END;
                 END IF;
              -- cagg changes for FSD for FSV Maintenance and BBC Collaterals - 2 V0.3.docx end

              securityTypeParam := null;
              securitySubTypeParam := null;
              securitySubTypeDescParam := null;
              securityTypeParam :=  bbtl_security_type_param;
              securitySubTypeParam := bbcCollJ158List(bbcJ158Index);
              securitySubTypeDescParam :=  null;

              -- As per the change request SECURITY_TYPE AND SECURITY_SUB_TYPE is populated from SCI
              -- SCI SECURITY_ID, SECURITY_TYPE and SECURITY_SUB_TYPE START
              security_id :=null;
              securityType := null;
              securitySubType := null;
              exceptnSecSubType := 0;

              -- Changes done by Kishore on 24th SEPT 2013
             temp_ext_limit_id := scbf_get_sci_limit_id(bankGroupCode,ctyCode,custId,facilityLimitIdList(facilityLimitIndex),custLEID);

 /*             --Added logic to find the Parent limit id if the security is not found for the INNER LIMIT ID --START
              BEGIN
                 SELECT ext_limit_id, inner_to_id
                     BULK COLLECT INTO extLimitIdList, innerToIdListForSCI
                   FROM SCBT_R_CUST_PRODUCT_LIMIT
                     START WITH limit_id = facilityLimitIdList(facilityLimitIndex) --v_prod_limit_id
                     CONNECT BY NOCYCLE PRIOR   inner_to_id=ext_limit_id  --ext_limit_id=inner_to_id
                     AND BANK_GROUP_CODE = bankGroupCode
                     AND CTY_CODE = ctyCode
                     AND CUST_ID = custId
                     order by level desc;
              EXCEPTION
                  WHEN OTHERS THEN
                  NULL;
              END;


              --To report parent id if SCI LIMIT ID is not there
              temp_ext_limit_id:= null;
              FOR sciLimitIndex IN 1..innerToIdListForSCI.COUNT LOOP
                  BEGIN
                     SELECT LAS_LMT_ID into temp_ext_limit_id
                         FROM (
                            select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                              WHERE A.LAS_LE_ID=custLEID
                              and A.LAS_LMT_ID=extLimitIdList(sciLimitIndex)
                         ) where rownum=1;
                     exit;

                  EXCEPTION WHEN OTHERS THEN
                      BEGIN
                         SELECT LAS_LMT_ID into temp_ext_limit_id
                            FROM ( select LAS_LMT_ID from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                                WHERE A.LAS_LE_ID=custLEID
                                and A.LAS_LMT_ID=innerToIdListForSCI(sciLimitIndex)
                            ) where rownum=1;
                         exit;
                      EXCEPTION  WHEN OTHERS THEN
                           temp_parent_limit_id := nvl(temp_ext_limit_id, extLimitIdList(sciLimitIndex));
                           NULL;
                      END;
                  END;
              END LOOP;
*/
              BEGIN
                 select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                   into security_id, securityType, securitySubType
                     FROM (
                       select LAS_SEC_ID, SEC_TYPE_VALUE, SEC_SUB_TYPE_VALUE
                         from SCBT_T_IPS_SCI_LMT_APPR_SEC A
                            WHERE A.LAS_LE_ID=custLEID and A.LAS_LMT_ID=temp_ext_limit_id
                              AND UPPER(SEC_TYPE_VALUE) = UPPER(securityTypeParam)
                              AND UPPER(SEC_SUB_TYPE_VALUE) = UPPER(securitySubTypeParam)
                              AND UPDATE_STATUS_IND <> 'D'
                     ) where rownum=1;
              EXCEPTION
                 WHEN OTHERS THEN
                       NULL;
                       security_id :=null;
                       securityType := null;
                       securitySubType :=null;
              END;

              --Added logic to find the Parent limit id if the security is not found for the INNER LIMIT ID --END
              --EXCEPTIONAL SECURITY SUB TYPE
              BEGIN
                 select count(CODE_VALUE_1)
                     INTO exceptnSecSubType
                   from SCBT_R_MAP_INFO A
                     WHERE MAP_ID='CAGG_EXCPTN_LIST'
                   AND CODE_VALUE_1 = securitySubTypeParam;
              EXCEPTION
                WHEN OTHERS THEN
                  exceptnSecSubType := 0;
                END;

              --START
              isCTAExpired :=  Scbf_C_Get_Param_Data('TP11',
                                    '01',
                                    bankGroupCode,
                                    '*',
                                    '*',
                                    '*',
                                    ctyCode,
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '',
                                    '');

            isExpiredColl := 0;
            IF ( isCTAExpired IS NOT NULL and isCTAExpired = 'Y'
                 AND bbtl_certificate_date IS NOT NULL
                 AND bbtl_certificate_date <=  trunc(sysdate) ) THEN
               isExpiredColl := 1;
            END IF;

        -- To calculate USD_CMV_AMT 25-FEB-2013 -- START
            v_usd_cmv_amt := 0;
            BEGIN
                    IF(custExpCcy = 'USD') THEN
                    v_usd_cmv_amt := actualCMVAmount;
                ELSE
                        v_usd_cmv_amt := Scbf_Fetch_Exch_Rate(
                                              bankGroupCode
                                              , ctyCode
                                              , custExpCcy
                                                , NVL(actualCMVAmount,0)
                                              , 'USD','N');
               END IF;
                    EXCEPTION WHEN OTHERS THEN
                       v_usd_cmv_amt := 0;
               END;
            -- To calculate USD_CMV_AMT 25-FEB-2013 -- END

            BEGIN
              is_valid_data :=true;
              runningSeq := runningSeq + 1;
              custom_error_mesg := NULL;
              -- Exception handling
              if ( temp_ext_limit_id is null  or length(temp_ext_limit_id) < 1 ) then
                 is_valid_data := false;
        	       custom_error_mesg :=  custom_error_mesg ||'SCI Limit id is not tagged to any limits.';
              END IF;
              IF ( ( securityTypeParam is null or securitySubTypeParam is null ) or ( length(securityTypeParam) < 1 or length(securitySubTypeParam) < 1 )  ) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Security Type or Security Sub Type is missing in PARAM table.';
              END IF;

              IF ((security_id is null or securityType is null or securitySubType is null ) or (length(security_id) < 1  or length(securityType) < 1 or length(securitySubType) < 1 )  ) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is missing in SCI.';
              END IF;

              IF ( (upper(securityType) !=  upper(securityTypeParam) or upper(securitySubType) != upper(securitySubTypeParam))) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Security ID or Security Type or Security Sub Type is mismatch between SCI and PARAM table.';
              END IF;

              IF ( ctyCode IS NULL OR length(ctyCode)<1 ) THEN
                is_valid_data := false;
                custom_error_mesg :=  custom_error_mesg ||'Storage Location is empty.';
              END IF;

              IF ( actualCMVAmount is null or actualCMVAmount <=0) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Current Market Value is empty or ZERO.';
              END IF;

              --UK CTA changes
              IF (isExpiredColl IS NOT NULL and isExpiredColl =1) THEN
                 is_valid_data := false;
                 custom_error_mesg :=  custom_error_mesg ||'Collateral to be reported only for unexpired collaterals';
              END IF;

              v_tp_sys_code  := 'SCI'; --as suggested by sudheer

              bbc_run_seq        := bbc_run_seq + 1;

              /* SUMMARY OF CHANGES REFERRING TO INDIA OCTOBER PRODUCTION REPORTING
                 DEAL ID TO BE POPULATED INSTAED OF BBC ID
                 PARCEL ID TO BE MADE WITH RUNNING SEQ I.E. CUST ID || SEQ || PC
                 COLLATERAL APPROACH TO BE MADE TRANSACTIONAL INSTEAD OF FACILITY
                 TP REF ID TO BE POPULATED
                 TP SYSTEM CODE MANIPULATION MADE TO READ FROM MAP_INFO TABLE */
              IF ( is_valid_data ) THEN

                 INSERT INTO SCBT_T_IPS_CAGG_FEED_MST(
                            BANK_GROUP_CODE
                           , CTY_CODE
                           , CUST_ID
                           , COLLATERAL_ID
                           , DEAL_ID
                           , PARCEL_ID
                           , REC_ID
                           , BUSINESS_DATE
                           , SECURITY_VALUATION_DATE
                           , SOURCE_SYSTEM_CODE
                           , SECURITY_TYPE
                           , SECURITY_SUBTYPE
                           , COLLATERAL_APPROACH
                           , PRODUCT_CODE
                           , IS_SECURITY_PERFECTED
                           , MATURITY_DATE
                           , EFFECTIVE_DATE
                           , SECURITY_PERFECTION_DATE
                           , STORAGE_CTY_CODE
                           , BOOKING_LOC_CTY_CODE
                           , CMV_CCY_CODE
                           , CMV_CCY_AMT
                           , SCI_LEID
                           , TP_SYSTEM_CODE
                           , SCI_LIMIT_ID
                           , SECURITY_ID
                           , TXN_REF_ID
                           , CAGG_CATURED_TYPE
                           , USD_CMV_AMT
                           , FSV_PCT
                           , FSV_VALUE
                           , FSV_OVERRIDE_FLAG)
                       VALUES(
                           bankGroupCode
                           , ctyCode
                           , custId
                           , bbtl_certificate_id
                           , facilityLimitIdList(facilityLimitIndex)
                           , CONCAT(CONCAT(custId, bbc_run_seq), 'PC')
                           , recordID || LPAD(runningSeq,8,'0')
                           , bussDate
                           , bussDate
                           , 'CCA'
                           , securityType
                           , securitySubType
                           , 'F'
                           , prodCode
                           , 'Y'
                           , bbtl_extended_expiry_date
                           , bbtl_certificate_date
                           , bbtl_certificate_date
                           , ctyCode --collStorageLoc(commodityIndex)
                           , ctyCode
                           , custExpCcy --ccyCodeForCMV
                           , actualCMVAmount
                           , custLEID
                           , v_tp_sys_code
                           , temp_ext_limit_id --txnProdCodeList(txnLimitIDIndex)
                           , security_id
                           , ctyCode --for new OBU changes, txn ref id defaulted to ctycode
                           , 'CAGG_BBTL_COLL'
                           , v_usd_cmv_amt
                           , fsvPct
                           , fsvValue
                           , fsvOverrideFlag);


                           COMMIT;
                       ELSE
                         --2012-08-21 Requested by Pramod and Sunil i revert exceptional security sub type logic
                         IF ( (actualCMVAmount is null or actualCMVAmount <=0) ) THEN
                            GOTO SKIP_TXN_LOOP;
                         END IF;

                         INSERT INTO SCBT_T_IPS_CAGG_FEED_MST_ERR (
                              BANK_GROUP_CODE
                              , CTY_CODE
                              , CUST_ID
                              , COLLATERAL_ID
                              , DEAL_ID
                              , PARCEL_ID
                              , REC_ID
                              , BUSINESS_DATE
                              , SECURITY_VALUATION_DATE
                              , SOURCE_SYSTEM_CODE
                              , SECURITY_TYPE
                              , SECURITY_SUBTYPE
                              , COLLATERAL_APPROACH
                              , PRODUCT_CODE
                              , IS_SECURITY_PERFECTED
                              , MATURITY_DATE
                              , EFFECTIVE_DATE
                              , SECURITY_PERFECTION_DATE
                              , STORAGE_CTY_CODE
                              , BOOKING_LOC_CTY_CODE
                              , CMV_CCY_CODE
                              , CMV_CCY_AMT
                              , SCI_LEID
                              , TP_SYSTEM_CODE
                              , SCI_LIMIT_ID
                              , SECURITY_ID
                              , ERROR_MESSAGE
                              , securitySubTypeDesc
                              , TXN_REF_ID
                              , CAGG_CATURED_TYPE
                              , USD_CMV_AMT
                              , FSV_PCT
                              , FSV_VALUE
                              , FSV_OVERRIDE_FLAG)
                          VALUES(
                              bankGroupCode
                              , ctyCode
                              , custId
                              , bbtl_certificate_id
                              , facilityLimitIdList(facilityLimitIndex)
                              , CONCAT(CONCAT(custId, bbc_run_seq), 'PC')
                              , recordID || LPAD(runningSeq,8,'0')
                              , bussDate
                              , bussDate
                              , 'CCA'
                              , NVL(securityTypeParam, securityType)  --securityType
                              , NVL(securitySubTypeParam, securitySubType)  --securitySubType
                              , 'F'
                              , prodCode
                              , 'Y'
                              , bbtl_extended_expiry_date
                              , bbtl_certificate_date
                              , bbtl_certificate_date
                              , ctyCode
                              , ctyCode
                              , custExpCcy --ccyCodeForCMV
                              , actualCMVAmount
                              , custLEID
                              , v_tp_sys_code
                              , temp_ext_limit_id --txnProdCodeList(txnLimitIDIndex)
                              , security_id
                              , custom_error_mesg
                              , securitySubTypeDescParam
                              , ctyCode --for new OBU changes, txn ref id defaulted to ctycode
                              , 'CAGG_BBTL_COLL_ERR'
                              , v_usd_cmv_amt
                              , fsvPct
                              , fsvValue
                              , fsvOverrideFlag);
                           <<SKIP_TXN_LOOP>>
                              NULL;
                       END IF;
                       COMMIT;
                    EXCEPTION
                       WHEN OTHERS THEN
                        dbms_output.put_line(recordID|| '**BBTL**' || LPAD(runningSeq,8,'0') || 'error while insert records...' || SQLERRM);
                         NULL;
                    END;

                 END LOOP;
              END;
              END LOOP;

   -- COMMIT;

   END SCBP_P_BBTL_COLL_AGGR_FEED_EXT;


-- COCOACR_24SEP2013
FUNCTION SCBF_GET_SCI_LIMIT_ID (
   v_bank_grp_code   IN   VARCHAR2,
   v_cty_code        IN   VARCHAR2,
   v_cust_id         IN   VARCHAR2,
   v_limit_id        IN   VARCHAR2,
   v_cust_leid       IN   VARCHAR2
)
   RETURN VARCHAR2
IS
      v_sci_limit_id      varchar2(16);
      TYPE extlimitidtype IS TABLE OF SCBT_R_CUST_PRODUCT_LIMIT.ext_limit_id%TYPE INDEX BY PLS_INTEGER;
      extlimitidlist      extlimitidtype;
BEGIN
   BEGIN
      SELECT     ext_limit_id
      BULK COLLECT INTO extlimitidlist
            FROM SCBT_R_CUST_PRODUCT_LIMIT
      START WITH limit_id = v_limit_id
      CONNECT BY NOCYCLE PRIOR inner_to_id = ext_limit_id
             AND bank_group_code = v_bank_grp_code
             AND cty_code = v_cty_code
             AND cust_id = v_cust_id
        ORDER BY LEVEL ASC;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;
   v_sci_limit_id := null;
   FOR scilimitindex IN 1..extlimitidlist.COUNT
   LOOP
      IF v_sci_limit_id IS NULL THEN
         BEGIN
              SELECT lmt_id INTO v_sci_limit_id
              FROM SCBT_T_IPS_SCI_APPR_LIMITS
              WHERE lmt_le_id = v_cust_leid
              AND lmt_id = extlimitidlist(scilimitindex);
         EXCEPTION
            WHEN OTHERS THEN
               v_sci_limit_id := NULL;
         END;
      END IF;
   END LOOP;
   --IF extlimitidlist IS NOT NULL AND extlimitidlist.COUNT>0 AND v_sci_limit_id IS NULL  THEN
   --   v_sci_limit_id := extlimitidlist(1);
   --END IF;

   RETURN v_sci_limit_id;
END SCBF_GET_SCI_LIMIT_ID;



END SCBK_P_CAGG_FEED; 
/
