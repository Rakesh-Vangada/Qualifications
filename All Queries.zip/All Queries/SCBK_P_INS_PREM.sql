CREATE OR REPLACE PACKAGE body COCOOWNER.SCBK_P_INS_PREM
IS
function SCBF_TLS_EXCH_RATE(BankGroupCode in varchar2,
                                              CtyCode       in varchar2,
                                              FromCcyCode   in varchar2,
                                              FromAmt       in number,
                                              ToCcyCode     in varchar2,
                                              RoundFlag     in varchar2)
  return number is
  Result       number := 0.0;
  BaseCcyCode  SCBT_R_LIMIT_FX_RATE_MST.base_ccy_code%type;
  Leg1Rate     number;
  Leg2Rate     number;
  ToCcyDecNo   integer;
begin

  if FromCcyCode = ToCcyCode Or FromAmt = 0 then
     Result := FromAmt;
     return Result;
  end if;

  BEGIN
      select decode(fx_ccy_code, FromCcyCode, multiplying_factor, 1.0),
             decode(fx_ccy_code, ToCcyCode, multiplying_factor, 1.0),
             base_ccy_code,
             decode(fx_ccy_code,
                    FromCcyCode,
                    base_ccy_decimal_no,
                    fx_ccy_decimal_no)
        into Leg1Rate, Leg2Rate, BaseCcyCode, ToCcyDecNo
        from SCBT_R_LIMIT_FX_RATE_MST
       where bank_group_code = BankGroupCode
         and cty_code = CtyCode
         and ((fx_ccy_code = FromCcyCode And fx_ccy_code <> base_ccy_code) Or
             (base_ccy_code = FromCcyCode And fx_ccy_code = ToCcyCode));
  EXCEPTION
           WHEN NO_DATA_FOUND THEN
                Leg1Rate := 0;
                Leg2Rate := 1;
                BaseCcyCode := '';
  END;

  if BaseCcyCode <> ToCcyCode And BaseCcyCode <> FromCcyCode then
    /* Foreign to Foreign Coversion, read the second leg */
    select multiplying_factor, fx_ccy_decimal_no
      into Leg2Rate, ToCcyDecNo
      from SCBT_R_LIMIT_FX_RATE_MST
     where bank_group_code = BankGroupCode
       and cty_code = CtyCode
       and fx_ccy_code = ToCcyCode;
  end if;

  Result := FromAmt * Leg1Rate / Leg2Rate;

  if RoundFlag = 'Y' then
    Result := round(Result, nvl(ToCcyDecNo,2));
  end if;
  return(Result);
end SCBF_TLS_EXCH_RATE;



FUNCTION SCBF_GET_INV_INS_UOM_DATE(p_bankGroupCode VARCHAR2,
                                   p_ctyCode       VARCHAR2,
                                   p_custId        VARCHAR2,
                                   p_inv_id        VARCHAR2,
                                   p_dealId        VARCHAR2,
                                   p_from_date     VARCHAR2,
                                   p_to_date       VARCHAR2) RETURN VARCHAR2
IS

  v_qnty_uom SCBT_T_INVENTORY_MST.COMMODITY_QNTY_UOM%TYPE;
  v_invQnty SCBT_T_INVENTORY_MST.COMMODITY_QNTY%TYPE;
  v_value SCBT_R_PARAM_DATA.PARAM_DATA_01%TYPE;

  CURSOR child_inv IS
  SELECT INVENTORY_ID,
         NET_COMMODITY_QNTY,
         NET_COMMODITY_QNTY_UOM
    FROM SCBT_T_INVENTORY_MST inv
   WHERE BANK_GROUP_CODE = p_bankGroupCode
     AND CTY_CODE        = p_ctyCode
     AND CUST_ID         = p_custId
     AND DEAL_ID  = p_dealId
     AND INV.FIRST_COLLATERAL_DATE <=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')
     AND ((GOODS_IN_TYPE_CODE                                        = 'T'
     AND repurchase_date                                            IS NULL )
         OR (inv.Inventory_Type_Code                                 ='REL' AND INV.REPURCHASE_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS') ))
     AND INVENTORY_ID                                               <> p_inv_id
  START WITH INVENTORY_ID                                       = p_inv_id
  CONNECT BY PRIOR INVENTORY_ID                                 = LINK_INVENTORY_ID;

BEGIN

  v_invQnty := 0;

  SELECT NET_COMMODITY_QNTY_UOM
    INTO v_qnty_uom
    FROM SCBT_T_INVENTORY_MST
   WHERE BANK_GROUP_CODE = p_bankGroupCode
     AND CTY_CODE          = p_ctyCode
     AND INVENTORY_ID      = p_inv_id;

  FOR I1   IN child_inv LOOP

    IF I1.NET_COMMODITY_QNTY_UOM <> v_qnty_uom THEN
      v_value                    := Scbf_C_Get_Param_Data('UC01', '01', p_bankGroupCode, p_ctyCode, '*', '*', I1.NET_COMMODITY_QNTY_UOM, v_qnty_uom, '*', '*', '', '', '', '', '', '');
      v_invQnty                  := I1.NET_COMMODITY_QNTY_UOM * v_value;
    ELSE
      v_invQnty := v_invQnty + I1.NET_COMMODITY_QNTY;
    END IF;

  END LOOP;

  RETURN(v_invQnty);

END SCBF_GET_INV_INS_UOM_DATE;

/*********************************************************************************************************************************/

FUNCTION scbf_inv_max_repurchase_date(p_bankGroupCode VARCHAR2,
                                      p_ctyCode       VARCHAR2,
                                      p_custId        VARCHAR2,
                                      p_inv_id        VARCHAR2,
                                      p_dealId        VARCHAR2,
                                      p_to_date       VARCHAR2,
                                      p_ins_sess_id   VARCHAR2,
                                      p_repurchase_date date) RETURN DATE
IS

  prem_end_date SCBT_T_INS_PRE_TMP.REPURCHASE_DATE%TYPE;

BEGIN

  prem_end_date :=p_repurchase_date;

  SELECT distinct TMP.repurchase_date
    INTO prem_end_date
    FROM SCBT_T_INS_PRE_TMP TMP
   WHERE TMP.BANK_GROUP_CODE      =p_bankGroupCode
     AND TMP.CTY_CODE          =p_ctyCode
     AND TMP.CUST_ID           =p_custId
     AND TMP.DEAL_ID = p_dealId
     AND TMP.INVENTORY_ID      =p_inv_id
     AND TMP.INS_SESSION_ID    =p_ins_sess_id
     AND TMP.INS_PRE_TYPE      ='MAX';

  RETURN prem_end_date;

EXCEPTION

    WHEN OTHERS THEN
         dbms_output.put_line('Error'||SQLERRM);
         NULL;
    RETURN prem_end_date;

END scbf_inv_max_repurchase_date;

/*********************************************************************************************************************************/

FUNCTION scbf_inv_total_deal_value(p_bankGroupCode VARCHAR2,
                                   p_ctyCode       VARCHAR2,
                                   p_custId        VARCHAR2,
                                   p_inv_id        VARCHAR2,
                                   p_dealId        VARCHAR2,
                                   p_from_date     VARCHAR2,
                                   p_to_date       VARCHAR2,
                                   p_inv_qty       number,
                                   p_inv_UOM       VARCHAR2) RETURN DOUBLE PRECISION

IS

  total_deal_value DOUBLE PRECISION;
  v_deal_type_code Scbt_t_Sip_Deal_Smry_mst.Deal_Type_Code%TYPE;
  v_purchase_price_ccy_amt Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Ccy_Amt%type;
  v_purchase_price_ccy_code Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Ccy_Code%type;
  v_purchase_price_uom Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Uom%type;
  v_hedge_price_ccy_amt Scbt_t_Sip_Deal_Smry_mst.Hedge_Price_Ccy_Amt%type;
  v_hedge_price_ccy_code Scbt_t_Sip_Deal_Smry_mst.Hedge_Price_Ccy_Code%type;
  v_net_commodity_qty_uom  scbt_t_inventory_mst.net_commodity_qnty_uom%type;
  v_invQnty SCBT_T_INVENTORY_MST.NET_COMMODITY_QNTY%TYPE;
  v_value SCBT_R_PARAM_DATA.PARAM_DATA_01%TYPE;
  v_commodity_id scbt_r_commodity_dtls.COMMODITY_ID%type;
  v_commodity_price_id scbt_r_commodity_dtls.COMMODITY_PRICE_ID%type;

BEGIN
  total_deal_value :=0;
  v_invQnty :=0;

  SELECT SMST.DEAL_TYPE_CODE, SMST.PURCHASE_PRICE_CCY_AMT, SMST.PURCHASE_PRICE_CCY_CODE, SMST.PURCHASE_PRICE_UOM,
         INV.NET_COMMODITY_QNTY_UOM, SMST.HEDGE_PRICE_CCY_AMT, SMST.HEDGE_PRICE_CCY_CODE,
         COMM_DTLS.COMMODITY_ID, COMM_DTLS.COMMODITY_PRICE_ID
    INTO v_deal_type_code, v_purchase_price_ccy_amt, v_purchase_price_ccy_code, v_purchase_price_uom,
         v_net_commodity_qty_uom, v_hedge_price_ccy_amt, v_hedge_price_ccy_code,
         v_commodity_id, v_commodity_price_id
    FROM scbt_t_inventory_mst inv,
         scbt_t_deal_mst DM,
         Scbt_t_Sip_Deal_Smry_mst SMST,
         scbt_r_commodity_dtls comm_dtls,
         scbt_r_commodity_mst comm_mst,
         scbt_t_inventory_smry inv_smry
   WHERE inv.bank_group_code          = p_bankGroupCode
     AND inv.CTY_CODE                 = p_ctyCode
     AND inv.CUST_ID                  = p_custId
     AND inv.DEAL_ID      = p_dealId
     AND inv.inventory_id             = p_inv_id
     AND SMST.bank_group_code         = DM.BANK_GROUP_CODE
     AND SMST.cty_code                = DM.CTY_CODE
     AND SMST.deal_id    = DM.DEAL_ID
     AND SMST.cust_id                 = DM.CUST_ID
     --AND SMST.lateast_deal_step_id    = DM.LATEST_DEAL_STEP_ID
     AND inv_smry.BANK_GROUP_CODE     = inv.BANK_GROUP_CODE
     AND inv_smry.DEAL_ID = inv.DEAL_ID
     AND comm_mst.BANK_GROUP_CODE     = inv_smry.BANK_GROUP_CODE
     AND comm_mst.COMMODITY_ID        = inv_smry.COMMODITY_ID
     AND comm_dtls.COMMODITY_ID       = comm_mst.COMMODITY_ID
     AND comm_dtls.BANK_GROUP_CODE    = comm_mst.BANK_GROUP_CODE
     AND SMST.DEAL_ID    = INV.DEAL_ID
     AND SMST.INSURANCE_COVERED_BY='SCB';

 
    IF v_purchase_price_uom <> v_net_commodity_qty_uom THEN
       v_value    := Scbf_C_Get_Param_Data('UC01', '01', p_bankGroupCode, p_ctyCode, '*', '*', v_purchase_price_uom, v_net_commodity_qty_uom, '*', '*', '', '', '', '', '', '');
       v_invQnty  := v_invQnty + (p_inv_qty * v_value);
    ELSE
       v_invQnty := v_invQnty + p_inv_qty;
    END IF;

    --To calculate TOTAL_DEAL_VALUE
    IF v_deal_type_code IN ('EDHIP','CONT') THEN
     --  total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_purchase_price_ccy_code, v_invQnty * v_purchase_price_ccy_amt,'USD','Y');
     total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_hedge_price_ccy_code, v_invQnty * v_hedge_price_ccy_amt,'USD','Y');
    ELSE
       total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_purchase_price_ccy_code, v_invQnty * Scbf_Get_Market_Price(p_bankGroupCode, p_ctyCode,v_commodity_id, v_commodity_price_id, NULL),'USD','Y');
    END IF;

  RETURN total_deal_value;

EXCEPTION

   WHEN OTHERS THEN
        NULL;
   RETURN total_deal_value;

END scbf_inv_total_deal_value;











FUNCTION scbf_inv_total_deal_value_NEW(p_bankGroupCode VARCHAR2,
                                   p_ctyCode       VARCHAR2,
                                   p_custId        VARCHAR2,
                                   p_inv_id        VARCHAR2,
                                   p_dealId        VARCHAR2,
                                   p_from_date     VARCHAR2,
                                   p_to_date       VARCHAR2,
                                   p_inv_qty       number,
                                   p_inv_UOM       VARCHAR2,
                                   p_inv_deal_step_id VARCHAR2) RETURN DOUBLE PRECISION

IS

  total_deal_value DOUBLE PRECISION;
  v_deal_type_code Scbt_t_Sip_Deal_Smry_mst.Deal_Type_Code%TYPE;
  v_purchase_price_ccy_amt Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Ccy_Amt%type;
  v_purchase_price_ccy_code Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Ccy_Code%type;
  v_purchase_price_uom Scbt_t_Sip_Deal_Smry_mst.Purchase_Price_Uom%type;
  v_hedge_price_ccy_amt Scbt_t_Sip_Deal_Smry_mst.Hedge_Price_Ccy_Amt%type;
  v_hedge_price_ccy_code Scbt_t_Sip_Deal_Smry_mst.Hedge_Price_Ccy_Code%type;
  v_net_commodity_qty_uom  scbt_t_inventory_mst.net_commodity_qnty_uom%type;
  v_invQnty SCBT_T_INVENTORY_MST.NET_COMMODITY_QNTY%TYPE;
  v_value SCBT_R_PARAM_DATA.PARAM_DATA_01%TYPE;
  v_commodity_id scbt_r_commodity_dtls.COMMODITY_ID%type;
  v_commodity_price_id scbt_r_commodity_dtls.COMMODITY_PRICE_ID%type;

BEGIN
  total_deal_value :=0;
  v_invQnty :=0;

  SELECT SMST.DEAL_TYPE_CODE, SMST.PURCHASE_PRICE_CCY_AMT, SMST.PURCHASE_PRICE_CCY_CODE, SMST.PURCHASE_PRICE_UOM,
         INV.NET_COMMODITY_QNTY_UOM, SMST.HEDGE_PRICE_CCY_AMT, SMST.HEDGE_PRICE_CCY_CODE,
         COMM_DTLS.COMMODITY_ID, COMM_DTLS.COMMODITY_PRICE_ID
    INTO v_deal_type_code, v_purchase_price_ccy_amt, v_purchase_price_ccy_code, v_purchase_price_uom,
         v_net_commodity_qty_uom, v_hedge_price_ccy_amt, v_hedge_price_ccy_code,
         v_commodity_id, v_commodity_price_id
    FROM SCBT_T_INVENTORY_SNAPSHOT inv,
         scbt_t_deal_mst DM,
         Scbt_t_Sip_Deal_Smry_mst SMST,
         scbt_r_commodity_dtls comm_dtls,
         scbt_r_commodity_mst comm_mst,
         scbt_t_inventory_smry inv_smry
   WHERE inv.bank_group_code          = p_bankGroupCode
     AND inv.CTY_CODE                 = p_ctyCode
     AND inv.CUST_ID                  = p_custId
     AND inv.DEAL_ID      = p_dealId
     AND inv.inventory_id             = p_inv_id
     AND SMST.bank_group_code         = DM.BANK_GROUP_CODE
     AND SMST.cty_code                = DM.CTY_CODE
     AND SMST.deal_id    = DM.DEAL_ID
     AND SMST.cust_id                 = DM.CUST_ID
     and inv.deal_step_id=p_inv_deal_step_id
     --AND SMST.lateast_deal_step_id    = DM.LATEST_DEAL_STEP_ID
     AND inv_smry.BANK_GROUP_CODE     = inv.BANK_GROUP_CODE
     AND inv_smry.DEAL_ID = inv.DEAL_ID
     AND comm_mst.BANK_GROUP_CODE     = inv_smry.BANK_GROUP_CODE
     AND comm_mst.COMMODITY_ID        = inv_smry.COMMODITY_ID
     AND comm_dtls.COMMODITY_ID       = comm_mst.COMMODITY_ID
     AND comm_dtls.BANK_GROUP_CODE    = comm_mst.BANK_GROUP_CODE
     AND SMST.DEAL_ID    = INV.DEAL_ID
     AND SMST.INSURANCE_COVERED_BY='SCB';

 
    IF v_purchase_price_uom <> v_net_commodity_qty_uom THEN
       v_value    := Scbf_C_Get_Param_Data('UC01', '01', p_bankGroupCode, p_ctyCode, '*', '*', v_purchase_price_uom, v_net_commodity_qty_uom, '*', '*', '', '', '', '', '', '');
       v_invQnty  := v_invQnty + (p_inv_qty * v_value);
    ELSE
       v_invQnty := v_invQnty + p_inv_qty;
    END IF;

    --To calculate TOTAL_DEAL_VALUE
    IF v_deal_type_code IN ('EDHIP','CONT') THEN
     --  total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_purchase_price_ccy_code, v_invQnty * v_purchase_price_ccy_amt,'USD','Y');
     total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_hedge_price_ccy_code, v_invQnty * v_hedge_price_ccy_amt,'USD','Y');
    ELSE
       total_deal_value := SCBF_TLS_EXCH_RATE(p_bankGroupCode, p_ctyCode, v_purchase_price_ccy_code, v_invQnty * Scbf_Get_Market_Price(p_bankGroupCode, p_ctyCode,v_commodity_id, v_commodity_price_id, NULL),'USD','Y');
    END IF;

  RETURN total_deal_value;

EXCEPTION

   WHEN OTHERS THEN
        NULL;
   RETURN total_deal_value;

END scbf_inv_total_deal_value_NEW;

/*********************************************************************************************************************************/

PROCEDURE SCBP_INS_PRE_CALC(p_INS_SESS_ID VARCHAR2,
                            p_from_date   VARCHAR2,
                            p_to_date     VARCHAR2)
IS

  TYPE typBankGroupCode       IS TABLE OF scbt_t_inventory_MST.Bank_Group_Code%TYPE INDEX BY PLS_INTEGER;
  TYPE typCtyCode             IS TABLE OF scbt_t_inventory_MST.CTY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE typCustID              IS TABLE OF scbt_t_inventory_MST.CUST_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typDealID              IS TABLE OF scbt_t_inventory_MST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typStorageLocation     IS TABLE OF scbt_t_inventory_MST.Storage_Location_Id%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryID         IS TABLE OF scbt_t_inventory_MST.inventory_id%TYPE INDEX BY PLS_INTEGER;
  TYPE typLinkInventoryID     IS TABLE OF scbt_t_inventory_MST.LINK_INVENTORY_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryTypeCode   IS TABLE OF scbt_t_inventory_MST.inventory_type_code%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryStatusCode IS TABLE OF scbt_t_inventory_MST.inventory_status_code%TYPE INDEX BY PLS_INTEGER;
  TYPE typNetCommodityQntyUOM IS TABLE OF scbt_t_inventory_MST.Net_Commodity_Qnty_Uom%TYPE INDEX BY PLS_INTEGER;
  TYPE typNetCommodityQnty    IS TABLE OF scbt_t_inventory_MST.NET_COMMODITY_QNTY%TYPE INDEX BY PLS_INTEGER;
  TYPE typRepurchaseDate      IS TABLE OF scbt_t_inventory_MST.COMMODITY_ID%TYPE INDEX BY PLS_INTEGER;
  --TYPE typCommodityId         IS TABLE OF scbt_t_inventory_MST.Commodity_Id%TYPE INDEX BY PLS_INTEGER;
  --TYPE typFlag                IS TABLE OF scbt_t_inventory_MST.Document_Ref_No%TYPE INDEX BY PLS_INTEGER;
  TYPE typCollateralDate      IS TABLE OF scbt_t_inventory_MST.first_collateral_date%TYPE INDEX BY PLS_INTEGER;
  --v_qnty_uom                  SCBT_T_INVENTORY_MST.COMMODITY_QNTY_UOM%TYPE;
  objMaxRepurchaseDate        scbt_t_inventory_MST.repurchase_date%TYPE;
  objchildRepurchaseDate      scbt_t_inventory_MST.repurchase_date%TYPE;
  objParentRepurchaseDate     scbt_t_inventory_MST.repurchase_date%TYPE;
  intExclude NUMBER;

  ObjtypBankGroupCode typBankGroupCode;
  ObjtypCtyCode typCtyCode;
  ObjtypCustID typCustID;
  ObjtypDealID typDealID;
  objStorageLocation typStorageLocation;
  ObjtypInventoryID typInventoryID;
  ObjIgnoreInventoryID typInventoryID;
  ObjtypLinkInventoryID typLinkInventoryID;
  ObjtypInventoryTypeCode typInventoryTypeCode;
  ObjtypInventoryStatusCode typInventoryStatusCode;
  ObjtypNetCommodityQntyUOM typNetCommodityQntyUOM;
  ObjtypNetCommodityQnty typNetCommodityQnty;
  ObjtypRepurchaseDate typRepurchaseDate;
  ObjtypHighestRepurchaseDate typRepurchaseDate;
  ObjtypCollateralDate typCollateralDate;
  v_prem_start_date SCBT_T_INS_PREM_CALC_TMP.PREM_START_DATE%TYPE;
  v_prem_end_date SCBT_T_INS_PREM_CALC_TMP.PREM_END_DATE%TYPE;
  --ObjtypCommodityId typCommodityId;
  NO_OF_Days number;

  --objtypeFlag typFlag;

  CURSOR INS_DTL IS
  SELECT 'ACTIVE' AS STATUS,inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id, inv.storage_location_id,
         inv.inventory_id, inv.link_inventory_id, inv.inventory_type_code, inv.inventory_status_code,
         inv.net_commodity_qnty_uom,
        (inv.NET_COMMODITY_QNTY- SCBK_P_INS_PREM.SCBF_GET_INV_INS_UOM_DATE (inv.BANK_GROUP_CODE,inv.CTY_CODE,inv.CUST_ID,inv.INVENTORY_ID,inv.DEAL_ID,p_from_date,p_to_date)) as qty,
         inv.repurchase_date, inv.first_collateral_date, inv.commodity_id
    FROM scbt_t_inventory_MST inv,
         scbt_t_sip_deal_smry_mst SMST
   WHERE inv.BANK_GROUP_CODE      = SMST.BANK_GROUP_CODE
     AND inv.CTY_CODE               = SMST.CTY_CODE
     AND inv.goods_in_type_code     = 'S'
     AND inv.inventory_type_code    = 'MST'
     AND inv.first_collateral_date <= TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS')
     AND inventory_id NOT IN (SELECT inventory_id
                                FROM scbt_t_ins_pre_tmp tmp
                               WHERE tmp.bank_group_code = inv.bank_group_code
                                 AND tmp.cty_code          = inv.cty_code
                                 AND tmp.cust_id           = inv.cust_id
                                 AND tmp.deal_id           = inv.deal_id
                                 AND tmp.ins_pre_type      = 'EXC'
                                 AND tmp.ins_session_id    = 1 )
     AND SMST.DEAL_ID                 = INV.DEAL_ID
     AND INV.BANK_GROUP_CODE=SMST.BANK_GROUP_CODE
     AND INV.CTY_CODE=SMST.CTY_CODE
     AND ((INV.FIRST_COLLATERAL_DATE>=to_date(p_from_date,'YYYY-MM-DD HH24:MI:SS') and
          INV.FIRST_COLLATERAL_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')))
     AND SMST.INSURANCE_COVERED_BY='SCB'
  UNION
  SELECT 'ACTIVE' AS STATUS,inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id, inv.storage_location_id,
         inv.inventory_id, inv.link_inventory_id, inv.inventory_type_code, inv.inventory_status_code,
         inv.net_commodity_qnty_uom, inv.NET_COMMODITY_QNTY as qty, inv.repurchase_date, inv.first_collateral_date, inv.commodity_id
    FROM scbt_t_inventory_MST inv,
         scbt_t_sip_deal_smry_mst SMST
   WHERE inv.BANK_GROUP_CODE        = SMST.BANK_GROUP_CODE
     AND inv.CTY_CODE               = SMST.CTY_CODE
     AND inv.goods_in_type_code     = 'S'
     AND inv.inventory_type_code    = 'MST'
     AND SMST.DEAL_ID  = INV.DEAL_ID
     AND INV.BANK_GROUP_CODE=SMST.BANK_GROUP_CODE
     AND INV.CTY_CODE=SMST.CTY_CODE
     AND inv.inventory_status_code in ('01','02')
     AND INV.FIRST_COLLATERAL_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')
     AND inv.inventory_id not in ( SELECT INVENTORY_ID
                                     FROM scbt_t_inventory_MST inv, scbt_t_sip_deal_smry_mst SMST
                                    WHERE inv.BANK_GROUP_CODE      = SMST.Bank_Group_Code
                                      AND inv.CTY_CODE             = SMST.Cty_Code
                                      AND inv.goods_in_type_code   = 'S'
                                      AND inv.inventory_type_code  = 'MST'
                                      AND inventory_id NOT IN (SELECT inventory_id
                                                                 FROM scbt_t_ins_pre_tmp tmp
                                                                WHERE tmp.bank_group_code = inv.bank_group_code
                                                                  AND tmp.cty_code          = inv.cty_code
                                                                  AND tmp.cust_id           = inv.cust_id
                                                                  AND tmp.deal_id = inv.deal_id
                                                                  AND tmp.ins_pre_type      = 'EXC'
                                                                  AND tmp.ins_session_id    = 1 )
     AND SMST.DEAL_ID = INV.DEAL_ID
     AND INV.BANK_GROUP_CODE       = SMST.BANK_GROUP_CODE
     AND INV.CTY_CODE              = SMST.CTY_CODE
     AND ((INV.FIRST_COLLATERAL_DATE>=to_date(p_from_date,'YYYY-MM-DD HH24:MI:SS') AND
           INV.FIRST_COLLATERAL_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS'))))
           AND SMST.INSURANCE_COVERED_BY='SCB'
   UNION
   
   SELECT 'ACTIVE' AS STATUS,inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id, inv.storage_location_id,
         inv.inventory_id, inv.link_inventory_id, inv.inventory_type_code, inv.inventory_status_code,
         inv.net_commodity_qnty_uom, inv.NET_COMMODITY_QNTY as qty, inv.repurchase_date, inv.first_collateral_date, inv.commodity_id
    FROM scbt_t_inventory_MST inv,
         scbt_t_sip_deal_smry_mst SMST
   WHERE inv.BANK_GROUP_CODE        = SMST.BANK_GROUP_CODE
     AND inv.CTY_CODE               = SMST.CTY_CODE
     AND inv.goods_in_type_code     = 'S'
     AND inv.inventory_type_code    = 'MST'
     AND SMST.DEAL_ID  = INV.DEAL_ID
     AND INV.BANK_GROUP_CODE=SMST.BANK_GROUP_CODE
     AND INV.CTY_CODE=SMST.CTY_CODE
     AND inv.inventory_status_code in ('03')
     and smst.deal_status_code='DCL'
     
     AND INV.FIRST_COLLATERAL_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')
     AND inv.inventory_id not in ( SELECT INVENTORY_ID
                                     FROM scbt_t_inventory_MST inv, scbt_t_sip_deal_smry_mst SMST
                                    WHERE inv.BANK_GROUP_CODE      = SMST.Bank_Group_Code
                                      AND inv.CTY_CODE             = SMST.Cty_Code
                                      AND inv.goods_in_type_code   = 'S'
                                      AND inv.inventory_type_code  = 'MST'
                                      AND inventory_id NOT IN (SELECT inventory_id
                                                                 FROM scbt_t_ins_pre_tmp tmp
                                                                WHERE tmp.bank_group_code = inv.bank_group_code
                                                                  AND tmp.cty_code          = inv.cty_code
                                                                  AND tmp.cust_id           = inv.cust_id
                                                                  AND tmp.deal_id = inv.deal_id
                                                                  AND tmp.ins_pre_type      = 'EXC'
                                                                  AND tmp.ins_session_id    = 1 )
     AND SMST.DEAL_ID = INV.DEAL_ID
     AND INV.BANK_GROUP_CODE       = SMST.BANK_GROUP_CODE
     AND INV.CTY_CODE              = SMST.CTY_CODE
     AND ((INV.FIRST_COLLATERAL_DATE>=to_date(p_from_date,'YYYY-MM-DD HH24:MI:SS') AND
           INV.FIRST_COLLATERAL_DATE<=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS'))))
     AND INV.REPURCHASE_DATE>to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')
           AND SMST.INSURANCE_COVERED_BY='SCB';
       
           
          
           
            
           
     

BEGIN

  --v_qnty_uom := 0;
  BEGIN

    DELETE FROM SCBT_T_INS_PRE_TMP TMP WHERE TMP.INS_SESSION_ID=p_INS_SESS_ID;

    COMMIT;

    SELECT INV.BANK_GROUP_CODE,
           INV.CTY_CODE,
           INV.CUST_ID,
           INV.DEAL_ID,
           INV.STORAGE_LOCATION_ID,
           inv.inventory_id,
           LINK_INVENTORY_ID,
           inv.inventory_type_code,
           inv.inventory_status_code,
           inv.Net_Commodity_Qnty_Uom,
          (INV.NET_COMMODITY_QNTY - SCBF_GET_INV_INS_UOM_DATE (INV.BANK_GROUP_CODE,INV.CTY_CODE,INV.CUST_ID,INV.INVENTORY_ID,INV.DEAL_ID,p_from_date,p_to_Date)) AS QTY,
           inv.repurchase_date,
           inv.first_collateral_date BULK COLLECT
      INTO ObjtypBankGroupCode,
           ObjtypCtyCode,
           ObjtypCustID,
           ObjtypDealID,
           objStorageLocation,
           ObjtypInventoryID,
           ObjtypLinkInventoryID,
           ObjtypInventoryTypeCode,
           ObjtypInventoryStatusCode,
           ObjtypNetCommodityQntyUOM,
           ObjtypNetCommodityQnty ,
           ObjtypRepurchaseDate ,
           ObjtypCollateralDate
      FROM scbt_t_inventory_MST inv,
           scbt_t_sip_deal_smry_mst SMST
     WHERE SMST.DEAL_ID = INV.DEAL_ID
       AND inv.goods_in_type_code    ='S'
       AND (INV.LINK_INVENTORY_ID IS NOT NULL OR INV.INVENTORY_ID IN (SELECT LINK_INVENTORY_ID FROM SCBT_T_INVENTORY_MST))
       AND INV.BANK_GROUP_CODE       = SMST.BANK_GROUP_CODE
       AND INV.CTY_CODE              = SMST.CTY_CODE
       AND SMST.INSURANCE_COVERED_BY = SMST.BANK_GROUP_CODE
       AND INV.FIRST_COLLATERAL_DATE>=to_date(p_from_Date,'YYYY-MM-DD HH24:MI:SS')
       AND INV.FIRST_COLLATERAL_DATE<=to_date(p_TO_Date,'YYYY-MM-DD HH24:MI:SS');

  EXCEPTION
      WHEN OTHERS THEN
           NULL;
      END;

  IF ObjtypBankGroupCode.COUNT > 0 THEN

     FOR i  IN 1 ..ObjtypBankGroupCode.COUNT LOOP

      BEGIN

        SELECT INVENTORY_ID ,
               INV.REPURCHASE_DATE BULK COLLECT
          INTO ObjIgnoreInventoryID ,
               ObjtypHighestRepurchaseDate
          FROM SCBT_T_INVENTORY_MST inv
        WHERE BANK_GROUP_CODE             = ObjtypBankGroupCode(i)
          AND CTY_CODE                    = ObjtypCtyCode(i)
          AND CUST_ID                     = ObjtypCustID(i)
          AND DEAL_ID        = ObjtypDealID(i)
          AND INV.STORAGE_LOCATION_ID     = objStorageLocation(i)
          AND INV.NET_COMMODITY_QNTY_UOM  = ObjtypNetCommodityQntyUOM(i)
          AND (INV.NET_COMMODITY_QNTY - SCBF_GET_INV_INS_UOM_DATE (INV.BANK_GROUP_CODE,INV.CTY_CODE,INV.CUST_ID,INV.INVENTORY_ID,INV.DEAL_ID,p_from_Date,p_to_Date)) = ObjtypNetCommodityQnty(i)
          AND INV.FIRST_COLLATERAL_DATE  <=to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS')
          AND INVENTORY_ID               <> ObjtypInventoryID(i)
          AND INVENTORY_ID NOT IN (SELECT INVENTORY_ID
                                     FROM SCBT_T_INS_PRE_TMP TMP
                                    WHERE TMP.BANK_GROUP_CODE  = INV.BANK_GROUP_CODE
                                      AND TMP.CTY_CODE         = INV.CTY_CODE
                                      AND TMP.CUST_ID          = INV.CUST_ID
                                      AND TMP.DEAL_ID = INV.DEAL_ID
                                      AND TMP.INS_PRE_TYPE     = 'EXC'
                                      AND TMP.INS_SESSION_ID   = p_INS_SESS_ID)
          START WITH INVENTORY_ID       = ObjtypInventoryID(i)
          CONNECT BY PRIOR INVENTORY_ID = LINK_INVENTORY_ID;

      EXCEPTION

         WHEN OTHERS THEN
              NULL;
         END;

      objMaxRepurchaseDate   :=NVL(ObjtypRepurchaseDate(i),to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS'));
      objParentRepurchaseDate:=NVL(ObjtypRepurchaseDate(i),to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS'));
      intExclude             :=0;

      FOR j IN 1 ..ObjIgnoreInventoryID.COUNT LOOP

        objchildRepurchaseDate   :=NVL(ObjtypHighestRepurchaseDate(j),to_date(p_to_date,'YYYY-MM-DD HH24:MI:SS'));

        IF (objchildRepurchaseDate>objMaxRepurchaseDate) THEN
            objMaxRepurchaseDate   :=objchildRepurchaseDate;
        END IF;

        INSERT INTO SCBT_T_INS_PRE_TMP VALUES ( ObjtypBankGroupCode(i),
                                                ObjtypCtyCode(i),
                                                ObjtypCustID(i),
                                                ObjtypDealID(i),
                                                ObjIgnoreInventoryID(j),
                                                ObjtypInventoryID(i),
                                                '',
                                                '',
                                                'EXC',
                                                p_INS_SESS_ID);

        COMMIT;

        intExclude:=1;

      END LOOP;

      IF ( objMaxRepurchaseDate>=objParentRepurchaseDate AND intExclude=1 ) THEN

           INSERT INTO SCBT_T_INS_PRE_TMP VALUES (ObjtypBankGroupCode(i),
                                                  ObjtypCtyCode(i),
                                                  ObjtypCustID(i),
                                                  ObjtypDealID(i),
                                                  ObjtypInventoryID(i),
                                                  ObjtypLinkInventoryID(i),
                                                  objMaxRepurchaseDate,
                                                  '',
                                                  'MAX',
                                                  p_INS_SESS_ID);

           COMMIT;

      END IF;

     END LOOP;

   END IF;

   BEGIN

    DELETE FROM SCBT_T_INS_PREM_CALC_TMP WHERE INS_SESSION_ID=p_INS_SESS_ID;

    COMMIT;

    EXCEPTION
       WHEN OTHERS THEN
            NULL;
    END;

    FOR i IN INS_DTL LOOP

      BEGIN

        --Derive Prem Start Date
        BEGIN
            IF ((i.first_collateral_date >=TO_DATE (p_from_date, 'YYYY-MM-DD HH24:MI:SS')) AND
                (i.first_collateral_date <= TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS'))) THEN
                 v_prem_start_date := i.first_collateral_date;
            ELSE
                 v_prem_start_date :=TO_DATE (p_from_date, 'YYYY-MM-DD HH24:MI:SS');
            END IF;

        EXCEPTION

             WHEN OTHERS THEN
                  v_prem_start_date:=NULL;
             END;

        BEGIN
        --Derive Prem End Date

         v_prem_end_date:=scbf_inv_max_repurchase_date (i.bank_group_code, i.cty_code, i.cust_id, i.inventory_id, i.deal_id, p_to_date, p_ins_sess_id,i.repurchase_date);

         IF (v_prem_end_date IS  NULL) THEN
             v_prem_end_date   :=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
         END IF;

         IF (i.inventory_status_code in ('01','02')) THEN
             v_prem_end_date :=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
         END IF;

         IF (v_prem_end_date>TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS')) THEN
             v_prem_end_date:=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
         END IF;

         EXCEPTION
              WHEN OTHERS THEN
                   v_prem_end_date:=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
              END;
        -- number of days calculation
         IF (v_prem_end_date=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS')) then
             NO_OF_Days:=v_prem_end_date-v_prem_start_date+1;
         ELSE
             NO_OF_Days:=v_prem_end_date-v_prem_start_date;
         END IF;

         INSERT INTO SCBT_T_INS_PREM_CALC_TMP (BANK_GROUP_CODE, CTY_CODE, CUST_ID, DEAL_ID, INVENTORY_ID, LINK_INVENTORY_ID,
                                               PREM_END_DATE,  PREM_START_DATE, INS_PRE_TYPE,INS_SESSION_ID, STORAGE_LOCATION_ID,
                                               NET_COMMODITY_QNTY_UOM, QTY, FIRST_COLLATERAL_DATE,REPURCHASE_DATE,INVENTORY_TYPE_CODE,
                                               INVENTORY_STATUS_CODE, NO_OF_DAYS, TOTAL_DEAL_VALUE, WAREHOUSE, COMMODITY_ID)
                                       VALUES (i.bank_group_code,i.cty_code,i.cust_id,i.deal_id,i.inventory_id,i.link_inventory_id,
                                               v_prem_end_date,v_prem_start_date,null,p_ins_sess_id,i.storage_location_id,
                                               i.net_commodity_qnty_uom,i.QTY,i.first_collateral_date,i.repurchase_date,i.inventory_type_code,
                                               i.inventory_status_code,NO_OF_Days,
                                               scbf_inv_total_deal_value (i.bank_group_code, i.cty_code, i.cust_id, i.inventory_id, i.deal_id, p_to_date, p_from_date,i.qty,i.net_commodity_qnty_uom),
                                               ' ',i.commodity_id);
         COMMIT;

         END;

   END LOOP;

END SCBP_INS_PRE_CALC;





--------------------------------------------------------------------------------------------------------


PROCEDURE SCBP_INS_PRE_CALC_NEW(p_INS_SESS_ID VARCHAR2,
                            p_from_date   VARCHAR2,
                            p_to_date     VARCHAR2)
IS

  TYPE typBankGroupCode       IS TABLE OF scbt_t_inventory_MST.Bank_Group_Code%TYPE INDEX BY PLS_INTEGER;
  TYPE typCtyCode             IS TABLE OF scbt_t_inventory_MST.CTY_CODE%TYPE INDEX BY PLS_INTEGER;
  TYPE typCustID              IS TABLE OF scbt_t_inventory_MST.CUST_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typDealID              IS TABLE OF scbt_t_inventory_MST.DEAL_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typStorageLocation     IS TABLE OF scbt_t_inventory_MST.Storage_Location_Id%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryID         IS TABLE OF scbt_t_inventory_MST.inventory_id%TYPE INDEX BY PLS_INTEGER;
  TYPE typLinkInventoryID     IS TABLE OF scbt_t_inventory_MST.LINK_INVENTORY_ID%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryTypeCode   IS TABLE OF scbt_t_inventory_MST.inventory_type_code%TYPE INDEX BY PLS_INTEGER;
  TYPE typInventoryStatusCode IS TABLE OF scbt_t_inventory_MST.inventory_status_code%TYPE INDEX BY PLS_INTEGER;
  TYPE typNetCommodityQntyUOM IS TABLE OF scbt_t_inventory_MST.Net_Commodity_Qnty_Uom%TYPE INDEX BY PLS_INTEGER;
  TYPE typNetCommodityQnty    IS TABLE OF scbt_t_inventory_MST.NET_COMMODITY_QNTY%TYPE INDEX BY PLS_INTEGER;
  TYPE typRepurchaseDate      IS TABLE OF scbt_t_inventory_MST.COMMODITY_ID%TYPE INDEX BY PLS_INTEGER;
  --TYPE typCommodityId         IS TABLE OF scbt_t_inventory_MST.Commodity_Id%TYPE INDEX BY PLS_INTEGER;
  --TYPE typFlag                IS TABLE OF scbt_t_inventory_MST.Document_Ref_No%TYPE INDEX BY PLS_INTEGER;
  TYPE typCollateralDate      IS TABLE OF scbt_t_inventory_MST.first_collateral_date%TYPE INDEX BY PLS_INTEGER;
  --v_qnty_uom                  SCBT_T_INVENTORY_MST.COMMODITY_QNTY_UOM%TYPE;
  objMaxRepurchaseDate        scbt_t_inventory_MST.repurchase_date%TYPE;
  objchildRepurchaseDate      scbt_t_inventory_MST.repurchase_date%TYPE;
  objParentRepurchaseDate     scbt_t_inventory_MST.repurchase_date%TYPE;
  intExclude NUMBER;

  ObjtypBankGroupCode typBankGroupCode;
  ObjtypCtyCode typCtyCode;
  ObjtypCustID typCustID;
  ObjtypDealID typDealID;
  objStorageLocation typStorageLocation;
  ObjtypInventoryID typInventoryID;
  ObjIgnoreInventoryID typInventoryID;
  ObjtypLinkInventoryID typLinkInventoryID;
  ObjtypInventoryTypeCode typInventoryTypeCode;
  ObjtypInventoryStatusCode typInventoryStatusCode;
  ObjtypNetCommodityQntyUOM typNetCommodityQntyUOM;
  ObjtypNetCommodityQnty typNetCommodityQnty;
  ObjtypRepurchaseDate typRepurchaseDate;
  ObjtypHighestRepurchaseDate typRepurchaseDate;
  ObjtypCollateralDate typCollateralDate;
  v_prem_start_date SCBT_T_INS_PREM_CALC_TMP.PREM_START_DATE%TYPE;
  v_prem_end_date SCBT_T_INS_PREM_CALC_TMP.PREM_END_DATE%TYPE;
  --ObjtypCommodityId typCommodityId;
  NO_OF_Days number;

  --objtypeFlag typFlag;

  CURSOR INS_DTL IS
  

 
/*SELECT DISTINCT inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id, inv.storage_location_id,
         inv.inventory_id, inv.link_inventory_id, inv.inventory_type_code, inv.inventory_status_code,
         inv.net_commodity_qnty_uom, (NVL(inv.NET_COMMODITY_QNTY, 0) - NVL(inv.utilised_qnty, 0)) as qty, inv.repurchase_date, inv.first_collateral_date, inv.commodity_id,
         inv.deal_step_id
FROM SCBT_T_INVENTORY_SNAPSHOT inv,
  Scbt_t_Sip_Deal_Smry_Hst shist
 
WHERE
 inv.deal_step_id IN
(SELECT MAX(DEAL_STEP_ID)
          FROM SCBT_T_DEAL_HIST HI
         WHERE HI.BUSINESS_DATE <= TO_DATE(p_to_date, 'YYYY-MM-DD HH24:MI:SS')
             AND STEP_CODE = 'SIPI'
             and hi.step_status_code='03'
             and hi.BANK_GROUP_CODE=inv.bank_group_code
             and hi.cty_code=inv.cty_code
             and hi.cust_id=inv.cust_id
             AND substr(HI.DEAL_ID,1,11)          = substr(inv.DEAL_ID,1,11)
         GROUP BY substr(DEAL_ID,1,11))
AND substr(inv.deal_id,1,11)                                                   = substr(shist.deal_id,1,11)
AND inv.GOODS_IN_TYPE_CODE                                        = 'S'

AND inv.inventory_status_code                                    IN ('01', '02')
AND inv.inventory_type_code                                      IN ('MST','ROI','TRI','CRE')
AND (NVL(inv.NET_COMMODITY_QNTY, 0)                               - NVL(inv.utilised_qnty, 0)) > 0

AND shist.deal_step_id                                            IN
  (SELECT MAX(DEAL_STEP_ID)
  FROM SCBT_T_DEAL_HIST HI
  WHERE HI.BUSINESS_DATE <= TO_DATE(p_to_date, 'YYYY-MM-DD HH24:MI:SS')
  AND STEP_CODE           = 'SIPD'
  AND hi.step_status_code = '03'
  AND substr(HI.DEAL_ID,1,11)          = substr(inv.DEAL_ID,1,11)
   and hi.BANK_GROUP_CODE=inv.bank_group_code
             and hi.cty_code=inv.cty_code
             and hi.cust_id=inv.cust_id

  GROUP BY substr(DEAL_ID,1,11)
  )

AND SHIST.DEAL_STATUS_CODE NOT IN ('IRO','FRO','DCL','FER')
and shist.insurance_covered_by='SCB';*/


--- COMMENTED ON DECEMBER 05 2012 --------

/*SELECT DISTINCT inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id,
                inv.storage_location_id, inv.inventory_id,
                inv.link_inventory_id, inv.inventory_type_code,
                inv.inventory_status_code, inv.net_commodity_qnty_uom,
                (NVL (inv.net_commodity_qnty, 0) - NVL (inv.utilised_qnty, 0)
                ) AS qty,
                inv.repurchase_date, inv.first_collateral_date,
                inv.commodity_id, inv.deal_step_id
           FROM scbt_t_inventory_snapshot inv, scbt_t_sip_deal_smry_hst shist
          WHERE inv.bank_group_code = shist.bank_group_code
            AND inv.cty_code = shist.cty_code
            AND inv.cust_id = shist.cust_id
           AND SUBSTR (inv.deal_id, 1, 11) = SUBSTR (shist.deal_id, 1, 11)
          
                      AND inv.deal_step_id IN (
                   SELECT   MAX (deal_step_id)
                       FROM scbt_t_deal_hist hi
                      WHERE hi.BANK_GROUP_CODE = inv.BANK_GROUP_CODE
                      and hi.CTY_CODE = inv.CTY_CODE
                     
                      and hi.business_date <=
                               TO_DATE (p_to_date,
                                        'YYYY-MM-DD HH24:MI:SS'
                                       )
                        AND step_code = 'SIPI'
                        AND hi.step_status_code = '03'
                        AND SUBSTR (hi.deal_id, 1, 11) = SUBSTR (inv.deal_id, 1, 11)
                   GROUP BY SUBSTR (hi.deal_id, 1, 11))  
            AND inv.goods_in_type_code = 'S'
            AND inv.inventory_status_code IN ('01', '02')
            AND inv.inventory_type_code IN ('MST', 'ROI', 'TRI', 'CRE')
            AND (NVL (inv.net_commodity_qnty, 0) - NVL (inv.utilised_qnty, 0)
                ) > 0
            AND shist.deal_step_id IN (
                   SELECT   MAX (deal_step_id)
                       FROM scbt_t_deal_hist hi
                      WHERE  hi.business_date <=
                               TO_DATE (p_to_date,
                                        'YYYY-MM-DD HH24:MI:SS'
                                       )
                        AND step_code = 'SIPD'
                        AND hi.step_status_code = '03'
                        AND SUBSTR (hi.deal_id, 1, 11) = SUBSTR (inv.deal_id, 1, 11)
                   GROUP BY SUBSTR (deal_id, 1, 11)) 
            AND shist.deal_status_code  NOT IN ('IRO', 'FRO', 'DCL', 'FER') 
            AND shist.insurance_covered_by = 'SCB';*/

     -----------DEC 05 2012 COMMENT END ----  
     
 --- added new query DEC 05 2012 start ---  
 
 
   
     SELECT DISTINCT inv.bank_group_code, inv.cty_code, inv.cust_id, inv.deal_id,
                inv.storage_location_id, inv.inventory_id,
                inv.link_inventory_id, inv.inventory_type_code,
                inv.inventory_status_code, inv.net_commodity_qnty_uom,
                (NVL (inv.net_commodity_qnty, 0) - NVL (inv.utilised_qnty, 0)
                ) AS qty,
                inv.repurchase_date, inv.first_collateral_date,
                inv.commodity_id, inv.deal_step_id
           FROM scbt_t_inventory_snapshot inv, scbt_t_sip_deal_smry_hst shist
WHERE inv.bank_group_code = shist.bank_group_code
   AND inv.cty_code = shist.cty_code
   AND inv.cust_id = shist.cust_id
      
 
      
 
   AND SUBSTR(inv.deal_id, 1, 11) = SUBSTR(shist.deal_id, 1, 11)
   AND inv.goods_in_type_code = 'S'
      
   AND inv.inventory_status_code IN ('01', '02')
   AND inv.inventory_type_code IN ('MST', 'ROI', 'TRI', 'CRE')
   AND (NVL(inv.net_commodity_qnty, 0) - NVL(inv.utilised_qnty, 0)) > 0
   AND shist.deal_status_code NOT IN ('IRO', 'FRO', 'DCL', 'FER')
   AND inv.deal_step_id IN
       (SELECT MAX(hi.deal_step_id)
          FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv1
         WHERE hi.business_date <= TO_DATE(p_to_date, 'YYYY-MM-DD HH24:MI:SS')
              
           AND step_code = 'SIPI'
              
           AND hi.step_status_code = '03'
           AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv1.deal_id, 1, 11)
         GROUP BY SUBSTR(hi.deal_id, 1, 11))
   AND shist.deal_step_id IN
       (SELECT MAX(hi.deal_step_id)
          FROM scbt_t_deal_hist hi, scbt_t_inventory_snapshot inv2
         WHERE hi.business_date <= TO_DATE(p_to_date, 'YYYY-MM-DD HH24:MI:SS')
           AND step_code = 'SIPD'
              
           AND hi.step_status_code = '03'
           AND SUBSTR(hi.deal_id, 1, 11) = SUBSTR(inv2.deal_id, 1, 11)
         GROUP BY SUBSTR(hi.deal_id, 1, 11))
         
         AND shist.insurance_covered_by = 'SCB';
    
    --- added new query DEC 05 2012 end ---  
    
BEGIN


  DELETE FROM SCBT_T_INS_PRE_TMP TMP WHERE TMP.INS_SESSION_ID=p_INS_SESS_ID;
  
   BEGIN

    DELETE FROM SCBT_T_INS_PREM_CALC_TMP WHERE INS_SESSION_ID=p_INS_SESS_ID;

    COMMIT;

    EXCEPTION
       WHEN OTHERS THEN
            NULL;
    END;

    FOR i IN INS_DTL LOOP

      BEGIN

        --Derive Prem Start Date
        BEGIN
            IF ((i.first_collateral_date >=TO_DATE (p_from_date, 'YYYY-MM-DD HH24:MI:SS')) AND
                (i.first_collateral_date <= TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS'))) THEN
                 v_prem_start_date := i.first_collateral_date;
            ELSE
                 v_prem_start_date :=TO_DATE (p_from_date, 'YYYY-MM-DD HH24:MI:SS');
            END IF;

        EXCEPTION

             WHEN OTHERS THEN
                  v_prem_start_date:=NULL;
             END;

        BEGIN
        --Derive Prem End Date

       --  v_prem_end_date:=scbf_inv_max_repurchase_date (i.bank_group_code, i.cty_code, i.cust_id, i.inventory_id, i.deal_id, p_to_date, p_ins_sess_id,i.repurchase_date);
         

         IF (i.inventory_status_code in ('01','02')) THEN
             v_prem_end_date :=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
         END IF;

         IF (v_prem_end_date>TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS')) THEN
             v_prem_end_date:=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
         END IF;

         EXCEPTION
              WHEN OTHERS THEN
                   v_prem_end_date:=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS');
              END;
        -- number of days calculation
         IF (v_prem_end_date=TO_DATE (p_to_date, 'YYYY-MM-DD HH24:MI:SS')) then
             NO_OF_Days:=v_prem_end_date-v_prem_start_date+1;
         ELSE
             NO_OF_Days:=v_prem_end_date-v_prem_start_date;
         END IF;

         INSERT INTO SCBT_T_INS_PREM_CALC_TMP (BANK_GROUP_CODE, CTY_CODE, CUST_ID, DEAL_ID, INVENTORY_ID, LINK_INVENTORY_ID,
                                               PREM_END_DATE,  PREM_START_DATE, INS_PRE_TYPE,INS_SESSION_ID, STORAGE_LOCATION_ID,
                                               NET_COMMODITY_QNTY_UOM, QTY, FIRST_COLLATERAL_DATE,REPURCHASE_DATE,INVENTORY_TYPE_CODE,
                                               INVENTORY_STATUS_CODE, NO_OF_DAYS, TOTAL_DEAL_VALUE, WAREHOUSE, COMMODITY_ID)
                                       VALUES (i.bank_group_code,i.cty_code,i.cust_id,i.deal_id,i.inventory_id,i.link_inventory_id,
                                               v_prem_end_date,v_prem_start_date,null,p_ins_sess_id,i.storage_location_id,
                                               i.net_commodity_qnty_uom,i.QTY,i.first_collateral_date,i.repurchase_date,i.inventory_type_code,
                                               i.inventory_status_code,NO_OF_Days,
                                               scbf_inv_total_deal_value_NEW (i.bank_group_code, i.cty_code, i.cust_id, i.inventory_id, i.deal_id, p_to_date, p_from_date,i.qty,i.net_commodity_qnty_uom,i.deal_step_id),
                                               ' ',i.commodity_id);
         COMMIT;

         END;

   END LOOP;

END SCBP_INS_PRE_CALC_NEW;



-------------------------------------------------------------------------------------------------------------------------------

END SCBK_P_INS_PREM;
/
